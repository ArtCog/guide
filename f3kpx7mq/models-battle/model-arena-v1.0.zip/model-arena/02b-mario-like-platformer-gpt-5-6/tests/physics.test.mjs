import test from 'node:test';
import assert from 'node:assert/strict';
import { canOpenGate, collectSeed, createRunState, resolveEnemyHit, stepBody, tryJump } from '../physics.js';

test('courier can jump only from the ground', () => {
  const body = { x: 40, y: 100, w: 20, h: 28, vx: 0, vy: 0, grounded: true };
  assert.equal(tryJump(body), true);
  assert.ok(body.vy < 0);
  body.grounded = false;
  assert.equal(tryJump(body), false);
});

test('falling courier lands on a platform instead of passing through it', () => {
  const body = { x: 45, y: 70, w: 20, h: 28, vx: 0, vy: 230, grounded: false };
  stepBody(body, [{ x: 0, y: 120, w: 140, h: 20 }], 0.2);
  assert.equal(body.y, 92);
  assert.equal(body.vy, 0);
  assert.equal(body.grounded, true);
});

test('gate opens only after every unique glowseed is collected', () => {
  const run = createRunState(2);
  collectSeed(run, 'a');
  collectSeed(run, 'a');
  assert.equal(run.seeds.length, 1);
  assert.equal(canOpenGate(run), false);
  collectSeed(run, 'b');
  assert.equal(canOpenGate(run), true);
});

test('falling onto a threat defeats it but a side collision hurts the courier', () => {
  assert.equal(resolveEnemyHit({ x: 55, y: 70, w: 20, h: 28, vy: 140 }, { x: 54, y: 92, w: 26, h: 24 }), 'stomp');
  assert.equal(resolveEnemyHit({ x: 28, y: 92, w: 20, h: 28, vy: 0 }, { x: 45, y: 92, w: 26, h: 24 }), 'hurt');
});
