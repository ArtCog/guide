# Glowseed Run Implementation Plan

**Goal:** Build an original, local Canvas 2D platformer in Russian with a playable level, hazards, enemies, collectibles, defeat, restart, and victory.

**Design:** “Сад пыльцы” is a warm ochre world of stone terraces and bioluminescent seeds. The player guides a courier to collect five seeds and reach the observatory gate. No external assets, character names, music, or imagery are used.

**Files:**

- `physics.js` — deterministic collision, jumping, enemy defeat, and win rules.
- `tests/physics.test.mjs` — Node tests for these rules.
- `index.html`, `styles.css`, `game.js` — Canvas renderer, input, complete level, HUD, and screens.
- `REPORT.md` — delivery and verification record.

**Verification:** write and run failing physics tests first; then run syntax checks, full tests, static requirement checks, and a browser launch/playthrough attempt.
