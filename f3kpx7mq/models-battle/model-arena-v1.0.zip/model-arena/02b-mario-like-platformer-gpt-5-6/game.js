import { canOpenGate, collectSeed, createRunState, resolveEnemyHit, stepBody, tryJump } from './physics.js';

const canvas = document.querySelector('#gameCanvas');
const ctx = canvas.getContext('2d');
const seedCount = document.querySelector('#seedCount');
const goalText = document.querySelector('#goalText');
const attemptCount = document.querySelector('#attemptCount');
const message = document.querySelector('#message');
const intro = document.querySelector('#screen');
const endScreen = document.querySelector('#endScreen');
const endKicker = document.querySelector('#endKicker');
const endTitle = document.querySelector('#endTitle');
const endText = document.querySelector('#endText');
const soundButton = document.querySelector('#soundButton');

const WORLD = 3000;
const PLATFORMS = [
  {x:0,y:590,w:580,h:160},{x:680,y:590,w:520,h:160},{x:1330,y:560,w:620,h:190},{x:2070,y:590,w:930,h:160},
  {x:245,y:470,w:180,h:25},{x:420,y:385,w:145,h:25},{x:840,y:475,w:165,h:25},{x:1035,y:440,w:150,h:25},
  {x:1450,y:485,w:170,h:25},{x:1730,y:420,w:175,h:25},{x:2210,y:500,w:175,h:25},{x:2440,y:430,w:170,h:25}
];
const seedBlueprint = [
  {id:'a',x:330,y:420},{id:'b',x:500,y:335},{id:'c',x:920,y:425},{id:'d',x:1515,y:445},{id:'e',x:2295,y:460}
];
const hazards = [{x:1070,y:414,w:58,h:26},{x:1790,y:394,w:54,h:26},{x:2590,y:564,w:65,h:26}];
const gate = {x:2860,y:480,w:62,h:110};
const enemyBlueprint = [
  {x:455,y:566,min:330,max:550},{x:860,y:566,min:720,max:980},{x:1480,y:536,min:1360,max:1650},{x:2260,y:476,min:2120,max:2350},{x:2680,y:566,min:2510,max:2820}];
const keys = new Set();
let run, player, enemies, phase = 'intro', attempts = 1, last = performance.now(), camera = 0, audio, musicTimer, soundOn = true;

function resetRun() {
  run = createRunState(seedBlueprint.length);
  player = {x:76,y:552,w:28,h:38,vx:0,vy:0,grounded:true,face:1};
  enemies = enemyBlueprint.map((enemy,index)=>({...enemy,w:28,h:24,vx:index%2?55:-55,dead:false}));
  phase = 'playing'; camera = 0; endScreen.hidden = true;
  setMessage('Соберите пять светосемян и дойдите до обсерватории.'); syncHud();
}
function syncHud(){seedCount.textContent=`${run.seeds.length} / ${run.requiredSeeds}`;goalText.textContent=canOpenGate(run)?'ОБСЕРВАТОРИЯ ОТКРЫТА':'НАЙТИ СЕМЕНА';attemptCount.textContent=attempts}
function setMessage(text){message.textContent=text}
function rectsOverlap(a,b){return a.x+a.w>b.x&&a.x<b.x+b.w&&a.y+a.h>b.y&&a.y<b.y+b.h}
function startGame(){intro.hidden=true;attempts=1;resetRun();canvas.focus();startMusic()}
function restart(){attempts++;resetRun();canvas.focus();startMusic()}
function finish(won){phase=won?'won':'lost';endKicker.textContent=won?'САД СНОВА СВЕТИТСЯ':'СВЕТОСЕМЕНА ПОГАСЛИ';endTitle.textContent=won?'ЗАБЕГ ЗАВЕРШЁН':'ЗАБЕГ ПРЕРВАН';endText.textContent=won?'Вы открыли обсерваторию и вернули свет в сад.':'Курьер вернётся к началу тропы и попробует снова.';endScreen.hidden=false;beep(won?660:105,won?.24:.55,won?.07:.11)}
function update(dt){
  if(phase!=='playing')return;
  const direction=(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0);
  player.vx=direction*245;if(direction)player.face=direction;
  player.x=Math.max(0,Math.min(WORLD-player.w,player.x+player.vx*dt));
  stepBody(player,PLATFORMS,dt);
  if(player.y>760){finish(false);return}
  for(const seed of seedBlueprint){if(!run.seeds.includes(seed.id)&&Math.hypot(player.x+player.w/2-seed.x,player.y+player.h/2-seed.y)<32){collectSeed(run,seed.id);beep(580+run.seeds.length*70,.09,.06);setMessage(canOpenGate(run)?'Все светосемена собраны. Обсерватория справа открыта!':`Светосемя найдено: ${run.seeds.length} из ${run.requiredSeeds}.`);syncHud()}}
  for(const enemy of enemies){if(enemy.dead)continue;enemy.x+=enemy.vx*dt;if(enemy.x<enemy.min||enemy.x>enemy.max){enemy.vx*=-1;enemy.x=Math.max(enemy.min,Math.min(enemy.max,enemy.x))}const hit=resolveEnemyHit(player,enemy);if(hit==='stomp'){enemy.dead=true;player.vy=-270;beep(190,.08,.07);setMessage('Каменный жук обезврежен.');}else if(hit==='hurt'){finish(false);return}}
  for(const hazard of hazards){if(rectsOverlap(player,hazard)){finish(false);return}}
  if(rectsOverlap(player,gate)){if(canOpenGate(run))finish(true);else setMessage(`Ворота спят. Осталось семян: ${run.requiredSeeds-run.seeds.length}.`)}
  camera=Math.max(0,Math.min(WORLD-canvas.width,player.x-canvas.width*.34));
}
function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);drawSky();ctx.save();ctx.translate(-camera,0);drawWorld();ctx.restore();
}
function drawSky(){
  ctx.fillStyle='#77b7bd';ctx.fillRect(0,0,1280,720);ctx.fillStyle='#f4e8c8';ctx.beginPath();ctx.arc(978-camera*.08,126,58,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#5b8f82';for(let i=0;i<7;i++){const x=(i*270-camera*.18)%1500-130;ctx.beginPath();ctx.moveTo(x,590);ctx.lineTo(x+170,350);ctx.lineTo(x+330,590);ctx.fill()}
  ctx.fillStyle='#396e62';for(let i=0;i<8;i++){const x=(i*220-camera*.36)%1500-150;ctx.beginPath();ctx.moveTo(x,610);ctx.lineTo(x+120,425);ctx.lineTo(x+260,610);ctx.fill()}
}
function drawWorld(){
  ctx.fillStyle='#334d46';ctx.fillRect(0,590,WORLD,130);for(const platform of PLATFORMS)drawPlatform(platform);for(const hazard of hazards)drawSpikes(hazard);for(const seed of seedBlueprint)if(!run.seeds.includes(seed.id))drawSeed(seed);for(const enemy of enemies)if(!enemy.dead)drawBeetle(enemy);drawGate();drawPlayer();
  for(const gap of [{x:580,w:100},{x:1200,w:130},{x:1950,w:120}]){ctx.fillStyle='#7c3542';ctx.fillRect(gap.x,640,gap.w,80);ctx.fillStyle='#e86948';for(let x=gap.x;x<gap.x+gap.w;x+=22){ctx.beginPath();ctx.arc(x+10,650,10,Math.PI,0);ctx.fill()}}
}
function drawPlatform(p){ctx.fillStyle='#866349';ctx.fillRect(p.x,p.y,p.w,p.h);ctx.fillStyle='#d9a55e';ctx.fillRect(p.x,p.y,p.w,8);ctx.fillStyle='#5f4538';for(let x=p.x+15;x<p.x+p.w;x+=38)ctx.fillRect(x,p.y+18,5,5)}
function drawSpikes(h){ctx.fillStyle='#f4e8c8';for(let x=h.x;x<h.x+h.w;x+=14){ctx.beginPath();ctx.moveTo(x,h.y+h.h);ctx.lineTo(x+7,h.y);ctx.lineTo(x+14,h.y+h.h);ctx.fill()}}
function drawSeed(seed){const glow=7+Math.sin((performance.now()/160)+seed.x)*3;ctx.fillStyle='#ffcc4d';ctx.beginPath();ctx.arc(seed.x,seed.y,glow,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff4c8';ctx.beginPath();ctx.arc(seed.x-2,seed.y-2,3,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#3f7659';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(seed.x,seed.y+7);ctx.quadraticCurveTo(seed.x+9,seed.y+15,seed.x+6,seed.y+21);ctx.stroke()}
function drawBeetle(e){ctx.save();ctx.translate(e.x+14,e.y+12);ctx.scale(e.vx>0?1:-1,1);ctx.fillStyle='#554260';ctx.beginPath();ctx.ellipse(0,1,14,11,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#2c2734';ctx.fillRect(3,-9,10,13);ctx.fillStyle='#ffcc4d';ctx.fillRect(7,-5,3,3);ctx.fillStyle='#18232a';for(let i=-9;i<12;i+=7)ctx.fillRect(i,9,4,7);ctx.restore()}
function drawPlayer(){ctx.save();ctx.translate(player.x+14,player.y+19);ctx.scale(player.face,1);ctx.fillStyle='#e86948';ctx.fillRect(-10,-14,20,25);ctx.fillStyle='#f4e8c8';ctx.fillRect(-8,-25,16,14);ctx.fillStyle='#18232a';ctx.fillRect(2,-20,3,3);ctx.fillStyle='#3f7659';ctx.fillRect(-13,-13,5,20);ctx.fillStyle='#ffcc4d';ctx.fillRect(-13,-13,5,7);ctx.fillStyle='#18232a';ctx.fillRect(-13,11,10,6);ctx.fillRect(3,11,10,6);ctx.restore()}
function drawGate(){const opened=canOpenGate(run);ctx.fillStyle=opened?'#3f7659':'#554260';ctx.fillRect(gate.x,gate.y,gate.w,gate.h);ctx.fillStyle='#f4e8c8';ctx.fillRect(gate.x+8,gate.y+12,gate.w-16,gate.h-12);ctx.fillStyle=opened?'#ffcc4d':'#554260';ctx.beginPath();ctx.arc(gate.x+gate.w/2,gate.y+42,13,0,Math.PI*2);ctx.fill();ctx.fillStyle='#18232a';ctx.font='bold 10px Arial';ctx.fillText(opened?'ВХОД':'ЗАКРЫТО',gate.x+7,gate.y+85)}
function frame(now){const dt=Math.min(.035,(now-last)/1000);last=now;update(dt);draw();requestAnimationFrame(frame)}
function initAudio(){if(!audio){audio=new AudioContext()}if(audio.state==='suspended')audio.resume()}
function beep(freq,duration,volume){if(!soundOn)return;try{initAudio();const oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.type='triangle';oscillator.frequency.value=freq;gain.gain.setValueAtTime(volume,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);oscillator.connect(gain).connect(audio.destination);oscillator.start();oscillator.stop(audio.currentTime+duration)}catch{}}
function startMusic(){if(!soundOn||musicTimer)return;const notes=[294,370,440,370,330,440,494,440];let index=0;musicTimer=setInterval(()=>{if(phase==='playing')beep(notes[index++%notes.length],.12,.025)},520)}
function stopMusic(){clearInterval(musicTimer);musicTimer=null}
document.addEventListener('keydown',event=>{const key=event.key.toLowerCase();if(['a','d','arrowleft','arrowright','w','arrowup',' '].includes(key)){keys.add(key);event.preventDefault()}if((key==='w'||key==='arrowup'||key===' ')&&phase==='playing'){if(tryJump(player))beep(420,.08,.05)}});
document.addEventListener('keyup',event=>keys.delete(event.key.toLowerCase()));
document.querySelector('#startButton').addEventListener('click',startGame);document.querySelector('#restartButton').addEventListener('click',restart);soundButton.addEventListener('click',()=>{soundOn=!soundOn;soundButton.textContent=`ЗВУК: ${soundOn?'ВКЛ':'ВЫКЛ'}`;if(soundOn)startMusic();else stopMusic()});
resetRun();phase='intro';requestAnimationFrame(frame);
