const GRAVITY = 900;
const JUMP_SPEED = -390;

export function createRunState(requiredSeeds) {
  return { requiredSeeds, seeds: [], phase: 'playing' };
}

export function collectSeed(run, id) {
  if (run.phase !== 'playing' || run.seeds.includes(id)) return false;
  run.seeds.push(id);
  return true;
}

export function canOpenGate(run) {
  return run.seeds.length >= run.requiredSeeds;
}

export function tryJump(body) {
  if (!body.grounded) return false;
  body.vy = JUMP_SPEED;
  body.grounded = false;
  return true;
}

export function stepBody(body, platforms, dt) {
  const previousBottom = body.y + body.h;
  body.vy += GRAVITY * dt;
  body.y += body.vy * dt;
  body.grounded = false;
  for (const platform of platforms) {
    const horizontalOverlap = body.x + body.w > platform.x && body.x < platform.x + platform.w;
    const newBottom = body.y + body.h;
    if (horizontalOverlap && body.vy >= 0 && previousBottom <= platform.y && newBottom >= platform.y) {
      body.y = platform.y - body.h;
      body.vy = 0;
      body.grounded = true;
      break;
    }
  }
  return body;
}

export function resolveEnemyHit(player, enemy) {
  const horizontalOverlap = player.x + player.w > enemy.x && player.x < enemy.x + enemy.w;
  const verticalOverlap = player.y + player.h > enemy.y && player.y < enemy.y + enemy.h;
  if (!horizontalOverlap || !verticalOverlap) return 'none';
  return player.vy > 80 && player.y + player.h <= enemy.y + 12 ? 'stomp' : 'hurt';
}
