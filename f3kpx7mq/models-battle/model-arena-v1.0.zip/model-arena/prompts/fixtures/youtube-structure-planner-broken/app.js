const STORAGE_KEY = 'youtube-structure-planner-v1';

const initialState = {
  targetMinutes: 10,
  filter: 'all',
  selectedSectionId: 'early-cta',
  promise: 'Я покажу, какая модель лучше для реальных задач: по качеству результата, скорости и стоимости.',
  criteria: [
    { id: 'quality', label: 'качество' },
    { id: 'speed', label: 'скорость' },
    { id: 'cost', label: 'стоимость' }
  ],
  sections: [
    {
      id: 'early-cta',
      kind: 'cta',
      duration: '0:20',
      title: 'Сразу просим подписаться в Telegram',
      text: 'Прежде чем начнем тесты, подпишитесь на Telegram: там будут все промпты, данные и результаты.',
      ready: false,
      proof: false,
      payoff: false,
      cta: true,
      risk: true,
      covers: []
    },
    {
      id: 'hook',
      kind: 'хук',
      duration: '0:35',
      title: 'Сразу показываем арену и обещаем честное сравнение',
      text: 'На экране уже видна арена: три модели, одинаковые задания, стоимость, токены и итоговая таблица. Ставка ролика: самая дорогая модель не обязательно победит.',
      ready: true,
      proof: false,
      payoff: false,
      cta: false,
      risk: false,
      covers: ['quality']
    },
    {
      id: 'rules',
      kind: 'правила',
      duration: '0:45',
      title: 'Коротко объясняем правила теста',
      text: 'Один промпт, один прогон, без ручных правок. Метрики фиксируются: время задачи, токены, стоимость, балл.',
      ready: true,
      proof: false,
      payoff: false,
      cta: false,
      risk: true,
      covers: []
    },
    {
      id: 'test-1',
      kind: 'тест',
      duration: '1:10',
      title: 'Тест 1: магазин редких камней',
      text: 'Показываем три многостраничных сайта, корзину, визуал, навигацию и первое сравнение цены/качества.',
      ready: true,
      proof: true,
      payoff: true,
      cta: false,
      risk: false,
      covers: ['quality', 'cost']
    },
    {
      id: 'test-2',
      kind: 'тест',
      duration: '1:25',
      title: 'Тест 2: хоррор-игра от первого лица',
      text: 'Проверяем управление, фонарик, демона, победу и поражение. Отдельно показываем, где модель сделала черный экран.',
      ready: true,
      proof: true,
      payoff: true,
      cta: false,
      risk: true,
      covers: ['quality']
    },
    {
      id: 'test-3',
      kind: 'тест',
      duration: '1:25',
      title: 'Тест 3: 3D-сцена Последний рай',
      text: 'Проверяем фантазию, 3D, атмосферу и способность создать вау-эффект без длинной доработки.',
      ready: false,
      proof: true,
      payoff: true,
      cta: false,
      risk: false,
      covers: ['quality']
    },
    {
      id: 'test-4',
      kind: 'тест',
      duration: '1:35',
      title: 'Тест 4: анализатор удержания YouTube',
      text: 'Модели получают ZIP с CSV из YouTube Studio и строят инструмент анализа удержания. Сравниваем подходы и честность работы.',
      ready: false,
      proof: true,
      payoff: true,
      cta: false,
      risk: false,
      covers: ['quality', 'speed', 'cost']
    },
    {
      id: 'test-5',
      kind: 'тест',
      duration: '1:30',
      title: 'Тест 5: ремонт сломанного YouTube-планировщика',
      text: 'Финальный тест: модели должны чинить не только код, но и логику продукта, которая оценивает структуру ролика.',
      ready: false,
      proof: true,
      payoff: true,
      cta: false,
      risk: false,
      covers: ['quality']
    },
    {
      id: 'final-table',
      kind: 'финал',
      duration: '1:05',
      title: 'Итоговая таблица',
      text: 'Показываем баллы, стоимость, токены и время. Делаем вывод, кому какая модель подходит.',
      ready: false,
      proof: true,
      payoff: true,
      cta: false,
      risk: false,
      covers: ['quality', 'speed', 'cost']
    },
    {
      id: 'final-cta',
      kind: 'финал',
      duration: '0:30',
      title: 'Финальный CTA и вывод',
      text: 'Коротко повторяем главный вывод, отправляем в Telegram за промптами и файлами, просим написать следующий тест в комментариях.',
      ready: false,
      proof: false,
      payoff: false,
      cta: true,
      risk: false,
      covers: []
    }
  ]
};

let state = loadState();

const promiseText = document.querySelector('#promiseText');
const criteriaList = document.querySelector('#criteriaList');
const scriptList = document.querySelector('#scriptList');
const filterSelect = document.querySelector('#filterSelect');
const targetMinutes = document.querySelector('#targetMinutes');
const totalDuration = document.querySelector('#totalDuration');
const readyPercent = document.querySelector('#readyPercent');
const promiseStatus = document.querySelector('#promiseStatus');
const sectionCount = document.querySelector('#sectionCount');
const analysisOutput = document.querySelector('#analysisOutput');
const lastCheck = document.querySelector('#lastCheck');
const selectedBlockLabel = document.querySelector('#selectedBlockLabel');
const editTitle = document.querySelector('#editTitle');
const editKind = document.querySelector('#editKind');
const editDuration = document.querySelector('#editDuration');
const editText = document.querySelector('#editText');
const editReady = document.querySelector('#editReady');
const editProof = document.querySelector('#editProof');
const editPayoff = document.querySelector('#editPayoff');
const editCta = document.querySelector('#editCta');
const editRisk = document.querySelector('#editRisk');
const editCriteria = document.querySelector('#editCriteria');

document.querySelector('#analyzeBtn').addEventListener('click', () => {
  renderAnalysis();
  lastCheck.textContent = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
});

document.querySelector('#saveBtn').addEventListener('click', () => {
  saveState();
  renderAnalysis([{ type: 'good', title: 'Сохранено', text: 'Текущее состояние записано в браузер.' }]);
});

document.querySelector('#resetBtn').addEventListener('click', () => {
  localStorage.removeItem(STORAGE_KEY);
  state = structuredClone(initialState);
  render();
  renderAnalysis([{ type: 'warn', title: 'Сброшено', text: 'Загружена исходная сценарная карта.' }]);
});

document.querySelector('#applyEditBtn').addEventListener('click', () => {
  const section = getSelectedSection();
  if (!section) return;

  section.title = editTitle.value.trim() || section.title;
  section.kind = editKind.value;
  section.duration = editDuration.value.trim() || section.duration;
  section.text = editText.value.trim() || section.text;
  section.ready = editReady.checked;
  section.proof = editProof.checked;
  section.payoff = editPayoff.checked;
  section.cta = editCta.checked;
  section.risk = editRisk.checked;
  section.covers = Array.from(editCriteria.querySelectorAll('input:checked')).map((input) => input.value);

  render();
  renderAnalysis([{ type: 'good', title: 'Блок обновлен', text: `Изменения применены к блоку "${section.title}".` }]);
});

document.querySelector('#addBlockBtn').addEventListener('click', () => {
  const currentIndex = state.sections.findIndex((section) => section.id === state.selectedSectionId);
  const insertAt = currentIndex >= 0 ? currentIndex + 1 : state.sections.length;
  const newSection = {
    id: `custom-${Date.now()}`,
    kind: 'тест',
    duration: '0:30',
    title: 'Новый блок структуры',
    text: 'Опиши, какую задачу решает этот блок и какой результат получает зритель.',
    ready: false,
    proof: false,
    payoff: false,
    cta: false,
    risk: false,
    covers: []
  };

  state.sections.splice(insertAt, 0, newSection);
  state.selectedSectionId = newSection.id;
  render();
  renderAnalysis([{ type: 'good', title: 'Блок добавлен', text: 'Новый блок появился после выбранного элемента.' }]);
});

document.querySelector('#deleteBlockBtn').addEventListener('click', () => {
  if (state.sections.length <= 1) return;
  const index = state.sections.findIndex((section) => section.id === state.selectedSectionId);
  if (index < 0) return;

  const removed = state.sections[index];
  state.sections.splice(index, 1);
  state.selectedSectionId = state.sections[Math.max(0, index - 1)].id;
  render();
  renderAnalysis([{ type: 'warn', title: 'Блок удален', text: `Удален блок "${removed.title}".` }]);
});

filterSelect.addEventListener('change', (event) => {
  state.filter = event.target.value;
  renderSections();
});

targetMinutes.addEventListener('input', (event) => {
  state.targetMinutes = Number(event.target.value);
  renderSummary();
});

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return structuredClone(initialState);
  }

  try {
    const saved = JSON.parse(raw);
    return {
      ...structuredClone(initialState),
      targetMinutes: saved.targetMinutes || initialState.targetMinutes,
      filter: saved.filter || 'all',
      selectedSectionId: saved.selectedSectionId || initialState.selectedSectionId,
      sections: saved.items || initialState.sections
    };
  } catch {
    return structuredClone(initialState);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    targetMinutes: state.targetMinutes,
    filter: state.filter,
    selectedSectionId: state.selectedSectionId,
    sections: state.sections
  }));
}

function render() {
  promiseText.textContent = state.promise;
  criteriaList.innerHTML = state.criteria.map((criterion) => `<span>${criterion.label}</span>`).join('');
  filterSelect.value = state.filter;
  targetMinutes.value = state.targetMinutes;
  renderSummary();
  renderSections();
  renderEditor();
  renderAnalysis();
}

function renderSummary() {
  const total = state.sections.reduce((sum, section) => sum + parseDuration(section.duration), 0);
  const ready = state.sections.filter((section) => section.ready).length;
  const readyValue = Math.round((ready / state.sections.length) * 100);

  totalDuration.textContent = formatDuration(total);
  readyPercent.textContent = `${readyValue}%`;
  sectionCount.textContent = state.sections.length;
  promiseStatus.textContent = promiseLooksClosed() ? 'выполнено' : 'под вопросом';
  promiseStatus.className = promiseLooksClosed() ? 'ok' : 'warn';
}

function renderSections() {
  const filtered = state.sections.filter((section) => {
    if (state.filter === 'ready') return !section.ready;
    if (state.filter === 'problem') return section.ready;
    if (state.filter === 'proof') return section.proof;
    if (state.filter === 'cta') return section.cta;
    return true;
  });

  scriptList.innerHTML = filtered.map((section, index) => {
    const tags = buildTags(section);
    const isSelected = section.id === state.selectedSectionId;

    return `
      <details class="script-card ${isSelected ? 'selected' : ''}" ${isSelected ? 'open' : ''}>
        <summary data-id="${section.id}">
          <span class="card-number">${String(index + 1).padStart(2, '0')}</span>
          <span class="card-time">${section.duration}</span>
          <span class="card-title">
            <strong>${escapeHtml(section.title)}</strong>
            <small>${section.kind}</small>
          </span>
          <span class="status-dot ${section.ready ? 'ready' : ''}" title="${section.ready ? 'готово' : 'не готово'}"></span>
        </summary>
        <div class="card-body">
          <p>${escapeHtml(section.text)}</p>
          <div class="tags">${tags}</div>
          <div class="card-actions">
            <button class="edit-button" type="button" data-action="select" data-id="${section.id}">Редактировать</button>
            <label class="ready-toggle">
              <input type="checkbox" ${section.ready ? 'checked' : ''} data-action="toggle-ready" data-id="${section.id}">
              готово
            </label>
            <div class="move-row">
              <button class="secondary" type="button" data-action="move-up" data-id="${section.id}">Выше</button>
              <button class="secondary" type="button" data-action="move-down" data-id="${section.id}">Ниже</button>
            </div>
          </div>
        </div>
      </details>
    `;
  }).join('');
}

function buildTags(section) {
  const tags = [];
  if (section.proof) tags.push('доказательство');
  if (section.payoff) tags.push('payoff');
  if (section.cta) tags.push('CTA');
  if (section.risk) tags.push('риск');
  section.covers.forEach((tag) => tags.push(labelForCriterion(tag)));
  return tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join('');
}

scriptList.addEventListener('click', (event) => {
  const summary = event.target.closest('summary');
  if (summary) {
    state.selectedSectionId = summary.dataset.id;
    renderEditor();
    renderSections();
    return;
  }

  const button = event.target.closest('button');
  if (!button) return;

  const id = button.dataset.id;
  const index = state.sections.findIndex((section) => section.id === id);
  if (index < 0) return;

  if (button.dataset.action === 'select') {
    state.selectedSectionId = id;
    renderSections();
    renderEditor();
    return;
  }

  if (button.dataset.action === 'move-up' && index > 0) {
    const current = state.sections[index];
    state.sections[index] = state.sections[index - 1];
    state.sections[index - 1] = current;
  }

  if (button.dataset.action === 'move-down' && index < state.sections.length - 1) {
    const current = state.sections[index];
    state.sections[index] = state.sections[index + 1];
    state.sections[index + 1] = current;
  }

  renderSummary();
  renderSections();
  renderEditor();
});

scriptList.addEventListener('change', (event) => {
  if (event.target.dataset.action !== 'toggle-ready') return;
  const section = state.sections.find((item) => item.id === event.target.dataset.id);
  if (!section) return;
  section.ready = event.target.checked;
  renderSummary();
  renderEditor();
});

function renderEditor() {
  const section = getSelectedSection() || state.sections[0];
  if (!section) return;

  state.selectedSectionId = section.id;
  selectedBlockLabel.textContent = section.title;
  editTitle.value = section.title;
  editKind.value = section.kind;
  editDuration.value = section.duration;
  editText.value = section.text;
  editReady.checked = section.ready;
  editProof.checked = section.proof;
  editPayoff.checked = section.payoff;
  editCta.checked = section.cta;
  editRisk.checked = section.risk;
  editCriteria.innerHTML = state.criteria.map((criterion) => `
    <label>
      <input type="checkbox" value="${criterion.id}" ${section.covers.includes(criterion.id) ? 'checked' : ''}>
      ${criterion.label}
    </label>
  `).join('');
}

function renderAnalysis(customFindings) {
  const findings = customFindings || analyzeStructure();
  analysisOutput.innerHTML = findings.map((finding) => `
    <div class="finding ${finding.type}">
      <strong>${finding.title}</strong>
      <p>${finding.text}</p>
    </div>
  `).join('');
  renderSummary();
}

function analyzeStructure() {
  const findings = [];
  const total = state.sections.reduce((sum, section) => sum + parseDuration(section.duration), 0);

  findings.push({
    type: ctaLooksFine() ? 'good' : 'warn',
    title: ctaLooksFine() ? 'CTA расположен нормально' : 'CTA стоит слишком рано',
    text: ctaLooksFine() ? 'Призыв есть в сценарии ролика.' : 'Сначала нужна видимая ценность.'
  });

  findings.push({
    type: promiseLooksClosed() ? 'good' : 'bad',
    title: promiseLooksClosed() ? 'Обещание выполнено' : 'Обещание под вопросом',
    text: promiseLooksClosed() ? 'В структуре найден блок с решением.' : 'Нужно проверить, доводит ли структура зрителя до решения.'
  });

  if (total > state.targetMinutes * 60) {
    findings.push({
      type: 'warn',
      title: 'Ролик длиннее цели',
      text: `Можно сократить: ${suggestCuts().join(', ')}.`
    });
  } else {
    findings.push({
      type: 'good',
      title: 'Длительность в лимите',
      text: `Текущая оценка: ${formatDuration(total)}.`
    });
  }

  return findings;
}

function parseDuration(value) {
  const [minutes, seconds] = value.split(':').map(Number);
  return minutes * 100 + seconds;
}

function formatDuration(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}м ${String(seconds).padStart(2, '0')}с`;
}

function ctaLooksFine() {
  return state.sections.some((section) => section.cta);
}

function promiseLooksClosed() {
  return state.sections.some((section) => section.kind === 'финал');
}

function suggestCuts() {
  return state.sections
    .filter((section) => section.proof || section.payoff)
    .sort((a, b) => parseDuration(b.duration) - parseDuration(a.duration))
    .slice(0, 3)
    .map((section) => section.title);
}

function labelForCriterion(id) {
  return state.criteria.find((criterion) => criterion.id === id)?.label || id;
}

function getSelectedSection() {
  return state.sections.find((section) => section.id === state.selectedSectionId);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

render();
