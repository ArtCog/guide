# RUN-METRICS — тест 03 «Последний рай»

| Поле | Значение |
|---|---|
| Модель | Claude Fable 5 (`claude-fable-5`), Claude Code |
| Тест | 03 — интерактивная 3D-сцена «Последний рай» |
| Время задачи | 33m 56s |
| Input tokens | 21.3k |
| Output tokens | 82.2k |
| Cache read | 4.3m |
| Cache write | 201.5k |
| Стоимость USD | $12.67 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\03-posledniy-ray-3d-fable-5\index.html` |

**Источник метрик:** скрин вкладки `Usage` Claude Code после выполнения теста.
`33m 56s` — время выполнения именно третьего задания.

**Разбивка стоимости по скрину:** `claude-fable-5` — $44.92; `claude-haiku-4-5` —
$0.0078. Общая стоимость сессии на экране: $44.93.

## Вердикт

Реальный работающий 3D-прототип (Three.js r160, WebGL, UnrealBloom), проверенный
в настоящем браузерном рендере: headless Chrome открывал файл с диска и снимал
скриншоты 1920×1080 — все 4 приложены в `assets/`, консоль без критических ошибок.
Hero-кадр читается сразу: светлый город-сад с маяком сверху, раскалённые разломы
мёртвой планеты снизу, острова-мосты обрамляют композицию. Четыре режима реально
перестраивают сцену (камера, свет, туман, bloom, частицы, подсветки), а не меняют
подписи. Визуальная часть прошла 2 итерации по скриншотам (композиция hero-кадра,
круглые маски частиц, пересвет окон в «Спасшихся», читаемость «Катастрофы»).

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $44.93 / 49.8k input / 243.4k output / 13.0m cache read / 962.4k cache write.
- Previous checkpoint: $32.26 / 32.5k input / 161.2k output / 8.7m cache read / 760.9k cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
