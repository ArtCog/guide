import test from 'node:test';
import assert from 'node:assert/strict';
import CartCore from '../assets/cart-core.js';

const { addLine, changeQuantity, removeLine, summarize } = CartCore;

const catalogue = [{ id: 'luna', price: 18400 }, { id: 'europa', price: 22100 }];

test('repeated additions increase one request line', () => {
  let cart = addLine([], 'luna', catalogue);
  cart = addLine(cart, 'luna', catalogue);
  assert.deepEqual(cart, [{ id: 'luna', quantity: 2 }]);
  assert.deepEqual(summarize(cart, catalogue), { itemCount: 2, total: 36800 });
});

test('quantity changes recalculate the grand total', () => {
  const cart = changeQuantity([{ id: 'europa', quantity: 1 }], 'europa', 3);
  assert.deepEqual(summarize(cart, catalogue), { itemCount: 3, total: 66300 });
});

test('zero quantity and explicit removal remove the request line', () => {
  assert.deepEqual(changeQuantity([{ id: 'luna', quantity: 1 }], 'luna', 0), []);
  assert.deepEqual(removeLine([{ id: 'luna', quantity: 1 }, { id: 'europa', quantity: 1 }], 'luna'), [{ id: 'europa', quantity: 1 }]);
});
