(function () {
  'use strict';

  const catalogue = [
    {id:'luna',code:'LUN-071',name:'Осколок Лунного моря',origin:'Луна',type:'тёмный каменный фрагмент',price:18400,group:'inner',visual:'luna',description:'Пористый камень с мягким серым блеском, похожий на часть древнего лунного ландшафта.'},
    {id:'mars',code:'MAR-114',name:'Гранат Долины Маринер',origin:'Марс',type:'красный гранат',price:12900,group:'inner',visual:'mars',description:'Глубокий красный камень с сухим марсианским оттенком.'},
    {id:'europa',code:'EUR-018',name:'Ледяной опал Европы',origin:'Европа · спутник Юпитера',type:'светлый опал',price:22100,group:'satellites',visual:'europa',description:'Полупрозрачный камень с холодным голубым свечением.'},
    {id:'titan',code:'TIT-093',name:'Янтарное ядро Титана',origin:'Титан · спутник Сатурна',type:'янтарный минерал',price:17600,group:'satellites',visual:'titan',description:'Тёплый медовый камень, будто сохранённый в густой атмосфере Титана.'},
    {id:'ceres',code:'CER-052',name:'Соляной кристалл Цереры',origin:'Церера',type:'светлый кристалл',price:9400,group:'inner',visual:'ceres',description:'Сухой светлый кристалл с тонкими белыми прожилками.'},
    {id:'psyche',code:'PSY-044',name:'Железное сердце Психеи',origin:'Психея',type:'металлический фрагмент',price:26500,group:'asteroid',visual:'psyche',description:'Тяжёлый блестящий образец с никелево-железным оттенком.'},
    {id:'io',code:'IO-067',name:'Серная призма Ио',origin:'Ио · спутник Юпитера',type:'жёлто-оранжевый кристалл',price:11300,group:'satellites',visual:'io',description:'Яркий камень с вулканическим характером.'},
    {id:'enceladus',code:'ENC-028',name:'Жемчужина Энцелада',origin:'Энцелад · спутник Сатурна',type:'перламутровая сфера',price:19800,group:'satellites',visual:'enceladus',description:'Холодный жемчужный образец, вдохновлённый ледяными гейзерами.'}
  ];
  const money = new Intl.NumberFormat('ru-RU', { style:'currency', currency:'USD', maximumFractionDigits:0 });
  const storageKey = 'orbit-vault-sol-request';
  const page = document.body.dataset.page || 'home';
  let cart = loadCart();

  function loadCart() {
    try { return JSON.parse(localStorage.getItem(storageKey)) || []; } catch { return []; }
  }
  function saveCart() { localStorage.setItem(storageKey, JSON.stringify(cart)); }
  function productCard(item) {
    return `<article class="product-card" data-group="${item.group}"><div class="product-visual ${item.visual}" aria-hidden="true"></div><div class="product-copy"><p class="product-code">${item.code} · ${item.origin.toUpperCase()}</p><h2>${item.name}</h2><p class="product-type">${item.type}</p><p class="product-description">${item.description}</p><div class="product-footer"><strong class="price">${money.format(item.price)}</strong><button type="button" class="add-item" data-add="${item.id}">ДОБАВИТЬ +</button></div></div></article>`;
  }
  function renderChrome() {
    const links = [['index.html','Главная','home'],['catalog.html','Каталог','catalog'],['provenance.html','Подлинность','provenance'],['collections.html','Коллекции','collections'],['contacts.html','Контакты','contacts']];
    document.body.insertAdjacentHTML('afterbegin', `<header class="site-header"><nav class="nav"><a class="brand" href="index.html"><span class="brand-mark">⊙</span><span>СОКРОВИЩНИЦА ОРБИТ</span></a><div class="nav-links">${links.map(([href,label,id])=>`<a class="${page===id?'active':''}" href="${href}">${label}</a>`).join('')}</div><button type="button" class="request-toggle open-request">ЗАЯВКА <span class="request-count">0</span></button></nav></header>`);
    document.body.insertAdjacentHTML('beforeend', `<aside class="request-drawer" aria-label="Заявка на частную покупку"><div class="drawer-head"><h2>Частная заявка</h2><button type="button" class="drawer-close" aria-label="Закрыть">×</button></div><div class="request-lines"></div><form class="drawer-footer" id="requestForm"><div class="drawer-total"><span>ИТОГО</span><strong>${money.format(0)}</strong></div><label>ПОЧТА ДЛЯ ОТВЕТА<input type="email" name="email" placeholder="name@example.ru" required></label><button class="primary" type="submit">ЗАПРОСИТЬ ПОКУПКУ</button></form></aside><div class="toast" role="status"></div>`);
  }
  function renderCatalogue(filter='all') {
    const root = document.querySelector('#catalogue');
    if (!root) return;
    root.innerHTML = catalogue.filter(item => filter === 'all' || item.group === filter).map(productCard).join('');
  }
  function renderSpotlight() {
    const root = document.querySelector('#spotlight');
    if (root) root.innerHTML = [catalogue[2], catalogue[5], catalogue[6]].map(productCard).join('');
  }
  function renderCart() {
    const root = document.querySelector('.request-lines');
    const totals = CartCore.summarize(cart, catalogue);
    document.querySelectorAll('.request-count').forEach(node => node.textContent = totals.itemCount);
    document.querySelector('.drawer-total strong').textContent = money.format(totals.total);
    if (!cart.length) {
      root.innerHTML = '<p class="empty">Заявка пуста. Откройте каталог и добавьте один или несколько образцов.</p>';
      return;
    }
    root.innerHTML = cart.map(line => {
      const item = catalogue.find(candidate => candidate.id === line.id);
      return `<article class="request-line"><div><h3>${item.name}</h3><p>${item.origin} · ${money.format(item.price)}</p><div class="quantity"><button type="button" data-qty="${item.id}" data-delta="-1">−</button><strong>${line.quantity}</strong><button type="button" data-qty="${item.id}" data-delta="1">+</button></div></div><div class="line-price"><strong>${money.format(item.price*line.quantity)}</strong><button type="button" class="remove-line" data-remove="${item.id}">УДАЛИТЬ</button></div></article>`;
    }).join('');
  }
  function openDrawer() { document.querySelector('.request-drawer').classList.add('open'); }
  function closeDrawer() { document.querySelector('.request-drawer').classList.remove('open'); }
  function notify(text) {
    const toast = document.querySelector('.toast');
    toast.textContent = text; toast.classList.add('show');
    clearTimeout(window.solToast); window.solToast = setTimeout(() => toast.classList.remove('show'), 2500);
  }
  function bindEvents() {
    document.addEventListener('click', event => {
      const add = event.target.closest('[data-add]');
      if (add) { cart = CartCore.addLine(cart, add.dataset.add, catalogue); saveCart(); renderCart(); notify('Образец добавлен. Итог заявки пересчитан.'); openDrawer(); return; }
      const qty = event.target.closest('[data-qty]');
      if (qty) { const line = cart.find(item => item.id === qty.dataset.qty); cart = CartCore.changeQuantity(cart, qty.dataset.qty, line.quantity + Number(qty.dataset.delta)); saveCart(); renderCart(); return; }
      const remove = event.target.closest('[data-remove]');
      if (remove) { cart = CartCore.removeLine(cart, remove.dataset.remove); saveCart(); renderCart(); notify('Образец удалён из заявки.'); return; }
      if (event.target.closest('.open-request')) { openDrawer(); return; }
      if (event.target.closest('.drawer-close')) { closeDrawer(); return; }
      const filter = event.target.closest('[data-filter]');
      if (filter) { document.querySelectorAll('[data-filter]').forEach(button => button.classList.toggle('active', button === filter)); renderCatalogue(filter.dataset.filter); }
    });
    document.querySelector('#requestForm').addEventListener('submit', event => {
      event.preventDefault();
      if (!cart.length) { notify('Сначала добавьте образец в заявку.'); return; }
      notify('Заявка подготовлена. Куратор ответит на указанную почту.');
      closeDrawer();
    });
  }

  renderChrome(); renderSpotlight(); renderCatalogue(); renderCart(); bindEvents();
})();
