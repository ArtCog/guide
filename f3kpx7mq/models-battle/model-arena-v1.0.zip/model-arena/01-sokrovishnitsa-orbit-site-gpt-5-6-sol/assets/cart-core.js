function addLine(cart, id, catalogue) {
  if (!catalogue.some((item) => item.id === id)) return cart;
  return cart.some((line) => line.id === id)
    ? cart.map((line) => line.id === id ? { ...line, quantity: line.quantity + 1 } : line)
    : [...cart, { id, quantity: 1 }];
}

function changeQuantity(cart, id, quantity) {
  const next = Math.max(0, Math.floor(Number(quantity) || 0));
  if (!next) return removeLine(cart, id);
  return cart.map((line) => line.id === id ? { ...line, quantity: next } : line);
}

function removeLine(cart, id) {
  return cart.filter((line) => line.id !== id);
}

function summarize(cart, catalogue) {
  return cart.reduce((summary, line) => {
    const item = catalogue.find((candidate) => candidate.id === line.id);
    if (!item) return summary;
    summary.itemCount += line.quantity;
    summary.total += item.price * line.quantity;
    return summary;
  }, { itemCount: 0, total: 0 });
}

const CartCore = { addLine, changeQuantity, removeLine, summarize };
if (typeof window !== 'undefined') window.CartCore = CartCore;
if (typeof module !== 'undefined' && module.exports) module.exports = CartCore;
