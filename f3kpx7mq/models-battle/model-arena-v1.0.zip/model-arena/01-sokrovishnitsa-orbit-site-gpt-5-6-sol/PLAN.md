# GPT-5.6 Sol Orbit Vault Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** Build an independent second implementation of test 01 for comparison with the existing Terra result.

**Architecture:** Five static Russian HTML pages share one archival design system and one ES-module storefront. Catalogue data is canonical; a pure tested cart core persists quantities through localStorage and drives a real request drawer on every page.

**Tech Stack:** HTML, CSS, vanilla JavaScript ES modules, Node built-in test runner; no remote dependencies.

## Global Constraints

- Output only under `01-sokrovishnitsa-orbit-site-gpt-5-6-sol`.
- Preserve the original eight products and prices.
- Pages: home, catalogue, provenance, private collections, contacts.
- The cart must add, change quantity, remove, calculate line totals and grand total.
- All visible copy is Russian; the visual is scientific luxury, not fantasy.

## Tasks

- [ ] Write failing tests for cart totals and duplicate additions; run RED; implement `assets/cart-core.js`; run GREEN.
- [ ] Create five linked pages, shared catalogue data, responsive styles, request drawer, and visible feedback states.
- [ ] Add README and run metrics; register Sol next to Terra in the arena.
- [ ] Verify syntax, tests, all eight catalogue entries, HTTP routes, and the complete cart path.
