# Metrics Delta Audit

Updated: 2026-07-04.

Rule: Claude Code `Usage` values were cumulative. For tests 02-05, cost and token counts are calculated as the delta between the checkpoint after the current test and the checkpoint after the previous test. Test 01 uses zero as the baseline. Sonnet 5 test 05 uses the standalone screenshot showing a clean session at $5.62.

Token columns below include the visible helper Haiku calls where screenshots/reports exposed them. Cost columns are total USD cost deltas.

| Test | Model | Test cost | Input | Output | Fresh total | Cache read | Cache write | Method |
|---|---|---:|---:|---:|---:|---:|---:|---|
| 01 | Fable 5 | $14.75 | 15.8k | 63.1k | 78.9k | 2.1m | 464.9k | first checkpoint |
| 01 | Opus 4.8 | $9.30 | 16.9k | 68.0k | 84.9k | 3.5m | 574.4k | first checkpoint |
| 01 | Sonnet 5 | $4.20 | 16.7k | 83.1k | 99.8k | 2.6m | 352.7k | first checkpoint |
| 02 | Fable 5 | $17.51 | 20.0k | 98.2k | 118.2k | 6.6m | 296.0k | $32.26 - $14.75, plus helper tokens |
| 02 | Opus 4.8 | $5.92 | 20.4k | 66.3k | 86.7k | 3.3m | 255.1k | $15.22 - $9.30, plus helper tokens |
| 02 | Sonnet 5 | $5.15 | 21.5k | 81.9k | 103.4k | 6.7m | 311.4k | $9.35 - $4.20, plus helper tokens |
| 03 | Fable 5 | $12.67 | 21.3k | 82.2k | 103.5k | 4.3m | 201.5k | $44.93 - $32.26, plus helper tokens |
| 03 | Opus 4.8 | $8.74 | 22.9k | 107.9k | 130.8k | 7.1m | 270.5k | $23.96 - $15.22, plus helper tokens |
| 03 | Sonnet 5 | $12.26 | 27.5k | 159.9k | 187.4k | 23.5m | 435.9k | $21.61 - $9.35, plus helper tokens |
| 04 | Fable 5 | $13.49 | 18.4k | 91.7k | 110.1k | 4.2m | 237.6k | $58.42 - $44.93, plus helper tokens |
| 04 | Opus 4.8 | $5.51 | 18.8k | 75.1k | 93.9k | 2.9m | 200.0k | $29.47 - $23.96, plus helper tokens |
| 04 | Sonnet 5 | $11.23 | 20.8k | 143.8k | 164.6k | 17.3m | 700.0k | $32.84 - $21.61, plus helper tokens |
| 05 | Fable 5 | $6.96 | 17.3k | 42.4k | 59.7k | 2.3m | 100.0k | $65.38 - $58.42, plus helper tokens |
| 05 | Opus 4.8 | $6.55 | 17.9k | 51.4k | 69.3k | 2.4m | 400.0k | $36.02 - $29.47, plus helper tokens |
| 05 | Sonnet 5 | $5.62 | 19.6k | 55.7k | 75.3k | 4.9m | 542.4k | standalone session, includes helper tokens |
