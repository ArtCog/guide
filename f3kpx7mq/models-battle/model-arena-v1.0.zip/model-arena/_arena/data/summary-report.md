# Итоговый отчет арены

Обновлено: 13.07.2026, 01:51:43

| Тест | Модель | Оценка | Стоимость | Время | Токены | Папка |
|---|---:|---:|---:|---:|---:|---|
| многостраничный сайт | Fable 5 | 9/10 | $14.75 | — | 78.9k | 01-sokrovishnitsa-orbit-site-fable-5 |
| многостраничный сайт | GPT-5.6 Sol | 7/10 | ~$4.51 | 7 мин 58 сек | — | 01-sokrovishnitsa-orbit-site-gpt-5-6-sol |
| многостраничный сайт | Opus 4.8 | 8.5/10 | $9.30 | — | 84.9k | 01-sokrovishnitsa-orbit-site-opus-4-8 |
| многостраничный сайт | Sonnet 5 | 7/10 | $4.20 | — | 99.8k | 01-sokrovishnitsa-orbit-site-sonnet-5 |
| хоррор-игра от первого лица | Fable 5 | 9/10 | $17.51 | 13m 25s | 118k | 02-poslednyaya-smena-horror-fable-5 |
| платформер в духе Mario | Fable 5 | 10/10 | $10.90 | 24m 47s | 118k | 02b-mario-like-platformer-fable-5 |
| хоррор-игра от первого лица | GPT-5.6 Sol | — | $3.512621 | 00:14:02 | 211k | 02-poslednyaya-smena-horror-gpt-5-6-sol |
| платформер в духе Mario | GPT-5.6 Sol | — | ~$2.91 | 13m 8s | 172k | 02b-mario-like-platformer-gpt-5-6-sol |
| хоррор-игра от первого лица | Opus 4.8 | 7/10 | $5.92 | 15m 39s | 86.7k | 02-poslednyaya-smena-horror-opus-4-8 |
| платформер в духе Mario | Opus 4.8 | 6/10 | $4.48 | 16m 26s | 81.9k | 02b-mario-like-platformer-opus-4-8 |
| хоррор-игра от первого лица | Sonnet 5 | 7/10 | $5.15 | 13m 30s | 103k | 02-poslednyaya-smena-horror-sonnet-5 |
| платформер в духе Mario | Sonnet 5 | 5/10 | $6.30 | 23m 25s | 88.6k | 02b-mario-like-platformer-sonnet-5 |
| обучающая HTML-страница | Fable 5 | 9/10 | — | ~10m | — | 03-ai-personal-teacher-fourier-fable-5 |
| обучающая HTML-страница | GPT-5.6 Sol | 8/10 | ~$2.36 API-equivalent (cache-write cost unavailable) | 11m 23s (measured wall interval; active time unavailable separately) | 153k | 03-ai-personal-teacher-fourier-gpt-5-6-sol |
| обучающая HTML-страница | Opus 4.8 | 8/10 | — | ~13m | — | 03-ai-personal-teacher-fourier-opus-4-8 |
| обучающая HTML-страница | Sonnet 5 | 8/10 | — | 13m | — | 03-ai-personal-teacher-fourier-sonnet-5 |
| 3D-симуляция | Fable 5 | 9.5/10 | $12.67 | 33m 56s | 104k | 04-posledniy-ray-3d-fable-5 |
| 3D-симуляция | GPT-5.6 Sol | 10/10 | ~$2.77 API-equivalent (cache-write cost unavailable) | 14m 08s | 186k | 04-posledniy-ray-3d-gpt-5-6-sol |
| 3D-симуляция | Opus 4.8 | 8/10 | $8.74 | 42m 7s | 131k | 04-posledniy-ray-3d-opus-4-8 |
| 3D-симуляция | Sonnet 5 | 5/10 | $12.26 | 54m 4s | 187k | 04-posledniy-ray-3d-sonnet-5 |
| практический дашборд | Fable 5 | 9/10 | $13.49 | 8m 34s | 110k | 05-youtube-retention-dashboard-fable-5 |
| практический дашборд | GPT-5.6 Sol | 9/10 | ~$6.37 | 22m 44s | 417k | 05-youtube-retention-dashboard-gpt-5-6-sol |
| практический дашборд | Opus 4.8 | 9/10 | $5.51 | 6m 53s | 93.9k | 05-youtube-retention-dashboard-opus-4-8 |
| практический дашборд | Sonnet 5 | 5.5/10 | $11.23 | 31m 17s | 165k | 05-youtube-retention-dashboard-sonnet-5 |
| debug + логика продукта | Fable 5 | 10/10 | $6.96 | 12m 12s | 59.7k | 06-youtube-structure-planner-fable-5 |
| debug + логика продукта | GPT-5.6 Sol | 9/10 | ~$3.75 API-equivalent (cache-write cost unavailable) | 14m 34s | 192k | 06-youtube-structure-planner-gpt-5-6-sol |
| debug + логика продукта | Opus 4.8 | 7/10 | $6.55 | 11m 29s | 69.3k | 06-youtube-structure-planner-opus-4-8 |
| debug + логика продукта | Sonnet 5 | 6/10 | $5.62 | 15m 14s | 75.3k | 06-youtube-structure-planner-sonnet-5 |
