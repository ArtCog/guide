const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const ARENA_DIR = __dirname;
const MASTER_DIR = path.resolve(ARENA_DIR, "..");
const DATA_DIR = path.join(ARENA_DIR, "data");
const PROMPTS_ROOT = path.join(MASTER_DIR, "prompts");
const PORT = Number(process.env.ARENA_PORT || 7358);

const mime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon"
};

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

function safeResolve(root, parts) {
  const resolved = path.resolve(root, ...parts);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    return null;
  }
  return resolved;
}

function send(res, code, body, type = "text/plain; charset=utf-8") {
  res.writeHead(code, {
    "Content-Type": type,
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function serveFile(res, file) {
  if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    send(res, 404, "Not found");
    return;
  }
  const type = mime[path.extname(file).toLowerCase()] || "application/octet-stream";
  res.writeHead(200, {
    "Content-Type": type,
    "Cache-Control": "no-store"
  });
  fs.createReadStream(file).pipe(res);
}

function parseMetrics(folder, runFolder) {
  const metricsPath = path.join(folder, "RUN-METRICS.md");
  const metrics = {
    path: metricsPath,
    exists: fs.existsSync(metricsPath),
    costUsd: "",
    taskTime: "",
    apiTime: "",
    wallTime: "",
    inputTokens: "",
    outputTokens: "",
    cacheRead: "",
    cacheWrite: "",
    verdict: ""
  };

  if (!metrics.exists) return metrics;

  const text = fs.readFileSync(metricsPath, "utf8");
  const get = (aliases) => readMetricValue(text, aliases);

  metrics.costUsd = cleanMetric(get(["Стоимость USD", "РЎС‚РѕРёРјРѕСЃС‚СЊ USD", "Cost USD"]));
  metrics.taskTime = cleanMetric(get(["Время задачи", "Р’СЂРµРјСЏ Р·Р°РґР°С‡Рё", "Task time"]));
  metrics.apiTime = cleanMetric(get(["Время API", "Р’СЂРµРјСЏ API", "API time"]));
  metrics.wallTime = cleanMetric(get(["Wall-время", "Wall-РІСЂРµРјСЏ", "Wall time"]));
  metrics.inputTokens = cleanMetric(get(["Input tokens"]));
  metrics.outputTokens = cleanMetric(get(["Output tokens"]));
  metrics.cacheRead = cleanMetric(get(["Cache read"]));
  metrics.cacheWrite = cleanMetric(get(["Cache write"]));
  metrics.verdict = cleanMetric(get(["Короткий вердикт", "РљРѕСЂРѕС‚РєРёР№ РІРµСЂРґРёРєС‚", "Verdict"]));
  metrics.relativePath = path.relative(MASTER_DIR, metricsPath);
  metrics.runFolder = runFolder;
  return metrics;
}

function normalizeMetricLabel(label) {
  return String(label || "")
    .replaceAll("*", "")
    .replaceAll("`", "")
    .replaceAll(":", "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function readMetricValue(text, aliases) {
  const wanted = aliases.map(normalizeMetricLabel).filter(Boolean);
  const matches = (label) => {
    const normalized = normalizeMetricLabel(label);
    return wanted.some((alias) => normalized === alias);
  };

  for (const line of text.split(/\r?\n/)) {
    const table = line.trim();
    if (table.startsWith("|") && table.endsWith("|")) {
      const cells = table.slice(1, -1).split("|").map((cell) => cell.trim());
      if (cells.length >= 2 && matches(cells[0])) {
        return cells[1];
      }
    }

    const keyValue = line.match(/^\s*-?\s*(?:\*\*)?([^:|]+?)(?:\*\*)?\s*:\s*(.+)$/);
    if (keyValue && matches(keyValue[1])) {
      return keyValue[2].trim();
    }
  }

  return "";
}

function cleanMetric(value) {
  const text = String(value || "").trim();
  if (!text || text === "-" || text === "—") return "";
  if (/^-\s*[^:]+:\s*$/.test(text)) return "";
  if (/^-\s*(Путь|Wall|Input|Output|Cache|Стоимость|Короткий)/i.test(text)) return "";
  return text;
}

function detectModel(folderName) {
  if (folderName.endsWith("fable-5")) return "fable-5";
  if (folderName.endsWith("opus-4-8")) return "opus-4-8";
  if (folderName.endsWith("sonnet-5")) return "sonnet-5";
  if (folderName.endsWith("glm-5-2")) return "glm-5-2";
  if (folderName.endsWith("gpt-5-6")) return "gpt-5-6";
  if (folderName.endsWith("gpt-5-6-sol")) return "gpt-5-6-sol";
  return "unknown";
}

function scanRuns() {
  const dirs = fs.readdirSync(MASTER_DIR, { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => entry.name)
    .filter((name) => /^\d{2}[a-z]?-/i.test(name));

  return dirs.map((name) => {
    const folder = path.join(MASTER_DIR, name);
    const caseId = (name.match(/^(\d{2}[a-z]?)-/i)?.[1] || name.slice(0, 2)).toLowerCase();
    const testId = caseId.slice(0, 2);
    const modelId = detectModel(name);
    const indexPath = path.join(folder, "index.html");
    const hasIndex = fs.existsSync(indexPath);

    return {
      id: name,
      folder: name,
      testId,
      caseId,
      modelId,
      title: name,
      status: hasIndex ? "ready" : "missing-index",
      previewUrl: hasIndex ? `/result/${encodeURIComponent(name)}/index.html` : "",
      openUrl: hasIndex ? `/result/${encodeURIComponent(name)}/index.html` : "",
      mainFile: indexPath,
      metrics: parseMetrics(folder, name)
    };
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error("Body too large"));
        req.destroy();
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function buildArenaPayload() {
  const config = readJson(path.join(DATA_DIR, "arena.json"), {
    title: "Local Arena",
    subtitle: "",
    models: [],
    tests: []
  });
  const ratings = readJson(path.join(DATA_DIR, "ratings.json"), {});
  const runs = scanRuns().map((run) => ({
    ...run,
    rating: ratings[run.id] || {
      score: "",
      strength: "",
      bug: "",
      verdict: ""
    }
  }));

  return {
    ...config,
    masterDir: MASTER_DIR,
    generatedAt: new Date().toISOString(),
    runs
  };
}

function readPromptPayload(testId) {
  const config = readJson(path.join(DATA_DIR, "arena.json"), { tests: [] });
  const test = config.tests.find((item) => item.id === testId);
  if (!test || !test.promptFile) return null;

  const file = path.resolve(MASTER_DIR, test.promptFile);
  if (file !== PROMPTS_ROOT && !file.startsWith(PROMPTS_ROOT + path.sep)) {
    return null;
  }

  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
    return {
      title: test.title || testId,
      path: file,
      text: "Файл промпта не найден."
    };
  }

  return {
    title: test.title || testId,
    path: file,
    text: extractPromptText(fs.readFileSync(file, "utf8"))
  };
}

function extractPromptText(markdown) {
  const text = String(markdown || "").replace(/^\uFEFF/, "");
  const exactPrompt = text.match(/##\s+Точный промпт[\s\S]*?```(?:text|txt)?\s*\r?\n([\s\S]*?)\r?\n```/i);
  if (exactPrompt) return exactPrompt[1].trim();

  const firstTextBlock = text.match(/```(?:text|txt)?\s*\r?\n([\s\S]*?)\r?\n```/i);
  if (firstTextBlock) return firstTextBlock[1].trim();

  return text.trim();
}

function parseTokenNumber(value) {
  const raw = String(value || "").trim().toLowerCase().replaceAll(",", "");
  if (!raw || raw === "—") return 0;
  const target = raw.includes("=") ? raw.split("=").pop() : raw;
  const match = target.match(/~?\s*([\d.]+)\s*(k|m)\b/) || target.match(/^\s*([\d.]+)\s*(k|m)?\s*$/);
  if (!match) return Number(raw.replace(/[^0-9.]/g, "")) || 0;
  const base = Number(match[1]);
  const suffix = match[2];
  if (suffix === "m") return base * 1_000_000;
  if (suffix === "k") return base * 1_000;
  return base;
}

function formatTokenTotal(input, output) {
  const total = parseTokenNumber(input) + parseTokenNumber(output);
  if (!total) return "—";
  if (total >= 1_000_000) return `${(total / 1_000_000).toFixed(total >= 10_000_000 ? 0 : 1)}M`;
  if (total >= 1_000) return `${(total / 1_000).toFixed(total >= 100_000 ? 0 : 1)}k`;
  return String(Math.round(total));
}

function getRunTestLabel(test, run) {
  if (!test) return run.testId;
  const caseId = run.caseId || run.testId;
  const variant = Array.isArray(test.variants)
    ? test.variants.find((item) => item.id === caseId)
    : null;
  return variant?.kind || variant?.title || test.kind || test.title || run.testId;
}

function writeSummaryReport(arena) {
  const testById = new Map(arena.tests.map((test) => [test.id, test]));
  const modelById = new Map(
    arena.models
      .filter((model) => model.scored !== false)
      .map((model) => [model.id, model])
  );
  const rows = arena.runs
    .filter((run) => run.status === "ready" && modelById.has(run.modelId))
    .sort((a, b) => a.testId.localeCompare(b.testId) || a.modelId.localeCompare(b.modelId))
    .map((run) => {
      const test = testById.get(run.testId);
      const model = modelById.get(run.modelId);
      return [
        getRunTestLabel(test, run),
        model?.label || run.modelId,
        run.rating?.score ? `${run.rating.score}/10` : "—",
        run.metrics?.costUsd || "—",
        run.metrics?.taskTime || "—",
        formatTokenTotal(run.metrics?.inputTokens, run.metrics?.outputTokens),
        run.folder
      ];
    });

  const lines = [
    "# Итоговый отчет арены",
    "",
    `Обновлено: ${new Date().toLocaleString("ru-RU")}`,
    "",
    "| Тест | Модель | Оценка | Стоимость | Время | Токены | Папка |",
    "|---|---:|---:|---:|---:|---:|---|",
    ...rows.map((row) => `| ${row.map((cell) => String(cell).replaceAll("|", "\\|")).join(" | ")} |`),
    ""
  ];

  fs.writeFileSync(path.join(DATA_DIR, "summary-report.md"), lines.join("\n"), "utf8");
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = decodeURIComponent(url.pathname);

  try {
    if (req.method === "GET" && pathname === "/") {
      serveFile(res, path.join(ARENA_DIR, "index.html"));
      return;
    }

    if (req.method === "GET" && pathname === "/report") {
      serveFile(res, path.join(ARENA_DIR, "report.html"));
      return;
    }

    if (req.method === "GET" && pathname === "/data/summary-report.md") {
      res.writeHead(302, {
        Location: "/report",
        "Cache-Control": "no-store"
      });
      res.end();
      return;
    }

    if (req.method === "GET" && pathname === "/api/arena") {
      const arena = buildArenaPayload();
      writeSummaryReport(arena);
      send(res, 200, JSON.stringify(arena), "application/json; charset=utf-8");
      return;
    }

    if (req.method === "GET" && pathname.startsWith("/api/prompt/")) {
      const testId = pathname.slice("/api/prompt/".length);
      const prompt = readPromptPayload(testId);
      if (!prompt) {
        send(res, 404, JSON.stringify({ error: "Prompt not found" }), "application/json; charset=utf-8");
        return;
      }
      send(res, 200, JSON.stringify(prompt), "application/json; charset=utf-8");
      return;
    }

    if (req.method === "POST" && pathname === "/api/rating") {
      const body = await readBody(req);
      const payload = JSON.parse(body || "{}");
      if (!payload.runId || !/^\d{2}[a-z]?-/i.test(payload.runId)) {
        send(res, 400, "Bad runId");
        return;
      }
      const ratingsFile = path.join(DATA_DIR, "ratings.json");
      const ratings = readJson(ratingsFile, {});
      ratings[payload.runId] = {
        score: String(payload.score || ""),
        strength: String(payload.strength || ""),
        bug: String(payload.bug || ""),
        verdict: String(payload.verdict || "")
      };
      writeJson(ratingsFile, ratings);
      writeSummaryReport(buildArenaPayload());
      send(res, 200, JSON.stringify({ ok: true }), "application/json; charset=utf-8");
      return;
    }

    if (req.method === "GET" && pathname.startsWith("/data/")) {
      const file = safeResolve(DATA_DIR, [pathname.slice("/data/".length)]);
      serveFile(res, file);
      return;
    }

    if (req.method === "GET" && pathname.startsWith("/assets/")) {
      const file = safeResolve(path.join(ARENA_DIR, "assets"), [pathname.slice("/assets/".length)]);
      serveFile(res, file);
      return;
    }

    if (req.method === "GET" && pathname.startsWith("/result/")) {
      const parts = pathname.slice("/result/".length).split("/").filter(Boolean);
      const folder = parts.shift();
      if (!folder || !/^\d{2}[a-z]?-/i.test(folder)) {
        send(res, 404, "Result folder not found");
        return;
      }
      const file = safeResolve(path.join(MASTER_DIR, folder), parts.length ? parts : ["index.html"]);
      serveFile(res, file);
      return;
    }

    send(res, 404, "Not found");
  } catch (error) {
    console.error(error);
    send(res, 500, error.message || "Server error");
  }
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`AI model test arena: http://localhost:${PORT}`);
  console.log(`Master folder: ${MASTER_DIR}`);
});
