const modelLabels = {
  "fable-5": "Fable 5",
  "opus-4-8": "Opus 4.8",
  "sonnet-5": "Sonnet 5",
  "glm-5-2": "GLM 5.2",
  unknown: "Unknown"
};

const statusLabels = {
  ready: "готово",
  waiting: "ожидает",
  planned: "план",
  "missing-index": "нет index"
};

const $ = (selector, root = document) => root.querySelector(selector);

function readStoredValue(key, fallback) {
  try {
    return localStorage.getItem(key) || fallback;
  } catch {
    return fallback;
  }
}

function writeStoredValue(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {
    // The arena still works if browser storage is blocked.
  }
}

function readStoredSet(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "[]");
    return new Set(Array.isArray(value) ? value : []);
  } catch {
    return new Set();
  }
}

function writeStoredSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify([...value]));
  } catch {
    // The arena still works if browser storage is blocked.
  }
}

let arenaState = null;
let activeViewerRun = null;
let activeViewerModelName = "";
let activeViewerScore = "";
let initialHashViewerHandled = false;
const spoilerStorage = {
  mode: "immersive-arena-spoiler-mode",
  tasks: "immersive-arena-revealed-tasks",
  variants: "immersive-arena-revealed-variants",
  runs: "immersive-arena-revealed-runs",
  report: "immersive-arena-report-revealed-v2"
};
let spoilerMode = readStoredValue(spoilerStorage.mode, "on") !== "off";
let revealedTasks = readStoredSet(spoilerStorage.tasks);
let revealedVariants = readStoredSet(spoilerStorage.variants);
let revealedRuns = readStoredSet(spoilerStorage.runs);
let reportRevealed = readStoredValue(spoilerStorage.report, "off") === "on";

async function loadArena() {
  const response = await fetch("/api/arena", { cache: "no-store" });
  if (!response.ok) throw new Error(`Arena API error: ${response.status}`);
  arenaState = await response.json();
  render(arenaState);
}

function byTestAndModel(runs) {
  const map = new Map();
  for (const run of runs) {
    map.set(`${run.caseId || run.testId}:${run.modelId}`, run);
  }
  return map;
}

function render(data) {
  $("#arena-title").textContent = data.title;
  $("#arena-subtitle").textContent = data.subtitle;

  updateSpoilerUi();
  renderNav(data.tests);
  renderTasks(data);
  renderReport(data);
  renderBonusRuns(data);
  if (!initialHashViewerHandled) {
    initialHashViewerHandled = true;
    openHashViewer(data);
  }
}

function renderNav(tests) {
  $("#task-nav").innerHTML = tests
    .map((test) => `
      <a class="task-link" href="#task-${test.id}" title="${escapeHtml(test.title)}">
        <span class="task-number">${test.id}</span>
        <span class="task-name">${escapeHtml(test.kind)}</span>
      </a>
    `)
    .join("");
}

function renderTasks(data) {
  const tasksRoot = $("#tasks");
  const taskTemplate = $("#task-template");
  const runTemplate = $("#run-template");
  const runMap = byTestAndModel(data.runs);

  tasksRoot.innerHTML = "";

  for (const test of data.tests) {
    const taskNode = taskTemplate.content.firstElementChild.cloneNode(true);
    taskNode.id = `task-${test.id}`;
    taskNode.dataset.taskId = test.id;
    const taskVisible = !spoilerMode || revealedTasks.has(test.id);
    taskNode.classList.toggle("task-collapsed", spoilerMode && !taskVisible);
    taskNode.classList.toggle("task-revealed", taskVisible);
    $(".task-kicker", taskNode).innerHTML = `
      <span class="task-index-large">${escapeHtml(test.id)}</span>
      <span class="task-meta-line">${escapeHtml(statusLabels[test.status] || test.status)}</span>
    `;
    const titleNode = $("h2", taskNode);
    titleNode.textContent = test.kind;
    const caseNode = document.createElement("div");
    caseNode.className = "task-case";
    const caseLabel = document.createElement("span");
    caseLabel.className = "task-case-label";
    caseLabel.textContent = "кейс";
    const promptButton = document.createElement("button");
    promptButton.type = "button";
    promptButton.className = "prompt-title-button";
    promptButton.textContent = test.title;
    promptButton.title = "Открыть промпт задания";
    promptButton.addEventListener("click", () => openPrompt(test));
    caseNode.append(caseLabel, promptButton);
    titleNode.after(caseNode);
    $("p", taskNode).textContent = test.summary;
    if (test.masterLayer) {
      const masterLayer = document.createElement("div");
      masterLayer.className = "master-layer-note";
      masterLayer.innerHTML = `
        <span>${escapeHtml(test.masterLayer.title || "Скрытый мастер-слой")}</span>
        <p>${escapeHtml(test.masterLayer.text || "")}</p>
      `;
      $("p", taskNode).after(masterLayer);
    }

    const revealTaskButton = document.createElement("button");
    revealTaskButton.type = "button";
    revealTaskButton.className = "control task-reveal-button";
    revealTaskButton.textContent = taskVisible ? "Скрыть задание" : "Раскрыть задание";
    revealTaskButton.addEventListener("click", () => toggleTaskReveal(test.id));
    $(".task-head", taskNode).appendChild(revealTaskButton);

    const variants = getTaskVariants(test, data.runs);
    const grid = $(".run-grid", taskNode);

    if (variants.length > 1) {
      grid.remove();
      const stack = document.createElement("div");
      stack.className = "variant-stack";
      for (const variant of variants) {
        stack.appendChild(renderVariantBlock(variant, data.models, runMap, runTemplate));
      }
      $(".task-head", taskNode).after(stack);
    } else {
      for (const model of data.models) {
        const run = runMap.get(`${test.id}:${model.id}`) || makeEmptyRun(test, model);
        grid.appendChild(renderRun(runTemplate, run, model, test));
      }
    }

    if (test.productDemo) {
      taskNode.appendChild(renderProductDemo(test, data.models, runMap));
    }

    tasksRoot.appendChild(taskNode);
  }
}

function getTaskVariants(test, runs) {
  if (Array.isArray(test.variants) && test.variants.length) {
    return test.variants.map((variant) => ({
      ...test,
      ...variant,
      parentId: test.id,
      variantId: variant.id
    }));
  }

  const caseIds = [...new Set(
    runs
      .filter((run) => run.testId === test.id)
      .map((run) => run.caseId || run.testId)
  )].sort();

  if (caseIds.length <= 1) return [{ ...test, parentId: test.id, variantId: test.id }];

  return caseIds.map((caseId) => ({
    ...test,
    id: caseId,
    parentId: test.id,
    variantId: caseId,
    kind: caseId === test.id ? test.kind : caseId,
    title: caseId === test.id ? test.title : caseId,
    summary: caseId === test.id ? test.summary : ""
  }));
}

function renderVariantBlock(variant, models, runMap, runTemplate) {
  const details = document.createElement("details");
  details.className = "task-variant";
  details.dataset.variantId = variant.id;
  details.open = !spoilerMode || revealedVariants.has(variant.id);
  details.innerHTML = `
    <summary class="variant-summary">
      <span class="variant-number">${escapeHtml(variant.label || variant.id)}</span>
      <div class="variant-copy">
        <strong>${escapeHtml(variant.kind || variant.title || variant.id)}</strong>
        <em>${escapeHtml(variant.title || "")}</em>
      </div>
      <span class="variant-action">${!spoilerMode ? "Скрыть" : "Показать"}</span>
    </summary>
    <p class="variant-description">${escapeHtml(variant.summary || "")}</p>
    <div class="run-grid variant-grid"></div>
  `;

  const grid = $(".variant-grid", details);
  for (const model of models) {
    const run = runMap.get(`${variant.id}:${model.id}`) || makeEmptyRun(variant, model);
    grid.appendChild(renderRun(runTemplate, run, model, variant));
  }

  details.addEventListener("toggle", () => {
    const label = $(".variant-action", details);
    if (label) label.textContent = details.open ? "Скрыть" : "Показать";
    if (!spoilerMode) return;
    if (details.open) {
      revealedVariants.add(variant.id);
    } else {
      revealedVariants.delete(variant.id);
    }
    writeStoredSet(spoilerStorage.variants, revealedVariants);
  });

  return details;
}

function renderBonusRuns(data) {
  let bonusRoot = $("#bonus-runs");
  if (!bonusRoot) {
    bonusRoot = document.createElement("section");
    bonusRoot.id = "bonus-runs";
    bonusRoot.className = "bonus-runs";
    $(".canvas").appendChild(bonusRoot);
  }

  const coreModelIds = new Set(data.models.map((model) => model.id));
  const bonusRuns = data.runs
    .filter((run) => run.status === "ready" && !coreModelIds.has(run.modelId))
    .sort((a, b) => a.testId.localeCompare(b.testId) || a.modelId.localeCompare(b.modelId));

  if (!bonusRuns.length) {
    bonusRoot.innerHTML = "";
    bonusRoot.hidden = true;
    return;
  }

  const runTemplate = $("#run-template");
  const testById = new Map(data.tests.map((test) => [test.id, test]));
  const groups = new Map();
  for (const run of bonusRuns) {
    if (!groups.has(run.testId)) groups.set(run.testId, []);
    groups.get(run.testId).push(run);
  }

  bonusRoot.hidden = false;
  bonusRoot.innerHTML = `
    <details class="bonus-details">
      <summary>
        <span>Бонус</span>
        <strong>Дополнительные модели</strong>
        <em>${bonusRuns.length} результат(а), скрыто от основного сравнения</em>
      </summary>
      <div class="bonus-content"></div>
    </details>
  `;

  const content = $(".bonus-content", bonusRoot);
  for (const [testId, runs] of groups) {
    const test = testById.get(testId);
    const group = document.createElement("section");
    group.className = "bonus-group";
    group.innerHTML = `
      <div class="bonus-group-head">
        <span>${escapeHtml(testId)}</span>
        <div>
          <strong>${escapeHtml(test?.kind || test?.title || testId)}</strong>
          <p>${escapeHtml(test?.title || "")}</p>
        </div>
      </div>
      <div class="bonus-grid"></div>
    `;

    const grid = $(".bonus-grid", group);
    for (const run of runs) {
      grid.appendChild(renderRun(runTemplate, run, {
        id: run.modelId,
        label: modelLabels[run.modelId] || run.modelId,
        bonus: true
      }, test || { id: testId }));
    }
    content.appendChild(group);
  }
}

function renderReport(data) {
  const body = $("#report-body");
  const testById = new Map(data.tests.map((test) => [test.id, test]));
  const scoredModels = data.models.filter((model) => model.scored !== false);
  const modelById = new Map(scoredModels.map((model) => [model.id, model]));
  const readyRuns = data.runs
    .filter((run) => run.status === "ready" && modelById.has(run.modelId))
    .sort((a, b) => {
      const caseA = a.caseId || a.testId;
      const caseB = b.caseId || b.testId;
      return caseA.localeCompare(caseB) || a.modelId.localeCompare(b.modelId);
    });

  if (!readyRuns.length) {
    body.innerHTML = `<tr><td colspan="6">Пока нет готовых работ.</td></tr>`;
    updateReportSpoiler();
    return;
  }

  body.innerHTML = readyRuns.map((run) => {
    const test = testById.get(run.testId);
    const model = modelById.get(run.modelId);
    return `
      <tr>
        <td>${escapeHtml(getRunTestLabel(test, run))}</td>
        <td>${escapeHtml(model?.label || modelLabels[run.modelId] || run.modelId)}</td>
        <td class="report-score">${run.rating?.score ? `${escapeHtml(run.rating.score)}/10` : "—"}</td>
        <td>${escapeHtml(formatMetricCost(run.metrics?.costUsd))}</td>
        <td>${escapeHtml(displayRunTime(run.metrics) || "—")}</td>
        <td>${escapeHtml(formatTokenTotal(run.metrics?.inputTokens, run.metrics?.outputTokens))}</td>
      </tr>
    `;
  }).join("");
  updateReportSpoiler();
}

function getRunTestLabel(test, run) {
  if (!test) return run.testId;
  const caseId = run.caseId || run.testId;
  const variant = Array.isArray(test.variants)
    ? test.variants.find((item) => item.id === caseId)
    : null;
  return variant?.kind || variant?.title || test.kind || test.title || run.testId;
}

function makeEmptyRun(test, model) {
  return {
    id: `${test.id}-${model.id}-empty`,
    folder: `${test.id}-${model.id}`,
    testId: test.id,
    modelId: model.id,
    status: "waiting",
    previewUrl: "",
    openUrl: "",
    metrics: {},
    rating: {}
  };
}

function renderRun(template, run, model, test) {
  const node = template.content.firstElementChild.cloneNode(true);
  const ready = run.status === "ready";
  const modelName = model.label || modelLabels[run.modelId] || run.modelId;
  const analysis = test?.analysisMode === "review" ? test.analysis?.[run.modelId] : null;
  const locked = spoilerMode && !revealedRuns.has(run.id);
  if (analysis) run.analysis = analysis;

  node.dataset.runId = run.id;
  node.classList.toggle("review-card", Boolean(analysis));
  node.classList.toggle("outside-ranking", model.scored === false);
  node.classList.toggle("spoiler-card-locked", locked);
  node.classList.toggle("empty", !ready);
  $(".status-dot", node).classList.add(ready ? "ready" : run.status === "missing-index" ? "missing" : "waiting");
  $("h3", node).textContent = modelName;
  if (model.scored === false) {
    const note = document.createElement("span");
    note.className = "outside-ranking-note";
    note.textContent = "вне зачёта";
    $(".model-line", node).appendChild(note);
  }
  $(".folder-line", node).textContent = run.folder;
  $(".status-pill", node).textContent = statusLabels[run.status] || run.status;

  const iframe = $("iframe", node);
  const emptyPreview = $(".empty-preview", node);
  iframe.title = `${modelName} — ${run.folder}`;
  if (ready && locked) {
    const preview = $(".preview-wrap", node);
    preview.innerHTML = renderSpoilerCover(modelName);
    $(".spoiler-card-button", preview).addEventListener("click", (event) => {
      event.stopPropagation();
      revealRun(run.id);
    });
  } else if (ready && analysis) {
    const preview = $(".preview-wrap", node);
    preview.innerHTML = renderAnalysisPreview(analysis);
  } else if (ready) iframe.src = run.previewUrl;
  if (emptyPreview) {
    emptyPreview.textContent = run.status === "missing-index" ? "index.html не найден" : "результат еще не добавлен";
  }

  const openLink = $(".open-link", node);
  if (ready && !locked) {
    openLink.href = run.openUrl;
  } else {
    openLink.removeAttribute("href");
    openLink.setAttribute("aria-disabled", "true");
  }

  if (ready && spoilerMode && !locked) {
    const hideButton = document.createElement("button");
    hideButton.className = "mini-button hide-result-button";
    hideButton.type = "button";
    hideButton.textContent = "Скрыть";
    hideButton.addEventListener("click", (event) => {
      event.stopPropagation();
      hideRun(run.id);
    });
    $(".card-actions", node).prepend(hideButton);
  }

  $(".fullscreen-button", node).addEventListener("click", () => {
    if (!ready) return;
    if (locked) {
      revealRun(run.id);
      return;
    }
    openViewer(run, modelName);
  });

  $(".preview-wrap", node).addEventListener("dblclick", () => {
    if (!ready) return;
    if (locked) {
      revealRun(run.id);
      return;
    }
    openViewer(run, modelName);
  });

  $(".preview-wrap", node).addEventListener("click", () => {
    if (!ready) return;
    if (locked) {
      revealRun(run.id);
      return;
    }
    openViewer(run, modelName);
  });

  renderMetrics($(".metrics", node), run.metrics || {}, locked);
  hydrateRating(node, run, locked);
  return node;
}

function renderMetrics(root, metrics, locked = false) {
  if (locked) {
    root.replaceChildren();
    root.hidden = true;
    return;
  }

  root.hidden = false;
  const freshTokens = formatTokenTotal(metrics.inputTokens, metrics.outputTokens);
  const tokenDetails = freshTokens === "—"
    ? "—"
    : `Input: ${metrics.inputTokens || "—"} · Output: ${metrics.outputTokens || "—"}`;
  const items = [
    { label: "Стоимость", value: formatMetricCost(metrics.costUsd) },
    { label: "Время", value: displayRunTime(metrics) || "—", kind: "time" },
    { label: "Токены", value: freshTokens, full: tokenDetails },
    { label: "Оценка", value: "—" }
  ];

  root.innerHTML = items
    .map((item) => {
      const display = ArenaMetricFormat.compact(item.value, item.kind);
      item.full = ArenaMetricFormat.tooltip(item.full || item.value);
      return `<div class="metric-cell"><span>${item.label}</span><strong title="${escapeHtml(item.full)}">${escapeHtml(display)}</strong></div>`;
    })
    .join("");
}

function renderSpoilerCover(modelName) {
  return `
    <div class="spoiler-cover">
      <span>${escapeHtml(modelName)}</span>
      <strong>Результат скрыт</strong>
      <p>Открой, когда дойдешь до этой модели в записи.</p>
      <button class="spoiler-card-button" type="button">Показать результат</button>
    </div>
  `;
}

function renderAnalysisPreview(analysis) {
  return `
    <div class="analysis-card">
      <div class="analysis-topline">
        <span>наш разбор</span>
        <strong>${escapeHtml(analysis.score || "—")}</strong>
      </div>
      <h4>${escapeHtml(analysis.verdict || "Вердикт")}</h4>
      <dl>
        <div>
          <dt>Нашла</dt>
          <dd>${escapeHtml(analysis.found || "—")}</dd>
        </div>
        <div>
          <dt>Не дожала</dt>
          <dd>${escapeHtml(analysis.missed || "—")}</dd>
        </div>
      </dl>
      <p>${escapeHtml(analysis.note || "")}</p>
    </div>
  `;
}

function renderAnalysisViewer(analysis, modelName, run) {
  return `
    <section class="analysis-view">
      <div class="analysis-view-kicker">Тест ${escapeHtml(run.testId || "—")} / наш анализ</div>
      <h2>${escapeHtml(modelName)} — ${escapeHtml(analysis.verdict || "разбор работы")}</h2>
      <div class="analysis-score">${escapeHtml(analysis.score || "—")}</div>
      <div class="analysis-view-grid">
        <article>
          <span>Что сделала</span>
          <p>${escapeHtml(analysis.found || "—")}</p>
        </article>
        <article>
          <span>Где не дожала</span>
          <p>${escapeHtml(analysis.missed || "—")}</p>
        </article>
        <article>
          <span>Вывод для видео</span>
          <p>${escapeHtml(analysis.note || "—")}</p>
        </article>
      </div>
      <footer>
        <span>Исправленный проект остался доступен через кнопку «Вкладка».</span>
        <code>${escapeHtml(run.folder)}</code>
      </footer>
    </section>
  `;
}

function renderProductDemo(test, models, runMap) {
  const runs = models
    .map((model) => ({
      model,
      run: runMap.get(`${test.id}:${model.id}`)
    }))
    .filter(({ run }) => run?.status === "ready" && run.previewUrl);

  const section = document.createElement("section");
  section.className = "product-demo";
  if (!runs.length) {
    section.innerHTML = `
      <div class="product-demo-head">
        <span>продукт теста</span>
        <strong>${escapeHtml(test.productDemo.title || "Сам продукт")}</strong>
      </div>
      <p>Готовый index.html пока не найден.</p>
    `;
    return section;
  }

  section.innerHTML = `
    <div class="product-demo-head">
      <div>
        <span>продукт теста</span>
        <strong>${escapeHtml(test.productDemo.title || "Сам продукт")}</strong>
        <em>${escapeHtml(test.productDemo.description || "")}</em>
      </div>
    </div>
    <div class="product-demo-actions">
      ${runs.map(({ model, run }) => `
        <a class="mini-button product-demo-button" href="${escapeHtml(run.openUrl)}" target="_blank" rel="noreferrer">
          Открыть ${escapeHtml(model.label || modelLabels[model.id] || model.id)}
        </a>
      `).join("")}
    </div>
  `;

  return section;
}

function displayRunTime(metrics = {}) {
  return formatMetricTime(metrics.taskTime);
}

function formatMetricCost(value) {
  const text = String(value || "").trim();
  if (!text || text === "—") return "—";

  const match = text.match(/\$?\s*([0-9]+(?:\.[0-9]+)?)/);
  if (!match) return "—";

  const amount = Number(match[1]);
  const estimated = /[~≈]|api[- ]?equivalent|approx|оцен|эквивалент/i.test(text);
  return `${estimated ? "~" : ""}$${amount.toFixed(2)}`;
}

function formatMetricTime(value) {
  const text = String(value || "").trim();
  if (!text || /^(?:unavailable|недоступно)$/i.test(text)) return "";

  const approximate = /^[~≈]/.test(text) || /approx|около|оцен/i.test(text);
  const colon = text.match(/\b(\d{1,2}):(\d{2}):(\d{2})\b/);
  let hours = 0;
  let minutes = 0;
  let seconds = 0;

  if (colon) {
    hours = Number(colon[1]);
    minutes = Number(colon[2]);
    seconds = Number(colon[3]);
  } else {
    const hourMatch = text.match(/(\d+)\s*(?:ч|час(?:а|ов)?|h)/i);
    const minuteMatch = text.match(/(\d+)\s*(?:мин(?:ут(?:ы|а)?)?|m)/i);
    const secondMatch = text.match(/(\d+(?:\.\d+)?)\s*(?:сек(?:унд(?:ы|а)?)?|s)/i);
    hours = hourMatch ? Number(hourMatch[1]) : 0;
    minutes = minuteMatch ? Number(minuteMatch[1]) : 0;
    seconds = secondMatch ? Math.round(Number(secondMatch[1])) : 0;
  }

  minutes += Math.floor(seconds / 60);
  seconds %= 60;
  hours += Math.floor(minutes / 60);
  minutes %= 60;

  const parts = [];
  if (hours) parts.push(`${hours}ч`);
  if (minutes) parts.push(`${minutes}м`);
  if (seconds || !parts.length) parts.push(`${String(seconds).padStart(2, "0")}с`);
  return `${approximate ? "~" : ""}${parts.join(" ")}`;
}

function hydrateRating(node, run, locked = false) {
  const rating = run.rating || {};
  const score = $(".score-input", node);

  if (locked) {
    score.value = "";
    score.disabled = true;
    return;
  }

  score.disabled = false;
  const metricScore = $(".metric-cell:last-child strong", node);
  score.value = rating.score || "";
  metricScore.textContent = rating.score ? `${rating.score}/10` : "—";
  metricScore.title = metricScore.textContent;

  score.addEventListener("input", () => {
    metricScore.textContent = score.value ? `${score.value}/10` : "—";
    metricScore.title = metricScore.textContent;
  });

  $(".save-button", node).addEventListener("click", async () => {
    await saveRating(run.id, score.value);
    $(".save-button", node).textContent = "Сохранено";
    setTimeout(() => {
      $(".save-button", node).textContent = "OK";
    }, 1200);
  });
}

function updateSpoilerUi() {
  document.body.classList.toggle("spoiler-mode", spoilerMode);
  document.body.classList.toggle("spoiler-off", !spoilerMode);
  const button = $("#spoiler-toggle");
  if (!button) return;
  button.textContent = spoilerMode ? "Показать всё" : "Скрыть спойлеры";
  button.setAttribute(
    "aria-pressed",
    spoilerMode ? "true" : "false"
  );
}

function toggleSpoilerMode() {
  spoilerMode = !spoilerMode;
  writeStoredValue(spoilerStorage.mode, spoilerMode ? "on" : "off");

  if (spoilerMode) {
    revealedTasks = new Set();
    revealedVariants = new Set();
    revealedRuns = new Set();
    reportRevealed = false;
    writeStoredSet(spoilerStorage.tasks, revealedTasks);
    writeStoredSet(spoilerStorage.variants, revealedVariants);
    writeStoredSet(spoilerStorage.runs, revealedRuns);
    writeStoredValue(spoilerStorage.report, "off");
  }

  if (arenaState) render(arenaState);
}

function toggleTaskReveal(testId) {
  if (!spoilerMode) return;
  if (revealedTasks.has(testId)) {
    revealedTasks.delete(testId);
  } else {
    revealedTasks.add(testId);
  }
  writeStoredSet(spoilerStorage.tasks, revealedTasks);
  if (arenaState) render(arenaState);
}

function revealRun(runId) {
  if (!spoilerMode) return;
  clearViewerHash();
  const run = arenaState?.runs?.find((item) => item.id === runId);
  if (run) {
    revealedTasks.add(run.testId);
    revealedVariants.add(run.caseId || run.testId);
    writeStoredSet(spoilerStorage.tasks, revealedTasks);
    writeStoredSet(spoilerStorage.variants, revealedVariants);
  }
  revealedRuns.add(runId);
  writeStoredSet(spoilerStorage.runs, revealedRuns);
  if (arenaState) {
    render(arenaState);
    scrollRunIntoView(runId);
  }
}

function hideRun(runId) {
  if (!spoilerMode) return;
  clearViewerHash();
  revealedRuns.delete(runId);
  writeStoredSet(spoilerStorage.runs, revealedRuns);
  if (activeViewerRun?.id === runId) {
    closeViewer({ fromHistory: true });
  }
  if (arenaState) render(arenaState);
}

function scrollRunIntoView(runId) {
  requestAnimationFrame(() => {
    const escapedRunId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(runId) : runId.replaceAll('"', '\\"');
    const card = document.querySelector(`.run-card[data-run-id="${escapedRunId}"]`);
    if (card) card.scrollIntoView({ block: "center", inline: "nearest" });
  });
}

function clearViewerHash() {
  if (location.hash.startsWith("#view=")) {
    history.replaceState(null, "", `${location.pathname}${location.search}`);
  }
}

function revealReport() {
  reportRevealed = true;
  writeStoredValue(spoilerStorage.report, "on");
  updateReportSpoiler();
}

function hideReport() {
  reportRevealed = false;
  writeStoredValue(spoilerStorage.report, "off");
  updateReportSpoiler();
}

function updateReportSpoiler() {
  const report = $("#report");
  if (!report) return;
  let cover = $(".report-cover", report);
  if (!cover) {
    cover = document.createElement("div");
    cover.className = "report-cover";
    report.appendChild(cover);
  }

  const locked = !reportRevealed;
  report.classList.toggle("report-locked", locked);
  report.classList.toggle("report-open", !locked);
  cover.hidden = !locked;
  cover.innerHTML = locked
    ? `
      <div>
        <span>Итоговая таблица скрыта</span>
        <strong>Открой ее в финале ролика</strong>
        <p>Оценки, стоимость и общий победитель не будут видны зрителю заранее.</p>
      </div>
      <button class="control report-reveal-button" type="button">Показать таблицу</button>
    `
    : "";

  const button = $(".report-reveal-button", cover);
  if (button) button.addEventListener("click", revealReport);
  const collapseButton = $("#report-collapse");
  if (collapseButton) collapseButton.hidden = locked;
}

function openViewer(run, modelName, { pushHistory = true } = {}) {
  const viewer = $("#viewer");
  activeViewerRun = run;
  activeViewerModelName = modelName;
  activeViewerScore = run.rating?.score || "";
  $("#viewer-title").textContent = modelName;
  $("#viewer-path").textContent = run.folder;
  if (run.analysis) {
    $("#viewer-frame").hidden = true;
    $("#viewer-frame").removeAttribute("src");
    $("#viewer-analysis").hidden = false;
    $("#viewer-analysis").innerHTML = renderAnalysisViewer(run.analysis, modelName, run);
  } else {
    $("#viewer-analysis").hidden = true;
    $("#viewer-analysis").innerHTML = "";
    $("#viewer-frame").hidden = false;
    $("#viewer-frame").src = `${run.previewUrl}?view=${Date.now()}`;
  }
  $("#viewer-open").href = run.openUrl;
  setViewerScore(activeViewerScore);
  viewer.hidden = false;
  document.body.classList.add("viewer-open");

  if (pushHistory && (!history.state || history.state.viewer !== run.id)) {
    history.pushState({ viewer: run.id }, "", `#view=${encodeURIComponent(run.id)}`);
  }
}

function closeViewer({ fromHistory = false } = {}) {
  $("#viewer").hidden = true;
  $("#viewer-frame").removeAttribute("src");
  $("#viewer-frame").hidden = false;
  $("#viewer-analysis").hidden = true;
  $("#viewer-analysis").innerHTML = "";
  document.body.classList.remove("viewer-open");
  activeViewerRun = null;
  activeViewerModelName = "";
  activeViewerScore = "";

  if (!fromHistory && history.state?.viewer) {
    history.back();
  } else if (!fromHistory && location.hash.startsWith("#view=")) {
    history.replaceState(null, "", location.pathname);
  }
}

function openHashViewer(data) {
  if (!location.hash.startsWith("#view=") || !$("#viewer").hidden) return;
  const runId = decodeURIComponent(location.hash.slice("#view=".length));
  const run = data.runs.find((item) => item.id === runId && item.status === "ready");
  if (!run) return;
  if (spoilerMode && !revealedRuns.has(run.id)) return;
  const model = data.models.find((item) => item.id === run.modelId);
  openViewer(run, model?.label || modelLabels[run.modelId] || run.modelId, { pushHistory: false });
}

function setViewerScore(score) {
  activeViewerScore = String(score || "");
  $("#viewer-score-label").textContent = activeViewerScore ? `${activeViewerScore}/10` : "—";
  document.querySelectorAll(".score-button").forEach((button) => {
    const active = button.dataset.score === activeViewerScore;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
  });
}

async function saveRating(runId, score) {
  const cleanScore = String(score || "");
  const payload = {
    runId,
    score: cleanScore,
    strength: "",
    bug: "",
    verdict: ""
  };
  const response = await fetch("/api/rating", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(`Rating API error: ${response.status}`);
  applyRatingLocally(runId, cleanScore);
}

function applyRatingLocally(runId, score) {
  const cleanScore = String(score || "");

  if (arenaState) {
    const run = arenaState.runs.find((item) => item.id === runId);
    if (run) {
      run.rating = {
        ...(run.rating || {}),
        score: cleanScore
      };
    }
    renderReport(arenaState);
  }

  const escapedRunId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(runId) : runId.replaceAll('"', '\\"');
  const card = document.querySelector(`.run-card[data-run-id="${escapedRunId}"]`);
  if (card) {
    const input = $(".score-input", card);
    const metricScore = $(".metric-cell:last-child strong", card);
    if (input) input.value = cleanScore;
    if (metricScore) metricScore.textContent = cleanScore ? `${cleanScore}/10` : "—";
  }

  if (activeViewerRun?.id === runId) {
    activeViewerRun.rating = {
      ...(activeViewerRun.rating || {}),
      score: cleanScore
    };
    setViewerScore(cleanScore);
  }
}

async function openPrompt(test) {
  const viewer = $("#prompt-viewer");
  $("#prompt-title").textContent = test.title;
  $("#prompt-text").textContent = "Загружаю промпт...";
  $("#prompt-copy").textContent = "Копировать";
  viewer.hidden = false;

  try {
    const response = await fetch(`/api/prompt/${encodeURIComponent(test.id)}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`Prompt API error: ${response.status}`);
    const payload = await response.json();
    $("#prompt-title").textContent = payload.title || test.title;
    $("#prompt-text").textContent = payload.text || "Промпт пустой.";
  } catch (error) {
    $("#prompt-text").textContent = `Не удалось открыть промпт: ${error.message}`;
  }
}

function closePrompt() {
  $("#prompt-viewer").hidden = true;
  $("#prompt-text").textContent = "";
  $("#prompt-copy").textContent = "Копировать";
}

async function copyPrompt() {
  const text = $("#prompt-text").textContent;
  if (!text || text === "Загружаю промпт...") return;

  try {
    await navigator.clipboard.writeText(text);
    $("#prompt-copy").textContent = "Скопировано";
  } catch {
    const range = document.createRange();
    range.selectNodeContents($("#prompt-text"));
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    $("#prompt-copy").textContent = "Выделено";
  }

  setTimeout(() => {
    $("#prompt-copy").textContent = "Копировать";
  }, 1200);
}

function initViewerScoreButtons() {
  const root = $("#viewer-score-buttons");
  root.innerHTML = Array.from({ length: 10 }, (_, index) => {
    const value = String(index + 1);
    return `<button class="score-button" type="button" data-score="${value}">${value}</button>`;
  }).join("");
  root.addEventListener("click", (event) => {
    const button = event.target.closest(".score-button");
    if (!button) return;
    setViewerScore(button.dataset.score);
  });
}

function parseTokenNumber(value) {
  const raw = String(value || "").trim().toLowerCase().replaceAll(",", "");
  if (!raw || raw === "—") return 0;
  const target = raw.includes("=") ? raw.split("=").pop() : raw;
  const match = target.match(/~?\s*([\d.]+)\s*(k|m)\b/) || target.match(/^\s*([\d.]+)\s*(k|m)?\s*$/);
  if (!match) return Number(raw.replace(/[^0-9.]/g, "")) || 0;
  const base = Number(match[1]);
  const suffix = match[2];
  if (suffix === "m") return base * 1_000_000;
  if (suffix === "k") return base * 1_000;
  return base;
}

function formatTokenTotal(input, output) {
  const total = parseTokenNumber(input) + parseTokenNumber(output);
  if (!total) return "—";
  if (total >= 1_000_000) return `${(total / 1_000_000).toFixed(total >= 10_000_000 ? 0 : 1)}M`;
  if (total >= 1_000) return `${(total / 1_000).toFixed(total >= 100_000 ? 0 : 1)}k`;
  return String(Math.round(total));
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

$("#refresh").addEventListener("click", loadArena);
$("#spoiler-toggle").addEventListener("click", toggleSpoilerMode);
$("#report-collapse").addEventListener("click", hideReport);
$("#viewer-close").addEventListener("click", closeViewer);
$("#viewer-save-score").addEventListener("click", async () => {
  if (!activeViewerRun) return;
  await saveRating(activeViewerRun.id, activeViewerScore);
  $("#viewer-save-score").textContent = "Сохранено";
  setTimeout(() => {
    $("#viewer-save-score").textContent = "Сохранить";
  }, 1200);
});
$("#prompt-close").addEventListener("click", closePrompt);
$("#prompt-copy").addEventListener("click", copyPrompt);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("#viewer").hidden) closeViewer();
  if (event.key === "Escape" && !$("#prompt-viewer").hidden) closePrompt();
});
window.addEventListener("popstate", () => {
  if (!$("#viewer").hidden) {
    closeViewer({ fromHistory: true });
  }
});

initViewerScoreButtons();
loadArena().catch((error) => {
  $("#tasks").innerHTML = `<section class="task-block"><div class="task-head"><div><h2>Ошибка арены</h2><p>${escapeHtml(error.message)}</p></div></div></section>`;
});
