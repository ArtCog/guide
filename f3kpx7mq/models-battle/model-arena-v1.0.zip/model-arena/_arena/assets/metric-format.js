(function exposeMetricFormat(root) {
  function normalize(value) {
    const text = String(value ?? "").trim();
    return text || "—";
  }

  function compact(value, kind = "generic") {
    const normalized = normalize(value);
    if (normalized === "—") return normalized;
    let visible = normalized.replace(/\s*\([^)]*\).*$/, "").trim() || "—";

    if (kind === "time") {
      visible = visible
        .replace(/(\d+)\s*мин(?:ут[а-я]*)?/giu, "$1м")
        .replace(/(\d+)\s*сек(?:унд[а-я]*)?/giu, "$1с")
        .replace(/(\d+)\s*ч(?:ас[а-я]*)?/giu, "$1ч");

      const parts = visible.match(/~?\d+(?:[.,]\d+)?\s*(?:h|m|s|ч|м|с)/giu);
      if (parts && parts.length > 2 && /(?:h|ч)$/iu.test(parts[0])) {
        visible = parts.slice(0, 2).join(" ");
      }
    }

    return visible;
  }

  function tooltip(value) {
    return normalize(value);
  }

  const api = { compact, tooltip };
  root.ArenaMetricFormat = api;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
