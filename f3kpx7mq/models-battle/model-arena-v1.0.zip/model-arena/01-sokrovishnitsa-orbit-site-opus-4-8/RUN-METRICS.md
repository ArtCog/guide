# Метрики прогона

Тест: 01 — Сокровищница Орбит
Тип: многостраничный сайт магазина редких камней
Модель: Claude Opus 4.8
Статус: готово

Папка результата:
`C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-opus-4-8\`

Главный файл:
`C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-opus-4-8\index.html`

Метрики:
- Стоимость USD: $9.30
- Время API: 16м 58с
- Wall-время: 5ч 5м 28с
- Input tokens: 16,900
- Output tokens: 68,000
- Cache read: 3,500,000
- Cache write: 574,400

Источник:
`ОТЧЁТ-ТЕСТА-opus-4.8.md`

Короткий вердикт:
Заполнить после ручной оценки на арене.
