/* ============================================================
   Сокровищница Орбит — интерактив
   Корзина (localStorage), рендер каталога, drawer, заявка.
   ============================================================ */
(function () {
  "use strict";

  var STORE_KEY = "so_cart_v1";
  var items = window.SPECIMENS || [];
  var byId = {};
  items.forEach(function (it) { byId[it.id] = it; });

  /* --- Форматирование цены (доллары) ------------------------- */
  function money(n) {
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " $";
  }

  /* --- Хранилище корзины ------------------------------------- */
  function loadCart() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {}; }
    catch (e) { return {}; }
  }
  function saveCart(c) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(c)); } catch (e) {}
  }
  var cart = loadCart();

  function count() {
    var n = 0; for (var k in cart) n += cart[k]; return n;
  }
  function total() {
    var s = 0;
    for (var k in cart) { if (byId[k]) s += byId[k].price * cart[k]; }
    return s;
  }

  /* --- Разметка образца (переиспользуется везде) ------------- */
  function specimenHTML(it) {
    var extra = "";
    if (it.shape === "ceres") extra = '<span class="veins"></span>';
    if (it.shape === "europa" || it.shape === "enceladus") extra = '<span class="glow"></span>';
    return (
      '<div class="specimen">' +
        '<div class="stone shape-' + it.shape + ' stone-' + it.shape + '">' + extra + '</div>' +
      '</div>'
    );
  }

  /* --- Рендер каталога --------------------------------------- */
  function renderCatalog() {
    var grid = document.getElementById("catalog-grid");
    if (!grid) return;

    grid.innerHTML = items.map(function (it) {
      return (
        '<article class="card" data-origin="' + it.origin + '">' +
          '<div class="card__media">' +
            '<span class="card__lot">' + it.lot + '</span>' +
            specimenHTML(it) +
          '</div>' +
          '<div class="card__body">' +
            '<span class="card__origin">' + it.origin + '</span>' +
            '<h3 class="card__name">' + it.name + '</h3>' +
            '<span class="card__type">' + it.type + '</span>' +
            '<p class="card__desc">' + it.desc + '</p>' +
            '<div class="card__foot">' +
              '<span class="card__price">' + money(it.price) + '</span>' +
              '<button class="add-btn" data-add="' + it.id + '">В корзину</button>' +
            '</div>' +
          '</div>' +
        '</article>'
      );
    }).join("");

    grid.addEventListener("click", function (e) {
      var btn = e.target.closest("[data-add]");
      if (!btn) return;
      addToCart(btn.getAttribute("data-add"));
      btn.classList.add("added");
      btn.textContent = "Добавлено ✓";
      setTimeout(function () {
        btn.classList.remove("added");
        btn.textContent = "В корзину";
      }, 1400);
    });
  }

  /* --- Фильтры по происхождению ------------------------------ */
  function renderFilters() {
    var bar = document.getElementById("filters");
    if (!bar) return;
    var origins = ["Все"].concat(items.map(function (i) { return i.origin; })
      .filter(function (v, i, a) { return a.indexOf(v) === i; }));

    bar.innerHTML = origins.map(function (o, i) {
      return '<button class="chip" data-filter="' + o + '" aria-pressed="' + (i === 0) + '">' + o + '</button>';
    }).join("");

    bar.addEventListener("click", function (e) {
      var chip = e.target.closest("[data-filter]");
      if (!chip) return;
      var f = chip.getAttribute("data-filter");
      bar.querySelectorAll(".chip").forEach(function (c) {
        c.setAttribute("aria-pressed", c === chip);
      });
      document.querySelectorAll("#catalog-grid .card").forEach(function (card) {
        var show = (f === "Все") || (card.getAttribute("data-origin") === f);
        card.style.display = show ? "" : "none";
      });
    });
  }

  /* --- Операции с корзиной ----------------------------------- */
  function addToCart(id) { cart[id] = (cart[id] || 0) + 1; commit(); openDrawer(); }
  function setQty(id, q) {
    if (q <= 0) { delete cart[id]; } else { cart[id] = q; }
    commit();
  }
  function removeItem(id) { delete cart[id]; commit(); }
  function commit() { saveCart(cart); updateBadge(); renderDrawer(); }

  function updateBadge() {
    document.querySelectorAll("[data-cart-count]").forEach(function (el) {
      var n = count();
      el.textContent = n;
      el.setAttribute("data-empty", n === 0);
    });
  }

  /* --- Drawer корзины ---------------------------------------- */
  function buildDrawer() {
    if (document.getElementById("cart-drawer")) return;
    var html =
      '<div class="drawer-backdrop" id="cart-backdrop"></div>' +
      '<aside class="drawer" id="cart-drawer" role="dialog" aria-modal="true" aria-label="Корзина заявки">' +
        '<div class="drawer__head">' +
          '<h3>Заявка на приобретение</h3>' +
          '<button class="drawer__close" id="cart-close" aria-label="Закрыть">×</button>' +
        '</div>' +
        '<div class="drawer__body" id="cart-body"></div>' +
        '<div class="drawer__foot" id="cart-foot"></div>' +
      '</aside>';
    var wrap = document.createElement("div");
    wrap.innerHTML = html;
    while (wrap.firstChild) document.body.appendChild(wrap.firstChild);

    document.getElementById("cart-close").addEventListener("click", closeDrawer);
    document.getElementById("cart-backdrop").addEventListener("click", closeDrawer);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeDrawer(); });
  }

  function renderDrawer() {
    var body = document.getElementById("cart-body");
    var foot = document.getElementById("cart-foot");
    if (!body || !foot) return;

    var ids = Object.keys(cart);
    if (ids.length === 0) {
      body.innerHTML =
        '<div class="cart-empty">' +
          '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><circle cx="9" cy="10" r="1" fill="currentColor" stroke="none"/><circle cx="15" cy="10" r="1" fill="currentColor" stroke="none"/></svg>' +
          '<p>В заявке пока нет образцов.</p>' +
          '<p style="font-size:.82rem;margin-top:8px">Добавьте экспонаты из каталога, чтобы запросить частную покупку.</p>' +
        '</div>';
      foot.innerHTML = '<a class="btn btn--block" href="catalog.html">Перейти в каталог</a>';
      return;
    }

    body.innerHTML = ids.map(function (id) {
      var it = byId[id]; var q = cart[id];
      return (
        '<div class="cart-line">' +
          '<div class="cart-line__thumb">' + specimenHTML(it) + '</div>' +
          '<div>' +
            '<div class="cart-line__name">' + it.name + '</div>' +
            '<div class="cart-line__origin">' + it.origin + '</div>' +
            '<div class="cart-line__unit">' + money(it.price) + ' / шт.</div>' +
            '<div class="qty" style="margin-top:8px">' +
              '<button data-dec="' + id + '" aria-label="Меньше">−</button>' +
              '<span>' + q + '</span>' +
              '<button data-inc="' + id + '" aria-label="Больше">+</button>' +
            '</div>' +
          '</div>' +
          '<div class="cart-line__right">' +
            '<div class="cart-line__sum">' + money(it.price * q) + '</div>' +
            '<button class="cart-line__remove" data-rm="' + id + '">Убрать</button>' +
          '</div>' +
        '</div>'
      );
    }).join("");

    foot.innerHTML =
      '<div class="cart-total"><span>Итого</span><b>' + money(total()) + '</b></div>' +
      '<p class="cart-note">Оформление проходит через личного консультанта: цена фиксируется, подлинность подтверждается сертификатом, доставка страхуется.</p>' +
      '<button class="btn btn--block" id="request-btn">Запросить частную покупку</button>';

    // делегирование внутри тела
    body.querySelectorAll("[data-inc]").forEach(function (b) {
      b.onclick = function () { setQty(b.dataset.inc, cart[b.dataset.inc] + 1); };
    });
    body.querySelectorAll("[data-dec]").forEach(function (b) {
      b.onclick = function () { setQty(b.dataset.dec, cart[b.dataset.dec] - 1); };
    });
    body.querySelectorAll("[data-rm]").forEach(function (b) {
      b.onclick = function () { removeItem(b.dataset.rm); };
    });
    var req = document.getElementById("request-btn");
    if (req) req.onclick = submitRequest;
  }

  function openDrawer() {
    buildDrawer(); renderDrawer();
    document.getElementById("cart-backdrop").classList.add("open");
    document.getElementById("cart-drawer").classList.add("open");
    document.body.style.overflow = "hidden";
  }
  function closeDrawer() {
    var b = document.getElementById("cart-backdrop"), d = document.getElementById("cart-drawer");
    if (b) b.classList.remove("open");
    if (d) d.classList.remove("open");
    document.body.style.overflow = "";
  }

  /* --- Заявка (мок-подтверждение) ---------------------------- */
  function submitRequest() {
    var ref = "СО-" + new Date().getFullYear() + "-" +
      Math.floor(1000 + Math.random() * 9000);
    cart = {}; commit(); closeDrawer();
    showModal(ref);
  }

  function showModal(ref) {
    var m = document.getElementById("req-modal");
    if (!m) {
      var html =
        '<div class="modal-backdrop" id="req-modal">' +
          '<div class="modal" role="dialog" aria-modal="true">' +
            '<svg class="seal" viewBox="0 0 24 24" fill="none" stroke="#c9a86a" stroke-width="1.2"><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg>' +
            '<h3>Заявка принята</h3>' +
            '<p>Личный консультант «Сокровищницы Орбит» свяжется с вами в течение одного рабочего дня для подтверждения и организации закрытого показа.</p>' +
            '<div class="ref" id="req-ref"></div>' +
            '<button class="btn btn--block" id="modal-close">Понятно</button>' +
          '</div>' +
        '</div>';
      var wrap = document.createElement("div");
      wrap.innerHTML = html;
      document.body.appendChild(wrap.firstChild);
      m = document.getElementById("req-modal");
      document.getElementById("modal-close").addEventListener("click", function () {
        m.classList.remove("open"); document.body.style.overflow = "";
      });
      m.addEventListener("click", function (e) {
        if (e.target === m) { m.classList.remove("open"); document.body.style.overflow = ""; }
      });
    }
    document.getElementById("req-ref").textContent = "Номер заявки: " + ref;
    m.classList.add("open");
    document.body.style.overflow = "hidden";
  }

  /* --- Витрина на главной ------------------------------------ */
  function renderShowcase() {
    var slot = document.getElementById("showcase-stone");
    if (!slot) return;
    var featured = byId["psyche-iron"]; // самый дорогой лот
    slot.innerHTML = specimenHTML(featured);
    var cap = document.getElementById("showcase-caption");
    if (cap) {
      cap.innerHTML =
        '<div><span class="origin">' + featured.origin + '</span>' +
        '<h3>' + featured.name + '</h3>' +
        '<span class="card__type">' + featured.type + '</span></div>' +
        '<span class="price">' + money(featured.price) + '</span>';
    }
    var lot = document.getElementById("showcase-lot");
    if (lot) lot.textContent = featured.lot + " · Экспонат недели";
  }

  /* --- Мини-каталог на главной (3 избранных) ----------------- */
  function renderHighlights() {
    var grid = document.getElementById("highlights-grid");
    if (!grid) return;
    var picks = ["luna-shard", "europa-opal", "titan-amber"].map(function (id) { return byId[id]; });
    grid.innerHTML = picks.map(function (it) {
      return (
        '<article class="card">' +
          '<div class="card__media"><span class="card__lot">' + it.lot + '</span>' + specimenHTML(it) + '</div>' +
          '<div class="card__body">' +
            '<span class="card__origin">' + it.origin + '</span>' +
            '<h3 class="card__name">' + it.name + '</h3>' +
            '<span class="card__type">' + it.type + '</span>' +
            '<div class="card__foot">' +
              '<span class="card__price">' + money(it.price) + '</span>' +
              '<button class="add-btn" data-add="' + it.id + '">В корзину</button>' +
            '</div>' +
          '</div>' +
        '</article>'
      );
    }).join("");
    grid.addEventListener("click", function (e) {
      var btn = e.target.closest("[data-add]");
      if (!btn) return;
      addToCart(btn.getAttribute("data-add"));
      btn.classList.add("added"); btn.textContent = "Добавлено ✓";
      setTimeout(function () { btn.classList.remove("added"); btn.textContent = "В корзину"; }, 1400);
    });
  }

  /* --- Мобильное меню ---------------------------------------- */
  function initMobileNav() {
    var burger = document.getElementById("burger");
    var nav = document.getElementById("mobile-nav");
    if (!burger || !nav) return;
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      document.body.style.overflow = open ? "hidden" : "";
    });
    nav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        nav.classList.remove("open"); document.body.style.overflow = "";
      });
    });
  }

  /* --- Форма контактов --------------------------------------- */
  function initContactForm() {
    var form = document.getElementById("contact-form");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var status = document.getElementById("form-status");
      status.textContent = "Спасибо. Ваше сообщение получено — консультант ответит в течение рабочего дня.";
      form.reset();
    });
  }

  /* --- Подключение кнопки корзины в шапке -------------------- */
  function initCartButtons() {
    document.querySelectorAll("[data-open-cart]").forEach(function (b) {
      b.addEventListener("click", function (e) { e.preventDefault(); openDrawer(); });
    });
  }

  /* --- Инициализация ----------------------------------------- */
  document.addEventListener("DOMContentLoaded", function () {
    buildDrawer();
    updateBadge();
    renderCatalog();
    renderFilters();
    renderShowcase();
    renderHighlights();
    renderDrawer();
    initCartButtons();
    initMobileNav();
    initContactForm();
  });
})();
