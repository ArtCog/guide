# RUN-METRICS — тест 05 «YouTube-планировщик»

| Поле | Значение |
|---|---|
| Модель | Claude Opus 4.8 (`claude-opus-4-8`), Claude Code |
| Тест | 05 — ремонт сломанного YouTube-планировщика |
| Время задачи | 11m 29s |
| Input tokens | 17.9k |
| Output tokens | 51.4k |
| Cache read | 2.4m |
| Cache write | 400.0k |
| Стоимость USD | $6.55 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\05-youtube-structure-planner-opus-4-8\index.html` |

**Источник времени:** ручная фиксация после завершения теста.

**Примечание по стоимости и токенам:** метрики токенов и USD для теста 05
оценочные, потому что счетчик сессии был загрязнен предыдущими задачами после
очистки истории. Для этого теста валиднее сравнивать время задачи и качество
ремонта.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $36.02 / 86.5k input / 368.6k output / 19.2m cache read / 1.7m cache write.
- Previous checkpoint: $29.47 / 69.7k input / 317.2k output / 16.8m cache read / 1.3m cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
