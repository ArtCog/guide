/* =====================================================================
   ЛИСЁНОК И КРИСТАЛЛЫ — оригинальный Mario-like платформер
   Чистый Canvas / JS, без внешних ассетов. Все спрайты рисуются кодом.
   ===================================================================== */
'use strict';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const CW = canvas.width;   // 960
const CH = canvas.height;  // 540

/* ---------------------- Константы мира и физики --------------------- */
const TILE = 40;
const ROWS = 15;
let   COLS = 230;                 // ширина уровня в тайлах (задаётся при сборке)
const GRAVITY   = 2100;           // px/s^2
const MAX_RUN   = 255;            // максимальная горизонтальная скорость
const RUN_ACCEL = 2100;
const RUN_DECEL = 1900;
const AIR_ACCEL = 1400;
const JUMP_V    = 720;            // стартовая скорость прыжка (вверх)
const JUMP_CUT  = 250;            // "обрезка" при отпускании — переменная высота
const COYOTE    = 0.09;           // окно coyote-time, сек
const JBUFFER   = 0.12;           // окно jump-buffer, сек
const ENEMY_SPD = 62;
const POWER_SPD = 78;
const START_TIME = 200;           // отсчёт времени на уровень

let worldW = COLS * TILE;
let worldH = ROWS * TILE;

/* ------------------------- Коды тайлов ------------------------------ */
const T = { EMPTY:0, GROUND:1, DIRT:2, BRICK:3, QUESTION:4, QUSED:5, PIPE:6, PLATFORM:7, STAIR:8 };
const SOLID = new Set([T.GROUND, T.DIRT, T.BRICK, T.QUESTION, T.QUSED, T.PIPE, T.PLATFORM, T.STAIR]);

/* --------------------------- Игровые данные ------------------------- */
let grid = [];                    // grid[row][col]
let blocks = new Map();           // "c,r" -> {c,r,type,item,used,anim}
let coins = [];                   // собираемые кристаллы
let enemies = [];                 // враги
let enemySpawns = [];             // исходные позиции врагов (для респавна)
let powerups = [];                // выпавшие бонусы (плоды роста)
let particles = [];               // визуальные эффекты
let flag = null;                  // финиш

const player = {
  x:0, y:0, w:30, h:38, vx:0, vy:0,
  dir:1, onGround:false, big:false,
  coyote:0, jbuf:0, jumpHeld:false, jumping:false,
  invuln:0, animT:0, squash:1, isPlayer:true,
  spawnX:0, spawnY:0
};

let gems = 0;
let lives = 3;
let timeLeft = START_TIME;

/* ------------------------- Состояния игры --------------------------- */
const S = { MENU:'menu', PLAY:'play', WIN:'win', LOSE:'lose' };
let state = S.MENU;
let camX = 0, camY = 0;
let globalT = 0;                  // общее время для анимаций фона

/* ============================ ВВОД ================================== */
const keys = new Set();
const JUMP_KEYS = new Set(['Space','ArrowUp','KeyW']);
const LEFT_KEYS = new Set(['ArrowLeft','KeyA']);
const RIGHT_KEYS = new Set(['ArrowRight','KeyD']);

window.addEventListener('keydown', (e) => {
  ensureAudio();
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.repeat) return;

  if (JUMP_KEYS.has(e.code)) {
    if (state === S.PLAY) player.jbuf = JBUFFER;
    else if (state === S.MENU) startGame();
    else if (state === S.WIN || state === S.LOSE) startGame();
  }
  if (e.code === 'Enter' && state !== S.PLAY) startGame();
  if (e.code === 'KeyR') { if (state === S.PLAY) softRestart(); else startGame(); }
  if (e.code === 'KeyM') { muted = !muted; }

  keys.add(e.code);
});
window.addEventListener('keyup', (e) => keys.delete(e.code));

function isDown(set){ for (const k of set) if (keys.has(k)) return true; return false; }

/* ============================ ЗВУК ================================== */
/* Все звуки синтезируются WebAudio — ни одного внешнего файла. */
let actx = null, muted = false;
function ensureAudio(){
  if (!actx){
    try { actx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e){ actx = null; }
  }
  if (actx && actx.state === 'suspended') actx.resume();
}
function beep(freq, dur, type='square', vol=0.15, slideTo=null){
  if (!actx || muted) return;
  const t0 = actx.currentTime;
  const o = actx.createOscillator();
  const g = actx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  g.gain.setValueAtTime(vol, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(actx.destination);
  o.start(t0); o.stop(t0 + dur);
}
const sfxJump  = () => beep(440, 0.14, 'square', 0.14, 760);
const sfxCoin  = () => { beep(880, 0.07, 'square', 0.16); setTimeout(()=>beep(1320,0.1,'square',0.16),60); };
const sfxStomp = () => beep(180, 0.12, 'sawtooth', 0.18, 90);
const sfxBump  = () => beep(150, 0.08, 'square', 0.14, 110);
const sfxPower = () => { beep(520,0.09,'square',0.16); setTimeout(()=>beep(700,0.09,'square',0.16),90); setTimeout(()=>beep(950,0.12,'square',0.16),180); };
const sfxDie   = () => { beep(400,0.15,'sawtooth',0.2,120); setTimeout(()=>beep(200,0.3,'sawtooth',0.2,80),150); };
const sfxWin   = () => { const n=[523,659,784,1047]; n.forEach((f,i)=>setTimeout(()=>beep(f,0.16,'square',0.18),i*140)); };

/* ======================= ПОСТРОЕНИЕ УРОВНЯ ========================== */
function setTile(c, r, t){ if (r>=0 && r<ROWS && c>=0 && c<COLS) grid[r][c] = t; }
function fillRect(c0, r0, c1, r1, t){ for (let r=r0;r<=r1;r++) for (let c=c0;c<=c1;c++) setTile(c,r,t); }
function ground(c0, c1){                       // земля: трава сверху, грунт ниже
  for (let c=c0;c<=c1;c++){ setTile(c,13,T.GROUND); setTile(c,14,T.DIRT); }
}
function platform(c0, c1, r){ for (let c=c0;c<=c1;c++) setTile(c,r,T.PLATFORM); }
function addBrick(c, r){ setTile(c,r,T.BRICK); blocks.set(c+','+r, {c,r,type:'brick', item:null, used:false, anim:0}); }
function addQuestion(c, r, item='gem'){ setTile(c,r,T.QUESTION); blocks.set(c+','+r, {c,r,type:'question', item, used:false, anim:0}); }
function addCoin(c, r){ coins.push({ x:c*TILE+TILE/2, y:r*TILE+TILE/2, r:11, taken:false, bob:Math.random()*Math.PI*2 }); }
function addCoinRow(c0, c1, r){ for (let c=c0;c<=c1;c++) addCoin(c,r); }
function addEnemy(c, rTop){                     // rTop — строка, на которой стоит враг
  const e = { x:c*TILE+5, y:rTop*TILE - 34, w:30, h:34, vx:-ENEMY_SPD, vy:0, alive:true, dead:0, type:'slime' };
  enemies.push(e);
  enemySpawns.push({ x:e.x, y:e.y });
}

function buildLevel(){
  COLS = 230; worldW = COLS*TILE; worldH = ROWS*TILE;
  grid = Array.from({length:ROWS}, () => new Array(COLS).fill(T.EMPTY));
  blocks.clear(); coins = []; enemies = []; enemySpawns = []; powerups = []; particles = [];

  // --- Пол с ямами (ямы = разрывы) ---
  const runs = [[0,27],[33,69],[75,94],[102,149],[155,179],[186,229]];
  runs.forEach(([a,b]) => ground(a,b));
  // Ямы получаются в промежутках: 28–32, 70–74, 95–101, 150–154, 180–185

  // --- Левая стена, чтобы не уйти за экран ---
  fillRect(0,0,0,14,T.DIRT);

  // --- Секция 1: обучающие кристаллы + блоки ---
  addCoinRow(6, 9, 10);
  addBrick(12, 8);
  addQuestion(13, 8, 'gem');
  addQuestion(14, 8, 'fruit');     // первый бонус роста
  addBrick(15, 8);
  addEnemy(22, 13);

  // --- Секция 2: лесенка вверх с кристаллами над первой ямой ---
  platform(24, 25, 11);
  platform(26, 27, 9);
  addCoinRow(24, 27, 8);           // кристаллы-дуга над ямой 28–32
  addCoin(29, 6); addCoin(30, 5); addCoin(31, 6);

  // --- Секция 3: враг + плавающие блоки ---
  addEnemy(50, 13);
  addQuestion(56, 8, 'gem');
  addBrick(57, 8);
  addBrick(58, 8);
  addQuestion(59, 8, 'fruit');
  addCoinRow(55, 60, 6);
  // труба-препятствие
  fillRect(64,11,65,12,T.PIPE);
  addCoin(70,10); addCoin(72,9); addCoin(74,10);   // над ямой 70–74

  // --- Секция 4: враг + широкая яма 95–101 со ступеньками ---
  addEnemy(84, 13);
  platform(96, 97, 10);
  platform(99, 100, 9);
  addCoin(96,8); addCoin(97,8); addCoin(99,7); addCoin(100,7);

  // --- Секция 5: парные враги + высокие платформы ---
  addEnemy(120, 13);
  addEnemy(123, 13);
  platform(128, 131, 9);
  addCoinRow(128, 131, 8);
  addQuestion(134, 8, 'gem');
  addBrick(135, 8);
  addQuestion(136, 8, 'gem');

  // --- Секция 6: яма 150–154 + одиночная платформа посередине ---
  platform(151, 153, 10);
  addCoin(151,9); addCoin(152,8); addCoin(153,9);
  addEnemy(165, 13);

  // --- Секция 7: яма 180–185 + разбег к финалу ---
  platform(181, 184, 11);
  addCoinRow(181, 184, 10);
  addEnemy(200, 13);

  // --- Финальная лестница (как в классике) + флаг ---
  for (let i=0;i<6;i++) fillRect(210+i, 12-i, 210+i, 12, T.STAIR);
  addCoin(208,10); addCoin(207,9);
  flag = { c:220, x:220*TILE, baseR:12 };  // шест финиша

  // --- Спавн игрока ---
  player.spawnX = 3*TILE;
  player.spawnY = 13*TILE - player.h;
}

/* ==================== КОЛЛИЗИИ С ТАЙЛАМИ ============================ */
function tileSolidAt(c, r){
  if (r < 0 || r >= ROWS) return false;   // выше/ниже мира — не твёрдо
  if (c < 0) return true;                 // левая граница мира
  if (c >= COLS) return false;
  return SOLID.has(grid[r][c]);
}

function collideX(e){
  const r0 = Math.floor(e.y / TILE);
  const r1 = Math.floor((e.y + e.h - 1) / TILE);
  e.hitWall = false;
  if (e.vx > 0){
    const c = Math.floor((e.x + e.w - 1) / TILE);
    for (let r=r0;r<=r1;r++) if (tileSolidAt(c,r)){ e.x = c*TILE - e.w; e.vx = 0; e.hitWall = true; break; }
  } else if (e.vx < 0){
    const c = Math.floor(e.x / TILE);
    for (let r=r0;r<=r1;r++) if (tileSolidAt(c,r)){ e.x = (c+1)*TILE; e.vx = 0; e.hitWall = true; break; }
  }
}

function collideY(e){
  const c0 = Math.floor(e.x / TILE);
  const c1 = Math.floor((e.x + e.w - 1) / TILE);
  e.onGround = false;
  if (e.vy > 0){
    const r = Math.floor((e.y + e.h) / TILE);   // detect floor on contact (no penetration needed)
    for (let c=c0;c<=c1;c++) if (tileSolidAt(c,r)){ e.y = r*TILE - e.h; e.vy = 0; e.onGround = true; break; }
  } else if (e.vy < 0){
    const r = Math.floor(e.y / TILE);
    for (let c=c0;c<=c1;c++) if (tileSolidAt(c,r)){
      e.y = (r+1)*TILE; e.vy = 0;
      if (e.isPlayer) tryHitBlock(c, r);   // удар головой снизу
      break;
    }
  }
}

/* Удар по блоку снизу */
function tryHitBlock(c, r){
  const key = c+','+r;
  const b = blocks.get(key);
  if (!b) return;
  if (b.type === 'question'){
    if (b.used) return;
    b.used = true; b.anim = 1;
    setTile(c, r, T.QUSED);
    if (b.item === 'fruit'){
      // выпадает плод роста
      powerups.push({ x:c*TILE+6, y:r*TILE-2, w:28, h:28, vx:POWER_SPD, vy:-120, rise:TILE, ry:0 });
      sfxBump();
    } else {
      gems++; sfxCoin();
      spawnGemPop(c*TILE+TILE/2, r*TILE);
    }
  } else if (b.type === 'brick'){
    b.anim = 1;
    if (player.big){                 // большой герой ломает кирпич
      setTile(c, r, T.EMPTY);
      blocks.delete(key);
      spawnShards(c*TILE+TILE/2, r*TILE+TILE/2);
      sfxBump();
    } else {
      sfxBump();
    }
  }
}

/* ========================= ЭФФЕКТЫ / ЧАСТИЦЫ ======================== */
function spawnGemPop(x, y){
  particles.push({ x, y, vx:0, vy:-220, life:0.6, max:0.6, type:'gempop', size:12 });
  for (let i=0;i<8;i++)
    particles.push({ x, y, vx:(Math.random()-0.5)*160, vy:-Math.random()*180-40, life:0.5, max:0.5, type:'spark', size:3+Math.random()*3, color:'#ffe27a' });
}
function spawnShards(x, y){
  for (let i=0;i<10;i++)
    particles.push({ x, y, vx:(Math.random()-0.5)*260, vy:-Math.random()*260-60, life:0.7, max:0.7, type:'shard', size:4+Math.random()*4, color:'#c66a2e', grav:true });
}
function spawnPuff(x, y, color='#fff'){
  for (let i=0;i<12;i++)
    particles.push({ x, y, vx:(Math.random()-0.5)*220, vy:(Math.random()-0.5)*220, life:0.5, max:0.5, type:'puff', size:4+Math.random()*4, color });
}

/* ============================ ОБНОВЛЕНИЕ =========================== */
function update(dt){
  globalT += dt;
  if (state !== S.PLAY) return;

  // --- время уровня ---
  timeLeft -= dt;
  if (timeLeft <= 0){ timeLeft = 0; killPlayer(); return; }

  updatePlayer(dt);
  updateEnemies(dt);
  updatePowerups(dt);
  updateCoins(dt);
  updateParticles(dt);
  updateBlocksAnim(dt);
  updateCamera();

  // --- проверка финиша ---
  if (player.x + player.w/2 >= flag.x){ winGame(); }
}

function updatePlayer(dt){
  const p = player;
  p.animT += dt;
  if (p.invuln > 0) p.invuln -= dt;

  // горизонтальный ввод
  let dir = 0;
  if (isDown(LEFT_KEYS))  dir -= 1;
  if (isDown(RIGHT_KEYS)) dir += 1;

  const accel = p.onGround ? RUN_ACCEL : AIR_ACCEL;
  if (dir !== 0){
    p.vx += dir * accel * dt;
    p.vx = Math.max(-MAX_RUN, Math.min(MAX_RUN, p.vx));
    p.dir = dir;
  } else if (p.onGround){
    // трение
    if (p.vx > 0) p.vx = Math.max(0, p.vx - RUN_DECEL*dt);
    else if (p.vx < 0) p.vx = Math.min(0, p.vx + RUN_DECEL*dt);
  }

  // прыжок: coyote + буфер + переменная высота
  p.jumpHeld = isDown(JUMP_KEYS);
  if (p.onGround) p.coyote = COYOTE; else p.coyote = Math.max(0, p.coyote - dt);
  if (p.jbuf > 0) p.jbuf -= dt;

  if (p.jbuf > 0 && p.coyote > 0){
    p.vy = -JUMP_V; p.onGround = false; p.jumping = true;
    p.coyote = 0; p.jbuf = 0; p.squash = 1.35;
    sfxJump();
  }
  if (p.jumping && !p.jumpHeld && p.vy < -JUMP_CUT){ p.vy = -JUMP_CUT; }  // обрезка
  if (p.vy >= 0) p.jumping = false;

  // гравитация
  p.vy += GRAVITY * dt;
  if (p.vy > 1200) p.vy = 1200;

  // движение + коллизии по осям
  const wasAir = !p.onGround;
  p.x += p.vx * dt; collideX(p);
  p.y += p.vy * dt; collideY(p);

  if (p.onGround && wasAir) p.squash = 0.7;         // приземление — сплющивание
  p.squash += (1 - p.squash) * Math.min(1, dt*14); // возврат к норме

  // столкновения с врагами
  for (const e of enemies){
    if (!e.alive) continue;
    if (aabb(p, e)){
      const stomping = p.vy > 0 && (p.y + p.h) - e.y < 20;
      if (stomping){
        e.alive = false; e.dead = 0.4;
        p.vy = -JUMP_V*0.55; p.jumping = true;
        spawnPuff(e.x+e.w/2, e.y+e.h/2, '#9be36b');
        gems += 1; sfxStomp();
      } else {
        hurtPlayer();
      }
    }
  }

  // бонусы-плоды
  for (const pw of powerups){
    if (pw.dead) continue;
    if (aabb(p, pw)){ pw.dead = true; growPlayer(); }
  }

  // падение в яму
  if (p.y > worldH + 60){ killPlayer(); }
}

function growPlayer(){
  const p = player;
  if (!p.big){ p.big = true; p.h = 54; p.y -= 16; }
  p.invuln = 0.6;
  sfxPower();
  spawnPuff(p.x+p.w/2, p.y+p.h/2, '#ff9de0');
}
function shrinkPlayer(){
  const p = player;
  p.big = false; p.h = 38;
  p.invuln = 1.4;
  sfxDie();
}

function hurtPlayer(){
  const p = player;
  if (p.invuln > 0) return;
  if (p.big){ shrinkPlayer(); spawnPuff(p.x+p.w/2, p.y+p.h/2, '#ffd1a1'); }
  else killPlayer();
}

function killPlayer(){
  lives--;
  sfxDie();
  spawnPuff(player.x+player.w/2, player.y+player.h/2, '#ffd1a1');
  if (lives <= 0){ state = S.LOSE; }
  else respawn();
}

function respawn(){
  const p = player;
  p.x = p.spawnX; p.y = p.spawnY;
  p.vx = 0; p.vy = 0; p.big = false; p.h = 38;
  p.invuln = 1.6; p.dir = 1;
  timeLeft = START_TIME;
  // враги — на исходные позиции
  enemies.forEach((e, i) => {
    e.alive = true; e.dead = 0;
    e.x = enemySpawns[i].x; e.y = enemySpawns[i].y;
    e.vx = -ENEMY_SPD; e.vy = 0;
  });
  powerups = [];
  camX = 0;
}

function updateEnemies(dt){
  for (const e of enemies){
    if (!e.alive){ if (e.dead > 0) e.dead -= dt; continue; }
    // гравитация
    e.vy += GRAVITY * dt;
    e.x += e.vx * dt; collideX(e);
    if (e.hitWall) e.vx = -e.vx;              // разворот у стены
    e.y += e.vy * dt; collideY(e);

    // разворот у края платформы (чтобы не падали)
    if (e.onGround){
      const aheadC = Math.floor((e.vx > 0 ? e.x + e.w + 2 : e.x - 2) / TILE);
      const belowR = Math.floor((e.y + e.h + 2) / TILE);
      if (!tileSolidAt(aheadC, belowR)) e.vx = -e.vx;
    }
  }
}

function updatePowerups(dt){
  for (const pw of powerups){
    if (pw.dead) continue;
    if (pw.rise > 0){                          // фаза "выезда" из блока
      const step = Math.min(pw.rise, 60*dt);
      pw.y -= step; pw.rise -= step;
      continue;
    }
    pw.vy += GRAVITY * dt;
    pw.x += pw.vx * dt; collideX(pw);
    if (pw.hitWall) pw.vx = -pw.vx;
    pw.y += pw.vy * dt; collideY(pw);
  }
  powerups = powerups.filter(pw => !pw.dead && pw.y < worldH + 100);
}

function updateCoins(dt){
  const p = player;
  for (const c of coins){
    if (c.taken) continue;
    c.bob += dt*4;
    if (Math.abs((p.x+p.w/2)-c.x) < 24 && Math.abs((p.y+p.h/2)-c.y) < 26){
      c.taken = true; gems++; sfxCoin();
      spawnGemPop(c.x, c.y);
    }
  }
}

function updateParticles(dt){
  for (const pt of particles){
    pt.life -= dt;
    pt.x += pt.vx*dt; pt.y += pt.vy*dt;
    if (pt.grav) pt.vy += GRAVITY*dt;
    if (pt.type === 'gempop') pt.vy += 700*dt;   // подпрыгивает и падает
  }
  particles = particles.filter(pt => pt.life > 0);
}

function updateBlocksAnim(dt){
  for (const b of blocks.values()) if (b.anim > 0) b.anim = Math.max(0, b.anim - dt*4);
}

function updateCamera(){
  const targetX = player.x + player.w/2 - CW*0.4;
  camX += (targetX - camX) * 0.14;
  camX = Math.max(0, Math.min(worldW - CW, camX));
  const targetY = player.y + player.h/2 - CH*0.6;
  camY += (targetY - camY) * 0.1;
  camY = Math.max(0, Math.min(worldH - CH, camY));
}

function aabb(a, b){
  return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;
}

/* =============== УПРАВЛЕНИЕ СОСТОЯНИЯМИ ИГРЫ ======================== */
function startGame(){
  ensureAudio();
  buildLevel();
  gems = 0; lives = 3; timeLeft = START_TIME;
  const p = player;
  p.x = p.spawnX; p.y = p.spawnY; p.vx = 0; p.vy = 0;
  p.big = false; p.h = 38; p.invuln = 0; p.dir = 1; p.animT = 0;
  camX = 0; camY = 0;
  state = S.PLAY;
}
function softRestart(){                 // рестарт текущего уровня (клавиша R)
  buildLevel();
  gems = 0; timeLeft = START_TIME;
  const p = player;
  p.x = p.spawnX; p.y = p.spawnY; p.vx = 0; p.vy = 0;
  p.big = false; p.h = 38; p.invuln = 0;
  camX = 0;
}
function winGame(){ state = S.WIN; sfxWin(); }

/* ============================ ОТРИСОВКА ============================ */
function render(){
  ctx.setTransform(1,0,0,1,0,0);
  drawSky();
  drawParallax();

  ctx.save();
  ctx.translate(-Math.round(camX), -Math.round(camY));
  drawTiles();
  drawCoins();
  drawPowerups();
  drawFlag();
  drawEnemies();
  drawPlayer();
  drawParticles();
  ctx.restore();

  if (state === S.MENU) drawMenu();
  else if (state === S.WIN) drawWin();
  else if (state === S.LOSE) drawLose();

  updateHud();
}

function drawSky(){
  const g = ctx.createLinearGradient(0,0,0,CH);
  g.addColorStop(0, '#7ec6ff');
  g.addColorStop(0.55, '#bfe4ff');
  g.addColorStop(1, '#e9f6ff');
  ctx.fillStyle = g;
  ctx.fillRect(0,0,CW,CH);
}

function drawParallax(){
  // дальние холмы
  ctx.save();
  const hx = -(camX*0.25) % 640;
  for (let i=-1;i<3;i++){
    const bx = hx + i*640;
    ctx.fillStyle = '#8fd18a';
    hill(bx+80, CH-70, 260, 130);
    ctx.fillStyle = '#7bc177';
    hill(bx+420, CH-60, 320, 150);
  }
  ctx.restore();

  // облака
  ctx.save();
  ctx.globalAlpha = 0.9;
  const cx = -(camX*0.4) % 500;
  for (let i=-1;i<4;i++){
    const bx = cx + i*500;
    cloud(bx+60, 80 + 10*Math.sin(globalT*0.5+i));
    cloud(bx+300, 130 + 8*Math.sin(globalT*0.4+i*2));
  }
  ctx.restore();
}
function hill(x, baseY, w, h){
  ctx.beginPath();
  ctx.moveTo(x - w/2, baseY);
  ctx.quadraticCurveTo(x, baseY - h, x + w/2, baseY);
  ctx.closePath(); ctx.fill();
}
function cloud(x, y){
  ctx.fillStyle = 'rgba(255,255,255,0.92)';
  ctx.beginPath();
  ctx.arc(x, y, 22, 0, 7); ctx.arc(x+26, y+6, 28, 0, 7);
  ctx.arc(x+58, y, 20, 0, 7); ctx.arc(x+30, y-12, 22, 0, 7);
  ctx.fill();
}

function drawTiles(){
  const c0 = Math.max(0, Math.floor(camX/TILE));
  const c1 = Math.min(COLS-1, Math.ceil((camX+CW)/TILE));
  for (let r=0;r<ROWS;r++){
    for (let c=c0;c<=c1;c++){
      const t = grid[r][c];
      if (t === T.EMPTY) continue;
      const x = c*TILE, y = r*TILE;
      const b = blocks.get(c+','+r);
      const oy = b && b.anim>0 ? -Math.sin(b.anim*Math.PI)*10 : 0;
      drawTile(t, x, y+oy);
    }
  }
}

function drawTile(t, x, y){
  switch(t){
    case T.GROUND: {
      ctx.fillStyle = '#6b4a2b'; ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = '#4caf50'; ctx.fillRect(x, y, TILE, 12);
      ctx.fillStyle = '#3d8b40'; ctx.fillRect(x, y+10, TILE, 3);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(x+6, y+18, 5, 5); ctx.fillRect(x+24, y+27, 6, 5);
      break;
    }
    case T.DIRT: {
      ctx.fillStyle = '#5c3f24'; ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(x+8, y+8, 6, 6); ctx.fillRect(x+26, y+22, 6, 6);
      break;
    }
    case T.PLATFORM: {
      roundRect(x+1, y+2, TILE-2, TILE-8, 7);
      ctx.fillStyle = '#c98b4a'; ctx.fill();
      ctx.fillStyle = '#e8b57a'; ctx.fillRect(x+3, y+4, TILE-6, 6);
      ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 2; ctx.stroke();
      break;
    }
    case T.STAIR: {
      ctx.fillStyle = '#b07a3f'; ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = '#d9a561'; ctx.fillRect(x+2, y+2, TILE-4, 8);
      ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth=2; ctx.strokeRect(x+1,y+1,TILE-2,TILE-2);
      break;
    }
    case T.BRICK: {
      ctx.fillStyle = '#c1663a'; ctx.fillRect(x, y, TILE, TILE);
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 2;
      ctx.strokeRect(x+1,y+1,TILE-2,TILE-2);
      ctx.beginPath();
      ctx.moveTo(x, y+TILE/2); ctx.lineTo(x+TILE, y+TILE/2);
      ctx.moveTo(x+TILE/2, y); ctx.lineTo(x+TILE/2, y+TILE/2);
      ctx.moveTo(x+TILE/4, y+TILE/2); ctx.lineTo(x+TILE/4, y+TILE);
      ctx.moveTo(x+3*TILE/4, y+TILE/2); ctx.lineTo(x+3*TILE/4, y+TILE);
      ctx.stroke();
      break;
    }
    case T.QUESTION: {
      const pulse = 0.5 + 0.5*Math.sin(globalT*4);
      ctx.fillStyle = '#f0b429'; ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = `rgba(255,255,255,${0.25+0.25*pulse})`;
      ctx.fillRect(x+3, y+3, TILE-6, TILE-6);
      ctx.strokeStyle = '#7a4e00'; ctx.lineWidth = 3; ctx.strokeRect(x+2,y+2,TILE-4,TILE-4);
      ctx.fillStyle = '#7a4e00';
      ctx.font = 'bold 24px Segoe UI'; ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.fillText('?', x+TILE/2, y+TILE/2+1);
      // блики-заклёпки
      ctx.fillStyle = '#7a4e00';
      [[6,6],[TILE-6,6],[6,TILE-6],[TILE-6,TILE-6]].forEach(([dx,dy])=>{
        ctx.fillRect(x+dx-2, y+dy-2, 4, 4);
      });
      break;
    }
    case T.QUSED: {
      ctx.fillStyle = '#9a7b3a'; ctx.fillRect(x, y, TILE, TILE);
      ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 3; ctx.strokeRect(x+2,y+2,TILE-4,TILE-4);
      break;
    }
    case T.PIPE: {
      ctx.fillStyle = '#2fa85a'; ctx.fillRect(x, y, TILE, TILE);
      ctx.fillStyle = '#54c97e'; ctx.fillRect(x+3, y, 8, TILE);
      ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth=2; ctx.strokeRect(x+1,y+1,TILE-2,TILE-2);
      break;
    }
  }
}

function drawCoins(){
  for (const c of coins){
    if (c.taken) continue;
    const sx = Math.abs(Math.cos(c.bob));      // вращение (сжатие по X)
    const yy = c.y + Math.sin(c.bob)*3;
    ctx.save();
    ctx.translate(c.x, yy);
    ctx.scale(sx*1 + 0.15, 1);
    const g = ctx.createRadialGradient(-3,-3,2, 0,0,c.r);
    g.addColorStop(0, '#eafaff'); g.addColorStop(0.5, '#5fd0ff'); g.addColorStop(1, '#1f8fe0');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0,-c.r); ctx.lineTo(c.r*0.75,0); ctx.lineTo(0,c.r); ctx.lineTo(-c.r*0.75,0); ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth=1.5; ctx.stroke();
    ctx.restore();
  }
}

function drawPowerups(){
  for (const pw of powerups){
    if (pw.dead) continue;
    const x = pw.x+pw.w/2, y = pw.y+pw.h/2;
    // плод роста — розовая ягода с листиком
    ctx.fillStyle = '#ff5ea8';
    ctx.beginPath(); ctx.arc(x, y+2, pw.w/2, 0, 7); ctx.fill();
    ctx.fillStyle = '#ff8fc4';
    ctx.beginPath(); ctx.arc(x-4, y-2, pw.w/4, 0, 7); ctx.fill();
    ctx.fillStyle = '#4caf50';
    ctx.beginPath(); ctx.ellipse(x, y-pw.h/2+2, 7, 4, 0.5, 0, 7); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(x-4, y, 2.4, 0, 7); ctx.arc(x+4, y, 2.4, 0, 7); ctx.fill();
  }
}

function drawEnemies(){
  for (const e of enemies){
    if (!e.alive){
      if (e.dead > 0){                 // сплющенный при смерти
        ctx.save();
        ctx.globalAlpha = Math.max(0, e.dead/0.4);
        ctx.fillStyle = '#6fae4f';
        ctx.beginPath(); ctx.ellipse(e.x+e.w/2, e.y+e.h-4, e.w/2, 6, 0, 0, 7); ctx.fill();
        ctx.restore();
      }
      continue;
    }
    const x = e.x, y = e.y, w = e.w, h = e.h;
    const wob = Math.sin(globalT*8)*2;
    // тело-слизень
    const g = ctx.createLinearGradient(x, y, x, y+h);
    g.addColorStop(0, '#8fe36b'); g.addColorStop(1, '#4f9e34');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x, y+h);
    ctx.lineTo(x, y+12);
    ctx.quadraticCurveTo(x+w/2, y-6+wob, x+w, y+12);
    ctx.lineTo(x+w, y+h);
    ctx.closePath(); ctx.fill();
    // низ (ножки-волна)
    ctx.fillStyle = '#3d7d28';
    for (let i=0;i<3;i++) { ctx.beginPath(); ctx.arc(x+8+i*10, y+h, 6, 0, Math.PI); ctx.fill(); }
    // глаза
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(x+11, y+16, 5, 0, 7); ctx.arc(x+21, y+16, 5, 0, 7); ctx.fill();
    ctx.fillStyle = '#222';
    const ed = e.vx<0?-2:2;
    ctx.beginPath(); ctx.arc(x+11+ed, y+16, 2.4, 0, 7); ctx.arc(x+21+ed, y+16, 2.4, 0, 7); ctx.fill();
    // сердитые брови
    ctx.strokeStyle = '#2b5a1c'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(x+7,y+9); ctx.lineTo(x+15,y+13);
    ctx.moveTo(x+25,y+9); ctx.lineTo(x+17,y+13); ctx.stroke();
  }
}

function drawFlag(){
  const px = flag.x, topY = 2*TILE, baseY = (flag.baseR+1)*TILE;
  // дверь-портал у основания
  ctx.fillStyle = '#3a2a5e';
  roundRect(px+TILE-6, baseY-64, 44, 64, 8); ctx.fill();
  const pg = ctx.createLinearGradient(px+TILE, baseY-60, px+TILE, baseY);
  pg.addColorStop(0, '#7b5cff'); pg.addColorStop(1, '#3ad0ff');
  ctx.fillStyle = pg;
  roundRect(px+TILE-1, baseY-58, 34, 58, 6); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.fillRect(px+TILE+4, baseY-50, 4, 44);
  // шест
  ctx.fillStyle = '#cfd6e6';
  ctx.fillRect(px+2, topY, 6, baseY-topY);
  ctx.beginPath(); ctx.arc(px+5, topY, 7, 0, 7); ctx.fillStyle='#ffe27a'; ctx.fill();
  // флажок (колышется)
  const fw = 40, wob = Math.sin(globalT*3)*4;
  ctx.fillStyle = '#ff5d6c';
  ctx.beginPath();
  ctx.moveTo(px+8, topY+8);
  ctx.lineTo(px+8+fw, topY+18+wob);
  ctx.lineTo(px+8, topY+30);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.beginPath(); ctx.arc(px+8+fw*0.55, topY+18+wob*0.6, 5, 0, 7); ctx.fill();
}

function drawPlayer(){
  const p = player;
  if (p.invuln > 0 && Math.floor(p.invuln*20)%2===0) return;  // мигание неуязвимости

  const cx = p.x + p.w/2;
  const bottom = p.y + p.h;
  const sq = p.squash, st = 2 - sq;                            // squash & stretch
  const bw = p.w * (0.9/sq*sq + 0.1) ;                         // ширина
  const w = p.w * sq, h = p.h * st;
  const x = cx - w/2, y = bottom - h;

  ctx.save();
  ctx.translate(cx, bottom);
  ctx.scale(p.dir, 1);
  ctx.translate(-cx, -bottom);

  // ноги (шагающая анимация)
  const run = Math.abs(p.vx) > 20 && p.onGround;
  const legPhase = run ? Math.sin(p.animT*18) : 0;
  ctx.fillStyle = '#c8541f';
  ctx.fillRect(cx-10, bottom-10, 8, 10 + (p.onGround?0:0) );
  ctx.fillRect(cx+2,  bottom-10, 8, 10);
  if (run){
    ctx.clearRect(0,0,0,0);
    ctx.fillStyle = '#c8541f';
    ctx.fillRect(cx-10, bottom-10, 8, 10 - legPhase*4);
    ctx.fillRect(cx+2,  bottom-10, 8, 10 + legPhase*4);
  }

  // тело (лисёнок — оранжевый скруглённый)
  const bg = ctx.createLinearGradient(x, y, x, y+h);
  bg.addColorStop(0, '#ff9a3c'); bg.addColorStop(1, '#f57c1f');
  ctx.fillStyle = bg;
  roundRect(x+2, y+8, w-4, h-16, 10); ctx.fill();
  // животик
  ctx.fillStyle = '#ffe3c2';
  roundRect(cx-7, y+16, 14, h-26, 6); ctx.fill();

  // голова
  const hy = y + 8;
  ctx.fillStyle = '#ff9a3c';
  ctx.beginPath(); ctx.arc(cx, hy, 15, 0, 7); ctx.fill();
  // ушки
  ctx.fillStyle = '#f57c1f';
  ctx.beginPath(); ctx.moveTo(cx-14, hy-6); ctx.lineTo(cx-6, hy-20); ctx.lineTo(cx-2, hy-8); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(cx+14, hy-6); ctx.lineTo(cx+6, hy-20); ctx.lineTo(cx+2, hy-8); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#3a2a5e';
  ctx.beginPath(); ctx.moveTo(cx-11, hy-8); ctx.lineTo(cx-6, hy-16); ctx.lineTo(cx-3, hy-8); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(cx+11, hy-8); ctx.lineTo(cx+6, hy-16); ctx.lineTo(cx+3, hy-8); ctx.closePath(); ctx.fill();
  // мордочка
  ctx.fillStyle = '#ffe3c2';
  ctx.beginPath(); ctx.arc(cx+4, hy+4, 8, 0, 7); ctx.fill();
  // глаз
  ctx.fillStyle = '#2b2140';
  ctx.beginPath(); ctx.arc(cx+3, hy-1, 2.6, 0, 7); ctx.fill();
  // нос
  ctx.fillStyle = '#2b2140';
  ctx.beginPath(); ctx.arc(cx+11, hy+3, 2, 0, 7); ctx.fill();

  // если "большой" — корона роста
  if (p.big){
    ctx.fillStyle = '#ffd84a';
    ctx.beginPath();
    ctx.moveTo(cx-10, hy-16); ctx.lineTo(cx-6, hy-24); ctx.lineTo(cx-2, hy-17);
    ctx.lineTo(cx+2, hy-25); ctx.lineTo(cx+6, hy-17); ctx.lineTo(cx+10, hy-24);
    ctx.lineTo(cx+11, hy-15); ctx.closePath(); ctx.fill();
  }

  ctx.restore();
}

function drawParticles(){
  for (const pt of particles){
    const a = Math.max(0, pt.life/pt.max);
    ctx.globalAlpha = a;
    if (pt.type === 'gempop'){
      ctx.fillStyle = '#5fd0ff';
      ctx.beginPath();
      ctx.moveTo(pt.x, pt.y-pt.size); ctx.lineTo(pt.x+pt.size*0.7,pt.y);
      ctx.lineTo(pt.x, pt.y+pt.size); ctx.lineTo(pt.x-pt.size*0.7,pt.y); ctx.closePath(); ctx.fill();
    } else {
      ctx.fillStyle = pt.color || '#fff';
      if (pt.type === 'shard') ctx.fillRect(pt.x-pt.size/2, pt.y-pt.size/2, pt.size, pt.size);
      else { ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.size, 0, 7); ctx.fill(); }
    }
  }
  ctx.globalAlpha = 1;
}

function roundRect(x, y, w, h, r){
  ctx.beginPath();
  ctx.moveTo(x+r, y);
  ctx.arcTo(x+w, y, x+w, y+h, r);
  ctx.arcTo(x+w, y+h, x, y+h, r);
  ctx.arcTo(x, y+h, x, y, r);
  ctx.arcTo(x, y, x+w, y, r);
  ctx.closePath();
}

/* ---------------------- Экраны (меню / итог) ----------------------- */
function panel(title, lines, accent){
  ctx.fillStyle = 'rgba(10,8,22,0.62)';
  ctx.fillRect(0,0,CW,CH);
  const pw = 560, ph = 320, px = (CW-pw)/2, py = (CH-ph)/2;
  ctx.fillStyle = 'rgba(24,18,46,0.92)';
  roundRect(px, py, pw, ph, 22); ctx.fill();
  ctx.strokeStyle = accent; ctx.lineWidth = 3; ctx.stroke();

  ctx.textAlign = 'center';
  ctx.fillStyle = accent;
  ctx.font = 'bold 46px Segoe UI';
  ctx.fillText(title, CW/2, py+82);

  ctx.fillStyle = '#e8ecff';
  ctx.font = '20px Segoe UI';
  lines.forEach((l, i) => ctx.fillText(l, CW/2, py+140 + i*34));
}

function drawMenu(){
  panel('ЛИСЁНОК И КРИСТАЛЛЫ', [
    'Соберите кристаллы и дойдите до портала!',
    '← → — движение,  Space / ↑ — прыжок',
    'Прыгайте на врагов сверху, бейте блоки «?» снизу',
    '',
    '▶  Нажмите ПРОБЕЛ, чтобы начать'
  ], '#7df0ff');
  // прыгающий лисёнок-иконка
  const by = CH/2 + 150 + Math.abs(Math.sin(globalT*3))*-14;
  ctx.fillStyle = '#ff9a3c';
  ctx.beginPath(); ctx.arc(CW/2, by, 16, 0, 7); ctx.fill();
}

function drawWin(){
  panel('ПОБЕДА!', [
    `Кристаллов собрано: ${gems}`,
    `Осталось времени: ${Math.ceil(timeLeft)}`,
    `Жизней осталось: ${lives}`,
    '',
    'Нажмите R или ПРОБЕЛ — сыграть снова'
  ], '#8dff9a');
}

function drawLose(){
  panel('ИГРА ОКОНЧЕНА', [
    `Кристаллов собрано: ${gems}`,
    'Лисёнок остался без жизней…',
    '',
    'Нажмите R или ПРОБЕЛ — попробовать снова'
  ], '#ff7a8a');
}

/* ------------------------------ HUD -------------------------------- */
const hudGems = document.getElementById('hud-gems');
const hudLives = document.getElementById('hud-lives');
const hudTime = document.getElementById('hud-time');
function updateHud(){
  hudGems.textContent = gems;
  hudLives.textContent = Math.max(0, lives);
  hudTime.textContent = Math.max(0, Math.ceil(timeLeft));
}

/* ======================= ГЛАВНЫЙ ЦИКЛ =============================== */
let last = performance.now(), acc = 0;
const STEP = 1/60;
function frame(now){
  let dt = (now - last)/1000; last = now;
  if (dt > 0.25) dt = 0.25;                 // защита от «скачков» при потере фокуса
  acc += dt;
  while (acc >= STEP){ update(STEP); acc -= STEP; }
  render();
  requestAnimationFrame(frame);
}

buildLevel();          // подготовить уровень для фона меню
requestAnimationFrame(frame);
