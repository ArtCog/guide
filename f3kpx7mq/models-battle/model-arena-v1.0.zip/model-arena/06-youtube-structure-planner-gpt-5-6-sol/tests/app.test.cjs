const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');

function createElement(id) {
  return {
    id,
    value: '',
    textContent: '',
    innerHTML: '',
    checked: false,
    className: '',
    dataset: {},
    listeners: {},
    addEventListener(type, listener) {
      this.listeners[type] = listener;
    },
    querySelectorAll() {
      return [];
    }
  };
}

function createHarness(savedValue = null) {
  const elements = new Map();
  const storage = new Map();
  if (savedValue !== null) {
    storage.set('youtube-structure-planner-v1', savedValue);
  }

  const document = {
    querySelector(selector) {
      if (!elements.has(selector)) {
        elements.set(selector, createElement(selector));
      }
      return elements.get(selector);
    }
  };

  const localStorage = {
    getItem(key) {
      return storage.has(key) ? storage.get(key) : null;
    },
    setItem(key, value) {
      storage.set(key, String(value));
    },
    removeItem(key) {
      storage.delete(key);
    }
  };

  const context = vm.createContext({
    console,
    document,
    localStorage,
    structuredClone,
    Date,
    JSON,
    Math,
    Number,
    String,
    Array,
    Object,
    Set
  });

  vm.runInContext(appSource, context, { filename: 'app.js' });

  return {
    context,
    elements,
    storage,
    evaluate(source) {
      return vm.runInContext(source, context);
    }
  };
}

test('duration parser uses 60 seconds per minute and rejects invalid values', () => {
  const app = createHarness();

  assert.equal(app.evaluate("parseDuration('1:10')"), 70);
  assert.equal(app.evaluate("parseDuration('10:00')"), 600);
  assert.equal(app.evaluate("parseDuration('1:75')"), null);
  assert.equal(app.evaluate("parseDuration('abc')"), null);
});

test('initial duration is 10 minutes 20 seconds', () => {
  const app = createHarness();

  assert.equal(app.elements.get('#totalDuration').textContent, '10м 20с');
});

test('saved sections are restored after reload', () => {
  const firstRun = createHarness();
  firstRun.evaluate("state.sections[0].title = 'Сохранённый заголовок'; saveState()");

  const saved = firstRun.storage.get('youtube-structure-planner-v1');
  const secondRun = createHarness(saved);

  assert.equal(secondRun.evaluate('state.sections[0].title'), 'Сохранённый заголовок');
});

test('ready filter shows ready blocks and problem filter shows incomplete or risky blocks', () => {
  const app = createHarness();

  app.evaluate("state.filter = 'ready'; renderSections()");
  const readyHtml = app.elements.get('#scriptList').innerHTML;
  assert.match(readyHtml, /Сразу показываем арену/);
  assert.doesNotMatch(readyHtml, /Сразу просим подписаться/);

  app.evaluate("state.filter = 'problem'; renderSections()");
  const problemHtml = app.elements.get('#scriptList').innerHTML;
  assert.match(problemHtml, /Сразу просим подписаться/);
  assert.match(problemHtml, /Коротко объясняем правила/);
  assert.doesNotMatch(problemHtml, /Сразу показываем арену/);
});

test('CTA assessment rejects a CTA before the first payoff and accepts one after it', () => {
  const app = createHarness();

  assert.equal(app.evaluate('getCtaAssessment().status'), 'early');

  app.evaluate("state.sections = state.sections.filter((section) => section.id !== 'early-cta')");
  assert.equal(app.evaluate('getCtaAssessment().status'), 'good');
});

test('promise requires a conclusion and evidence for every criterion', () => {
  const app = createHarness();

  assert.equal(app.evaluate('promiseLooksClosed()'), true);

  app.evaluate("state.sections = [{ id: 'final', kind: 'финал', proof: false, payoff: false, cta: false, risk: false, ready: true, covers: [], duration: '0:30', title: 'Финал', text: 'Вывод' }]");
  assert.equal(app.evaluate('promiseLooksClosed()'), false);

  app.evaluate("state.sections = [{ id: 'proof', kind: 'тест', proof: true, payoff: true, cta: false, risk: false, ready: true, covers: ['quality', 'speed'], duration: '1:00', title: 'Тест', text: 'Результат' }, { id: 'final', kind: 'финал', proof: true, payoff: true, cta: false, risk: false, ready: true, covers: ['cost'], duration: '0:30', title: 'Финал', text: 'Вывод' }]");
  assert.equal(app.evaluate('promiseLooksClosed()'), true);
});

test('cut suggestions protect proof, payoff and promise coverage', () => {
  const app = createHarness();
  const suggestions = app.evaluate('suggestCuts()');

  assert.deepEqual(Array.from(suggestions), [
    'Сразу просим подписаться в Telegram',
    'Коротко объясняем правила теста'
  ]);
});

test('analysis reports the real initial defects and overage', () => {
  const app = createHarness();
  const findings = app.evaluate('analyzeStructure()');
  const titles = Array.from(findings, (finding) => finding.title);
  const texts = Array.from(findings, (finding) => finding.text).join(' ');

  assert.ok(titles.includes('CTA стоит слишком рано'));
  assert.ok(titles.includes('Ролик длиннее цели'));
  assert.match(texts, /0м 20с/);
  assert.match(texts, /Сразу просим подписаться в Telegram/);
  assert.doesNotMatch(texts, /Тест 4: анализатор удержания YouTube/);
});

test('analysis output escapes dynamic text', () => {
  const app = createHarness();

  app.evaluate("renderAnalysis([{ type: 'warn', title: '<img src=x>', text: '<script>alert(1)</script>' }])");
  const html = app.elements.get('#analysisOutput').innerHTML;

  assert.doesNotMatch(html, /<img src=x>/);
  assert.doesNotMatch(html, /<script>/);
  assert.match(html, /&lt;img src=x&gt;/);
});
