import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const testsDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(testsDir, '..');
const profilePath = path.join(projectRoot, '.browser-test-profile');
const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

if (!profilePath.startsWith(`${projectRoot}${path.sep}`)) {
  throw new Error('Browser profile must stay inside the result folder');
}
fs.rmSync(profilePath, { recursive: true, force: true });

const port = await getFreePort();
const pageUrl = pathToFileURL(path.join(projectRoot, 'index.html')).href;
const chrome = spawn(chromePath, [
  '--headless=new',
  '--disable-gpu',
  '--no-first-run',
  `--remote-debugging-port=${port}`,
  `--user-data-dir=${profilePath}`,
  pageUrl
], { stdio: 'ignore', windowsHide: true });

let client;
try {
  const target = await waitForTarget(port, pageUrl);
  client = await createCdpClient(target.webSocketDebuggerUrl);
  await client.send('Runtime.enable');
  await waitForReady(client);

  const initial = await evaluate(client, `(() => ({
    duration: document.querySelector('#totalDuration').textContent,
    findings: [...document.querySelectorAll('.finding')].map((item) => item.textContent.trim())
  }))()`);
  assert.equal(initial.duration, '10м 20с');
  assert.ok(initial.findings.some((text) => text.includes('CTA стоит слишком рано')));
  assert.ok(initial.findings.some((text) => text.includes('Нужно сократить примерно 0м 20с')));

  const readyTitles = await setFilterAndReadTitles(client, 'ready');
  assert.ok(readyTitles.includes('Сразу показываем арену и обещаем честное сравнение'));
  assert.ok(!readyTitles.includes('Сразу просим подписаться в Telegram'));

  const problemTitles = await setFilterAndReadTitles(client, 'problem');
  assert.ok(problemTitles.includes('Сразу просим подписаться в Telegram'));
  assert.ok(problemTitles.includes('Коротко объясняем правила теста'));
  assert.ok(!problemTitles.includes('Сразу показываем арену и обещаем честное сравнение'));

  await evaluate(client, `(() => {
    document.querySelector('#editTitle').value = 'CTA для проверки сохранения';
    document.querySelector('#editDuration').value = '0:10';
    document.querySelector('#applyEditBtn').click();
    document.querySelector('#saveBtn').click();
  })()`);
  await reload(client);

  const restored = await evaluate(client, `(() => ({
    title: document.querySelector('#editTitle').value,
    duration: document.querySelector('#totalDuration').textContent,
    target: document.querySelector('#targetMinutes').value
  }))()`);
  assert.equal(restored.title, 'CTA для проверки сохранения');
  assert.equal(restored.duration, '10м 10с');

  const invalidEdit = await evaluate(client, `(() => {
    document.querySelector('#editDuration').value = '1:75';
    document.querySelector('#applyEditBtn').click();
    return {
      finding: document.querySelector('.finding strong').textContent,
      duration: document.querySelector('#totalDuration').textContent,
      storedValue: document.querySelector('#editDuration').value
    };
  })()`);
  assert.equal(invalidEdit.finding, 'Некорректная длительность');
  assert.equal(invalidEdit.duration, '10м 10с');
  assert.equal(invalidEdit.storedValue, '1:75');

  await evaluate(client, `(() => {
    const target = document.querySelector('#targetMinutes');
    target.value = '11';
    target.dispatchEvent(new Event('input', { bubbles: true }));
    document.querySelector('#analyzeBtn').click();
  })()`);
  const durationFinding = await evaluate(client, `[...document.querySelectorAll('.finding strong')].map((item) => item.textContent)`);
  assert.ok(durationFinding.includes('Длительность в лимите'));

  await evaluate(client, `(() => {
    document.querySelector('#editDuration').value = '0:10';
    document.querySelector('#deleteBlockBtn').click();
    document.querySelector('#analyzeBtn').click();
  })()`);
  const afterDelete = await evaluate(client, `[...document.querySelectorAll('.finding strong')].map((item) => item.textContent)`);
  assert.ok(afterDelete.includes('CTA расположен после ценности'));

  const ctaTitles = await setFilterAndReadTitles(client, 'cta');
  assert.deepEqual(ctaTitles, ['Финальный CTA и вывод']);

  console.log(JSON.stringify({
    verdict: 'passed',
    browser: 'Google Chrome headless',
    checks: [
      'filters',
      'editing',
      'reload persistence',
      'duration calculation and validation',
      'target limit',
      'structure diagnostics',
      'delete and CTA filter'
    ]
  }, null, 2));
} finally {
  if (client) {
    try {
      await client.send('Browser.close');
    } catch {
      // The browser may close the socket before replying.
    }
    client.close();
  }
  if (!chrome.killed) chrome.kill();
  await new Promise((resolve) => setTimeout(resolve, 300));
  fs.rmSync(profilePath, { recursive: true, force: true });
}

async function getFreePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      server.close(() => resolve(address.port));
    });
  });
}

async function waitForTarget(portNumber, expectedUrl) {
  const endpoint = `http://127.0.0.1:${portNumber}/json`;
  for (let attempt = 0; attempt < 80; attempt += 1) {
    try {
      const targets = await fetch(endpoint).then((response) => response.json());
      const target = targets.find((item) => item.type === 'page' && item.url === expectedUrl);
      if (target) return target;
    } catch {
      // Chrome is still starting.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error('Chrome DevTools target did not become ready');
}

async function createCdpClient(webSocketUrl) {
  const socket = new WebSocket(webSocketUrl);
  const pending = new Map();
  let nextId = 1;

  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
  });

  socket.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (!message.id || !pending.has(message.id)) return;
    const { resolve, reject } = pending.get(message.id);
    pending.delete(message.id);
    if (message.error) reject(new Error(message.error.message));
    else resolve(message.result);
  });

  return {
    send(method, params = {}) {
      const id = nextId;
      nextId += 1;
      socket.send(JSON.stringify({ id, method, params }));
      return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
    },
    close() {
      socket.close();
    }
  };
}

async function evaluate(cdp, expression) {
  const result = await cdp.send('Runtime.evaluate', {
    expression,
    awaitPromise: true,
    returnByValue: true
  });
  if (result.exceptionDetails) {
    throw new Error(result.exceptionDetails.text);
  }
  return result.result.value;
}

async function waitForReady(cdp) {
  for (let attempt = 0; attempt < 80; attempt += 1) {
    if (await evaluate(cdp, `document.readyState === 'complete' && Boolean(document.querySelector('#scriptList'))`)) return;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error('Application did not become ready');
}

async function reload(cdp) {
  await cdp.send('Page.reload', { ignoreCache: true });
  await waitForReady(cdp);
}

async function setFilterAndReadTitles(cdp, value) {
  return evaluate(cdp, `(() => {
    const filter = document.querySelector('#filterSelect');
    filter.value = ${JSON.stringify(value)};
    filter.dispatchEvent(new Event('change', { bubbles: true }));
    return [...document.querySelectorAll('.script-card .card-title strong')].map((item) => item.textContent);
  })()`);
}
