# Run Metrics

- Model: GPT-5.6 Sol (`gpt-5.6-sol`, reasoning `xhigh`)
- Test: 06 - YouTube structure planner repair
- Cost USD: ~$3.75 API-equivalent (cache-write cost unavailable)
- Task time: 14m 34s
- API time: ~12m 43s
- Wall time: 14m 34s
- Prompt tokens: unavailable separately; uncached input shown below
- Input tokens: 158 267
- Output tokens: 33 991
- Cache read: 3 882 496
- Cache write: unavailable
- Path: index.html
- Verdict: passed — project repaired; 9/9 unit tests and Chrome browser smoke test passed

## Calculation basis

The token counters are taken from the current Codex rollout's final `token_count` event before the first `task_complete`; they cover only the original repair task. Total input includes cached input, so uncached input is:

```text
4,040,763 - 3,882,496 = 158,267 tokens
```

Official standard API pricing for GPT-5.6 Sol is $5.00 per 1M uncached input tokens, $0.50 per 1M cached input tokens, and $30.00 per 1M output tokens. The base API-equivalent is:

```text
(158,267 × $5.00 + 3,882,496 × $0.50 + 33,991 × $30.00) / 1,000,000
= $3.752313
```

Cache-write tokens are not present in the local telemetry. GPT-5.6 cache writes cost 1.25 times the uncached input rate. If every uncached input token were also billed at the cache-write rate, the conservative upper estimate would be approximately $3.950147. No individual request exceeded the 272K-token long-context threshold (maximum observed input was 143,367), so the long-context multiplier does not apply.

API time is estimated from the rollout timeline: 874.730 seconds from `task_started` to `task_complete`, minus 111.267 seconds spent inside local and external tools, leaving 763.463 seconds (about 12:43) for model/API processing and orchestration.
