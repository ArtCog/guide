import test from 'node:test';
import assert from 'node:assert/strict';
import { addItem, getTotals, removeItem, setQuantity } from '../assets/cart-core.js';

const catalogue = [
  { id: 'luna', price: 18400 },
  { id: 'mars', price: 12900 }
];

test('adding an object creates a request line and correct total', () => {
  const cart = addItem([], 'luna', catalogue);
  assert.deepEqual(cart, [{ id: 'luna', quantity: 1 }]);
  assert.deepEqual(getTotals(cart, catalogue), { count: 1, total: 18400 });
});

test('changing quantity recalculates the request total', () => {
  const cart = setQuantity([{ id: 'luna', quantity: 1 }], 'luna', 3);
  assert.deepEqual(getTotals(cart, catalogue), { count: 3, total: 55200 });
});

test('removing an object leaves only remaining request lines', () => {
  const cart = removeItem([{ id: 'luna', quantity: 1 }, { id: 'mars', quantity: 2 }], 'luna');
  assert.deepEqual(cart, [{ id: 'mars', quantity: 2 }]);
  assert.deepEqual(getTotals(cart, catalogue), { count: 2, total: 25800 });
});
