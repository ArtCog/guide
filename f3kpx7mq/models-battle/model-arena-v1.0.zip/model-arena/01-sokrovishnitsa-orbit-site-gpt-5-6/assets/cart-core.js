export function addItem(cart, id, catalogue) {
  if (!catalogue.some((item) => item.id === id)) return cart;
  const line = cart.find((item) => item.id === id);
  return line
    ? cart.map((item) => item.id === id ? { ...item, quantity: item.quantity + 1 } : item)
    : [...cart, { id, quantity: 1 }];
}

export function setQuantity(cart, id, quantity) {
  const safeQuantity = Math.max(0, Math.floor(Number(quantity) || 0));
  if (!safeQuantity) return removeItem(cart, id);
  return cart.map((item) => item.id === id ? { ...item, quantity: safeQuantity } : item);
}

export function removeItem(cart, id) {
  return cart.filter((item) => item.id !== id);
}

export function getTotals(cart, catalogue) {
  return cart.reduce((totals, line) => {
    const item = catalogue.find((candidate) => candidate.id === line.id);
    if (!item) return totals;
    totals.count += line.quantity;
    totals.total += item.price * line.quantity;
    return totals;
  }, { count: 0, total: 0 });
}
