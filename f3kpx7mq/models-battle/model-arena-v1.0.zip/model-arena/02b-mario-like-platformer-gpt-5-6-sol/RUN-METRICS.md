# Run Metrics

- Model: GPT-5.6 Sol
- Test: 02B - browser platformer
- Cost USD: ~$2.91
- Task time: 13m 8s
- API time: unavailable
- Wall time: 13m 8s
- Input tokens: 135 283
- Output tokens: 36 602
- Cache read: 2 267 904
- Cache write: unavailable
- Verdict: Original Canvas platformer; browser gameplay and victory states were checked in Chrome. API-equivalent cost includes discounted cached input; cache-write data was not available.

## Source

Values are copied from `USAGE_REPORT.md`: exact session deltas for the implementation turn. The arena uses uncached input plus output as its token total; cached input is reported separately.
