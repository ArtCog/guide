# Lum and the Heart of the Valley Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and browser-verify a complete original Russian-language 2D platformer that runs directly from a self-contained `index.html`.

**Architecture:** One HTML file contains semantic overlays, responsive CSS, Canvas 2D rendering, fixed-step simulation, entity data, Web Audio synthesis, and a small browser-test API. Game state is explicit (`menu`, `playing`, `paused`, `gameover`, `won`) so every terminal condition can be exercised deterministically.

**Tech Stack:** HTML5, CSS, Canvas 2D, vanilla JavaScript, Web Audio API; no dependencies, build step, downloads, or network calls.

## Global Constraints

- All deliverables live only in `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02b-mario-like-platformer-gpt-5-6-sol\`.
- `index.html` must open directly in a modern browser.
- All user-facing text is Russian; identifiers and documentation remain English where appropriate.
- All art, names, mechanics presentation, sound effects, and music are original.
- The game must contain keyboard control, movement, jumping, platforms, hazards, collectibles, enemies, defeat, restart, a clear goal, a finish point, and victory.

---

### Task 1: Build the playable game shell and state machine

**Files:**
- Create: `index.html`

**Interfaces:**
- Produces: `window.__gameTest` with `snapshot()`, `start()`, `step(frames, input)`, `teleport(x, y)`, `setLives(value)`, `hit()`, `collectAll()`, and `win()`.

- [ ] Add semantic Russian menu, HUD, pause, game-over, and victory overlays around a 960×540 Canvas.
- [ ] Add responsive expedition-panel styling with clear keyboard focus and reduced-motion handling.
- [ ] Implement explicit game states and menu/restart/pause transitions.
- [ ] Run a syntax check by extracting the inline script and passing it to `node --check`; expect exit code 0.

### Task 2: Implement physics, world, entities, and camera

**Files:**
- Modify: `index.html`

**Interfaces:**
- Consumes: the state machine and input map from Task 1.
- Produces: fixed-step `update(dt)`, collision resolution, checkpoints, player damage/respawn, collectibles, enemies, moving platforms, exit activation, and finish detection.

- [ ] Define the continuous level, solid platforms, hazards, moving platforms, shards, enemies, checkpoint, and beacon.
- [ ] Implement horizontal acceleration/friction, coyote time, jump buffering, variable jump height, gravity, and axis-separated platform collision.
- [ ] Implement enemy patrol/stomp interactions, damage invulnerability, falls, lives, checkpoint respawn, game-over, shard collection, and beacon goal.
- [ ] Implement camera tracking and viewport/world coordinate separation.
- [ ] Use the browser-test API to assert that movement changes `player.x`, jumping changes `player.y`, collection changes `shards`, damage reduces `lives`, zero lives yields `gameover`, restart yields `playing`, and the finish yields `won`.

### Task 3: Add original procedural presentation and audio

**Files:**
- Modify: `index.html`

**Interfaces:**
- Consumes: world state and entities from Task 2.
- Produces: `render()`, synthesized soundtrack scheduling, and synthesized interaction sounds.

- [ ] Draw layered parallax scenery, mechanical-valley platforms, cyan flora, coral hazards, Lum, enemies, particles, checkpoint, and beacon using Canvas primitives only.
- [ ] Add readable goal guidance, progress indicator, lives, shard count, and contextual messages.
- [ ] Add an original Web Audio loop plus jump, shard, hit, checkpoint, stomp, victory, and defeat cues after user interaction.
- [ ] Inspect the rendered game at desktop and narrow viewport sizes; expect no obscured critical controls or unreadable HUD.

### Task 4: Verify the complete route and document results

**Files:**
- Create: `REPORT.md`
- Modify: `index.html` only if verification exposes defects.

**Interfaces:**
- Consumes: the complete game and test API.
- Produces: browser evidence and concise launch/report documentation.

- [ ] Open local `index.html` in the in-app browser and check the menu and Canvas render.
- [ ] Exercise keyboard movement and jump through real key events; verify snapshots change as expected.
- [ ] Exercise collectible, hazard, defeat/restart, full-goal, and victory paths; verify the authoritative overlay/state for each.
- [ ] Confirm the page makes zero required network requests and has no console errors.
- [ ] Write `REPORT.md` in Russian with implemented features, opening instructions, browser checks, and honest limitations.
- [ ] Re-run syntax validation and a file inventory; expect `index.html` and `REPORT.md` to exist and be non-empty.
