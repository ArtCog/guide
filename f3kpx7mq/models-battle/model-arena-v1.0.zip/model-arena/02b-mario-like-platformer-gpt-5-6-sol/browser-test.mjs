import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = fileURLToPath(new URL('.', import.meta.url));
const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const port = 9333;
const profile = join(tmpdir(), `lum-browser-test-${Date.now()}`);
mkdirSync(profile, { recursive: true });

const gameUrl = pathToFileURL(join(here, 'index.html')).href;
const chrome = spawn(chromePath, [
  '--headless=new',
  '--disable-gpu',
  '--disable-background-networking',
  '--disable-component-update',
  '--disable-default-apps',
  '--disable-sync',
  '--metrics-recording-only',
  '--no-first-run',
  '--no-default-browser-check',
  `--remote-debugging-port=${port}`,
  `--user-data-dir=${profile}`,
  '--window-size=1280,720',
  gameUrl
], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function getPage() {
  let lastError;
  for (let i = 0; i < 60; i++) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/json/list`);
      const pages = await response.json();
      const page = pages.find(item => item.type === 'page' && item.url.startsWith('file:'));
      if (page) return page;
    } catch (error) { lastError = error; }
    await delay(100);
  }
  throw lastError ?? new Error('Chrome DevTools page was not found');
}

class CDP {
  constructor(url) {
    this.socket = new WebSocket(url);
    this.id = 0;
    this.pending = new Map();
    this.events = [];
    this.socket.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const request = this.pending.get(message.id);
        if (!request) return;
        this.pending.delete(message.id);
        if (message.error) request.reject(new Error(message.error.message));
        else request.resolve(message.result);
      } else this.events.push(message);
    };
  }
  async open() {
    if (this.socket.readyState === WebSocket.OPEN) return;
    await new Promise((resolve, reject) => {
      this.socket.onopen = resolve;
      this.socket.onerror = reject;
    });
  }
  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.socket.send(JSON.stringify({ id, method, params }));
    });
  }
  close() { this.socket.close(); }
}

async function main() {
  const page = await getPage();
  const cdp = new CDP(page.webSocketDebuggerUrl);
  await cdp.open();
  await Promise.all([
    cdp.send('Runtime.enable'),
    cdp.send('Page.enable'),
    cdp.send('Log.enable'),
    cdp.send('Network.enable')
  ]);
  await delay(400);

  async function evaluate(expression) {
    const response = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (response.exceptionDetails) throw new Error(response.exceptionDetails.text);
    return response.result.value;
  }

  async function key(type, key, code, windowsVirtualKeyCode) {
    await cdp.send('Input.dispatchKeyEvent', { type, key, code, windowsVirtualKeyCode, nativeVirtualKeyCode: windowsVirtualKeyCode });
  }

  const results = [];
  const menu = await evaluate(`({title:document.title,state:window.__gameTest.snapshot().state,menuVisible:!document.getElementById('menu-screen').hidden,canvas:[game.width,game.height]})`);
  assert.equal(menu.title, 'Люм и Сердце долины');
  assert.equal(menu.state, 'menu');
  assert.equal(menu.menuVisible, true);
  assert.deepEqual(menu.canvas, [960, 540]);
  results.push('local-load-and-menu');

  await evaluate(`document.getElementById('start-button').click()`);
  await delay(250);
  const start = await evaluate(`window.__gameTest.snapshot()`);
  assert.equal(start.state, 'playing');
  const startX = start.player.x;

  await key('rawKeyDown', 'ArrowRight', 'ArrowRight', 39);
  await delay(520);
  await key('keyUp', 'ArrowRight', 'ArrowRight', 39);
  const moved = await evaluate(`window.__gameTest.snapshot()`);
  assert.ok(moved.player.x > startX + 20, `expected movement from ${startX}, got ${moved.player.x}`);
  results.push('real-keyboard-movement');

  await delay(120);
  const beforeJump = await evaluate(`window.__gameTest.snapshot()`);
  await key('rawKeyDown', ' ', 'Space', 32);
  await delay(135);
  await key('keyUp', ' ', 'Space', 32);
  await delay(70);
  const jumped = await evaluate(`window.__gameTest.snapshot()`);
  assert.ok(jumped.player.y < beforeJump.player.y - 8, `expected jump above ${beforeJump.player.y}, got ${jumped.player.y}`);
  assert.ok(jumped.player.vy < 0, `expected upward velocity, got ${jumped.player.vy}`);
  results.push('real-keyboard-jump');
  const gameplayShot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  writeFileSync(join(here, 'browser-gameplay.png'), Buffer.from(gameplayShot.data, 'base64'));

  const shardBefore = jumped.player.shards;
  const collected = await evaluate(`window.__gameTest.teleport(365,326); window.__gameTest.step(2,{})`);
  assert.equal(collected.player.shards, shardBefore + 1);
  results.push('collectible-and-hud');

  const checkpointState = await evaluate(`window.__gameTest.teleport(3650,380); window.__gameTest.step(2,{})`);
  assert.equal(checkpointState.checkpoint, true);
  results.push('checkpoint-activation');

  const hurt = await evaluate(`window.__gameTest.teleport(880,420); window.__gameTest.step(2,{})`);
  assert.equal(hurt.player.lives, 2);
  assert.equal(hurt.state, 'playing');
  results.push('hazard-respawn');

  const defeated = await evaluate(`window.__gameTest.setLives(1); window.__gameTest.hit(); window.__gameTest.snapshot()`);
  assert.equal(defeated.state, 'gameover');
  const gameoverVisible = await evaluate(`!document.getElementById('gameover-screen').hidden`);
  assert.equal(gameoverVisible, true);
  results.push('gameover-overlay');

  await key('rawKeyDown', 'r', 'KeyR', 82);
  await key('keyUp', 'r', 'KeyR', 82);
  await delay(100);
  const restarted = await evaluate(`window.__gameTest.snapshot()`);
  assert.equal(restarted.state, 'playing');
  assert.equal(restarted.player.lives, 3);
  results.push('real-keyboard-restart');

  const gapScenarios = [
    { start: 850, y: 350, finish: 1160 },
    { start: 1760, y: 340, finish: 2090 },
    { start: 2680, y: 345, finish: 3050 },
    { start: 3990, y: 310, finish: 4270 },
    { start: 5120, y: 295, finish: 5300 }
  ];
  for (const scenario of gapScenarios) {
    const crossed = await evaluate(`(() => {
      window.__gameTest.reset();
      window.__gameTest.teleport(${scenario.start}, ${scenario.y});
      let snapshot = window.__gameTest.snapshot();
      let furthestX = snapshot.player.x;
      let lowestY = snapshot.player.y;
      for (let frame = 0; frame < 240 && snapshot.state === 'playing' && snapshot.player.x < ${scenario.finish}; frame++) {
        snapshot = window.__gameTest.step(1, { ArrowRight: true, Space: true });
        furthestX = Math.max(furthestX, snapshot.player.x);
        lowestY = Math.max(lowestY, snapshot.player.y);
      }
      return { ...snapshot, furthestX, lowestY };
    })()`);
    assert.ok(crossed.player.x >= scenario.finish, `could not cross level gap from ${scenario.start}: ${JSON.stringify(crossed)}`);
  }
  results.push('all-five-level-gaps-with-real-physics');

  await evaluate(`window.__gameTest.reset()`);
  const won = await evaluate(`window.__gameTest.win(); window.__gameTest.snapshot()`);
  assert.equal(won.state, 'won');
  assert.ok(won.player.shards >= 12);
  const victoryVisible = await evaluate(`!document.getElementById('won-screen').hidden && document.getElementById('victory-stats').textContent.includes('Осколки')`);
  assert.equal(victoryVisible, true);
  results.push('powered-beacon-victory');

  const externalResources = await evaluate(`performance.getEntriesByType('resource').map(e=>e.name).filter(url=>/^https?:/i.test(url))`);
  assert.deepEqual(externalResources, []);
  results.push('zero-network-resources');

  const shot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  writeFileSync(join(here, 'browser-check.png'), Buffer.from(shot.data, 'base64'));

  const errors = cdp.events.filter(event => event.method === 'Runtime.exceptionThrown' || (event.method === 'Log.entryAdded' && event.params.entry.level === 'error'));
  assert.equal(errors.length, 0, errors.map(error => JSON.stringify(error.params)).join('\n'));
  results.push('no-console-errors');

  console.log(JSON.stringify({ browser: 'Google Chrome headless', results, finalState: won, screenshots: ['browser-gameplay.png', 'browser-check.png'] }, null, 2));
  cdp.close();
}

try {
  await main();
} finally {
  chrome.kill();
  await delay(250);
  rmSync(profile, { recursive: true, force: true });
}
