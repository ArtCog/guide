import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const html = readFileSync(join(here, 'index.html'), 'utf8');

const required = [
  '<canvas',
  'requestAnimationFrame',
  'AudioContext',
  'window.__gameTest',
  'data-screen="menu"',
  'data-screen="gameover"',
  'data-screen="won"',
  'collectibles',
  'enemies',
  'hazards',
  'checkpoint',
  'beacon',
  'keydown',
  'Прыжок',
  'ОСКОЛКИ',
  'ПОБЕДА',
  'ПОПРОБОВАТЬ СНОВА'
];

for (const marker of required) {
  assert.ok(html.includes(marker), `index.html must contain ${marker}`);
}

assert.ok(!/https?:\/\//i.test(html), 'the game must not require network resources');
assert.ok(html.length > 30000, 'the game must contain a substantial complete implementation');

console.log(`PASS: ${required.length} structural game requirements verified`);
