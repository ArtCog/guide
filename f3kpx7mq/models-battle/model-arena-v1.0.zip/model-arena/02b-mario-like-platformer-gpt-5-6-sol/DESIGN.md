# Design: «Люм и Сердце долины»

## Product goal

Create a complete, original, single-level browser platformer that starts directly from `index.html`, requires no build step or network access, and can be completed in roughly four to six minutes.

## Game concept

The player controls Lum, a small courier of light travelling through an abandoned mechanical valley. Lum must collect enough lumen shards to activate the exit beacon at the far end of the level. The setting, character, enemies, names, graphics, sound effects, and music are original.

## Controls and rules

- Move with `A`/`D` or the left/right arrow keys.
- Jump with `Space`, `W`, or the up arrow.
- Pause with `P`; restart with `R`.
- Horizontal movement uses acceleration, friction, and a capped speed.
- Jumping includes coyote time, jump buffering, variable jump height, and a predictable fall speed.
- Collecting shards increases score and powers the exit objective.
- Contact with thorns, moving enemies, or a fall costs one life and restores the latest checkpoint.
- Losing all lives shows a defeat screen with a clear restart action.
- Reaching the powered exit beacon shows the victory screen and completion statistics.

## Level structure

The level is a single continuous horizontal course with an opening tutorial area, progressively harder platform sections, patrol enemies, thorn pits, moving platforms, one mid-level checkpoint, a short final challenge, and the exit beacon. Shards are placed both on the main route and on optional risk/reward paths. The player only needs a subset of all shards to activate the beacon, so completion cannot be blocked by one missed collectible.

## Architecture

Everything ships in one self-contained `index.html`:

- semantic HTML for the canvas, HUD, start overlay, pause state, defeat screen, and victory screen;
- CSS for responsive framing, typography, overlays, and accessibility;
- JavaScript modules represented as isolated sections for input, audio, world data, physics, collision handling, entities, rendering, game state, and the main loop;
- Canvas 2D procedural art with no downloaded assets;
- Web Audio synthesis for an original looping soundtrack and event sound effects, enabled after the first player interaction.

The simulation uses a fixed timestep so movement remains stable across different display refresh rates. The camera follows the player horizontally while keeping the canvas responsive. Collision shapes remain simple rectangles or circles and are independent of decorative drawing.

## Visual direction

The look is a hand-painted nocturnal mechanical valley: deep ink-blue sky, warm brass structures, pale cyan luminous vegetation, and coral hazards. Shapes use crisp silhouettes, restrained texture, and layered parallax. The interface is in Russian and styled like an expedition instrument panel rather than a generic web dashboard.

## Testing strategy

Browser verification must cover:

1. loading the local `index.html` without network dependencies;
2. starting the game and moving left/right;
3. jumping onto platforms with stable collision;
4. collecting a shard and updating the HUD;
5. losing a life to a hazard and respawning;
6. reaching a game-over state and restarting;
7. progressing through the full level and triggering victory;
8. checking that the level can be completed with the required shard count;
9. checking responsive presentation and absence of console errors.

## Deliverables

- `index.html` — the complete playable game.
- `REPORT.md` — concise Russian summary, launch instructions, browser test results, and known limitations.
