# RUN-METRICS — тест 05 «YouTube-планировщик»

| Поле | Значение |
|---|---|
| Модель | Claude Fable 5 (`claude-fable-5`), Claude Code |
| Тест | 05 — ремонт сломанного YouTube-планировщика |
| Время задачи | 12m 12s |
| Input tokens | 17.3k |
| Output tokens | 42.4k |
| Cache read | 2.3m |
| Cache write | 100.0k |
| Стоимость USD | $6.96 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\05-youtube-structure-planner-fable-5\index.html` |

**Источник времени:** ручная фиксация после завершения теста.

**Примечание по стоимости и токенам:** метрики токенов и USD для теста 05
оценочные, потому что счетчик сессии был загрязнен предыдущими задачами после
очистки истории. Для этого теста валиднее сравнивать время задачи и качество
ремонта.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $65.38 / 82.4k input / 377.5k output / 19.5m cache read / 1.3m cache write.
- Previous checkpoint: $58.42 / 66.2k input / 335.1k output / 17.2m cache read / 1.2m cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
