# Run Metrics

- Model: GPT-5.6 Sol (`gpt-5.6-sol`, reasoning effort `xhigh`)
- Test: 04 - Last Paradise 3D scene
- Cost USD: ~$2.77 API-equivalent (cache-write cost unavailable)
- Task time: 14m 08s
- API time: unavailable
- Wall time: 14m 08s
- Prompt tokens: unavailable separately; telemetry exposes aggregate input only
- Input tokens: 154 025
- Output tokens: 32 026
- Cache read: 2 068 480
- Cache write: unavailable
- Path: index.html
- Verdict: PASS — real Chrome/WebGL render verified; 4 modes and 4 screenshots confirmed; 0 console/page errors
