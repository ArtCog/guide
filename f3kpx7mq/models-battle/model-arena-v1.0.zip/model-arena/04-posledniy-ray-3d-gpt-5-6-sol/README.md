# Last Paradise — interactive 3D scene

An original browser-based Three.js prototype of a living floating garden-city above a fractured, storm-covered planet. The experience is rendered in real time and uses no remote runtime assets.

## Open

ES modules require a local HTTP server. From this directory, run:

```powershell
python -m http.server 4173 --bind 127.0.0.1
```

Then open:

```text
http://127.0.0.1:4173/index.html
```

The main entry file is `index.html`.

## Interaction

- Drag to orbit the scene.
- Use the mouse wheel or trackpad to zoom.
- Choose `Рай`, `Правда`, `Катастрофа`, or `Выжившие` in the bottom dock.
- Keyboard shortcuts `1`–`4` activate the same four modes.

Each mode changes the camera and focus target, light color and intensity, exposure, fog, city glow, storm activity, catastrophe particles, and survivor beacons. The scene continuously animates clouds, water, particles, lightning, rings, planetary rotation, and drifting debris.

## Structure

- `index.html` — semantic Russian-language interface and launch entry.
- `styles.css` — responsive HUD, loading state, and visual system.
- `src/modes.js` — deterministic story-mode configuration.
- `src/scene.js` — Three.js world construction, motion, interaction, and transitions.
- `vendor/` — pinned local Three.js runtime and OrbitControls.
- `tests/modes.test.mjs` — mode-contract tests.
- `tests/browser-check.mjs` — real Chrome/WebGL integration check and screenshot capture.
- `screenshots/` — four verified 1440×900 scene states.

## Verification

Run unit tests:

```powershell
npm test
```

With the server running on port 4173, the installed-Chrome check can be repeated with:

```powershell
npm install
node tests/browser-check.mjs
```

See `REPORT.md` for the recorded verification result.
