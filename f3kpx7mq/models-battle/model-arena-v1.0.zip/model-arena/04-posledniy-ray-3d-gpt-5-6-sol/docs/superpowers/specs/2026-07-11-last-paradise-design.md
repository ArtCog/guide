# Last Paradise 3D — Design Specification

## Experience

The first frame shows one continuous vertical world: a bright floating garden-city in the upper half, a fractured planet and storm deck below, and luminous water falling between them. The visual center is the city's glass-and-gold sanctuary tree, framed by terraced architecture, canals, gardens, and orbital rings.

## Art direction

- Aesthetic: solar utopia suspended over a geological apocalypse.
- Paradise palette: ivory, warm gold, living green, cyan water.
- Ruin palette: charcoal, ember orange, bruised violet, cold blue lightning.
- Interface: restrained Russian-language observation console with editorial typography and hard-edged controls.
- No real countries, political symbols, blood, or violent human imagery.

## Scene architecture

- `index.html` owns semantic UI and accessibility.
- `styles.css` owns the responsive HUD, typography, and loading/error states.
- `src/modes.js` defines the public mode contract and deterministic scene parameters.
- `src/scene.js` builds and animates the Three.js world, camera, particles, clouds, water, debris, lighting, and transitions.
- Local `vendor/three.module.js` and `vendor/OrbitControls.js` remove runtime network dependency.

## Modes

- `paradise`: close elevated camera, warm sun, open petals, vivid gardens, restrained catastrophe.
- `truth`: wider side angle exposing the complete vertical relationship and planetary fractures.
- `catastrophe`: lower camera, red-violet storm light, heavier lightning, debris, embers, and turbulence.
- `survivors`: close civic view with inhabited lights isolated to a tiny residential arc and a numerical population indicator.

Mode changes interpolate camera, target, lighting, atmosphere, object visibility, and shader-free material properties over time. Orbit controls remain available after each transition.

## Interaction and resilience

- Four visible buttons, keyboard shortcuts `1`–`4`, drag to orbit, wheel/pinch to zoom.
- Responsive layout supports desktop and narrow screens.
- A loading veil avoids an empty frame; an explicit compatibility message appears if WebGL initialization fails.
- Automated tests verify the mode contract; browser checks verify rendering, interactions, screenshots, and console health.

