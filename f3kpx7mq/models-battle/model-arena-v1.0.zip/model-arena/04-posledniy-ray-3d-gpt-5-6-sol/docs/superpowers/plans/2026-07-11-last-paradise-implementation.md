# Last Paradise 3D Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a browser-native interactive 3D prototype contrasting a living sky city with a ruined planet in one immediate hero frame.

**Architecture:** A dependency-light static site uses locally vendored Three.js modules. A pure mode configuration module is covered by Node tests; the renderer consumes that contract to transition camera, lights, atmosphere, and story objects.

**Tech Stack:** HTML5, CSS, ES modules, Three.js, Node built-in test runner, local HTTP server, in-app Chromium verification.

## Global Constraints

- Russian interface; English code and docs.
- Main entry is `index.html`; all runtime dependencies are local.
- Four real modes: `paradise`, `truth`, `catastrophe`, `survivors`.
- The initial frame must show both the city and the ruined planet.
- No real countries, political symbols, blood, or cruelty.

---

### Task 1: Mode contract

**Files:**
- Create: `tests/modes.test.mjs`
- Create: `src/modes.js`
- Create: `package.json`

**Interfaces:**
- Produces: `MODE_ORDER: string[]`, `MODES: Record<string, Mode>`, `getMode(id): Mode`.

- [ ] Write tests asserting four stable IDs, complete camera/light/effect data, unique Russian labels, and fallback behavior.
- [ ] Run `npm test` and confirm failure because `src/modes.js` does not exist.
- [ ] Implement the minimal complete mode configuration.
- [ ] Run `npm test` and confirm all tests pass.

### Task 2: Static experience

**Files:**
- Create: `index.html`
- Create: `styles.css`
- Create: `src/scene.js`
- Create: `vendor/three.module.js`
- Create: `vendor/OrbitControls.js`

**Interfaces:**
- Consumes: `MODES`, `MODE_ORDER`, and `getMode()` from `src/modes.js`.
- Produces: visible WebGL canvas, `window.__LAST_PARADISE__`, four interactive mode controls, keyboard and pointer camera controls.

- [ ] Vendor pinned Three.js modules and validate import paths.
- [ ] Build semantic HUD and non-empty loading state.
- [ ] Build the city, sanctuary, garden terraces, canals, waterfalls, population lights, planet fragments, clouds, lightning, embers, stars, and debris.
- [ ] Add the animation loop and eased mode transitions.
- [ ] Add responsive and reduced-motion behavior.

### Task 3: Browser verification and deliverables

**Files:**
- Create: `README.md`
- Create: `REPORT.md`
- Create: `RUN-METRICS.md`
- Create: `screenshots/hero.png`
- Create: `screenshots/truth.png`
- Create: `screenshots/catastrophe.png`
- Create: `screenshots/survivors.png`

**Interfaces:**
- Consumes: local HTTP URL for the completed static site.
- Produces: verified artifact and evidence.

- [ ] Run the Node tests and a static-link/file audit.
- [ ] Start a local HTTP server and open `index.html` in Chromium.
- [ ] Confirm the first frame is populated and visually shows both world layers.
- [ ] Activate every mode and confirm scene state changes, collecting one screenshot per required state.
- [ ] Inspect console errors and runtime diagnostics.
- [ ] Record only task-local, available metrics; use `unavailable` for inaccessible values.

