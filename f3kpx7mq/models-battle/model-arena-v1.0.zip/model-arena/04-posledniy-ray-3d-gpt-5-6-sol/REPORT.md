# Verification Report

Date: 2026-07-11  
Artifact: `index.html`  
Test URL: `http://127.0.0.1:4173/index.html`

## Result

**PASS.** The prototype rendered in installed Google Chrome `150.0.7871.101` using an active WebGL 2 context at a 1440×900 viewport.

The initial `Рай` frame visibly contains both narrative layers: the white-and-gold garden city and sanctuary above, and the cracked, ember-lit planet below. The frame was visually inspected after capture. It was neither empty nor black.

## Recorded checks

- Mode-contract tests: 4 passed, 0 failed.
- Initial render: 114,278 triangles and 853 draw calls.
- Loading veil transitioned to the populated scene.
- Russian interface and all four required mode buttons were present.
- `Рай`: warm elevated city composition with active gardens and water.
- `Правда`: camera widened and lowered to expose the complete city/planet relationship.
- `Катастрофа`: camera descended to the planet; storm lighting, embers, debris, cracks, and lightning intensified.
- `Выжившие`: camera returned to the city; one residential arc and its population beacons became prominent, with the `0,00016%` panel visible.
- OrbitControls initialized; drag/orbit and wheel zoom are enabled.
- Browser console errors: 0.
- Uncaught page errors: 0.
- Runtime dependencies loaded locally; no remote CDN is required.

## Screenshots

- `screenshots/hero.png`
- `screenshots/truth.png`
- `screenshots/catastrophe.png`
- `screenshots/survivors.png`

The in-app browser bridge returned an environment-level startup error, so verification used Playwright Core against the installed Chrome executable. The resulting checks, clicks, WebGL render, console capture, and screenshots were all produced by the real browser.

## Task-local run metrics

The Codex rollout log for thread `019f51f5-b15f-7281-abc5-33ed51d84ed7` contains a `task_complete` record for the original build turn and cumulative token usage starting from that turn. It confirms `gpt-5.6-sol` with reasoning effort `xhigh`, 40 model calls, and a wall duration of 848,582 ms.

- Input: 2,222,505 tokens total — 154,025 uncached and 2,068,480 cached.
- Output: 32,026 tokens, including 5,877 reasoning output tokens.
- Total: 2,254,531 tokens.
- Time to first token: 9,854 ms. Aggregate API processing time was not recorded.
- Cache writes: the rollout schema did not emit `cache_write_tokens`, so their quantity and cost remain unavailable.
- Long-context surcharge: not applicable; the largest individual request was 75,676 input tokens, below the 272K threshold.

At the official GPT-5.6 Sol Standard API rates per 1M tokens — $5.00 uncached input, $0.50 cached input, $6.25 cache write, and $30.00 output — the logged-token API equivalent is:

```text
(154,025 × $5 + 2,068,480 × $0.50 + 32,026 × $30) / 1,000,000
= $2.765145
```

This excludes cache-write cost because cache-write tokens were not logged. It is an API-equivalent calculation, not evidence of the actual Codex/ChatGPT Plus charge. The corresponding Codex rate-card usage is 138.257250 credits (250/M uncached input, 25/M cached input, and 1,500/M output). The actual subscription or purchased-credit charge is not exposed in the local session data.

Official rate sources: [GPT-5.6 Sol model page](https://developers.openai.com/api/docs/models/gpt-5.6-sol), [OpenAI API pricing](https://developers.openai.com/api/docs/pricing), and [Codex pricing](https://learn.chatgpt.com/docs/pricing#what-are-tokens-and-credits).
