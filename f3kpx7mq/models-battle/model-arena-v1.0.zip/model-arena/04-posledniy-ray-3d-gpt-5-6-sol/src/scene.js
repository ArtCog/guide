import * as THREE from '../vendor/three.module.js';
import { OrbitControls } from '../vendor/OrbitControls.js';
import { MODE_ORDER, MODES, getMode } from './modes.js';

const $ = (selector) => document.querySelector(selector);
const sceneHost = $('#scene');
const loading = $('#loading');
const loadingProgress = $('#loading-progress');
const errorPanel = $('#error');

const runtime = {
  ready: false,
  mode: 'paradise',
  objects: 0,
  triangles: 0,
  setMode: () => {},
};
window.__LAST_PARADISE__ = runtime;

let renderer;

try {
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = MODES.paradise.exposure;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  sceneHost.appendChild(renderer.domElement);
} catch (error) {
  console.error('WebGL initialization failed:', error);
  loading.classList.add('is-hidden');
  errorPanel.hidden = false;
  throw error;
}

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x31414c);
scene.fog = new THREE.FogExp2(0x34454d, 0.0062);

const camera = new THREE.PerspectiveCamera(46, window.innerWidth / window.innerHeight, 0.1, 240);
camera.position.fromArray(MODES.paradise.camera);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.fromArray(MODES.paradise.target);
controls.enableDamping = true;
controls.dampingFactor = 0.045;
controls.enablePan = false;
controls.minDistance = 17;
controls.maxDistance = 96;
controls.minPolarAngle = 0.25;
controls.maxPolarAngle = Math.PI - 0.18;
controls.update();

const clock = new THREE.Clock();
const root = new THREE.Group();
const city = new THREE.Group();
const sanctuary = new THREE.Group();
const planet = new THREE.Group();
const weather = new THREE.Group();
const debris = new THREE.Group();
const population = new THREE.Group();
root.add(city, planet, weather, debris);
city.add(sanctuary, population);
scene.add(root);

const cityGlowMaterials = [];
const stormMaterials = [];
const waterMaterials = [];
const populationMaterials = [];
const lightningLines = [];
const fallingStreams = [];
const rotatingRings = [];
const floatingPieces = [];

const rng = (() => {
  let seed = 76421;
  return () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
})();

const color = (hex) => new THREE.Color(hex);
const material = (options) => new THREE.MeshStandardMaterial(options);

const ivory = material({ color: 0xe9e6d8, roughness: 0.62, metalness: 0.08 });
const warmStone = material({ color: 0xbfc2ae, roughness: 0.88, metalness: 0.02 });
const gardenMat = material({ color: 0x4c815b, roughness: 0.92 });
const darkGardenMat = material({ color: 0x25523f, roughness: 0.95 });
const gold = material({ color: 0xe4bd6b, roughness: 0.34, metalness: 0.72, emissive: 0x7d4c16, emissiveIntensity: 0.28 });
const glass = material({ color: 0xa8f0df, roughness: 0.08, metalness: 0.1, transparent: true, opacity: 0.42, emissive: 0x2b9f8f, emissiveIntensity: 0.28, side: THREE.DoubleSide });
const water = material({ color: 0x4ddccf, roughness: 0.16, metalness: 0.16, transparent: true, opacity: 0.72, emissive: 0x0c6f7b, emissiveIntensity: 0.75, side: THREE.DoubleSide });
waterMaterials.push(water);

function mesh(geometry, mat, position = [0, 0, 0], rotation = [0, 0, 0], scale = [1, 1, 1]) {
  const object = new THREE.Mesh(geometry, mat);
  object.position.set(...position);
  object.rotation.set(...rotation);
  object.scale.set(...scale);
  object.castShadow = true;
  object.receiveShadow = true;
  return object;
}

function addGlowSphere(parent, position, radius, hex, intensity = 2) {
  const mat = material({ color: hex, emissive: hex, emissiveIntensity: intensity, roughness: 0.18 });
  cityGlowMaterials.push(mat);
  const orb = mesh(new THREE.SphereGeometry(radius, 20, 12), mat, position);
  parent.add(orb);
  return orb;
}

function makeStars() {
  const count = 1300;
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const radius = 80 + rng() * 100;
    const theta = rng() * Math.PI * 2;
    const phi = Math.acos(2 * rng() - 1);
    positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = radius * Math.cos(phi) + 12;
    positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
    const c = new THREE.Color(rng() > 0.82 ? 0xbbe9ff : 0xfff4cc);
    colors.set([c.r, c.g, c.b], i * 3);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const stars = new THREE.Points(geometry, new THREE.PointsMaterial({ size: 0.17, transparent: true, opacity: 0.72, vertexColors: true, sizeAttenuation: true }));
  scene.add(stars);
}

function makeTree(parent, x, y, z, scale = 1, bright = false) {
  const tree = new THREE.Group();
  const trunkMat = bright ? gold : warmStone;
  tree.add(mesh(new THREE.CylinderGeometry(0.055 * scale, 0.09 * scale, 0.72 * scale, 6), trunkMat, [0, 0.36 * scale, 0]));
  const crownMat = bright ? material({ color: 0x91dfa1, emissive: 0x327346, emissiveIntensity: 0.52, roughness: 0.8 }) : (rng() > 0.45 ? gardenMat : darkGardenMat);
  if (bright) cityGlowMaterials.push(crownMat);
  tree.add(mesh(new THREE.IcosahedronGeometry(0.3 * scale, 1), crownMat, [0, 0.83 * scale, 0], [0, rng() * Math.PI, 0], [1, 1.22, 1]));
  tree.position.set(x, y, z);
  parent.add(tree);
  return tree;
}

function buildCity() {
  city.position.y = 2;

  city.add(mesh(new THREE.CylinderGeometry(2.4, 14.2, 7.2, 64, 1), warmStone, [0, -3.65, 0]));
  city.add(mesh(new THREE.CylinderGeometry(14.2, 15.2, 1.25, 64), ivory, [0, 0.4, 0]));
  city.add(mesh(new THREE.CylinderGeometry(12.8, 13.8, 0.42, 64), gardenMat, [0, 1.23, 0]));
  city.add(mesh(new THREE.CylinderGeometry(8.8, 10.4, 1.05, 64), ivory, [0, 2.06, 0]));
  city.add(mesh(new THREE.CylinderGeometry(6.2, 7.8, 0.76, 64), gardenMat, [0, 2.9, 0]));

  for (const [radius, tube, y, mat] of [[13.7, .12, 1.86, gold], [10.3, .16, 2.62, water], [7.75, .11, 3.36, gold]]) {
    const ring = mesh(new THREE.TorusGeometry(radius, tube, 8, 96), mat, [0, y, 0], [Math.PI / 2, 0, 0]);
    city.add(ring);
    if (mat === water) rotatingRings.push(ring);
  }

  const channelGeometry = new THREE.BoxGeometry(8.6, 0.1, 0.28);
  for (let i = 0; i < 8; i += 1) {
    const angle = i * Math.PI / 4;
    const channel = mesh(channelGeometry, water, [Math.cos(angle) * 6.4, 3.42, Math.sin(angle) * 6.4], [0, -angle, 0]);
    city.add(channel);
  }

  for (let i = 0; i < 26; i += 1) {
    const angle = (i / 26) * Math.PI * 2 + 0.12;
    const radius = 8.6 + (i % 3) * 1.55;
    const height = 1.3 + rng() * 3.2;
    const width = 0.5 + rng() * 0.48;
    const tower = new THREE.Group();
    const base = mesh(new THREE.CylinderGeometry(width * 0.78, width, height, 6), ivory, [0, height / 2, 0], [0, angle, 0]);
    tower.add(base);
    if (i % 3 === 0) {
      const capMat = material({ color: 0xdaf7ea, emissive: 0x77d7be, emissiveIntensity: 0.52, transparent: true, opacity: 0.72 });
      cityGlowMaterials.push(capMat);
      tower.add(mesh(new THREE.ConeGeometry(width * .8, .9, 6), capMat, [0, height + .45, 0]));
    } else {
      tower.add(mesh(new THREE.CylinderGeometry(width * .74, width * .74, .1, 12), gardenMat, [0, height + .05, 0]));
      makeTree(tower, 0, height + .08, 0, .58 + rng() * .34);
    }
    tower.position.set(Math.cos(angle) * radius, 1.65, Math.sin(angle) * radius);
    city.add(tower);
  }

  for (let i = 0; i < 68; i += 1) {
    const angle = rng() * Math.PI * 2;
    const radius = 4.3 + rng() * 8.2;
    makeTree(city, Math.cos(angle) * radius, 3.05 + rng() * .2, Math.sin(angle) * radius, .46 + rng() * .72, i % 17 === 0);
  }

  for (let i = 0; i < 6; i += 1) {
    const angle = i * Math.PI / 3 + Math.PI / 6;
    const bridge = mesh(new THREE.BoxGeometry(5.8, .16, .72), glass, [Math.cos(angle) * 14.4, 2.55, Math.sin(angle) * 14.4], [0, -angle, 0]);
    city.add(bridge);
    const outer = mesh(new THREE.CylinderGeometry(2.4, 3.2, .52, 32), ivory, [Math.cos(angle) * 18.1, 2.2, Math.sin(angle) * 18.1]);
    city.add(outer);
    city.add(mesh(new THREE.CylinderGeometry(2.1, 2.45, .2, 32), gardenMat, [Math.cos(angle) * 18.1, 2.58, Math.sin(angle) * 18.1]));
    for (let j = 0; j < 5; j += 1) {
      const a = angle + (j - 2) * .2;
      makeTree(city, Math.cos(angle) * 18.1 + Math.cos(a) * 1.4, 2.65, Math.sin(angle) * 18.1 + Math.sin(a) * 1.4, .52 + rng() * .3);
    }
  }

  buildSanctuary();
  buildWaterfalls();
  buildPopulation();
}

function buildSanctuary() {
  sanctuary.position.y = 3.15;
  sanctuary.add(mesh(new THREE.CylinderGeometry(3.35, 4.15, .5, 48), ivory, [0, .2, 0]));
  sanctuary.add(mesh(new THREE.CylinderGeometry(2.95, 3.2, .12, 48), water, [0, .52, 0]));

  const coreMat = material({ color: 0xfff4bd, emissive: 0xffc45b, emissiveIntensity: 3.8, roughness: .08 });
  cityGlowMaterials.push(coreMat);
  const core = mesh(new THREE.IcosahedronGeometry(1.05, 3), coreMat, [0, 4.2, 0]);
  sanctuary.add(core);
  core.userData.pulse = true;

  for (let i = 0; i < 10; i += 1) {
    const angle = (i / 10) * Math.PI * 2;
    const petal = mesh(new THREE.SphereGeometry(1, 20, 12), glass,
      [Math.cos(angle) * 2.25, 3.4, Math.sin(angle) * 2.25],
      [Math.sin(angle) * .28, -angle, Math.cos(angle) * .28],
      [.42, 2.75, .92]);
    sanctuary.add(petal);
  }

  for (let i = 0; i < 3; i += 1) {
    const arch = mesh(new THREE.TorusGeometry(4.2 + i * .48, .07 + i * .015, 8, 80, Math.PI * 1.34), gold, [0, 3.05, 0], [0, Math.PI / 2 + i * Math.PI / 3, Math.PI * .83]);
    sanctuary.add(arch);
    rotatingRings.push(arch);
  }

  const crownRing = mesh(new THREE.TorusGeometry(2.3, .06, 8, 72), gold, [0, 6.5, 0], [Math.PI / 2, 0, 0]);
  sanctuary.add(crownRing);
  rotatingRings.push(crownRing);
  for (let i = 0; i < 12; i += 1) {
    const a = i * Math.PI / 6;
    sanctuary.add(mesh(new THREE.CylinderGeometry(.03, .06, 2.8, 5), gold, [Math.cos(a) * 1.9, 2.3, Math.sin(a) * 1.9], [Math.sin(a) * .12, 0, -Math.cos(a) * .12]));
  }
}

function buildWaterfalls() {
  for (let i = 0; i < 7; i += 1) {
    const angle = i * Math.PI * 2 / 7 + .24;
    const radius = i % 2 ? 13.2 : 9.8;
    const length = 10 + rng() * 9;
    const streamMat = material({ color: 0x9ffff1, emissive: 0x24b9c2, emissiveIntensity: 1.15, transparent: true, opacity: .52, roughness: .1 });
    waterMaterials.push(streamMat);
    const stream = mesh(new THREE.CylinderGeometry(.06, .22, length, 10), streamMat, [Math.cos(angle) * radius, 1.2 - length / 2, Math.sin(angle) * radius]);
    stream.userData.baseY = stream.position.y;
    stream.userData.phase = rng() * 10;
    city.add(stream);
    fallingStreams.push(stream);
  }

  const count = 360;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const angle = (i % 7) * Math.PI * 2 / 7 + .24 + (rng() - .5) * .035;
    const radius = i % 2 ? 13.2 : 9.8;
    positions[i * 3] = Math.cos(angle) * radius;
    positions[i * 3 + 1] = 1 - rng() * 19;
    positions[i * 3 + 2] = Math.sin(angle) * radius;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const particles = new THREE.Points(geometry, new THREE.PointsMaterial({ color: 0x9cfff0, size: .18, transparent: true, opacity: .7, blending: THREE.AdditiveBlending }));
  particles.userData.waterParticles = true;
  city.add(particles);
  fallingStreams.push(particles);
}

function buildPopulation() {
  const beaconGeometry = new THREE.SphereGeometry(.09, 8, 6);
  for (let i = 0; i < 84; i += 1) {
    const angle = Math.PI * .78 + (rng() - .5) * .88;
    const radius = 8.4 + rng() * 4.3;
    const beaconMat = material({ color: 0xf5ffcb, emissive: 0x9dffbb, emissiveIntensity: 1.8, transparent: true, opacity: .34 });
    populationMaterials.push(beaconMat);
    const beacon = mesh(beaconGeometry, beaconMat, [Math.cos(angle) * radius, 3.2 + rng() * 3.5, Math.sin(angle) * radius]);
    beacon.userData.phase = rng() * Math.PI * 2;
    population.add(beacon);
  }
  population.position.y = 0;
}

function makeCloudCluster(parent, x, y, z, scale, dark = false) {
  const group = new THREE.Group();
  const cloudMat = material({ color: dark ? 0x262733 : 0xbccbc8, roughness: 1, transparent: true, opacity: dark ? .72 : .3, depthWrite: false });
  if (dark) stormMaterials.push(cloudMat);
  for (let i = 0; i < 7; i += 1) {
    const puff = mesh(new THREE.SphereGeometry(.9 + rng() * 1.1, 12, 8), cloudMat, [(rng() - .5) * 5, (rng() - .5) * 1.4, (rng() - .5) * 2.1], [0, 0, 0], [1.8, .72, 1]);
    puff.castShadow = false;
    group.add(puff);
  }
  group.position.set(x, y, z);
  group.scale.setScalar(scale);
  group.userData.speed = (dark ? .004 : .002) * (rng() > .5 ? 1 : -1);
  parent.add(group);
}

function buildWeather() {
  for (let i = 0; i < 20; i += 1) {
    const angle = rng() * Math.PI * 2;
    const radius = 23 + rng() * 16;
    makeCloudCluster(weather, Math.cos(angle) * radius, -5 + (rng() - .5) * 6, Math.sin(angle) * radius, .7 + rng() * 1.2, false);
  }
  for (let i = 0; i < 25; i += 1) {
    const angle = rng() * Math.PI * 2;
    const radius = 12 + rng() * 27;
    makeCloudCluster(weather, Math.cos(angle) * radius, -15 + (rng() - .5) * 8, Math.sin(angle) * radius, .9 + rng() * 1.45, true);
  }

  for (let i = 0; i < 10; i += 1) {
    const points = [];
    let x = (rng() - .5) * 36;
    const z = -3 + rng() * 11;
    for (let j = 0; j < 7; j += 1) {
      points.push(new THREE.Vector3(x, -10 - j * 2.2, z + (rng() - .5) * 2.5));
      x += (rng() - .5) * 3.2;
    }
    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const lineMat = new THREE.LineBasicMaterial({ color: 0xb9d8ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending });
    stormMaterials.push(lineMat);
    const line = new THREE.Line(geometry, lineMat);
    line.userData.phase = rng() * 12;
    line.userData.flash = rng();
    weather.add(line);
    lightningLines.push(line);
  }
}

function buildPlanet() {
  planet.position.y = -29;
  const coreMat = material({ color: 0x121419, roughness: 1, metalness: .08 });
  const sphere = mesh(new THREE.SphereGeometry(14.2, 72, 48), coreMat);
  planet.add(sphere);

  const atmosphereMat = material({ color: 0x512b37, emissive: 0x28101b, emissiveIntensity: .72, transparent: true, opacity: .23, side: THREE.BackSide });
  stormMaterials.push(atmosphereMat);
  planet.add(mesh(new THREE.SphereGeometry(15.1, 48, 32), atmosphereMat));

  for (let i = 0; i < 16; i += 1) {
    const a = rng() * Math.PI * 2;
    const b = (rng() - .5) * Math.PI * .78;
    const radius = 14.18;
    const plateMat = material({ color: i % 3 === 0 ? 0x31383a : 0x24292b, roughness: .94, metalness: .05 });
    const plate = mesh(new THREE.DodecahedronGeometry(2.7 + rng() * 2.8, 0), plateMat,
      [Math.cos(b) * Math.cos(a) * radius, Math.sin(b) * radius, Math.cos(b) * Math.sin(a) * radius],
      [rng() * Math.PI, rng() * Math.PI, rng() * Math.PI],
      [1.2, .32 + rng() * .35, 1]);
    plate.lookAt(0, 0, 0);
    planet.add(plate);
  }

  const crackMat = material({ color: 0xff7b3d, emissive: 0xff3c16, emissiveIntensity: 4.5, roughness: .2 });
  stormMaterials.push(crackMat);
  for (let i = 0; i < 15; i += 1) {
    const start = -1.1 + rng() * 2.2;
    const longitude = -.9 + rng() * 1.8;
    const points = [];
    for (let j = 0; j < 8; j += 1) {
      const lat = start + (j - 3.5) * .13 + (rng() - .5) * .1;
      const lon = longitude + Math.sin(j * 1.4 + i) * .13;
      const r = 14.48;
      points.push(new THREE.Vector3(Math.sin(lon) * Math.cos(lat) * r, Math.sin(lat) * r, Math.cos(lon) * Math.cos(lat) * r));
    }
    const curve = new THREE.CatmullRomCurve3(points);
    planet.add(mesh(new THREE.TubeGeometry(curve, 38, .045 + rng() * .055, 5, false), crackMat));
  }

  for (let i = 0; i < 36; i += 1) {
    const angle = rng() * Math.PI * 2;
    const radius = 17 + rng() * 15;
    const y = (rng() - .5) * 24;
    const rockMat = material({ color: rng() > .82 ? 0x6f3b2e : 0x242629, roughness: .96 });
    const piece = mesh(new THREE.DodecahedronGeometry(.32 + rng() * 1.25, 0), rockMat, [Math.cos(angle) * radius, y, Math.sin(angle) * radius], [rng() * 4, rng() * 4, rng() * 4], [1, .5 + rng(), 1]);
    piece.userData.speed = .02 + rng() * .08;
    piece.userData.phase = rng() * 10;
    debris.add(piece);
    floatingPieces.push(piece);
  }

  const emberCount = 600;
  const emberPositions = new Float32Array(emberCount * 3);
  for (let i = 0; i < emberCount; i += 1) {
    const angle = rng() * Math.PI * 2;
    const radius = 14 + rng() * 24;
    emberPositions[i * 3] = Math.cos(angle) * radius;
    emberPositions[i * 3 + 1] = -32 + rng() * 31;
    emberPositions[i * 3 + 2] = Math.sin(angle) * radius;
  }
  const emberGeometry = new THREE.BufferGeometry();
  emberGeometry.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));
  const emberMat = new THREE.PointsMaterial({ color: 0xff6a35, size: .22, transparent: true, opacity: .45, blending: THREE.AdditiveBlending });
  stormMaterials.push(emberMat);
  const embers = new THREE.Points(emberGeometry, emberMat);
  embers.userData.embers = true;
  debris.add(embers);
}

const hemisphere = new THREE.HemisphereLight(0xdff9ef, 0x351c27, MODES.paradise.ambientIntensity);
scene.add(hemisphere);
const sun = new THREE.DirectionalLight(0xfff0bd, MODES.paradise.sunIntensity);
sun.position.set(-16, 32, 24);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -36;
sun.shadow.camera.right = 36;
sun.shadow.camera.top = 36;
sun.shadow.camera.bottom = -36;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 95;
scene.add(sun);
const paradiseLight = new THREE.PointLight(0x99ffe4, 34, 55, 1.35);
paradiseLight.position.set(0, 10, 2);
scene.add(paradiseLight);
const planetLight = new THREE.PointLight(0xff421f, 18, 62, 1.7);
planetLight.position.set(2, -24, 10);
scene.add(planetLight);

loadingProgress.textContent = 'СТРОИМ ГОРОД-САД / 02';
makeStars();
buildCity();
loadingProgress.textContent = 'СОЕДИНЯЕМ МИРЫ / 03';
buildPlanet();
buildWeather();

const transition = {
  active: false,
  started: 0,
  duration: 1700,
  fromCamera: new THREE.Vector3(),
  toCamera: new THREE.Vector3(),
  fromTarget: new THREE.Vector3(),
  toTarget: new THREE.Vector3(),
  fromMode: MODES.paradise,
  toMode: MODES.paradise,
};

function updateInterface(modeId, mode) {
  document.documentElement.style.setProperty('--accent', `#${mode.accent}`);
  document.body.dataset.mode = modeId;
  $('.story').animate([{ opacity: .18, transform: 'translateY(-39%)' }, { opacity: 1, transform: 'translateY(-42%)' }], { duration: 620, easing: 'ease-out' });
  $('#eyebrow').textContent = mode.eyebrow;
  $('#story-title').innerHTML = mode.title.replace(' ', '<br>');
  $('#story-description').textContent = mode.description;
  $('#survivor-panel').classList.toggle('is-visible', modeId === 'survivors');
  $('#survivor-panel').setAttribute('aria-hidden', modeId === 'survivors' ? 'false' : 'true');

  const telemetry = {
    paradise: ['38 400 м', 'СТАБИЛЬНА', '87%'],
    truth: ['38 400 м', 'РАЗОРВАНА', '12%'],
    catastrophe: ['−7 200 м', 'КРИТИЧНО', '3%'],
    survivors: ['38 400 м', 'ЛОКАЛЬНА', '0,00016%'],
  }[modeId];
  $('#altitude').textContent = telemetry[0];
  $('#atmosphere').textContent = telemetry[1];
  $('#biosphere').textContent = telemetry[2];

  document.querySelectorAll('.mode-button').forEach((button) => {
    const active = button.dataset.mode === modeId;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

function setMode(modeId, immediate = false) {
  const resolvedId = MODES[modeId] ? modeId : 'paradise';
  const mode = getMode(resolvedId);
  runtime.mode = resolvedId;
  transition.fromCamera.copy(camera.position);
  transition.toCamera.fromArray(mode.camera);
  transition.fromTarget.copy(controls.target);
  transition.toTarget.fromArray(mode.target);
  transition.fromMode = getMode(document.body.dataset.mode || 'paradise');
  transition.toMode = mode;
  transition.started = performance.now();
  transition.duration = immediate ? 1 : 1700;
  transition.active = true;
  controls.enabled = immediate;
  updateInterface(resolvedId, mode);
  window.dispatchEvent(new CustomEvent('last-paradise-mode', { detail: { mode: resolvedId } }));
}

runtime.setMode = setMode;

for (const button of document.querySelectorAll('.mode-button')) {
  button.addEventListener('click', () => setMode(button.dataset.mode));
}

$('.identity').addEventListener('click', (event) => {
  event.preventDefault();
  setMode('paradise');
});

window.addEventListener('keydown', (event) => {
  const index = Number(event.key) - 1;
  if (MODE_ORDER[index]) setMode(MODE_ORDER[index]);
});

function easeInOutCubic(t) {
  return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function lerpModeValue(from, to, t) {
  return THREE.MathUtils.lerp(from, to, t);
}

function applyModeFrame(mode, t, elapsed) {
  const storm = lerpModeValue(transition.fromMode.storm, mode.storm, t);
  const glow = lerpModeValue(transition.fromMode.cityGlow, mode.cityGlow, t);
  const populationFocus = lerpModeValue(transition.fromMode.populationFocus, mode.populationFocus, t);
  sun.intensity = lerpModeValue(transition.fromMode.sunIntensity, mode.sunIntensity, t);
  hemisphere.intensity = lerpModeValue(transition.fromMode.ambientIntensity, mode.ambientIntensity, t);
  renderer.toneMappingExposure = lerpModeValue(transition.fromMode.exposure, mode.exposure, t);
  sun.color.lerpColors(color(`#${transition.fromMode.lightColor}`), color(`#${mode.lightColor}`), t);
  paradiseLight.intensity = 21 + glow * 15;
  planetLight.intensity = 5 + storm * 31;
  scene.fog.density = .0048 + storm * .0042;
  scene.fog.color.lerpColors(color(0x46595e), color(0x241d27), storm);
  scene.background.lerpColors(color(0x526b72), color(0x1c1822), storm * .86);

  for (const mat of cityGlowMaterials) mat.emissiveIntensity = Math.max(.15, (mat.userData?.base ?? mat.emissiveIntensity) * .86 + glow * .42);
  for (const mat of stormMaterials) {
    if ('opacity' in mat && mat.transparent) mat.opacity = Math.min(.92, .1 + storm * .72);
    if ('emissiveIntensity' in mat) mat.emissiveIntensity = .35 + storm * 4.1;
  }
  for (const mat of populationMaterials) {
    mat.opacity = .18 + populationFocus * .82;
    mat.emissiveIntensity = 1.1 + populationFocus * 5.4;
  }
  population.scale.setScalar(.8 + populationFocus * .32);
  planet.rotation.y += .00042 + storm * .0011;
  weather.rotation.y += .00018 + storm * .0008;
  debris.rotation.y -= .0003 + storm * .0007;

  lightningLines.forEach((line, index) => {
    const pulse = Math.max(0, Math.sin(elapsed * (2.7 + index * .07) + line.userData.phase));
    line.material.opacity = storm * (pulse > .94 ? .96 : .02);
  });
}

function updateMotion(elapsed, delta) {
  controls.update();
  sanctuary.rotation.y = Math.sin(elapsed * .09) * .04;
  rotatingRings.forEach((ring, i) => { ring.rotation.z += (.0008 + i * .00014) * (i % 2 ? 1 : -1); });
  weather.children.forEach((cloud) => { if (cloud.userData.speed) cloud.rotation.y += cloud.userData.speed * delta * 18; });
  floatingPieces.forEach((piece, index) => {
    piece.rotation.x += piece.userData.speed * delta;
    piece.rotation.y += piece.userData.speed * .74 * delta;
    piece.position.y += Math.sin(elapsed * .44 + piece.userData.phase + index) * .0015;
  });
  population.children.forEach((beacon) => {
    const pulse = .82 + Math.sin(elapsed * 2.1 + beacon.userData.phase) * .18;
    beacon.scale.setScalar(pulse);
  });
  sanctuary.children.forEach((child) => {
    if (child.userData.pulse) child.scale.setScalar(1 + Math.sin(elapsed * 1.35) * .055);
  });

  const waterParticles = fallingStreams.find((item) => item.userData.waterParticles);
  if (waterParticles) {
    const attr = waterParticles.geometry.attributes.position;
    for (let i = 0; i < attr.count; i += 1) {
      let y = attr.getY(i) - delta * (2.7 + (i % 5) * .16);
      if (y < -18) y = 1;
      attr.setY(i, y);
    }
    attr.needsUpdate = true;
  }
}

function animate(now) {
  requestAnimationFrame(animate);
  const delta = Math.min(clock.getDelta(), .05);
  const elapsed = clock.elapsedTime;

  if (transition.active) {
    const raw = Math.min(1, (now - transition.started) / transition.duration);
    const t = easeInOutCubic(raw);
    camera.position.lerpVectors(transition.fromCamera, transition.toCamera, t);
    controls.target.lerpVectors(transition.fromTarget, transition.toTarget, t);
    applyModeFrame(transition.toMode, t, elapsed);
    if (raw >= 1) {
      transition.active = false;
      controls.enabled = true;
      transition.fromMode = transition.toMode;
    }
  } else {
    applyModeFrame(getMode(runtime.mode), 1, elapsed);
  }

  updateMotion(elapsed, delta);
  renderer.render(scene, camera);
  runtime.triangles = renderer.info.render.triangles;
  runtime.objects = renderer.info.render.calls;
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
}
window.addEventListener('resize', onResize);

renderer.compile(scene, camera);
setMode('paradise', true);
animate(performance.now());

requestAnimationFrame(() => {
  runtime.ready = true;
  loadingProgress.textContent = 'СИСТЕМА ГОТОВА / 04';
  setTimeout(() => loading.classList.add('is-hidden'), 260);
  window.dispatchEvent(new CustomEvent('last-paradise-ready', { detail: { mode: runtime.mode } }));
});
