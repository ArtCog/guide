import assert from 'node:assert/strict';
import { chromium } from 'playwright-core';

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  headless: true,
  args: [
    '--use-angle=swiftshader',
    '--enable-webgl',
    '--enable-unsafe-swiftshader',
    '--ignore-gpu-blocklist',
  ],
});

const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const consoleErrors = [];
const pageErrors = [];

page.on('console', (message) => {
  if (message.type() === 'error') consoleErrors.push(message.text());
});
page.on('pageerror', (error) => pageErrors.push(error.message));

await page.goto('http://127.0.0.1:4173/index.html', { waitUntil: 'networkidle' });
await page.waitForFunction(() => window.__LAST_PARADISE__?.ready === true, null, { timeout: 30_000 });
await page.waitForTimeout(2200);

const initial = await page.evaluate(() => ({
  title: document.title,
  mode: window.__LAST_PARADISE__.mode,
  ready: window.__LAST_PARADISE__.ready,
  triangles: window.__LAST_PARADISE__.triangles,
  drawCalls: window.__LAST_PARADISE__.objects,
  canvas: {
    width: document.querySelector('canvas')?.width,
    height: document.querySelector('canvas')?.height,
  },
  loadingHidden: document.querySelector('#loading')?.classList.contains('is-hidden'),
  buttons: [...document.querySelectorAll('.mode-button[data-mode]')].map((button) => button.dataset.mode),
  webgl: (() => {
    const canvas = document.querySelector('canvas');
    const gl = canvas?.getContext('webgl2') || canvas?.getContext('webgl');
    return gl ? { version: gl.getParameter(gl.VERSION), renderer: gl.getParameter(gl.RENDERER) } : null;
  })(),
}));

assert.equal(initial.ready, true);
assert.equal(initial.mode, 'paradise');
assert.equal(initial.loadingHidden, true);
assert.deepEqual(initial.buttons, ['paradise', 'truth', 'catastrophe', 'survivors']);
assert.ok(initial.canvas.width > 0 && initial.canvas.height > 0);
assert.ok(initial.triangles > 10_000, `Expected a real 3D scene, got ${initial.triangles} triangles`);
assert.ok(initial.drawCalls > 100, `Expected a composed scene, got ${initial.drawCalls} draw calls`);
assert.ok(initial.webgl, 'Expected an active WebGL context');

await page.screenshot({ path: 'screenshots/hero.png', fullPage: true });

const states = [
  ['truth', 'screenshots/truth.png'],
  ['catastrophe', 'screenshots/catastrophe.png'],
  ['survivors', 'screenshots/survivors.png'],
];

for (const [mode, path] of states) {
  await page.locator(`.mode-button[data-mode="${mode}"]`).click();
  await page.waitForFunction((expected) => document.body.dataset.mode === expected && window.__LAST_PARADISE__.mode === expected, mode);
  await page.waitForTimeout(2300);
  const state = await page.evaluate(() => ({
    mode: window.__LAST_PARADISE__.mode,
    pressed: document.querySelector('.mode-button[data-mode][aria-pressed="true"]')?.dataset.mode,
    title: document.querySelector('#story-title')?.textContent,
    survivorPanel: document.querySelector('#survivor-panel')?.classList.contains('is-visible'),
    triangles: window.__LAST_PARADISE__.triangles,
  }));
  assert.equal(state.mode, mode);
  assert.equal(state.pressed, mode);
  assert.ok(state.title?.length > 8);
  assert.equal(state.survivorPanel, mode === 'survivors');
  assert.ok(state.triangles > 10_000);
  await page.screenshot({ path, fullPage: true });
}

assert.deepEqual(pageErrors, [], `Page errors: ${pageErrors.join(' | ')}`);
assert.deepEqual(consoleErrors, [], `Console errors: ${consoleErrors.join(' | ')}`);

console.log(JSON.stringify({
  verdict: 'pass',
  browser: await browser.version(),
  url: page.url(),
  initial,
  screenshots: ['hero.png', 'truth.png', 'catastrophe.png', 'survivors.png'],
  consoleErrors,
  pageErrors,
}, null, 2));

await browser.close();
