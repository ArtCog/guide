import test from 'node:test';
import assert from 'node:assert/strict';
import { MODE_ORDER, MODES, getMode } from '../src/modes.js';

test('exposes exactly four story modes in the required order', () => {
  assert.deepEqual(MODE_ORDER, ['paradise', 'truth', 'catastrophe', 'survivors']);
  assert.equal(Object.keys(MODES).length, 4);
});

test('every mode has a unique Russian label and complete scene parameters', () => {
  const labels = new Set();
  for (const id of MODE_ORDER) {
    const mode = MODES[id];
    assert.match(mode.label, /[А-Яа-яЁё]/);
    assert.equal(mode.camera.length, 3);
    assert.equal(mode.target.length, 3);
    assert.equal(mode.lightColor.length, 6);
    assert.equal(mode.accent.length, 6);
    assert.ok(Number.isFinite(mode.sunIntensity));
    assert.ok(Number.isFinite(mode.storm));
    assert.ok(Number.isFinite(mode.cityGlow));
    labels.add(mode.label);
  }
  assert.equal(labels.size, 4);
});

test('the modes produce materially different camera, light, and effect states', () => {
  const signatures = MODE_ORDER.map((id) => {
    const m = MODES[id];
    return JSON.stringify([m.camera, m.target, m.lightColor, m.storm, m.cityGlow]);
  });
  assert.equal(new Set(signatures).size, 4);
  assert.ok(MODES.catastrophe.storm > MODES.paradise.storm);
  assert.ok(MODES.survivors.populationFocus > MODES.truth.populationFocus);
});

test('getMode falls back to paradise for unknown input', () => {
  assert.equal(getMode('truth'), MODES.truth);
  assert.equal(getMode('not-a-mode'), MODES.paradise);
  assert.equal(getMode(), MODES.paradise);
});
