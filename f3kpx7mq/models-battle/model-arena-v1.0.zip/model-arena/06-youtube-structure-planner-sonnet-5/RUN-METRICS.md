# RUN-METRICS — тест 05 «YouTube-планировщик»

| Поле | Значение |
|---|---|
| Модель | Claude Sonnet 5 (`claude-sonnet-5`), Claude Code |
| Тест | 05 — ремонт сломанного YouTube-планировщика |
| Время задачи | 15m 14s |
| Input tokens | 19.6k |
| Output tokens | 55.7k |
| Cache read | 4.9m |
| Cache write | 542.4k |
| Стоимость USD | $5.62 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\05-youtube-structure-planner-sonnet-5\index.html` |

**Источник времени:** ручная фиксация после завершения теста.

**Примечание по стоимости и токенам:** метрики токенов и USD для теста 05
оценочные, потому что счетчик сессии был загрязнен предыдущими задачами после
очистки истории. Для этого теста валиднее сравнивать время задачи и качество
ремонта.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $5.62 / 17.5k input / 55.6k output / 4.9m cache read / 542.4k cache write.
- Previous checkpoint: clean standalone session, not cumulative after test 04.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
