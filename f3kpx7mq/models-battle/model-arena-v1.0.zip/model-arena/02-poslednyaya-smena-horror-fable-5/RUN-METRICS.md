# RUN-METRICS

| Поле | Значение |
|---|---|
| Модель | Fable 5 (claude-fable-5) |
| Тест | 02 — «Последняя смена», хоррор от первого лица |
| Время задачи | 13m 25s |
| Время API | 43m 11s |
| Wall-время | 10h 4m 39s |
| Input tokens | 20.0k |
| Output tokens | 98.2k |
| Cache read | 6.6m |
| Cache write | 296.0k |
| Стоимость USD | $17.51 |
| Путь к index.html | C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-fable-5\index.html |
| Короткий вердикт | |

## Детали

- Изменения кода: 4169 строк добавлено, 12 удалено.
- Токены в таблице — по основной модели claude-fable-5.
  Вспомогательная claude-haiku-4-5: 3.3k input, 66 output, без кэша.
- Время задачи обновлено по финальному сообщению Claude Code: `Sautéed for 13m 25s`.
- Wall-время включает простой сессии; старое API-время оставлено справочно и не используется как рабочее время задачи.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $32.26 / 32.5k input / 161.2k output / 8.7m cache read / 760.9k cache write.
- Previous checkpoint: $14.75 / 15.8k input / 63.1k output / 2.1m cache read / 464.9k cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
