'use strict';
/* ============================================================
   ПОСЛЕДНЯЯ СМЕНА — first-person browser horror prototype
   Pure Canvas2D raycaster, procedural textures & WebAudio SFX.
   No external assets, runs from file://
   ============================================================ */

/* ======================= MAP ======================= */
// # concrete  M fridge wall  T tiled wall  D auto door  X exit door (locked)
// G generator  P player start  S demon spawn  1/2/3 keycards  W win zone  . floor
const MAP = [
  "########################",
  "#P...#.....M.M.M.M.M...#",
  "#....#.................#",
  "#....D.....######..##D##",
  "#....#.....#TTTT#..#...#",
  "######.....#T.1.D..#.M.#",
  "#....#.....#TTTT#..#...#",
  "#.M..#.....######..#.M.#",
  "#.M..D.............#..3#",
  "#....#..#####D###..##.##",
  "#.2..#..#.......#......#",
  "#....#..#..GG...#......#",
  "######..#..GG...D..##D##",
  "#....#..#.......#..#...#",
  "#.S..D..#########..#.M.#",
  "#....#.............#...#",
  "##.###..##########.#.M.#",
  "#....#..#........#.#...#",
  "#.M..#..#..MMMM..#.##X##",
  "#....D..D........#.#..W#",
  "#......#..........#..WW#",
  "########################",
];
const MW = MAP[0].length, MH = MAP.length;
const grid = new Uint8Array(MW * MH);
const doors = new Map();          // idx -> {open, timer}
const winSet = new Set();         // idx of exit floor
const genCells = [];              // [x,y] generator blocks
let startPos = { x: 2.5, y: 2.5 }, demonSpawn = { x: 2.5, y: 14.5 };
const cardSpawns = [];            // {x,y,id}

for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) {
  const ch = MAP[y][x], idx = y * MW + x;
  switch (ch) {
    case '#': grid[idx] = 1; break;
    case 'M': grid[idx] = 2; break;
    case 'T': grid[idx] = 3; break;
    case 'D': grid[idx] = 4; doors.set(idx, { open: 0, timer: 0 }); break;
    case 'X': grid[idx] = 5; doors.set(idx, { open: 0, timer: 0 }); break;
    case 'G': grid[idx] = 6; genCells.push([x, y]); break;
    case 'P': startPos = { x: x + .5, y: y + .5 }; break;
    case 'S': demonSpawn = { x: x + .5, y: y + .5 }; break;
    case '1': case '2': case '3': cardSpawns.push({ x: x + .5, y: y + .5, id: +ch }); break;
    case 'W': winSet.add(idx); break;
  }
}

/* ======================= CANVAS ======================= */
const view = document.getElementById('view');
const vctx = view.getContext('2d');
let RW = 400, RH = 240, zbuf = new Float32Array(RW);

function resize() {
  const aspect = innerWidth / Math.max(1, innerHeight);
  RH = 240;
  RW = Math.max(220, Math.min(640, Math.round(RH * aspect)));
  view.width = RW; view.height = RH;
  vctx.imageSmoothingEnabled = false;
  zbuf = new Float32Array(RW);
}
addEventListener('resize', resize);
resize();

/* ======================= PROCEDURAL TEXTURES ======================= */
function mkTex(w, h, draw) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d');
  draw(g, w, h);
  return c;
}
const R = Math.random;

function grime(g, w, h, n, col) {
  for (let i = 0; i < n; i++) {
    g.fillStyle = `rgba(${col},${(R() * .14).toFixed(3)})`;
    const r = 2 + R() * 9;
    g.beginPath(); g.arc(R() * w, R() * h, r, 0, 7); g.fill();
  }
}
function speckle(g, w, h, n) {
  for (let i = 0; i < n; i++) {
    const v = (R() * 30) | 0;
    g.fillStyle = `rgba(${v},${v},${v},.25)`;
    g.fillRect(R() * w, R() * h, 1, 1);
  }
}

const texConcrete = mkTex(64, 64, (g, w, h) => {
  g.fillStyle = '#39362f'; g.fillRect(0, 0, w, h);
  speckle(g, w, h, 900);
  for (let i = 0; i < 12; i++) {          // damp streaks
    const x = R() * w, lw = 1 + R() * 3;
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, 'rgba(0,0,0,.35)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(x, 0, lw, h);
  }
  g.strokeStyle = 'rgba(10,10,10,.5)';    // cracks
  for (let i = 0; i < 4; i++) {
    g.beginPath(); let x = R() * w, y = 0;
    g.moveTo(x, y);
    while (y < h) { y += 6 + R() * 8; x += (R() - .5) * 8; g.lineTo(x, y); }
    g.stroke();
  }
  const gr = g.createLinearGradient(0, h * .6, 0, h);
  gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(5,8,5,.55)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
});

const texFridge = mkTex(64, 64, (g, w, h) => {
  g.fillStyle = '#3c4347'; g.fillRect(0, 0, w, h);
  speckle(g, w, h, 400);
  for (let ry = 0; ry < 2; ry++) for (let rx = 0; rx < 2; rx++) {
    const x = 3 + rx * 31, y = 3 + ry * 31;
    const gr = g.createLinearGradient(x, y, x + 27, y + 27);
    gr.addColorStop(0, '#4d565c'); gr.addColorStop(1, '#31383c');
    g.fillStyle = gr; g.fillRect(x, y, 27, 27);
    g.strokeStyle = '#1c2124'; g.lineWidth = 2; g.strokeRect(x, y, 27, 27);
    g.fillStyle = '#5e686e'; g.fillRect(x + 3, y + 11, 3, 8);        // handle
    g.fillStyle = 'rgba(200,200,190,.5)'; g.fillRect(x + 15, y + 5, 9, 5); // tag
  }
  grime(g, w, h, 25, '120,60,20');   // rust
  grime(g, w, h, 20, '0,0,0');
});

const texTile = mkTex(64, 64, (g, w, h) => {
  g.fillStyle = '#20241f'; g.fillRect(0, 0, w, h);
  for (let ty = 0; ty < 8; ty++) for (let tx = 0; tx < 8; tx++) {
    const v = 78 + (R() * 22 | 0);
    g.fillStyle = `rgb(${v},${v + 4},${v - 6})`;
    g.fillRect(tx * 8 + 1, ty * 8 + 1, 6, 6);
  }
  grime(g, w, h, 30, '20,16,10');
  grime(g, w, h, 6, '60,25,15');     // faint old stains
  const gr = g.createLinearGradient(0, h * .7, 0, h);
  gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.5)');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
});

const texDoor = mkTex(64, 64, (g, w, h) => {
  const gr = g.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, '#4a4c50'); gr.addColorStop(1, '#33353a');
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.strokeStyle = '#1e2023'; g.lineWidth = 3; g.strokeRect(2, 1, 60, 62);
  g.strokeStyle = '#565a60'; g.lineWidth = 1; g.strokeRect(8, 6, 48, 40);
  g.fillStyle = 'rgba(215,215,205,.55)'; g.fillRect(24, 12, 16, 8);  // plate
  g.fillStyle = '#171a1c';
  for (let i = 0; i < 5; i++) g.fillRect(14, 50 + i * 2.4, 36, 1.2); // vent
  g.fillStyle = '#6a7076'; g.fillRect(50, 30, 6, 3);                 // handle
  speckle(g, w, h, 250); grime(g, w, h, 12, '0,0,0');
});

function exitTex(on) {
  return mkTex(64, 64, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#3a3d42'); gr.addColorStop(1, '#26282c');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.strokeStyle = '#141517'; g.lineWidth = 3; g.strokeRect(2, 1, 60, 62);
    g.fillStyle = '#0a0c0a'; g.fillRect(10, 6, 44, 14);              // sign box
    g.font = 'bold 10px Arial'; g.textAlign = 'center';
    if (on) { g.shadowColor = '#4f6'; g.shadowBlur = 6; g.fillStyle = '#7fdf70'; }
    else { g.shadowColor = '#f33'; g.shadowBlur = 4; g.fillStyle = '#8f2318'; }
    g.fillText('ВЫХОД', 32, 17); g.shadowBlur = 0;
    g.fillStyle = on ? 'rgba(120,220,110,.9)' : 'rgba(140,30,20,.9)';
    g.beginPath(); g.arc(32, 28, 3, 0, 7); g.fill();                 // lamp
    g.fillStyle = '#101214';
    for (let i = 0; i < 4; i++) g.fillRect(14, 38 + i * 5, 36, 2.4); // bars
    speckle(g, w, h, 200);
  });
}
const texExitLocked = exitTex(false), texExitOpen = exitTex(true);

function genTex(on) {
  return mkTex(64, 64, (g, w, h) => {
    g.fillStyle = '#24262a'; g.fillRect(0, 0, w, h);
    g.strokeStyle = '#101214'; g.lineWidth = 2; g.strokeRect(3, 3, 58, 58);
    g.fillStyle = '#17191c';
    for (let i = 0; i < 7; i++) g.fillRect(8, 8 + i * 5, 30, 3);     // radiator
    g.fillStyle = '#0d0f11'; g.fillRect(44, 8, 14, 34);              // panel
    for (let i = 0; i < 4; i++) {
      if (on) { g.shadowColor = '#fa5'; g.shadowBlur = 5; g.fillStyle = i < 3 ? '#ffb04d' : '#7fdf70'; }
      else { g.shadowBlur = 0; g.fillStyle = '#2a2d31'; }
      g.beginPath(); g.arc(51, 13 + i * 8, 2.4, 0, 7); g.fill();
    }
    g.shadowBlur = 0;
    g.strokeStyle = '#0a0b0d'; g.lineWidth = 3;                      // cables
    for (let i = 0; i < 3; i++) {
      g.beginPath(); g.moveTo(10 + i * 16, 46);
      g.quadraticCurveTo(14 + i * 16, 58, 22 + i * 16, 62); g.stroke();
    }
    g.fillStyle = on ? '#c8b370' : '#4a4438';
    g.fillRect(10, 46, 10, 6);                                       // switch
    speckle(g, w, h, 250); grime(g, w, h, 10, '90,50,20');
  });
}
const texGenOff = genTex(false), texGenOn = genTex(true);

/* ---------- demon sprite ---------- */
const DEMW = 128, DEMH = 256;
const texDemon = mkTex(DEMW, DEMH, (g) => {
  // ragged towering silhouette
  g.fillStyle = '#07070a';
  g.beginPath();
  g.moveTo(64, 8);
  let pts = [];
  for (let y = 20; y <= 250; y += 14) {                 // right edge
    const spread = 20 + (y / 250) * 34;
    pts.push([64 + spread + (R() - .5) * 10, y]);
  }
  pts.forEach(p => g.lineTo(p[0], p[1]));
  g.lineTo(64, 254);
  pts = [];
  for (let y = 250; y >= 20; y -= 14) {                 // left edge
    const spread = 20 + (y / 250) * 34;
    pts.push([64 - spread - (R() - .5) * 10, y]);
  }
  pts.forEach(p => g.lineTo(p[0], p[1]));
  g.closePath(); g.fill();
  // faint cold rim so silhouette reads in half-light
  g.strokeStyle = 'rgba(70,80,105,.16)'; g.lineWidth = 2; g.stroke();
  // long arms with claws
  g.strokeStyle = '#050507'; g.lineCap = 'round';
  for (const s of [-1, 1]) {
    g.lineWidth = 9;
    g.beginPath(); g.moveTo(64 + s * 26, 78);
    g.quadraticCurveTo(64 + s * 48, 140, 64 + s * 44, 208); g.stroke();
    g.lineWidth = 2;
    for (let f = 0; f < 4; f++) {
      g.beginPath(); g.moveTo(64 + s * 44, 206);
      g.lineTo(64 + s * (40 + f * 4), 228 + R() * 8); g.stroke();
    }
  }
  // pale mask-like face
  g.save(); g.translate(64, 40); g.rotate(-.06);
  const fg = g.createRadialGradient(0, -6, 4, 0, 0, 30);
  fg.addColorStop(0, '#d6cfc0'); fg.addColorStop(.75, '#a89f8e'); fg.addColorStop(1, '#5d564a');
  g.fillStyle = fg;
  g.beginPath(); g.ellipse(0, 0, 21, 28, 0, 0, 7); g.fill();
  g.fillStyle = 'rgba(60,50,42,.45)';                    // sunken cheeks
  g.beginPath(); g.ellipse(-11, 12, 6, 10, .3, 0, 7); g.fill();
  g.beginPath(); g.ellipse(11, 12, 6, 10, -.3, 0, 7); g.fill();
  g.fillStyle = '#050505';                               // eye pits
  g.beginPath(); g.ellipse(-9, -7, 6.5, 9, .12, 0, 7); g.fill();
  g.beginPath(); g.ellipse(9, -6, 6.5, 9, -.12, 0, 7); g.fill();
  // wide wrong mouth
  g.beginPath();
  g.moveTo(-14, 14);
  g.bezierCurveTo(-6, 10, 8, 12, 15, 16);
  g.bezierCurveTo(10, 30, -4, 32, -12, 24);
  g.closePath(); g.fill();
  g.strokeStyle = 'rgba(20,16,14,.7)'; g.lineWidth = 1;  // face cracks
  for (let i = 0; i < 6; i++) {
    g.beginPath(); g.moveTo((R() - .5) * 34, (R() - .5) * 44);
    g.lineTo((R() - .5) * 40, (R() - .5) * 52); g.stroke();
  }
  g.restore();
});
// glowing eyes drawn unshaded (visible in the dark)
const texDemonEyes = mkTex(DEMW, DEMH, (g) => {
  for (const ex of [55, 73]) {
    const gr = g.createRadialGradient(ex, 33, 0, ex, 33, 9);
    gr.addColorStop(0, 'rgba(255,252,235,1)');
    gr.addColorStop(.3, 'rgba(255,205,130,.85)');
    gr.addColorStop(1, 'rgba(255,150,60,0)');
    g.fillStyle = gr;
    g.beginPath(); g.arc(ex, 33, 9, 0, 7); g.fill();
  }
});

/* ---------- keycard sprite ---------- */
const texCard = mkTex(64, 64, (g) => {
  const gr = g.createRadialGradient(32, 32, 2, 32, 32, 28);
  gr.addColorStop(0, 'rgba(255,210,110,.5)'); gr.addColorStop(1, 'rgba(255,180,60,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  g.save(); g.translate(32, 32); g.rotate(-.25);
  g.fillStyle = '#20313b'; g.fillRect(-19, -12, 38, 24);
  g.strokeStyle = '#d8c56a'; g.lineWidth = 2; g.strokeRect(-19, -12, 38, 24);
  g.fillStyle = '#d8c56a'; g.fillRect(-19, -4, 38, 6);
  g.fillStyle = '#9fb6bf'; g.fillRect(-14, 4, 16, 4);
  g.restore();
});

/* ---------- jumpscare face (512x512, drawn once) ---------- */
const scareFace = mkTex(512, 512, (g) => {
  g.fillStyle = '#000'; g.fillRect(0, 0, 512, 512);
  g.save(); g.translate(256, 268); g.rotate(-.045);
  const fg = g.createRadialGradient(0, -40, 30, 0, 0, 230);
  fg.addColorStop(0, '#ddd5c4'); fg.addColorStop(.6, '#9c937f'); fg.addColorStop(1, '#241f18');
  g.fillStyle = fg;
  g.beginPath(); g.ellipse(0, 0, 158, 205, 0, 0, 7); g.fill();
  // mottled skin
  for (let i = 0; i < 90; i++) {
    g.fillStyle = `rgba(70,58,45,${(R() * .16).toFixed(3)})`;
    g.beginPath(); g.arc((R() - .5) * 280, (R() - .5) * 360, 4 + R() * 16, 0, 7); g.fill();
  }
  // veins / cracks
  g.strokeStyle = 'rgba(52,40,34,.55)'; g.lineWidth = 2;
  for (let i = 0; i < 14; i++) {
    g.beginPath();
    let x = (R() - .5) * 260, y = -200 + R() * 60;
    g.moveTo(x, y);
    for (let s = 0; s < 5; s++) { x += (R() - .5) * 50; y += 40 + R() * 30; g.lineTo(x, y); }
    g.stroke();
  }
  // enormous black eye pits, asymmetric
  g.fillStyle = '#020202';
  g.beginPath(); g.ellipse(-64, -48, 42, 58, .1, 0, 7); g.fill();
  g.beginPath(); g.ellipse(66, -42, 40, 54, -.14, 0, 7); g.fill();
  // glowing pinpoints, off-center
  for (const [ex, ey] of [[-72, -40], [74, -52]]) {
    const gr2 = g.createRadialGradient(ex, ey, 0, ex, ey, 16);
    gr2.addColorStop(0, '#fffbe8'); gr2.addColorStop(.4, 'rgba(255,200,120,.9)');
    gr2.addColorStop(1, 'rgba(255,140,50,0)');
    g.fillStyle = gr2; g.beginPath(); g.arc(ex, ey, 16, 0, 7); g.fill();
  }
  // gaping stretched mouth
  g.fillStyle = '#030303';
  g.beginPath();
  g.moveTo(-84, 62);
  g.bezierCurveTo(-30, 46, 40, 50, 88, 70);
  g.bezierCurveTo(66, 168, -40, 176, -78, 118);
  g.closePath(); g.fill();
  g.strokeStyle = 'rgba(120,105,90,.5)'; g.lineWidth = 3; g.stroke();
  // teeth hints — thin pale slivers
  g.fillStyle = 'rgba(190,180,160,.35)';
  for (let i = 0; i < 9; i++) g.fillRect(-70 + i * 17, 60 + R() * 10, 3, 10 + R() * 12);
  g.restore();
});

/* ======================= AUDIO (all procedural) ======================= */
const AU = {
  ctx: null, master: null, noiseBuf: null,
  whisperGain: null, hissGain: null, droneGain: null, genGain: null,
  init() {
    if (this.ctx) return;
    const C = window.AudioContext || window.webkitAudioContext;
    this.ctx = new C();
    this.master = this.ctx.createGain();
    this.master.gain.value = .9;
    this.master.connect(this.ctx.destination);
    const sr = this.ctx.sampleRate;
    this.noiseBuf = this.ctx.createBuffer(1, sr * 2, sr);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    this._ambient(); this._whisper(); this._hiss();
  },
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); },
  _noiseSrc(loop) {
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf; s.loop = !!loop;
    return s;
  },
  _ambient() {
    const t = this.ctx.currentTime;
    const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 120;
    this.droneGain = this.ctx.createGain(); this.droneGain.gain.value = .05;
    lp.connect(this.droneGain); this.droneGain.connect(this.master);
    for (const f of [46, 46.7]) {
      const o = this.ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f;
      o.connect(lp); o.start(t);
    }
    const lfo = this.ctx.createOscillator(); lfo.frequency.value = .07;
    const lg = this.ctx.createGain(); lg.gain.value = .02;
    lfo.connect(lg); lg.connect(this.droneGain.gain); lfo.start(t);
  },
  _whisper() {
    const bp = this.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 1.6;
    this.whisperGain = this.ctx.createGain(); this.whisperGain.gain.value = 0;
    const s = this._noiseSrc(true);
    s.connect(bp); bp.connect(this.whisperGain); this.whisperGain.connect(this.master);
    s.start();
  },
  _hiss() {
    const hp = this.ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3500;
    this.hissGain = this.ctx.createGain(); this.hissGain.gain.value = 0;
    const s = this._noiseSrc(true);
    s.connect(hp); hp.connect(this.hissGain); this.hissGain.connect(this.master);
    s.start();
  },
  tone(type, f0, f1, dur, vol, delay = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + .012);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + dur + .05);
  },
  noise(fType, freq, q, dur, vol, delay = 0, pan = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const s = this._noiseSrc(false);
    const f = this.ctx.createBiquadFilter(); f.type = fType; f.frequency.value = freq; f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + .015);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    let out = g;
    if (pan && this.ctx.createStereoPanner) {
      const p = this.ctx.createStereoPanner(); p.pan.value = pan;
      g.connect(p); out = p;
    }
    s.connect(f); f.connect(g); out.connect(this.master);
    s.start(t); s.stop(t + dur + .05);
  },
  click() { this.tone('square', 900, 700, .04, .12); },
  step() { this.noise('lowpass', 350 + R() * 250, 1, .07, .09); },
  clank() {
    const pan = (R() - .5) * 1.6;
    this.noise('bandpass', 500 + R() * 900, 10, .4 + R() * .4, .06, 0, pan);
    if (R() < .4) this.tone('sine', 58, 40, 1.1, .1);
  },
  pickup() { this.tone('sine', 620, 620, .5, .1); this.tone('sine', 656, 656, .5, .08); this.click(); },
  creak() { this.tone('sawtooth', 120 + R() * 40, 65, .55, .045); this.noise('bandpass', 2200, 6, .3, .02); },
  thump(vol) {
    this.tone('sine', 78, 30, .13, .5 * vol);
    this.tone('sine', 70, 28, .11, .3 * vol, .16);
  },
  wail() {
    this.tone('sawtooth', 210, 65, 2.4, .16);
    this.tone('sawtooth', 216, 70, 2.4, .12);
    this.noise('bandpass', 800, 2, 2.2, .05);
  },
  groan(vol) { this.tone('sawtooth', 60, 40, 1.5, .1 * vol); },
  genStart() {
    this.tone('sine', 28, 55, 1.3, .3);
    this.noise('lowpass', 300, 1, .9, .2);
    if (!this.genGain) {
      const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 240;
      this.genGain = this.ctx.createGain(); this.genGain.gain.value = 0;
      lp.connect(this.genGain); this.genGain.connect(this.master);
      const o = this.ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 55;
      o.connect(lp); o.start();
      const lfo = this.ctx.createOscillator(); lfo.frequency.value = 13;
      const lg = this.ctx.createGain(); lg.gain.value = .015;
      lfo.connect(lg); lg.connect(this.genGain.gain); lfo.start();
    }
    this.genGain.gain.linearRampToValueAtTime(.04, this.ctx.currentTime + 1.4);
  },
  genStop() { if (this.genGain) this.genGain.gain.value = 0; },
  scream() {
    this.noise('bandpass', 900, .8, 1.1, .8);
    for (const f of [410, 417, 428]) this.tone('sawtooth', f, 85, .95, .3);
    this.tone('square', 1300, 180, .35, .25);
  },
  locked() { this.tone('sine', 150, 140, .08, .2); this.tone('sine', 130, 120, .08, .18, .13); },
};

/* ======================= STATE ======================= */
const ST = {};
function resetGame() {
  ST.mode = 'playing';        // playing | caught | dead | won
  ST.t = 0;
  ST.px = startPos.x; ST.py = startPos.y;
  ST.yaw = 0;
  ST.bob = 0; ST.stepAcc = 0;
  ST.flashOn = true; ST.battery = 100;
  ST.cards = 0;
  ST.items = cardSpawns.map(c => ({ ...c, taken: false }));
  ST.genOn = false;
  ST.msg = ''; ST.msgT = 0;
  ST.hintT = 0;
  ST.flick = 1;
  ST.scareT = 0;
  ST.demon = {
    x: demonSpawn.x, y: demonSpawn.y,
    active: false, path: [], repathT: 0,
    lastSeenT: 0, teleT: 0,
  };
  for (const d of doors.values()) { d.open = 0; d.timer = 0; }
  AU.genStop();
  hud();
  showMsg('Найди 3 ключ-карты и запусти генератор', 4);
}

/* ======================= INPUT ======================= */
const keys = {};
let interactQueued = false, pointerLocked = false;

addEventListener('keydown', e => {
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
  keys[e.code] = true;
  if (ST.mode !== 'playing') return;
  if (e.code === 'KeyF' && !e.repeat) {
    if (ST.flashOn) { ST.flashOn = false; AU.click(); }
    else if (ST.battery > 5) { ST.flashOn = true; AU.click(); }
    else showMsg('Батарея села. Подожди немного', 2);
  }
  if (e.code === 'KeyE' && !e.repeat) interactQueued = true;
});
addEventListener('keyup', e => { keys[e.code] = false; });

view.addEventListener('click', () => {
  if (ST.mode === 'playing' && !pointerLocked) view.requestPointerLock();
});
document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === view;
  mouseHint();
});
addEventListener('mousemove', e => {
  if (pointerLocked && ST.mode === 'playing') ST.yaw += e.movementX * 0.0022;
});

/* ======================= HELPERS ======================= */
function cellAt(x, y) {
  if (x < 0 || y < 0 || x >= MW || y >= MH) return 1;
  return grid[(y | 0) * MW + (x | 0)];
}
function blockedAt(x, y) {
  const c = cellAt(x, y);
  if (c === 0) return false;
  if (c === 4 || c === 5) {
    const d = doors.get((y | 0) * MW + (x | 0));
    return !d || d.open < 0.75;
  }
  return true;
}
function moveEnt(e, dx, dy, r) {
  if (dx) {
    const nx = e.x + dx, ex = nx + Math.sign(dx) * r;
    if (!blockedAt(ex, e.y - r * .7) && !blockedAt(ex, e.y + r * .7)) e.x = nx;
  }
  if (dy) {
    const ny = e.y + dy, ey = ny + Math.sign(dy) * r;
    if (!blockedAt(e.x - r * .7, ey) && !blockedAt(e.x + r * .7, ey)) e.y = ny;
  }
}
// grid line-of-sight (DDA), true if no wall between points
function los(x0, y0, x1, y1) {
  const dx = x1 - x0, dy = y1 - y0;
  const dist = Math.hypot(dx, dy);
  if (dist < .001) return true;
  const steps = Math.ceil(dist * 4);
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const c = cellAt(x0 + dx * t, y0 + dy * t);
    if (c === 1 || c === 2 || c === 3 || c === 6) return false;
    if (c === 4 || c === 5) {
      const d = doors.get(((y0 + dy * t) | 0) * MW + ((x0 + dx * t) | 0));
      if (!d || d.open < .6) return false;
    }
  }
  return true;
}
// BFS for demon pathing / distance fields
function demonWalkable(idx) {
  const c = grid[idx];
  if (c === 0) return !winSet.has(idx);
  if (c === 4) return true;
  if (c === 5) return ST.genOn;
  return false;
}
function bfsField(sx, sy) {
  const dist = new Int16Array(MW * MH).fill(-1);
  const q = [(sy | 0) * MW + (sx | 0)];
  dist[q[0]] = 0;
  for (let h = 0; h < q.length; h++) {
    const cur = q[h], cx = cur % MW, cy = (cur / MW) | 0;
    for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = cx + ox, ny = cy + oy;
      if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
      const ni = ny * MW + nx;
      if (dist[ni] === -1 && demonWalkable(ni)) { dist[ni] = dist[cur] + 1; q.push(ni); }
    }
  }
  return dist;
}
function findPath(sx, sy, tx, ty) {
  const start = (sy | 0) * MW + (sx | 0), goal = (ty | 0) * MW + (tx | 0);
  if (start === goal) return [];
  const prev = new Int32Array(MW * MH).fill(-2);
  const q = [start]; prev[start] = -1;
  for (let h = 0; h < q.length; h++) {
    const cur = q[h];
    if (cur === goal) break;
    const cx = cur % MW, cy = (cur / MW) | 0;
    for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = cx + ox, ny = cy + oy;
      if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
      const ni = ny * MW + nx;
      if (prev[ni] === -2 && (demonWalkable(ni) || ni === goal)) { prev[ni] = cur; q.push(ni); }
    }
  }
  if (prev[goal] === -2) return null;
  const path = [];
  for (let c = goal; c !== -1; c = prev[c]) path.push([c % MW, (c / MW) | 0]);
  path.reverse(); path.shift();          // drop start cell
  return path;
}
function toCamera(x, y) {                // world -> camera space
  const relX = x - ST.px, relY = y - ST.py;
  const dirX = Math.cos(ST.yaw), dirY = Math.sin(ST.yaw);
  const planeX = -dirY * .66, planeY = dirX * .66;
  const invDet = 1 / (planeX * dirY - dirX * planeY);
  return {
    tx: invDet * (dirY * relX - dirX * relY),
    ty: invDet * (-planeY * relX + planeX * relY),
  };
}
function flashActive() { return ST.flashOn && ST.battery > 0; }
function colLight(camX, dist) {
  let l = ST.genOn ? 0.12 : 0.045;
  if (flashActive()) {
    const beam = Math.exp(-camX * camX * 9);
    l += 1.2 * ST.flick * beam * Math.exp(-dist * 0.17);
  } else {
    l += 0.09 * Math.exp(-dist * 0.7);
  }
  return l > 1 ? 1 : l;
}

/* ======================= UI ======================= */
const elBat = document.getElementById('bat');
const elCards = document.getElementById('cards');
const elGen = document.getElementById('gen');
const elMsg = document.getElementById('msg');
const elNoise = document.getElementById('noise');
const nctx = elNoise.getContext('2d');
const elRed = document.getElementById('redpulse');
const elPause = document.getElementById('pauseHint');

function hud() {
  elBat.style.width = ST.battery + '%';
  elBat.style.background = ST.battery > 40 ? '#d8c56a' : ST.battery > 15 ? '#c8853e' : '#a33b2e';
  elCards.textContent = ST.cards + ' / 3';
  elGen.textContent = ST.genOn ? 'ВКЛ' : 'ВЫКЛ';
  elGen.style.color = ST.genOn ? '#7fdf70' : '#a33b2e';
}
function showMsg(text, dur = 2.6) {
  ST.msg = text; ST.msgT = dur;
  elMsg.textContent = text; elMsg.style.opacity = 1;
}
function mouseHint() {
  const need = ST.mode === 'playing' && !pointerLocked &&
    document.getElementById('startScreen').classList.contains('hidden');
  elPause.classList.toggle('hidden', !need);
}

/* ======================= UPDATE ======================= */
let noiseT = 0;

function update(dt) {
  ST.t += dt;
  const D = ST.demon;

  /* --- flashlight flicker --- */
  ST.flick = .9 + R() * .1;
  const demonDist = Math.hypot(D.x - ST.px, D.y - ST.py);
  if (D.active && demonDist < 4.5 && R() < .09) ST.flick *= .15;

  /* --- movement --- */
  const turn = (keys.ArrowRight ? 1 : 0) - (keys.ArrowLeft ? 1 : 0);
  ST.yaw += turn * 2.4 * dt;
  const dirX = Math.cos(ST.yaw), dirY = Math.sin(ST.yaw);
  const f = ((keys.KeyW || keys.ArrowUp) ? 1 : 0) - ((keys.KeyS || keys.ArrowDown) ? 1 : 0);
  const s = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0);
  if (f || s) {
    const sp = 3.0 * dt;
    let mx = dirX * f - dirY * s, my = dirY * f + dirX * s;
    const ml = Math.hypot(mx, my) || 1;
    const p = { x: ST.px, y: ST.py };   // moveEnt works on .x/.y; player lives in px/py
    moveEnt(p, mx / ml * sp, my / ml * sp, .22);
    ST.px = p.x; ST.py = p.y;
    ST.bob += dt * 9;
    ST.stepAcc += dt;
    if (ST.stepAcc > .42) { ST.stepAcc = 0; AU.step(); }
  } else ST.bob *= (1 - Math.min(1, dt * 6));

  /* --- battery --- */
  if (flashActive()) {
    ST.battery -= dt * 1.55;
    if (ST.battery <= 0) {
      ST.battery = 0; ST.flashOn = false;
      AU.click(); showMsg('Фонарик погас. Батарея на нуле', 2.5);
    }
  } else if (ST.battery < 100) {
    ST.battery = Math.min(100, ST.battery + dt * .8);
  }

  /* --- doors --- */
  for (const [idx, d] of doors) {
    const cx = idx % MW + .5, cy = ((idx / MW) | 0) + .5;
    const isExit = grid[idx] === 5;
    const nearP = Math.hypot(cx - ST.px, cy - ST.py) < 1.4;
    const nearD = D.active && Math.hypot(cx - D.x, cy - D.y) < 1.4;
    const allowed = !isExit || ST.genOn;
    if ((nearP || nearD) && allowed) {
      if (d.open === 0) AU.creak();
      d.open = Math.min(1, d.open + dt * 1.5);
      d.timer = 0;
    } else {
      d.timer += dt;
      if (d.timer > 2.5 && d.open > 0) d.open = Math.max(0, d.open - dt * 1.1);
    }
    if (isExit && !ST.genOn && nearP && ST.hintT <= 0) {
      showMsg('Заперто. Магнитный замок обесточен', 2.2);
      AU.locked(); ST.hintT = 3.5;
    }
  }
  if (ST.hintT > 0) ST.hintT -= dt;

  /* --- keycards --- */
  for (const it of ST.items) {
    if (it.taken) continue;
    if (Math.hypot(it.x - ST.px, it.y - ST.py) < .65) {
      it.taken = true; ST.cards++;
      AU.pickup(); hud();
      showMsg(ST.cards === 3
        ? 'Все ключ-карты у тебя. Запусти ГЕНЕРАТОР'
        : `Ключ-карта ${ST.cards} / 3`, 3);
      if (!D.active) activateDemon();
    }
  }

  /* --- interact (E) --- */
  if (interactQueued) {
    interactQueued = false;
    let nearGen = false;
    for (const [gx, gy] of genCells)
      if (Math.hypot(gx + .5 - ST.px, gy + .5 - ST.py) < 1.8) nearGen = true;
    if (nearGen) {
      if (ST.genOn) showMsg('Генератор уже работает', 2);
      else if (ST.cards < 3) {
        showMsg(`Нет питания стартера. Ключ-карты: ${ST.cards} / 3`, 2.6);
        AU.locked();
      } else {
        ST.genOn = true; hud();
        AU.genStart();
        showMsg('ПИТАНИЕ ВОССТАНОВЛЕНО. ВЫХОД ОТКРЫТ', 4);
        AU.wail();                                  // he heard that
      }
    }
  }
  // contextual generator hint
  if (!ST.genOn && ST.hintT <= 0) {
    for (const [gx, gy] of genCells)
      if (Math.hypot(gx + .5 - ST.px, gy + .5 - ST.py) < 1.8) {
        showMsg('[E] — запустить генератор', 2.2); ST.hintT = 4;
        break;
      }
  }

  /* --- demon --- */
  if (!D.active && ST.t > 10) activateDemon();
  if (D.active) updateDemon(dt, demonDist);

  /* --- proximity FX --- */
  const prox = D.active ? Math.max(0, 1 - demonDist / 9) : 0;
  AU.whisperGain && (AU.whisperGain.gain.value = prox * prox * .05);
  ST.heartT = (ST.heartT || 0) - dt;
  if (D.active && prox > .1 && ST.heartT <= 0) {
    AU.thump(.4 + prox * .6);
    ST.heartT = 1.5 - prox * 1.05;
  }
  const nProx = D.active ? Math.max(0, 1 - demonDist / 5.5) : 0;
  elNoise.style.opacity = (nProx * .5).toFixed(2);
  noiseT -= dt;
  if (nProx > 0 && noiseT <= 0) {
    noiseT = .08;
    const im = nctx.createImageData(160, 90);
    for (let i = 0; i < im.data.length; i += 4) {
      const v = (Math.random() * 255) | 0;
      im.data[i] = im.data[i + 1] = im.data[i + 2] = v;
      im.data[i + 3] = 60;
    }
    nctx.putImageData(im, 0, 0);
  }
  elRed.style.opacity = D.active && demonDist < 3
    ? ((Math.sin(ST.t * 7) * .5 + .5) * (1 - demonDist / 3) * .8).toFixed(2) : 0;

  /* --- random ambience --- */
  ST.clankT = (ST.clankT || 5) - dt;
  if (ST.clankT <= 0) { AU.clank(); ST.clankT = 6 + R() * 12; }
  ST.groanT = (ST.groanT || 8) - dt;
  if (D.active && ST.groanT <= 0) { AU.groan(.4 + prox); ST.groanT = 7 + R() * 9; }

  /* --- battery HUD + message fade --- */
  elBat.style.width = ST.battery.toFixed(0) + '%';
  elBat.style.background = ST.battery > 40 ? '#d8c56a' : ST.battery > 15 ? '#c8853e' : '#a33b2e';
  if (ST.msgT > 0) { ST.msgT -= dt; if (ST.msgT <= 0) elMsg.style.opacity = 0; }

  /* --- win --- */
  if (winSet.has((ST.py | 0) * MW + (ST.px | 0))) win();
}

function activateDemon() {
  const D = ST.demon;
  D.active = true; D.repathT = 0;
  AU.wail();
  ST.flick = .1;
  showMsg('Ты слышишь шаги в темноте. ТЫ НЕ ОДИН', 4);
}

function updateDemon(dt, dist) {
  const D = ST.demon;
  const seen = los(D.x, D.y, ST.px, ST.py);
  if (seen) D.lastSeenT = 0; else D.lastSeenT += dt;

  // is the flashlight beam burning him?
  const cam = toCamera(D.x, D.y);
  const inBeam = cam.ty > 0 && Math.abs(cam.tx / cam.ty) < .4;
  const lit = flashActive() && seen && dist < 9 && inBeam;
  AU.hissGain && (AU.hissGain.gain.value = lit && dist < 6 ? .06 : 0);

  // speed grows with keycards, time, generator; light slows him
  let spd = 1.05 + .24 * ST.cards + (ST.genOn ? .55 : 0) + .35 * Math.min(1, ST.t / 150);
  if (lit) spd *= .3;
  else if (!flashActive()) spd *= 1.12;
  if (seen && dist < 1.8 && !lit) spd *= 1.6;      // lunge
  spd = Math.min(3.2, spd);

  // repath
  D.repathT -= dt;
  if (D.repathT <= 0) {
    D.repathT = .35;
    D.path = findPath(D.x, D.y, ST.px, ST.py) || [];
  }

  // move: straight chase when close & visible, else follow path
  const step = spd * dt;
  if (seen && dist < 5) {
    const dx = ST.px - D.x, dy = ST.py - D.y, l = Math.hypot(dx, dy) || 1;
    moveEnt(D, dx / l * step, dy / l * step, .28);
  } else if (D.path.length) {
    const [nx, ny] = D.path[0];
    const tx = nx + .5, ty2 = ny + .5;
    const dx = tx - D.x, dy = ty2 - D.y, l = Math.hypot(dx, dy);
    if (l < .15) D.path.shift();
    else {
      const c = grid[ny * MW + nx];
      const door = (c === 4 || c === 5) ? doors.get(ny * MW + nx) : null;
      if (!door || door.open > .6) {
        const m = Math.min(step, l);
        D.x += dx / l * m; D.y += dy / l * m;
      }
    }
  }

  // pressure teleport: if he lost you for too long, he finds a shortcut
  D.teleT -= dt;
  if (D.teleT <= 0) {
    D.teleT = 2;
    if (D.lastSeenT > 8 && dist > 13) {
      const field = bfsField(ST.px, ST.py);
      const cand = [];
      for (let i = 0; i < field.length; i++)
        if (field[i] >= 7 && field[i] <= 11) {
          const cx = i % MW + .5, cy = ((i / MW) | 0) + .5;
          if (!los(cx, cy, ST.px, ST.py)) cand.push([cx, cy]);
        }
      if (cand.length) {
        const [cx, cy] = cand[(R() * cand.length) | 0];
        D.x = cx; D.y = cy; D.lastSeenT = 0;
        AU.clank();
      }
    }
  }

  if (dist < .6) caught();
}

/* ======================= END STATES ======================= */
const elJump = document.getElementById('jumpscare');
const faceCv = document.getElementById('face');
const faceCtx = faceCv.getContext('2d');

function caught() {
  if (ST.mode !== 'playing') return;
  ST.mode = 'caught'; ST.scareT = 0;
  AU.scream();
  faceCv.width = innerWidth; faceCv.height = innerHeight;
  elJump.style.display = 'block';
  document.exitPointerLock && document.exitPointerLock();
}
function drawScare(dt) {
  ST.scareT += dt;
  const w = faceCv.width, h = faceCv.height;
  faceCtx.fillStyle = '#000'; faceCtx.fillRect(0, 0, w, h);
  const size = Math.min(w, h) * (1.05 + ST.scareT * .5);
  const jx = (R() - .5) * 46, jy = (R() - .5) * 46;
  faceCtx.drawImage(scareFace, w / 2 - size / 2 + jx, h / 2 - size / 2 + jy, size, size);
  for (let i = 0; i < 7; i++) {                   // glitch slices
    const sy = R() * h, sh = 4 + R() * 26, off = (R() - .5) * 90;
    faceCtx.drawImage(faceCv, 0, sy, w, sh, off, sy, w, sh);
  }
  if (R() < .3) {                                  // white flash frames
    faceCtx.fillStyle = `rgba(255,255,255,${(R() * .18).toFixed(2)})`;
    faceCtx.fillRect(0, 0, w, h);
  }
  if (ST.scareT > 1.05) {
    ST.mode = 'dead';
    elJump.style.display = 'none';
    document.getElementById('deadScreen').classList.remove('hidden');
  }
}
function win() {
  if (ST.mode !== 'playing') return;
  ST.mode = 'won';
  const m = (ST.t / 60) | 0, s = (ST.t % 60) | 0;
  document.getElementById('winStats').innerHTML =
    `Ты выбрался за <b style="color:#d8c56a">${m}:${String(s).padStart(2, '0')}</b>.<br>` +
    'Смена окончена. Ты больше никогда сюда не вернёшься.';
  document.getElementById('winScreen').classList.remove('hidden');
  document.exitPointerLock && document.exitPointerLock();
  AU.tone && AU.tone('sine', 220, 220, 1.2, .08);
}

/* ======================= RENDER ======================= */
const sbuf = document.createElement('canvas');
sbuf.width = DEMW; sbuf.height = DEMH;
const sctx = sbuf.getContext('2d');

function shadeSprite(tex, light, eyes, eyeAlpha) {
  sctx.globalCompositeOperation = 'source-over';
  sctx.clearRect(0, 0, DEMW, DEMH);
  sctx.drawImage(tex, 0, 0);
  sctx.globalCompositeOperation = 'source-atop';
  sctx.fillStyle = `rgba(0,0,0,${(1 - light).toFixed(3)})`;
  sctx.fillRect(0, 0, DEMW, DEMH);
  sctx.globalCompositeOperation = 'source-over';
  if (eyes) {
    sctx.globalAlpha = eyeAlpha;
    sctx.drawImage(eyes, (R() - .5) * 1.2, (R() - .5) * 1.2);
    sctx.globalAlpha = 1;
  }
}

function render() {
  const dirX = Math.cos(ST.yaw), dirY = Math.sin(ST.yaw);
  const planeX = -dirY * .66, planeY = dirX * .66;
  const moving = (keys.KeyW || keys.KeyS || keys.KeyA || keys.KeyD || keys.ArrowUp || keys.ArrowDown);
  const bobOff = moving ? Math.sin(ST.bob) * RH * .012 : 0;
  const horizon = RH / 2 + bobOff;

  /* ceiling & floor */
  let gr = vctx.createLinearGradient(0, 0, 0, horizon);
  gr.addColorStop(0, '#0a0a0e'); gr.addColorStop(1, '#020203');
  vctx.fillStyle = gr; vctx.fillRect(0, 0, RW, horizon);
  gr = vctx.createLinearGradient(0, horizon, 0, RH);
  gr.addColorStop(0, '#020202'); gr.addColorStop(1, '#100e0a');
  vctx.fillStyle = gr; vctx.fillRect(0, horizon, RW, RH - horizon);

  /* walls */
  for (let x = 0; x < RW; x++) {
    const cameraX = 2 * x / RW - 1;
    let rdx = dirX + planeX * cameraX;
    let rdy = dirY + planeY * cameraX;
    if (Math.abs(rdx) < 1e-9) rdx = 1e-9;
    if (Math.abs(rdy) < 1e-9) rdy = 1e-9;
    let mapX = ST.px | 0, mapY = ST.py | 0;
    const deltaX = Math.abs(1 / rdx), deltaY = Math.abs(1 / rdy);
    const stepX = rdx < 0 ? -1 : 1, stepY = rdy < 0 ? -1 : 1;
    let sideDistX = (rdx < 0 ? (ST.px - mapX) : (mapX + 1 - ST.px)) * deltaX;
    let sideDistY = (rdy < 0 ? (ST.py - mapY) : (mapY + 1 - ST.py)) * deltaY;
    let dist = 0, side = 0, hitCell = 0, wallX = 0, texShift = 0, guard = 0;

    while (guard++ < 64) {
      if (sideDistX < sideDistY) { dist = sideDistX; sideDistX += deltaX; mapX += stepX; side = 0; }
      else { dist = sideDistY; sideDistY += deltaY; mapY += stepY; side = 1; }
      const cell = grid[mapY * MW + mapX];
      if (!cell) continue;
      if (cell === 4 || cell === 5) {
        const d2 = dist + (side === 0 ? deltaX : deltaY) / 2;   // door plane mid-cell
        if (d2 < Math.min(sideDistX, sideDistY)) {
          let wx = side === 0 ? ST.py + d2 * rdy : ST.px + d2 * rdx;
          wx -= Math.floor(wx);
          const dr = doors.get(mapY * MW + mapX);
          const open = dr ? dr.open : 0;
          if (wx < 1 - open) {
            hitCell = cell; dist = d2; wallX = wx; texShift = open;
            break;
          }
        }
        continue;
      }
      hitCell = cell;
      wallX = side === 0 ? ST.py + dist * rdy : ST.px + dist * rdx;
      wallX -= Math.floor(wallX);
      break;
    }
    if (!hitCell) { zbuf[x] = 99; continue; }
    dist = Math.max(.05, dist);
    zbuf[x] = dist;

    let tex;
    switch (hitCell) {
      case 2: tex = texFridge; break;
      case 3: tex = texTile; break;
      case 4: tex = texDoor; break;
      case 5: tex = ST.genOn ? texExitOpen : texExitLocked; break;
      case 6: tex = ST.genOn ? texGenOn : texGenOff; break;
      default: tex = texConcrete;
    }
    let texX = ((wallX + texShift) * 64) | 0;
    if ((side === 0 && rdx > 0) || (side === 1 && rdy < 0)) texX = 63 - (texX & 63);
    texX &= 63;

    const lh = RH / dist;
    const y0 = horizon - lh / 2;
    vctx.drawImage(tex, texX, 0, 1, 64, x, y0, 1, lh);

    const light = colLight(cameraX, dist) * (side === 1 ? .78 : 1);
    if (light < .995) {
      vctx.fillStyle = `rgba(0,0,0,${(1 - light).toFixed(3)})`;
      vctx.fillRect(x, y0, 1, lh);
    }
  }

  /* sprites (far -> near) */
  const sprites = [];
  for (const it of ST.items) if (!it.taken)
    sprites.push({ x: it.x, y: it.y, tex: texCard, tw: 64, th: 64, sh: .17, elev: .3 + Math.sin(ST.t * 2 + it.id) * .03, card: true });
  if (ST.demon.active)
    sprites.push({ x: ST.demon.x, y: ST.demon.y, tex: texDemon, tw: DEMW, th: DEMH, sh: 1.08, elev: 0, demon: true });

  for (const sp of sprites) {
    const c = toCamera(sp.x, sp.y);
    sp.ty = c.ty; sp.tx = c.tx;
  }
  sprites.sort((a, b) => b.ty - a.ty);

  for (const sp of sprites) {
    if (sp.ty < .08) continue;
    const lh = RH / sp.ty;
    const shPx = lh * sp.sh;
    const bottom = horizon + lh / 2 - lh * sp.elev;
    const top = bottom - shPx;
    const swPx = shPx * (sp.tw / sp.th);
    const screenX = (RW / 2) * (1 + sp.tx / sp.ty);
    const x0 = screenX - swPx / 2;

    let light = colLight(sp.tx / sp.ty, sp.ty);
    if (sp.card) light = Math.max(light, .35);          // cards faintly self-lit
    if (sp.demon) {
      const eyeA = .7 + .3 * Math.sin(ST.t * 11);
      shadeSprite(sp.tex, light, texDemonEyes, eyeA);
    } else {
      shadeSprite(sp.tex, light, null, 0);
    }

    const sx0 = Math.max(0, Math.ceil(x0));
    const sx1 = Math.min(RW - 1, Math.floor(x0 + swPx));
    for (let x = sx0; x <= sx1; x++) {
      if (zbuf[x] <= sp.ty) continue;
      const srcX = ((x - x0) / swPx * sp.tw) | 0;
      vctx.drawImage(sbuf, srcX, 0, 1, sp.th, x, top, 1, shPx);
    }
  }

  /* flashlight cone overlay */
  const cx = RW / 2, cy = horizon + RH * .05;
  let r0, r1, edge;
  if (flashActive()) { r0 = RH * .3 * ST.flick; r1 = RH * 1.1; edge = .88; }
  else { r0 = RH * .06; r1 = RH * .55; edge = .965; }
  gr = vctx.createRadialGradient(cx, cy, r0, cx, cy, r1);
  gr.addColorStop(0, 'rgba(0,0,0,0)');
  gr.addColorStop(1, `rgba(0,0,0,${edge})`);
  vctx.fillStyle = gr; vctx.fillRect(0, 0, RW, RH);
  if (flashActive()) {                                  // warm tint in the beam
    gr = vctx.createRadialGradient(cx, cy, 0, cx, cy, RH * .45);
    gr.addColorStop(0, `rgba(255,232,180,${(.05 * ST.flick).toFixed(3)})`);
    gr.addColorStop(1, 'rgba(255,232,180,0)');
    vctx.fillStyle = gr; vctx.fillRect(0, 0, RW, RH);
  }
}

/* ======================= MAIN LOOP ======================= */
let lastT = 0, running = false;

function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(.05, (now - lastT) / 1000 || .016);
  lastT = now;
  if (!running) return;
  if (ST.mode === 'playing') { update(dt); render(); }
  else if (ST.mode === 'caught') drawScare(dt);
}
requestAnimationFrame(frame);

/* ======================= SCREENS ======================= */
function startRun() {
  AU.init(); AU.resume();
  resetGame();
  document.getElementById('startScreen').classList.add('hidden');
  document.getElementById('deadScreen').classList.add('hidden');
  document.getElementById('winScreen').classList.add('hidden');
  running = true;
  view.requestPointerLock && view.requestPointerLock();
  mouseHint();
}
document.getElementById('startBtn').addEventListener('click', startRun);
document.getElementById('retryBtn').addEventListener('click', startRun);
document.getElementById('againBtn').addEventListener('click', startRun);
