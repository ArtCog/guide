// Headless win-path test: cards -> generator -> exit door -> win screen.
const fs = require('fs');
const vm = require('vm');
const log = [];

function anyObj() {
  const f = function () { return proxy; };
  const proxy = new Proxy(f, {
    get(t, p) {
      if (p === Symbol.toPrimitive) return () => 0;
      if (p === 'then') return undefined;
      return proxy;
    },
    set() { return true; },
    apply() { return proxy; },
    construct() { return proxy; },
  });
  return proxy;
}
const elements = {}, handlers = {};
function el(id) {
  if (elements[id]) return elements[id];
  const e = {
    id, style: {}, width: 0, height: 0, _text: '', _html: '',
    set textContent(v) { this._text = v; }, get textContent() { return this._text; },
    set innerHTML(v) { this._html = v; }, get innerHTML() { return this._html; },
    classList: {
      add: c => log.push(`${id}.add(${c})`),
      remove: c => log.push(`${id}.remove(${c})`),
      toggle: () => {}, contains: () => false,
    },
    addEventListener(ev, fn) { (handlers[id + ':' + ev] = handlers[id + ':' + ev] || []).push(fn); },
    getContext: () => anyObj(),
  };
  return elements[id] = e;
}
const sandbox = {
  console, Math, JSON, innerWidth: 1280, innerHeight: 720,
  Uint8Array, Int16Array, Int32Array, Float32Array, Map, Set, String, Number, Symbol, Object, Array, Promise,
  addEventListener(ev, fn) { (handlers['win:' + ev] = handlers['win:' + ev] || []).push(fn); },
  document: {
    getElementById: el,
    createElement: () => ({ width: 0, height: 0, getContext: () => anyObj() }),
    addEventListener(ev, fn) { (handlers['doc:' + ev] = handlers['doc:' + ev] || []).push(fn); },
    pointerLockElement: null, exitPointerLock: () => {},
  },
  requestAnimationFrame(cb) { sandbox.__raf = cb; return 1; },
  AudioContext: function () { return anyObj(); },
};
sandbox.window = sandbox; sandbox.globalThis = sandbox;

let code = fs.readFileSync(
  'C:/Users/magme/TEST FABLE VS OPUS VS SONNET/02-poslednyaya-smena-horror-fable-5/assets/game.js', 'utf8');
code += '\nglobalThis.__ST = ST; globalThis.__doors = doors; globalThis.__interact = () => { interactQueued = true; };';
vm.runInContext(code, vm.createContext(sandbox), { filename: 'game.js' });

handlers['startBtn:click'][0]();
const ST = sandbox.__ST, doors = sandbox.__doors;
let clock = 0;
const run = n => { for (let i = 0; i < n; i++) { clock += 16.7; sandbox.__raf(clock); } };
const parkDemon = () => { ST.demon.x = 2.5; ST.demon.y = 14.5; ST.demon.path = []; };

run(10);

// 1) collect the three keycards
for (const [x, y] of [[14.5, 5.5], [2.5, 10.5], [22.5, 8.5]]) {
  ST.px = x; ST.py = y; parkDemon(); run(8); parkDemon();
}
console.log('cards after pickup:', ST.cards, ST.cards === 3 ? 'OK' : 'FAIL');

// 2) generator: stand next to G block, press E
ST.px = 10.5; ST.py = 11.5; parkDemon();
sandbox.__interact(); run(4); parkDemon();
console.log('generator on:', ST.genOn ? 'OK' : 'FAIL');

// 3) exit door must auto-open now that power is on
ST.px = 21.5; ST.py = 17.5; parkDemon(); run(80); parkDemon();
const exitDoor = doors.get(18 * 24 + 21);
console.log('exit door open:', exitDoor.open.toFixed(2), exitDoor.open > 0.75 ? 'OK' : 'FAIL');

// 4) walk into the win zone
ST.px = 22.5; ST.py = 19.5; run(4);
const won = log.some(l => l === 'winScreen.remove(hidden)');
console.log('win screen shown:', won ? 'OK' : 'FAIL', '| mode:', ST.mode);
console.log('win stats html:', elements.winStats ? elements.winStats._html.slice(0, 60) : '?');

// 5) also verify: exit door does NOT open without generator (fresh run)
handlers['againBtn:click'][0]();
ST.px = 21.5; ST.py = 17.5; parkDemon(); run(80);
const exitDoor2 = doors.get(18 * 24 + 21);
console.log('exit stays locked without power:', exitDoor2.open === 0 ? 'OK' : 'FAIL (' + exitDoor2.open + ')');

// 6) flashlight slows demon: measure approach speed lit vs unlit
handlers['againBtn:click'][0]();
ST.px = 12.5; ST.py = 15.5; ST.yaw = Math.PI; // looking -x, corridor row 15
ST.demon.active = true; ST.demon.x = 8.5; ST.demon.y = 15.5; ST.demon.path = [];
ST.flashOn = true; ST.battery = 100;
let d0 = Math.hypot(ST.demon.x - ST.px, ST.demon.y - ST.py);
run(30);
const litGain = d0 - Math.hypot(ST.demon.x - ST.px, ST.demon.y - ST.py);

handlers['againBtn:click'][0]();
ST.px = 12.5; ST.py = 15.5; ST.yaw = Math.PI;
ST.demon.active = true; ST.demon.x = 8.5; ST.demon.y = 15.5; ST.demon.path = [];
ST.flashOn = false;
d0 = Math.hypot(ST.demon.x - ST.px, ST.demon.y - ST.py);
run(30);
const darkGain = d0 - Math.hypot(ST.demon.x - ST.px, ST.demon.y - ST.py);
console.log(`beam slowdown: lit=${litGain.toFixed(2)} dark=${darkGain.toFixed(2)} tiles/0.5s`,
  litGain < darkGain * 0.5 ? 'OK' : 'FAIL');

// 7) keyboard movement: hold W for ~1s, player must actually move
// (regression: moveEnt works on .x/.y, player lives in px/py)
handlers['againBtn:click'][0]();
parkDemon();
const startX = ST.px;                       // (2.5, 2.5), yaw=0 -> W moves +x
handlers['win:keydown'].forEach(h => h({ code: 'KeyW', preventDefault() {}, repeat: false }));
run(60); parkDemon();
handlers['win:keyup'].forEach(h => h({ code: 'KeyW' }));
console.log(`W-key movement: px ${startX} -> ${ST.px.toFixed(2)}`,
  ST.px - startX > 1 ? 'OK' : 'FAIL');

console.log('WIN-PATH TEST DONE');
