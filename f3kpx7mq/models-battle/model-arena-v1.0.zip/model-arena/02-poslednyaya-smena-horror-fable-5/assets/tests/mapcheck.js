// Map validator for "Последняя смена"
// Legend: # concrete, M fridge wall, T tiled wall, D auto-door, X exit door (locked),
// G generator block, P player start, S demon spawn, 1/2/3 keycards, W win zone, . floor
const MAP = [
"########################",
"#P...#.....M.M.M.M.M...#",
"#....#.................#",
"#....D.....######..##D##",
"#....#.....#TTTT#..#...#",
"######.....#T.1.D..#.M.#",
"#....#.....#TTTT#..#...#",
"#.M..#.....######..#.M.#",
"#.M..D.............#..3#",
"#....#..#####D###..##.##",
"#.2..#..#.......#......#",
"#....#..#..GG...#......#",
"######..#..GG...D..##D##",
"#....#..#.......#..#...#",
"#.S..D..#########..#.M.#",
"#....#.............#...#",
"##.###..##########.#.M.#",
"#....#..#........#.#...#",
"#.M..#..#..MMMM..#.##X##",
"#....D..D........#.#..W#",
"#......#..........#..WW#",
"########################",
];

const H = MAP.length, W = MAP[0].length;
let errs = [];

// 1) shape
MAP.forEach((r, i) => { if (r.length !== W) errs.push(`row ${i} len ${r.length} != ${W}`); });

const at = (x, y) => (y < 0 || y >= H || x < 0 || x >= W) ? '#' : MAP[y][x];
const find = ch => {
  const out = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (at(x, y) === ch) out.push([x, y]);
  return out;
};

const P = find('P'), S = find('S'), C1 = find('1'), C2 = find('2'), C3 = find('3');
const G = find('G'), X = find('X'), Wz = find('W');
if (P.length !== 1) errs.push(`P count ${P.length}`);
if (S.length !== 1) errs.push(`S count ${S.length}`);
[['1',C1],['2',C2],['3',C3]].forEach(([n,a]) => { if (a.length !== 1) errs.push(`card ${n} count ${a.length}`); });
if (!G.length) errs.push('no generator');
if (!X.length) errs.push('no exit door');
if (!Wz.length) errs.push('no win zone');

// BFS helper. exitOpen: treat X as walkable
function bfs(start, exitOpen) {
  const walk = ch => ch === '.' || ch === 'P' || ch === 'S' || ch === 'D' ||
    ch === '1' || ch === '2' || ch === '3' || ch === 'W' || (exitOpen && ch === 'X');
  const dist = Array.from({ length: H }, () => Array(W).fill(-1));
  const q = [start]; dist[start[1]][start[0]] = 0;
  while (q.length) {
    const [x, y] = q.shift();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (dist[ny]?.[nx] === -1 && walk(at(nx, ny))) { dist[ny][nx] = dist[y][x] + 1; q.push([nx, ny]); }
    }
  }
  return dist;
}

if (!errs.length) {
  const dOpen = bfs(P[0], true);
  const dClosed = bfs(P[0], false);
  const reach = (d, [x, y]) => d[y][x] >= 0;

  [['card1', C1[0]], ['card2', C2[0]], ['card3', C3[0]]].forEach(([n, p]) => {
    if (!reach(dClosed, p)) errs.push(`${n} unreachable with exit closed`);
    else console.log(`${n} dist=${dClosed[p[1]][p[0]]}`);
  });

  // generator must have adjacent reachable floor
  const genAdj = G.some(([x, y]) => [[1,0],[-1,0],[0,1],[0,-1]].some(([dx, dy]) => dClosed[y+dy]?.[x+dx] >= 0));
  if (!genAdj) errs.push('generator has no reachable adjacent floor');

  // win zone must be UNreachable while exit closed, reachable when open
  Wz.forEach(p => { if (reach(dClosed, p)) errs.push(`win tile ${p} reachable with exit CLOSED (leak!)`); });
  if (!Wz.some(p => reach(dOpen, p))) errs.push('win zone unreachable even with exit open');
  else console.log(`win dist(open)=${Math.min(...Wz.map(p => dOpen[p[1]][p[0]]))}`);

  // demon spawn: reachable, not too close
  if (!reach(dClosed, S[0])) errs.push('demon spawn unreachable');
  else {
    const ds = dClosed[S[0][1]][S[0][0]];
    console.log(`demon spawn dist=${ds}`);
    if (ds < 12) errs.push(`demon spawn too close (${ds})`);
  }

  // every floor tile reachable? (no orphan pockets except W zone)
  let orphan = 0;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const ch = at(x, y);
    if ((ch === '.' || ch === 'D') && dOpen[y][x] === -1) { orphan++; console.log(`orphan floor at ${x},${y}`); }
  }
  if (orphan) errs.push(`${orphan} orphan floor tiles`);
}

if (errs.length) { console.log('ERRORS:'); errs.forEach(e => console.log(' -', e)); process.exit(1); }
console.log('MAP OK', `${W}x${H}`);
