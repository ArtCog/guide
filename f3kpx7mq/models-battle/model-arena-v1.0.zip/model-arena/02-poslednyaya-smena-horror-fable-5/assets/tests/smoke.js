// Headless smoke test: run game.js with stubbed DOM/Canvas/WebAudio.
// Verifies: no runtime errors, demon AI reaches a stationary player -> jumpscare -> death screen.
const fs = require('fs');
const vm = require('vm');

const log = [];

// --- universal chainable proxy (canvas ctx, audio nodes, gradients...) ---
function anyObj(tag) {
  const f = function () { return proxy; };
  const proxy = new Proxy(f, {
    get(t, p) {
      if (p === Symbol.toPrimitive) return () => 0;
      if (p === 'then') return undefined;
      return proxy;
    },
    set() { return true; },
    apply() { return proxy; },
    construct() { return proxy; },
  });
  return proxy;
}

// --- element stub with recording ---
const elements = {};
function el(id) {
  if (elements[id]) return elements[id];
  const e = {
    id, style: {}, width: 0, height: 0,
    _text: '', _html: '',
    set textContent(v) { this._text = v; },
    get textContent() { return this._text; },
    set innerHTML(v) { this._html = v; },
    get innerHTML() { return this._html; },
    classList: {
      add: c => log.push(`${id}.classList.add(${c})`),
      remove: c => log.push(`${id}.classList.remove(${c})`),
      toggle: () => {},
      contains: () => false,
    },
    addEventListener(ev, fn) { (handlers[id + ':' + ev] = handlers[id + ':' + ev] || []).push(fn); },
    getContext: () => anyObj('ctx2d'),
  };
  elements[id] = e;
  return e;
}
const handlers = {};

// --- globals expected by game.js ---
const sandbox = {
  console, Math, JSON,
  innerWidth: 1280, innerHeight: 720,
  Uint8Array, Int16Array, Int32Array, Float32Array, Map, Set, String, Number, Symbol, Object, Array, Promise,
  addEventListener(ev, fn) { (handlers['win:' + ev] = handlers['win:' + ev] || []).push(fn); },
  document: {
    getElementById: el,
    createElement: () => ({ width: 0, height: 0, getContext: () => anyObj('ctx2d') }),
    addEventListener(ev, fn) { (handlers['doc:' + ev] = handlers['doc:' + ev] || []).push(fn); },
    pointerLockElement: null,
    exitPointerLock: () => {},
  },
  requestAnimationFrame(cb) { sandbox.__raf = cb; return 1; },
  AudioContext: function () { return anyObj('audio'); },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;

const code = fs.readFileSync(
  'C:/Users/magme/TEST FABLE VS OPUS VS SONNET/02-poslednyaya-smena-horror-fable-5/assets/game.js', 'utf8');
const ctx = vm.createContext(sandbox);
vm.runInContext(code, ctx, { filename: 'game.js' });
console.log('TOP-LEVEL OK (map parsed, textures built, listeners bound)');

// click "start"
handlers['startBtn:click'][0]();
console.log('startRun OK');

// drive the real main loop via the stored rAF callback: ~90 simulated seconds
let died = false, framesToDeath = 0;
for (let i = 0; i < 5600; i++) {
  sandbox.__raf(i * 16.7);
  if (!died && log.some(l => l === 'deadScreen.classList.remove(hidden)')) {
    died = true; framesToDeath = i;
    break;
  }
}

const batW = elements.bat ? elements.bat.style.width : '?';
console.log('battery HUD after run:', batW, '(NaN check:', /NaN/.test(String(batW)) ? 'FAIL' : 'ok)');
console.log('cards HUD:', elements.cards ? elements.cards._text : '?');

if (died) {
  console.log(`DEMON CAUGHT STATIONARY PLAYER at ~${(framesToDeath * 16.7 / 1000).toFixed(1)}s -> jumpscare -> death screen. AI PATH OK`);
} else {
  console.log('FAIL: demon never reached the player in 90s of sim');
  process.exit(1);
}

// restart must work after death
handlers['retryBtn:click'][0]();
for (let i = 0; i < 300; i++) sandbox.__raf(200000 + i * 16.7);
console.log('restart OK (300 frames after retry, no exceptions)');
console.log('SMOKE TEST PASSED');
