'use strict';

/* ============================================================
   1. Decoding — UTF-8 first, Windows-1252 fallback for legacy
      YouTube Studio exports with broken/non-UTF8 bytes.
   ============================================================ */

function decodeBytes(bytes) {
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch (e) {
    return new TextDecoder('windows-1252').decode(bytes);
  }
}

/* ============================================================
   2. CSV parsing — minimal RFC4180 parser (quoted fields can
      contain commas, e.g. "Anzahl, wie oft jeder Moment...").
   ============================================================ */

function parseCSV(rawText) {
  let text = rawText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);

  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  const n = text.length;

  for (let i = 0; i < n; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else { inQuotes = false; }
      } else {
        field += c;
      }
      continue;
    }
    if (c === '"') { inQuotes = true; continue; }
    if (c === ',') { row.push(field); field = ''; continue; }
    if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; continue; }
    field += c;
  }
  if (field.length > 0 || row.length > 0) { row.push(field); rows.push(row); }

  while (rows.length && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0].trim() === '') {
    rows.pop();
  }

  if (rows.length === 0) return { header: [], rows: [] };
  return { header: rows[0].map(h => h.trim()), rows: rows.slice(1) };
}

function parseNumber(raw) {
  if (raw == null) return null;
  let s = String(raw).trim();
  if (s === '') return null;
  if (/^-?\d+,\d+$/.test(s)) s = s.replace(',', '.');
  const val = parseFloat(s);
  return Number.isNaN(val) ? null : val;
}

/* ============================================================
   3. Classification — by column count & data type structure,
      NOT by filename (filenames are locale-dependent; the
      YouTube export format is not).
   ============================================================ */

function isNumericColumn(dataRows, colIdx, sampleSize = 30) {
  const sample = dataRows.slice(0, Math.min(sampleSize, dataRows.length));
  let checked = 0, numeric = 0;
  for (const r of sample) {
    const v = (r[colIdx] || '').trim();
    if (v === '') continue;
    checked++;
    if (/^-?[0-9]+([.,][0-9]+)?$/.test(v)) numeric++;
  }
  if (checked === 0) return false;
  return numeric / checked >= 0.8;
}

function classifyReport(header, dataRows) {
  const numCols = header.length;

  if (dataRows.length === 0) {
    return { kind: 'empty', header, numCols };
  }

  if (numCols === 2) {
    return { kind: 'base_curve', header, numCols };
  }

  if (numCols === 3) {
    const col1Numeric = isNumericColumn(dataRows, 1);
    if (col1Numeric) {
      return { kind: 'base_curve_with_relative', header, numCols };
    }
    const categories = [...new Set(dataRows.map(r => (r[1] || '').trim()).filter(Boolean))];
    return { kind: 'segment_comparison', header, numCols, categoryColumnName: header[1], categories };
  }

  if (numCols === 4) {
    const allNumeric = [1, 2, 3].every(i => isNumericColumn(dataRows, i));
    if (allNumeric) {
      return { kind: 'activity_detail', header, numCols };
    }
  }

  return { kind: 'unknown', header, numCols };
}

function classifySegmentType(categoryColumnName, categories) {
  const haystack = (categoryColumnName + ' ' + categories.join(' ')).toLowerCase();
  if (/\babo/.test(haystack)) return 'subscriber_status';
  if (/wiederkehr|return/.test(haystack) && categories.length <= 2) return 'new_vs_returning';
  if (/gelegentlich|regelm[äa]ssig|regelmäßig|casual|occasional|regular/.test(haystack)) return 'viewer_frequency';
  if (/organisch|bezahlt|paid|organic/.test(haystack)) return 'traffic_type';
  return 'custom';
}

const SEGMENT_TYPE_LABELS = {
  subscriber_status: 'Подписчики vs неподписчики',
  new_vs_returning: 'Новые vs вернувшиеся зрители',
  viewer_frequency: 'Новые / случайные / регулярные зрители',
  traffic_type: 'Органический vs платный трафик',
  custom: null,
};

/* ============================================================
   4. Building typed series from classified rows
   ============================================================ */

function buildCurve(dataRows, posIdx, valIdx) {
  const points = [];
  for (const r of dataRows) {
    const pos = parseNumber(r[posIdx]);
    const val = parseNumber(r[valIdx]);
    if (pos == null || val == null) continue;
    points.push({ position: pos, retention: val });
  }
  points.sort((a, b) => a.position - b.position);
  return points;
}

function buildCurveWithRelative(dataRows) {
  const points = [];
  for (const r of dataRows) {
    const pos = parseNumber(r[0]);
    let a = parseNumber(r[1]);
    let b = parseNumber(r[2]);
    if (pos == null || a == null || b == null) continue;
    // The relative-to-other-videos column can be negative / centered near 0;
    // the absolute retention column is always within [0, 100+]. Guard against
    // exports that swap column order.
    if (a < 0 && b >= 0) { const t = a; a = b; b = t; }
    points.push({ position: pos, retention: a, relative: b });
  }
  points.sort((a, b) => a.position - b.position);
  return points;
}

function buildSegmentSeries(dataRows) {
  const map = new Map();
  for (const r of dataRows) {
    const pos = parseNumber(r[0]);
    const cat = (r[1] || '').trim();
    const val = parseNumber(r[2]);
    if (pos == null || val == null || !cat) continue;
    if (!map.has(cat)) map.set(cat, []);
    map.get(cat).push({ position: pos, retention: val });
  }
  for (const arr of map.values()) arr.sort((a, b) => a.position - b.position);
  return map;
}

function buildActivityDetail(dataRows) {
  const points = [];
  for (const r of dataRows) {
    const pos = parseNumber(r[0]);
    if (pos == null) continue;
    points.push({
      position: pos,
      started: parseNumber(r[1]) ?? 0,
      ended: parseNumber(r[2]) ?? 0,
      viewsOfMoment: parseNumber(r[3]) ?? 0,
    });
  }
  points.sort((a, b) => a.position - b.position);
  return points;
}

/* ============================================================
   5. Organizing raw parsed reports into a structured bundle
   ============================================================ */

function organizeReports(parsedFiles) {
  const bundle = {
    curveCandidates: [],   // {filename, kind, data:[{position,retention[,relative]}]}
    segments: [],          // {filename, categoryColumnName, segmentType, series: Map}
    activityDetail: null,  // {filename, data}
    emptyFiles: [],        // {filename, header}
    unknownFiles: [],      // {filename, header, numCols}
  };

  for (const file of parsedFiles) {
    const { filename, header, rows, classification } = file;
    switch (classification.kind) {
      case 'empty':
        bundle.emptyFiles.push({ filename, header });
        break;
      case 'base_curve':
        bundle.curveCandidates.push({ filename, kind: 'base_curve', data: buildCurve(rows, 0, 1) });
        break;
      case 'base_curve_with_relative':
        bundle.curveCandidates.push({ filename, kind: 'base_curve_with_relative', data: buildCurveWithRelative(rows) });
        break;
      case 'segment_comparison': {
        const series = buildSegmentSeries(rows);
        const segmentType = classifySegmentType(classification.categoryColumnName, classification.categories);
        bundle.segments.push({
          filename,
          categoryColumnName: classification.categoryColumnName,
          categories: classification.categories,
          segmentType,
          series,
        });
        break;
      }
      case 'activity_detail':
        if (!bundle.activityDetail) {
          bundle.activityDetail = { filename, data: buildActivityDetail(rows) };
        }
        break;
      default:
        bundle.unknownFiles.push({ filename, header, numCols: classification.numCols });
    }
  }

  bundle.primaryCurve = pickPrimaryCurve(bundle.curveCandidates);
  bundle.secondaryCurves = bundle.curveCandidates.filter(c => c !== bundle.primaryCurve);

  return bundle;
}

function pickPrimaryCurve(candidates) {
  if (candidates.length === 0) return null;
  const twoCol = candidates.filter(c => c.kind === 'base_curve');
  const pool = twoCol.length > 0 ? twoCol : candidates;
  return pool.reduce((best, c) => (c.data.length > best.data.length ? c : best), pool[0]);
}

/* ============================================================
   6. Analysis — percentile points, drop zones, end moments,
      rewatch peaks, segment early-gap comparison.
   ============================================================ */

function getValueAtPosition(curve, position) {
  if (!curve || curve.length === 0) return null;
  const exact = curve.find(p => p.position === position);
  if (exact) return exact.retention;
  let below = null, above = null;
  for (const p of curve) {
    if (p.position < position && (!below || p.position > below.position)) below = p;
    if (p.position > position && (!above || p.position < above.position)) above = p;
  }
  if (!below) return above ? above.retention : null;
  if (!above) return below.retention;
  const t = (position - below.position) / (above.position - below.position);
  return below.retention + t * (above.retention - below.retention);
}

function getKeyPercentilePoints(curve, points = [0, 1, 5, 10, 25, 50, 75, 90, 99]) {
  if (!curve || curve.length === 0) return [];
  const minPos = curve[0].position;
  const maxPos = curve[curve.length - 1].position;
  return points
    .filter(p => p >= minPos && p <= maxPos)
    .map(p => ({ point: p, value: getValueAtPosition(curve, p) }));
}

function detectDropZones(curve, { window = 3, topN = 5, minDrop = 1.5, introWindow = 5, tailWindow = 3 } = {}) {
  if (!curve || curve.length < window + 1) return [];
  const minPos = curve[0].position;
  const maxPos = curve[curve.length - 1].position;
  const candidates = [];
  for (let i = 0; i < curve.length - window; i++) {
    const from = curve[i];
    const to = curve[i + window];
    const delta = to.retention - from.retention;
    if (delta < 0) {
      candidates.push({
        fromPos: from.position, toPos: to.position, fromVal: from.retention, toVal: to.retention, delta,
        // Nearly every video shows a steep % fall in the first few points (an
        // artifact of the metric — few viewers have dropped off yet, so the
        // denominator is still ~full) and a soft step down right at the tail
        // (natural finishers thinning out). Flag both so callers can avoid
        // presenting a near-universal pattern as this video's standout problem.
        isIntro: to.position <= minPos + introWindow,
        isNaturalTail: to.position >= maxPos - tailWindow,
      });
    }
  }
  candidates.sort((a, b) => a.delta - b.delta);
  const picked = [];
  for (const c of candidates) {
    if (Math.abs(c.delta) < minDrop) break;
    const overlaps = picked.some(p => !(c.toPos < p.fromPos || c.fromPos > p.toPos));
    if (!overlaps) picked.push(c);
    if (picked.length >= topN) break;
  }
  return picked;
}

function detectEndMoments(activityDetail, { topN = 6, tailFraction = 0.03, tailMin = 2 } = {}) {
  if (!activityDetail || activityDetail.length === 0) return [];
  const maxPos = Math.max(...activityDetail.map(r => r.position));
  const tailStart = maxPos - Math.max(tailMin, Math.round(maxPos * tailFraction));
  const withEnded = activityDetail.filter(r => r.ended > 0);
  const sorted = [...withEnded].sort((a, b) => b.ended - a.ended);
  return sorted.slice(0, topN).map(r => ({
    position: r.position,
    ended: r.ended,
    isNaturalTail: r.position >= tailStart,
  }));
}

function detectRewatchPeaks(activityDetail, { topN = 5, localWindow = 6, minExcess = 0.08, mergeDistance = 2 } = {}) {
  if (!activityDetail || activityDetail.length === 0) return [];
  const withViews = activityDetail.filter(r => r.viewsOfMoment != null);
  const candidates = [];
  for (let i = 0; i < withViews.length; i++) {
    const cur = withViews[i];
    if (cur.position === withViews[0].position) continue; // position 0 is always highest by definition
    const neighbors = [
      ...withViews.slice(Math.max(0, i - localWindow), i),
      ...withViews.slice(i + 1, i + 1 + localWindow),
    ];
    if (neighbors.length < 3) continue;
    const baseline = neighbors.reduce((s, p) => s + p.viewsOfMoment, 0) / neighbors.length;
    if (baseline <= 0) continue;
    const excess = (cur.viewsOfMoment - baseline) / baseline;
    if (excess >= minExcess) {
      candidates.push({ position: cur.position, viewsOfMoment: cur.viewsOfMoment, baseline, excess, source: 'raw' });
    }
  }
  candidates.sort((a, b) => b.excess - a.excess);
  const picked = [];
  for (const c of candidates) {
    const overlaps = picked.some(p => Math.abs(p.position - c.position) <= mergeDistance);
    if (!overlaps) picked.push(c);
    if (picked.length >= topN) break;
  }
  return picked;
}

function detectRewatchPeaksFromCurve(curve, opts = {}) {
  // Fallback when there is no Aktivitäten-im-Detail file: look for local
  // upward bumps in the absolute retention curve itself. Lower confidence —
  // callers must label this as an estimate, not a raw-count fact.
  if (!curve || curve.length === 0) return [];
  const fakeDetail = curve.map(p => ({ position: p.position, started: 0, ended: 0, viewsOfMoment: p.retention }));
  return detectRewatchPeaks(fakeDetail, opts).map(p => ({ ...p, source: 'estimated' }));
}

function findRelativeCurve(bundle) {
  const candidates = [bundle.primaryCurve, ...bundle.secondaryCurves].filter(Boolean);
  return candidates.find(c => c.kind === 'base_curve_with_relative' && c.data.some(p => p.relative != null)) || null;
}

function getFieldAtPosition(curve, position, field) {
  if (!curve || curve.length === 0) return null;
  const mapped = curve.map(p => ({ position: p.position, retention: p[field] })).filter(p => p.retention != null);
  return getValueAtPosition(mapped, position);
}

function compareSegmentsEarly(seriesMap, earlyPosition = 10) {
  const results = [];
  for (const [cat, points] of seriesMap.entries()) {
    const val = getValueAtPosition(points, earlyPosition);
    if (val != null) results.push({ category: cat, value: val });
  }
  return results.sort((a, b) => b.value - a.value);
}

/* ============================================================
   7. Recommendations & limitations — grounded in computed
      numbers only, nothing invented about video content.
   ============================================================ */

function fmtPct(n) {
  if (n == null || Number.isNaN(n)) return '—';
  return (Math.round(n * 10) / 10).toString().replace('.', ',') + '%';
}

function buildRecommendations(bundle, analysis) {
  const recs = [];

  const notableDrop = analysis.dropZones.find(z => !z.isIntro && !z.isNaturalTail) || analysis.dropZones[0];
  if (notableDrop) {
    if (notableDrop.isIntro) {
      recs.push(
        `Единственная заметная просадка удержания найдена в первые ${notableDrop.toPos}% видео ` +
        `(с ${fmtPct(notableDrop.fromVal)} до ${fmtPct(notableDrop.toVal)}) — такой спад есть почти у всех роликов ` +
        `на старте (по определению метрики), поэтому сам по себе он не обязательно означает проблему хука.`
      );
    } else if (notableDrop.fromPos <= 30) {
      recs.push(
        `Самая заметная просадка удержания (не считая обычного спада в начале и естественного завершения в конце) — ` +
        `на отрезке ${notableDrop.fromPos}–${notableDrop.toPos}% видео ` +
        `(удержание упало с ${fmtPct(notableDrop.fromVal)} до ${fmtPct(notableDrop.toVal)}), и это ещё в первой трети ролика. ` +
        `Стоит проверить, что происходит на этом отрезке в самом видео.`
      );
    } else {
      recs.push(
        `Самая заметная просадка удержания (не считая обычного спада в начале и естественного завершения в конце) — ` +
        `на отрезке ${notableDrop.fromPos}–${notableDrop.toPos}% видео ` +
        `(удержание упало с ${fmtPct(notableDrop.fromVal)} до ${fmtPct(notableDrop.toVal)}). Стоит посмотреть, что происходит в этом месте ролика.`
      );
    }
  }

  const relativeCurve = findRelativeCurve(bundle);
  if (relativeCurve) {
    const relEarly = getFieldAtPosition(relativeCurve.data, 5, 'relative');
    if (relEarly != null && Math.abs(relEarly) >= 3) {
      const dir = relEarly >= 0 ? 'выше' : 'ниже';
      recs.push(
        `По файлу «${relativeCurve.filename}»: на 5% видео удержание ${dir} типичного для похожих видео на ${fmtPct(Math.abs(relEarly))}. ` +
        `Это дополнительный контекст к просадке в начале, а не отдельный вывод — метрика «в сравнении с другими видео» шумная, особенно в хвосте ролика.`
      );
    }
  }

  const midEndMoments = analysis.endMoments.filter(m => !m.isNaturalTail);
  if (midEndMoments.length > 0) {
    const top = midEndMoments[0];
    recs.push(
      `Заметная точка ухода зрителей на ${top.position}% видео (${top.ended} завершённых сессий именно в этой точке, ` +
      `не в конце ролика). Это сильнее сигнал, чем проценты удержания — это реальные обрывы просмотра.`
    );
  }

  const rawRewatch = analysis.rewatchPeaks.filter(p => p.source === 'raw');
  if (rawRewatch.length > 0) {
    const top = rawRewatch[0];
    recs.push(
      `Момент на ${top.position}% пересматривают заметно чаще окружения (на ${Math.round(top.excess * 100)}% выше локального фона). ` +
      `Похоже на сильный приём — стоит понять, что там происходит, и повторить похожий приём в следующем ролике.`
    );
  } else if (analysis.activityDetailAvailable) {
    recs.push('Выраженных пиков пересмотра в данных не найдено — в ролике нет явного момента, к которому зрители возвращаются повторно.');
  }

  for (const seg of analysis.segmentAnalyses) {
    if (!seg.label || seg.earlyGap == null || seg.earlyGap < 15) continue;
    const [top, bottom] = seg.earlyComparison;
    recs.push(
      `«${seg.label}»: на ${seg.earlyPosition}% видео разрыв между «${top.category}» (${fmtPct(top.value)}) и ` +
      `«${bottom.category}» (${fmtPct(bottom.value)}) — ${Math.round(seg.earlyGap)} п.п. Похоже на проблему структуры входа ` +
      `для одной из аудиторий, а не на проблему темы ролика в целом.`
    );
  }

  if (recs.length === 0) {
    recs.push('По имеющимся данным не нашлось выраженных проблемных точек — резких просадок или аномальных обрывов просмотра.');
  }

  return recs;
}

function buildLimitations(bundle, analysis) {
  const items = [];
  items.push('Нет доступа к самому видео, сценарию, главам и субтитрам — можно указать, ГДЕ на кривой есть проблема, но нельзя утверждать, ЧТО именно происходило в кадре в этот момент.');
  items.push('В экспорте нет длительности видео в секундах — только позиция в процентах, поэтому сравнение с секундными бенчмарками (например, «стена 30 секунд») здесь невозможно.');
  items.push('Официальный AVD/APV (среднее время просмотра) в этом наборе CSV не публикуется — за точным числом нужно смотреть вкладку «Обзор» в YouTube Studio; оценка по площади под кривой удержания может расходиться с реальным AVD и не приводится как факт.');

  if (bundle.secondaryCurves.some(c => c.kind === 'base_curve_with_relative')) {
    items.push('Колонка «В сравнении с другими видео» шумная, особенно в хвосте ролика (может отличаться на 10–20 п.п. между экспортами того же видео) — важные выводы на ней одной не строятся, только в связке с абсолютной кривой.');
  }

  if (!analysis.activityDetailAvailable) {
    items.push('В архиве нет файла с детальной активностью («Wiedergabe gestartet/beendet», «Anzahl angesehen») — точки ухода и пики пересмотра не вычислены из сырых счётчиков; там, где они показаны, это менее надёжная оценка по форме кривой удержания.');
  }

  if (bundle.emptyFiles.length > 0) {
    items.push(`Пустые отчёты (0 строк данных) в архиве: ${bundle.emptyFiles.map(f => f.filename).join(', ')} — по этим форматам показов не было, это не ошибка чтения файла.`);
  }

  if (bundle.unknownFiles.length > 0) {
    items.push(`Не удалось классифицировать по структуре: ${bundle.unknownFiles.map(f => f.filename).join(', ')} — показаны как есть, без интерпретации.`);
  }

  return items;
}

/* ============================================================
   8. Top-level analyze() — ties everything together
   ============================================================ */

function analyze(bundle) {
  const curve = bundle.primaryCurve ? bundle.primaryCurve.data : null;
  const activityDetail = bundle.activityDetail ? bundle.activityDetail.data : null;

  const dropZones = curve ? detectDropZones(curve) : [];
  const endMoments = activityDetail ? detectEndMoments(activityDetail) : [];
  const rewatchPeaks = activityDetail
    ? detectRewatchPeaks(activityDetail)
    : (curve ? detectRewatchPeaksFromCurve(curve) : []);

  const segmentAnalyses = bundle.segments.map(seg => {
    const earlyPosition = 10;
    const earlyComparison = compareSegmentsEarly(seg.series, earlyPosition);
    const earlyGap = earlyComparison.length >= 2
      ? earlyComparison[0].value - earlyComparison[earlyComparison.length - 1].value
      : null;
    return {
      filename: seg.filename,
      segmentType: seg.segmentType,
      label: SEGMENT_TYPE_LABELS[seg.segmentType] || seg.categoryColumnName,
      categoryColumnName: seg.categoryColumnName,
      series: seg.series,
      earlyPosition,
      earlyComparison,
      earlyGap,
    };
  });

  const analysis = {
    keyPoints: curve ? getKeyPercentilePoints(curve) : [],
    dropZones,
    endMoments,
    rewatchPeaks,
    segmentAnalyses,
    activityDetailAvailable: !!activityDetail,
  };

  analysis.recommendations = buildRecommendations(bundle, analysis);
  analysis.limitations = buildLimitations(bundle, analysis);

  return analysis;
}

/* ============================================================
   9. Rendering — DOM helpers, formatting, Canvas line chart
   ============================================================ */

const PALETTE = {
  series: ['#3987e5', '#199e70', '#c98500', '#008300', '#9085e9', '#e66767', '#d55181', '#d95926'],
  gridline: '#2c2c2a',
  axis: '#383835',
  muted: '#898781',
  surface: '#1a1a19',
};

function el(tag, className, textContent) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (textContent != null) e.textContent = textContent;
  return e;
}

function fmtInt(n) {
  if (n == null || Number.isNaN(n)) return '—';
  return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

function niceNum(range, round) {
  if (!Number.isFinite(range) || range <= 0) return 1;
  const exponent = Math.floor(Math.log10(range));
  const fraction = range / Math.pow(10, exponent);
  let niceFraction;
  if (round) {
    if (fraction < 1.5) niceFraction = 1;
    else if (fraction < 3) niceFraction = 2;
    else if (fraction < 7) niceFraction = 5;
    else niceFraction = 10;
  } else {
    if (fraction <= 1) niceFraction = 1;
    else if (fraction <= 2) niceFraction = 2;
    else if (fraction <= 5) niceFraction = 5;
    else niceFraction = 10;
  }
  return niceFraction * Math.pow(10, exponent);
}

function niceTicks(min, max, count = 5) {
  if (min === max) { min -= 1; max += 1; }
  const range = niceNum(max - min, false);
  const step = niceNum(range / Math.max(1, count - 1), true);
  const niceMin = Math.floor(min / step) * step;
  const niceMax = Math.ceil(max / step) * step;
  const ticks = [];
  for (let v = niceMin; v <= niceMax + step / 1e6; v += step) ticks.push(Math.round(v * 1e6) / 1e6);
  return ticks;
}

/**
 * Two stacked canvases (static base + interactive overlay) plus an HTML
 * legend/tooltip. All series share one x-domain, so the crosshair snaps to
 * the nearest integer position and reads every series at once.
 */
function createLineChart(container, opts) {
  const {
    series,
    xDomain,
    yDomain = null,
    xTickFormat = (v) => Math.round(v) + '%',
    yTickFormat = (v) => String(Math.round(v * 10) / 10),
    highlightZones = [],
    height = 320,
  } = opts;

  container.innerHTML = '';
  const wrap = el('div', 'chart-wrap');
  wrap.style.height = height + 'px';
  const base = document.createElement('canvas');
  const overlay = document.createElement('canvas');
  overlay.className = 'chart-overlay';
  const tooltip = el('div', 'chart-tooltip');
  tooltip.style.display = 'none';
  wrap.appendChild(base);
  wrap.appendChild(overlay);
  wrap.appendChild(tooltip);
  container.appendChild(wrap);

  if (series.length >= 2 || highlightZones.some(z => z.label)) {
    const legend = el('div', 'chart-legend');
    for (const s of series) {
      const item = el('div', 'legend-item');
      const sw = el('span', 'legend-swatch');
      sw.style.background = s.color;
      item.appendChild(sw);
      item.appendChild(el('span', 'legend-name', s.name));
      legend.appendChild(item);
    }
    for (const z of highlightZones) {
      if (!z.label) continue;
      const item = el('div', 'legend-item');
      const sw = el('span', 'legend-swatch');
      sw.style.background = z.color;
      item.appendChild(sw);
      item.appendChild(el('span', 'legend-name', z.label));
      legend.appendChild(item);
    }
    container.appendChild(legend);
  }

  const padding = { top: 16, right: 16, bottom: 28, left: 46 };
  let plotW = 0, plotH = 0, dpr = window.devicePixelRatio || 1;
  const xMin = xDomain[0], xMax = xDomain[1];
  let yMin, yMax;
  if (yDomain) {
    yMin = yDomain[0]; yMax = yDomain[1];
  } else {
    const allY = series.flatMap(s => s.points.map(p => p.y));
    const ticks = niceTicks(Math.min(...allY, 0), Math.max(...allY, 1));
    yMin = ticks[0]; yMax = ticks[ticks.length - 1];
  }

  const scaleX = (x) => padding.left + ((x - xMin) / (xMax - xMin)) * plotW;
  const scaleY = (y) => padding.top + plotH - ((y - yMin) / (yMax - yMin)) * plotH;

  function resize() {
    const rect = wrap.getBoundingClientRect();
    dpr = window.devicePixelRatio || 1;
    const w = Math.max(200, rect.width);
    for (const c of [base, overlay]) {
      c.width = w * dpr;
      c.height = height * dpr;
      c.style.width = w + 'px';
      c.style.height = height + 'px';
    }
    plotW = w - padding.left - padding.right;
    plotH = height - padding.top - padding.bottom;
    draw();
  }

  function draw() {
    const ctx = base.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, base.width, base.height);

    for (const z of highlightZones) {
      ctx.fillStyle = z.color;
      const x1 = scaleX(z.from), x2 = scaleX(z.to);
      ctx.fillRect(x1, padding.top, Math.max(1, x2 - x1), plotH);
    }

    ctx.font = '11px system-ui, sans-serif';
    ctx.strokeStyle = PALETTE.gridline;
    ctx.lineWidth = 1;
    ctx.fillStyle = PALETTE.muted;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (const t of niceTicks(yMin, yMax, 5)) {
      if (t < yMin || t > yMax) continue;
      const y = scaleY(t);
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(padding.left + plotW, y);
      ctx.stroke();
      ctx.fillText(yTickFormat(t), padding.left - 8, y);
    }

    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const xStep = Math.max(1, Math.round((xMax - xMin) / 10));
    const xTicks = [];
    for (let v = xMin; v <= xMax; v += xStep) xTicks.push(Math.round(v));
    if (xTicks[xTicks.length - 1] !== Math.round(xMax)) xTicks.push(Math.round(xMax));
    for (const t of xTicks) ctx.fillText(xTickFormat(t), scaleX(t), padding.top + plotH + 8);

    ctx.strokeStyle = PALETTE.axis;
    ctx.beginPath();
    ctx.moveTo(padding.left, padding.top + plotH);
    ctx.lineTo(padding.left + plotW, padding.top + plotH);
    ctx.stroke();

    for (const s of series) {
      if (s.points.length === 0) continue;
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 2;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.beginPath();
      s.points.forEach((p, i) => {
        const x = scaleX(p.x), y = scaleY(Math.max(yMin, Math.min(yMax, p.y)));
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }
  }

  function clearOverlay() {
    const ctx = overlay.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, overlay.width, overlay.height);
  }

  function handleMove(evt) {
    const rect = overlay.getBoundingClientRect();
    const mx = evt.clientX - rect.left;
    if (mx < padding.left || mx > padding.left + plotW) { clearOverlay(); tooltip.style.display = 'none'; return; }
    const xVal = xMin + ((mx - padding.left) / plotW) * (xMax - xMin);
    const nearestX = Math.round(xVal);

    clearOverlay();
    const ctx = overlay.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.strokeStyle = PALETTE.muted;
    ctx.lineWidth = 1;
    const cx = scaleX(nearestX);
    ctx.beginPath();
    ctx.moveTo(cx, padding.top);
    ctx.lineTo(cx, padding.top + plotH);
    ctx.stroke();

    const rows = [];
    for (const s of series) {
      const val = getValueAtPosition(s.points.map(p => ({ position: p.x, retention: p.y })), nearestX);
      if (val == null) continue;
      const y = scaleY(Math.max(yMin, Math.min(yMax, val)));
      ctx.beginPath();
      ctx.arc(cx, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = s.color;
      ctx.fill();
      ctx.strokeStyle = PALETTE.surface;
      ctx.lineWidth = 2;
      ctx.stroke();
      rows.push({ name: s.name, color: s.color, value: val });
    }

    tooltip.innerHTML = '';
    tooltip.appendChild(el('p', 'tt-x', xTickFormat(nearestX)));
    for (const r of rows) {
      const row = el('div', 'tt-row');
      const key = el('span', 'tt-key');
      key.style.background = r.color;
      row.appendChild(key);
      row.appendChild(el('span', 'tt-name', r.name));
      row.appendChild(el('span', 'tt-value', yTickFormat(r.value)));
      tooltip.appendChild(row);
    }
    tooltip.style.display = 'block';
    let left = mx + 16;
    if (left + 190 > wrap.clientWidth) left = Math.max(0, mx - 190 - 8);
    tooltip.style.left = left + 'px';
    tooltip.style.top = '8px';
  }

  overlay.addEventListener('mousemove', handleMove);
  overlay.addEventListener('mouseleave', () => { clearOverlay(); tooltip.style.display = 'none'; });

  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(resize).observe(wrap);
  }
  resize();

  return { redraw: resize };
}

/* ============================================================
   10. Rendering — panels (summary, inventory, tables, segments)
   ============================================================ */

function makeStatTile(label, value, cls) {
  const tile = el('div', 'stat-tile');
  tile.appendChild(el('p', 'stat-tile-label', label));
  tile.appendChild(el('p', 'stat-tile-value' + (cls ? ' ' + cls : ''), value));
  return tile;
}

function renderSummary(container, bundle, analysis, parsedFiles) {
  container.innerHTML = '';
  const stats = el('div', 'summary-stats');
  const recognized = parsedFiles.length - bundle.unknownFiles.length - bundle.emptyFiles.length;

  stats.appendChild(makeStatTile('Файлов в архиве', String(parsedFiles.length)));
  stats.appendChild(makeStatTile('Распознано', recognized + ' из ' + parsedFiles.length));
  stats.appendChild(makeStatTile('Пустых отчётов', String(bundle.emptyFiles.length), bundle.emptyFiles.length > 0 ? 'warning' : ''));

  if (bundle.primaryCurve) {
    stats.appendChild(makeStatTile('Удержание на 25%', fmtPct(getValueAtPosition(bundle.primaryCurve.data, 25))));
    stats.appendChild(makeStatTile('Удержание на 50%', fmtPct(getValueAtPosition(bundle.primaryCurve.data, 50))));
  }
  container.appendChild(stats);

  const lines = el('div');
  if (!bundle.primaryCurve) {
    lines.appendChild(el('p', 'summary-line',
      'Не найдено ни одного файла с базовой кривой удержания (2–3 колонки: позиция + удержание). Проверьте, что это экспорт именно раздела «Удержание аудитории».'));
  } else {
    const notableDrop = analysis.dropZones.find(z => !z.isIntro && !z.isNaturalTail);
    const midEnd = analysis.endMoments.find(m => !m.isNaturalTail);
    const bits = [];
    if (notableDrop) bits.push(`просадка удержания на ${notableDrop.fromPos}–${notableDrop.toPos}%`);
    if (midEnd) bits.push(`заметный уход зрителей на ${midEnd.position}%`);
    const p = el('p', 'summary-line');
    if (bits.length > 0) {
      p.appendChild(document.createTextNode('Главные проблемные точки: '));
      const b = document.createElement('b');
      b.textContent = bits.join('; ');
      p.appendChild(b);
      p.appendChild(document.createTextNode('. Подробности — в разделах ниже.'));
    } else {
      p.textContent = 'Выраженных проблемных точек не найдено — просадки в пределах ожидаемого для формата видео.';
    }
    lines.appendChild(p);
  }
  container.appendChild(lines);
}

const REPORT_KIND_LABELS = {
  empty: 'нет данных (0 строк) — показов в этом разрезе не было',
  base_curve: 'базовая кривая удержания',
  base_curve_with_relative: 'кривая удержания + сравнение с похожими видео',
  activity_detail: 'детальная активность (начало / конец / пересмотры просмотра)',
};

function renderInventory(container, parsedFiles) {
  container.innerHTML = '';
  for (const file of parsedFiles) {
    const item = el('div', 'inventory-item');
    item.appendChild(el('span', 'inventory-filename', file.filename));
    let desc;
    if (file.classification.kind === 'segment_comparison') {
      desc = 'сравнение аудиторий: ' + file.classification.categoryColumnName;
    } else if (file.classification.kind === 'unknown') {
      desc = `формат не распознан (${file.classification.numCols} колонок) — показан как есть`;
    } else {
      desc = REPORT_KIND_LABELS[file.classification.kind] || 'не классифицирован';
    }
    item.appendChild(el('span', 'inventory-desc', desc));
    container.appendChild(item);
  }
}

function renderKeyPoints(container, keyPoints) {
  container.innerHTML = '';
  if (keyPoints.length === 0) {
    container.appendChild(el('p', 'empty-note', 'Нет базовой кривой удержания для расчёта точек.'));
    return;
  }
  const table = document.createElement('table');
  table.className = 'data-table';
  const thead = document.createElement('tr');
  thead.appendChild(el('th', null, 'Позиция видео'));
  thead.appendChild(el('th', null, 'Удержание'));
  table.appendChild(el('thead')).appendChild(thead);
  const tbody = document.createElement('tbody');
  for (const kp of keyPoints) {
    const tr = document.createElement('tr');
    tr.appendChild(el('td', null, kp.point + '%'));
    tr.appendChild(el('td', 'num', fmtPct(kp.value)));
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  container.appendChild(table);
}

function renderDropZones(container, dropZones) {
  container.innerHTML = '';
  if (dropZones.length === 0) {
    container.appendChild(el('p', 'empty-note', 'Резких просадок не обнаружено.'));
    return;
  }
  const table = document.createElement('table');
  table.className = 'data-table';
  const thead = document.createElement('tr');
  ['Отрезок', 'Удержание', 'Падение', ''].forEach(t => thead.appendChild(el('th', null, t)));
  table.appendChild(el('thead')).appendChild(thead);
  const tbody = document.createElement('tbody');
  for (const z of dropZones) {
    const tr = document.createElement('tr');
    tr.appendChild(el('td', null, z.fromPos + '–' + z.toPos + '%'));
    tr.appendChild(el('td', 'num', fmtPct(z.fromVal) + ' → ' + fmtPct(z.toVal)));
    tr.appendChild(el('td', 'num', fmtPct(z.delta)));
    const tagTd = document.createElement('td');
    if (z.isIntro) tagTd.appendChild(el('span', 'tag tag-info', 'начало видео'));
    else if (z.isNaturalTail) tagTd.appendChild(el('span', 'tag tag-info', 'финал видео'));
    else tagTd.appendChild(el('span', 'tag tag-warning', 'к рассмотрению'));
    tr.appendChild(tagTd);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  container.appendChild(table);
}

function renderEndMoments(container, endMoments, activityDetailAvailable) {
  container.innerHTML = '';
  if (!activityDetailAvailable) {
    container.appendChild(el('p', 'empty-note', 'В архиве нет файла детальной активности («Wiedergabe beendet») — точки ухода не вычислены.'));
    return;
  }
  if (endMoments.length === 0) {
    container.appendChild(el('p', 'empty-note', 'Данные об обрывах просмотра пусты.'));
    return;
  }
  const table = document.createElement('table');
  table.className = 'data-table';
  const thead = document.createElement('tr');
  ['Позиция', 'Обрывов', ''].forEach(t => thead.appendChild(el('th', null, t)));
  table.appendChild(el('thead')).appendChild(thead);
  const tbody = document.createElement('tbody');
  for (const m of endMoments) {
    const tr = document.createElement('tr');
    tr.appendChild(el('td', null, m.position + '%'));
    tr.appendChild(el('td', 'num', fmtInt(m.ended)));
    const tagTd = document.createElement('td');
    tagTd.appendChild(el('span', 'tag ' + (m.isNaturalTail ? 'tag-info' : 'tag-warning'), m.isNaturalTail ? 'финал видео' : 'обрыв просмотра'));
    tr.appendChild(tagTd);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  container.appendChild(table);
}

function renderRewatchPeaks(container, rewatchPeaks, activityDetailAvailable) {
  container.innerHTML = '';
  if (rewatchPeaks.length === 0) {
    container.appendChild(el('p', 'empty-note', 'Выраженных пиков пересмотра не найдено.'));
    return;
  }
  const table = document.createElement('table');
  table.className = 'data-table';
  const thead = document.createElement('tr');
  ['Позиция', 'Превышение фона', ''].forEach(t => thead.appendChild(el('th', null, t)));
  table.appendChild(el('thead')).appendChild(thead);
  const tbody = document.createElement('tbody');
  for (const p of rewatchPeaks) {
    const tr = document.createElement('tr');
    tr.appendChild(el('td', null, p.position + '%'));
    tr.appendChild(el('td', 'num', '+' + Math.round(p.excess * 100) + '%'));
    const tagTd = document.createElement('td');
    tagTd.appendChild(el('span', 'tag ' + (p.source === 'raw' ? 'tag-good' : 'tag-info'),
      p.source === 'raw' ? 'по сырым данным' : 'оценка по кривой'));
    tr.appendChild(tagTd);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  container.appendChild(table);
  if (!activityDetailAvailable) {
    container.appendChild(el('p', 'empty-note',
      'В архиве нет файла детальной активности — это оценка по форме кривой удержания, менее точная, чем расчёт по сырым счётчикам пересмотров.'));
  }
}

function renderSegments(container, segmentAnalyses) {
  container.innerHTML = '';
  if (segmentAnalyses.length === 0) {
    container.appendChild(el('p', 'empty-note', 'В архиве не нашлось файлов сравнения аудиторий (подписчики / новые / трафик и т.п.).'));
    return;
  }
  for (const seg of segmentAnalyses) {
    const block = el('div', 'segment-block');
    block.appendChild(el('h3', 'segment-block-title', seg.label || seg.categoryColumnName));
    const categories = [...seg.series.keys()];
    if (categories.length < 2) {
      block.appendChild(el('p', 'segment-block-sub',
        `В данных только одна категория («${categories[0] || '—'}») — сравнить не с чем, второй категории в этом экспорте нет (вероятно, 0 просмотров по ней).`));
    } else {
      const text = seg.earlyComparison.map(c => `«${c.category}» — ${fmtPct(c.value)}`).join(', ');
      block.appendChild(el('p', 'segment-block-sub', `На ${seg.earlyPosition}% видео: ${text}.`));
    }
    const chartDiv = el('div', 'chart-container');
    block.appendChild(chartDiv);
    container.appendChild(block);

    const series = categories.map((cat, i) => ({
      name: cat,
      color: PALETTE.series[i % PALETTE.series.length],
      points: seg.series.get(cat).map(p => ({ x: p.position, y: p.retention })),
    }));
    const allX = series.flatMap(s => s.points.map(p => p.x));
    if (allX.length === 0) continue;
    createLineChart(chartDiv, {
      series,
      xDomain: [Math.min(...allX), Math.max(...allX)],
      yDomain: [0, 100],
      yTickFormat: v => Math.round(v) + '%',
      xTickFormat: v => Math.round(v) + '%',
      height: 240,
    });
  }
}

function renderTextList(container, items) {
  container.innerHTML = '';
  for (const text of items) container.appendChild(el('li', null, text));
}

function renderDashboard(bundle, analysis, parsedFiles) {
  renderSummary(document.getElementById('summary-content'), bundle, analysis, parsedFiles);
  renderInventory(document.getElementById('inventory-content'), parsedFiles);
  renderKeyPoints(document.getElementById('key-points-content'), analysis.keyPoints);
  renderDropZones(document.getElementById('drops-content'), analysis.dropZones);
  renderEndMoments(document.getElementById('end-moments-content'), analysis.endMoments, analysis.activityDetailAvailable);
  renderRewatchPeaks(document.getElementById('rewatch-content'), analysis.rewatchPeaks, analysis.activityDetailAvailable);
  renderSegments(document.getElementById('segments-content'), analysis.segmentAnalyses);
  renderTextList(document.getElementById('recommendations-content'), analysis.recommendations);
  renderTextList(document.getElementById('limitations-content'), analysis.limitations);

  const mainChartContainer = document.getElementById('main-chart-container');
  if (bundle.primaryCurve) {
    const highlightZones = [
      ...analysis.dropZones.filter(z => !z.isIntro).map(z => ({ from: z.fromPos, to: z.toPos, color: 'rgba(208,59,59,0.16)' })),
      ...analysis.rewatchPeaks.filter(p => p.source === 'raw').map(p => ({ from: p.position - 1, to: p.position + 1, color: 'rgba(144,133,233,0.22)' })),
    ];
    createLineChart(mainChartContainer, {
      series: [{ name: 'Удержание, все зрители', color: PALETTE.series[0], points: bundle.primaryCurve.data.map(p => ({ x: p.position, y: p.retention })) }],
      xDomain: [bundle.primaryCurve.data[0].position, bundle.primaryCurve.data[bundle.primaryCurve.data.length - 1].position],
      yDomain: [0, 100],
      yTickFormat: v => Math.round(v) + '%',
      xTickFormat: v => Math.round(v) + '%',
      highlightZones,
      height: 340,
    });
  } else {
    mainChartContainer.innerHTML = '';
    mainChartContainer.appendChild(el('p', 'empty-note', 'Нет данных для построения графика.'));
  }

  document.getElementById('dashboard').classList.remove('hidden');
  document.getElementById('reset-btn').classList.remove('hidden');
}

/* ============================================================
   11. File pipeline — ZIP (JSZip, CDN) with manual-CSV fallback
   ============================================================ */

async function readFileFromInput(file) {
  const buf = await file.arrayBuffer();
  return { filename: file.name, bytes: new Uint8Array(buf) };
}

async function extractZipEntries(file) {
  if (typeof JSZip === 'undefined') {
    throw new Error('JSZip недоступен (не загрузился с CDN)');
  }
  const buf = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(buf);
  const entries = [];
  for (const [name, entry] of Object.entries(zip.files)) {
    if (entry.dir) continue;
    if (!/\.csv$/i.test(name)) continue;
    const bytes = await entry.async('uint8array');
    entries.push({ filename: name.split('/').pop(), bytes });
  }
  return entries;
}

function parseNamedFiles(namedByteArrays) {
  return namedByteArrays.map(({ filename, bytes }) => {
    const text = decodeBytes(bytes);
    const { header, rows } = parseCSV(text);
    const classification = classifyReport(header, rows);
    return { filename, header, rows, classification };
  });
}

function runPipeline(namedByteArrays) {
  const parsedFiles = parseNamedFiles(namedByteArrays);
  const bundle = organizeReports(parsedFiles);
  const analysis = analyze(bundle);
  renderDashboard(bundle, analysis, parsedFiles);
}

/* ============================================================
   12. UI wiring
   ============================================================ */

function setStatus(elm, text, kind) {
  elm.textContent = text;
  elm.className = 'status-line' + (kind ? ' status-' + kind : '');
}

function initApp() {
  const dropzone = document.getElementById('dropzone');
  const zipInput = document.getElementById('zip-input');
  const zipBrowseBtn = document.getElementById('zip-browse-btn');
  const zipStatus = document.getElementById('zip-status');
  const csvInput = document.getElementById('csv-input');
  const csvLoadBtn = document.getElementById('csv-load-btn');
  const csvStatus = document.getElementById('csv-status');
  const resetBtn = document.getElementById('reset-btn');

  async function handleZipFile(file) {
    setStatus(zipStatus, 'Распаковываю «' + file.name + '»…', 'busy');
    try {
      const entries = await extractZipEntries(file);
      if (entries.length === 0) {
        setStatus(zipStatus, 'В архиве не нашлось ни одного CSV-файла.', 'error');
        return;
      }
      runPipeline(entries);
      setStatus(zipStatus, 'Готово: обработано файлов — ' + entries.length + '.', 'ok');
    } catch (err) {
      setStatus(zipStatus, 'Не удалось распаковать ZIP: ' + err.message + '. Попробуйте ручную загрузку CSV ниже.', 'error');
    }
  }

  zipBrowseBtn.addEventListener('click', () => zipInput.click());
  zipInput.addEventListener('change', () => {
    if (zipInput.files[0]) handleZipFile(zipInput.files[0]);
  });

  ['dragover', 'dragenter'].forEach(evt => {
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add('drag-over'); });
  });
  ['dragleave', 'drop'].forEach(evt => {
    dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove('drag-over'); });
  });
  dropzone.addEventListener('drop', (e) => {
    const file = e.dataTransfer.files[0];
    if (file) handleZipFile(file);
  });

  csvLoadBtn.addEventListener('click', async () => {
    const files = Array.from(csvInput.files || []);
    if (files.length === 0) {
      setStatus(csvStatus, 'Сначала выберите один или несколько CSV-файлов.', 'error');
      return;
    }
    setStatus(csvStatus, 'Обрабатываю ' + files.length + ' файл(ов)…', 'busy');
    try {
      const named = await Promise.all(files.map(readFileFromInput));
      runPipeline(named);
      setStatus(csvStatus, 'Готово: обработано файлов — ' + named.length + '.', 'ok');
    } catch (err) {
      setStatus(csvStatus, 'Ошибка обработки: ' + err.message, 'error');
    }
  });

  resetBtn.addEventListener('click', () => {
    document.getElementById('dashboard').classList.add('hidden');
    resetBtn.classList.add('hidden');
    zipInput.value = '';
    csvInput.value = '';
    setStatus(zipStatus, '');
    setStatus(csvStatus, '');
    window.scrollTo(0, 0);
  });
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', initApp);
}

/* ============================================================
   Node-only export for automated verification against real
   fixture data before wiring up the browser UI. Harmless in
   the browser: `module` is undefined there.
   ============================================================ */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    decodeBytes, parseCSV, parseNumber, classifyReport, classifySegmentType,
    buildCurve, buildCurveWithRelative, buildSegmentSeries, buildActivityDetail,
    organizeReports, pickPrimaryCurve, getValueAtPosition, getKeyPercentilePoints,
    detectDropZones, detectEndMoments, detectRewatchPeaks, detectRewatchPeaksFromCurve,
    compareSegmentsEarly, buildRecommendations, buildLimitations, analyze,
  };
}
