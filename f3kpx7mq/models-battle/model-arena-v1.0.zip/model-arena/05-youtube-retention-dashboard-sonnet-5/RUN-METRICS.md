# RUN-METRICS — тест 04 «Анализатор удержания YouTube»

| Поле | Значение |
|---|---|
| Модель | Claude Sonnet 5 (`claude-sonnet-5`), Claude Code |
| Тест | 04 — локальный дашборд анализа ZIP/CSV из YouTube Studio |
| Время задачи | 31m 17s |
| Input tokens | 20.8k |
| Output tokens | 143.8k |
| Cache read | 17.3m |
| Cache write | 700.0k |
| Стоимость USD | $11.23 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\04-youtube-retention-dashboard-sonnet-5\index.html` |
| Короткий вердикт | Рабочий браузерный дашборд с анализом ZIP/CSV, Canvas-графиками, ручным CSV-fallback и проверкой в реальном Chrome. Методология явно опиралась на внешние skills, включая `youtube-video-analysis`, `dataviz`, `frontend-design` и planning-skills. |

**Источник метрик:** данные пользователя из вкладки `Usage` Claude Code после выполнения теста.

**Важно по времени:** `Total duration (API): 2h 17m 58s` и `Total duration (wall): 1d 4h 57m`
не используются как время задачи. Чистое время выполнения четвертого задания: `31m 17s`,
строка `Cogitated for 31m 17s`, предоставленная пользователем отдельно после завершения.

**Разбивка стоимости по скрину/статистике:** `claude-sonnet-5` — $32.83;
`claude-haiku-4-5` — $0.0099. Общая стоимость сессии: $32.84.

## Подход модели

Sonnet 5 начал с `superpowers:brainstorming`, изучил содержимое ZIP, затем явно
подключил `youtube-video-analysis`, `dataviz`, `frontend-design` и
`superpowers:writing-plans`. Перед реализацией модель представила дизайн-план и
задала пользователю вопрос-подтверждение, после чего уже приступила к созданию
`index.html`, `assets/styles.css`, `assets/script.js`, `README.md`, `REPORT.md`.

Проверки в логе:
- Node-проверки чистой логики на реальном ZIP;
- реальный Chrome через `puppeteer-core`;
- hover-tooltip;
- ручная загрузка CSV;
- сценарий недоступного CDN;
- сценарий архива без файла детальной активности.

## Проверка на «мухлеж»

Признаков чтения результатов Fable 5, Opus 4.8, `_arena`, `summary-report` или
чужих `REPORT.md` в присланном логе и проектных файлах не найдено. В основном
коде `assets/script.js` не обнаружены итоговые числа конкретного архива типа
`91.87`, `57.2`, `51.2`, `902`, `16 п.п.`, `24 п.п.`; эти числа находятся в
`REPORT.md` как итог анализа предоставленного ZIP.

При этом методология была не полностью самостоятельной: Sonnet 5 явно взял
иерархию надежности сигналов из `youtube-video-analysis`, визуальную палитру из
`dataviz`, дизайн-рамки из `frontend-design`, а процесс работы вел через
superpowers-планирование. Это не скрытый обман, но это самый сильный случай
использования внешней методологии среди трех моделей.

Отдельная особенность: модель потратила время на вопрос-подтверждение и план,
что ухудшает темп бенчмарка, но улучшает осознанность и проверяемость подхода.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $32.84 / 77.2k input / 468.6k output / 50.1m cache read / 1.8m cache write.
- Previous checkpoint: $21.61 / 58.4k input / 324.8k output / 32.8m cache read / 1.1m cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
