import http.server, socketserver, os, base64, json

DIR = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.path.join(DIR, 'screenshots')
os.makedirs(SHOTS, exist_ok=True)

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=DIR, **k)
    def do_POST(self):
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length)
        try:
            data = json.loads(body)
            name = data.get('name','shot')
            b64 = data.get('data','')
            # может быть data:image/png;base64,....
            if ',' in b64: b64 = b64.split(',',1)[1]
            raw = base64.b64decode(b64)
            path = os.path.join(SHOTS, name + '.png')
            with open(path, 'wb') as f:
                f.write(raw)
            msg = b'OK '+path.encode()
            self.send_response(200)
            self.send_header('Content-Type','text/plain')
            self.send_header('Access-Control-Allow-Origin','*')
            self.end_headers()
            self.wfile.write(msg)
        except Exception as e:
            self.send_response(500)
            self.send_header('Access-Control-Allow-Origin','*')
            self.end_headers()
            self.wfile.write(str(e).encode())
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('Access-Control-Allow-Methods','POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        self.end_headers()
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin','*')
        super().end_headers()

with socketserver.TCPServer(("", 8765), H) as httpd:
    print("serving on 8765, shots dir:", SHOTS)
    httpd.serve_forever()
