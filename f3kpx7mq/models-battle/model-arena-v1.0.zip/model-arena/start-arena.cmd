@echo off
cd /d "%~dp0_arena"
start "" http://localhost:7358
node server.js
