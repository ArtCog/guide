# RUN METRICS

| Field | Value |
|---|---|
| Model | Fable 5 |
| Test | 02B - Mario-like platformer |
| Result | Browser platformer prototype |
| Cost USD | $10.90 |
| Task time | 24m 47s |
| API time | 24m 7s |
| Wall time | 31m 1s |
| Input tokens | 19.5k |
| Output tokens | 98.5k |
| Cache read | 2.9m |
| Cache write | 143.7k |
| Code changes | 1625 lines added, 46 lines removed |
| Verdict | Created a Mario-like browser platformer with physics, enemies, crystals, hazards, lives, victory and loss states. Score pending. |

