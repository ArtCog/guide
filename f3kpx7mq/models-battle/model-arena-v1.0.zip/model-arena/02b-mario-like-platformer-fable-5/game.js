/* ============================================================
   «Рыжик и Кристальный лес» — Mario-like platformer prototype.
   Vanilla JS + Canvas 2D. No external assets, no network.
   All art is drawn procedurally, all sound is WebAudio synth.
   ============================================================ */
'use strict';

// ---------------- Canvas ----------------
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const VIEW_W = 960, VIEW_H = 480;
const DPR = Math.min(window.devicePixelRatio || 1, 2);
canvas.width = VIEW_W * DPR;
canvas.height = VIEW_H * DPR;

function fitCanvas() {
  const s = Math.min((window.innerWidth - 24) / VIEW_W, (window.innerHeight - 80) / VIEW_H);
  const k = Math.max(0.4, Math.min(s, 2));
  canvas.style.width = (VIEW_W * k) + 'px';
  canvas.style.height = (VIEW_H * k) + 'px';
}
window.addEventListener('resize', fitCanvas);
fitCanvas();

// ---------------- World constants ----------------
const TILE = 32, ROWS = 15, COLS = 176;
const WORLD_W = COLS * TILE;
const GRAV = 2200, MAX_FALL = 950;
const MOVE_ACC = 2800, AIR_ACC = 1900, FRICTION = 2400, MAX_SPD = 265;
const JUMP_V = 710, COYOTE = 0.10, BUFFER = 0.14;
const PW = 24, PH = 30;           // player hitbox
const EN_W = 26, EN_H = 24, ESPD = 62; // enemies

// Tile ids
const T = { EMPTY: 0, GROUND: 1, BRICK: 2, Q: 3, USED: 4, STONE: 5, SPIKE: 6, QHEART: 8 };
const isSolid = t => t === T.GROUND || t === T.BRICK || t === T.Q || t === T.USED || t === T.STONE || t === T.QHEART;

// ---------------- Small helpers ----------------
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
function hash(n) { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); }
function circle(x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }
function ell(x, y, rx, ry, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, 7); ctx.fill(); }
function rr(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
function heartShape(x, y, s, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x - s * 0.25, y, s * 0.32, 0, 7);
  ctx.arc(x + s * 0.25, y, s * 0.32, 0, 7);
  ctx.moveTo(x - s * 0.53, y + s * 0.12);
  ctx.lineTo(x, y + s * 0.78);
  ctx.lineTo(x + s * 0.53, y + s * 0.12);
  ctx.closePath();
  ctx.fill();
}

// ---------------- Level ----------------
function buildLevel() {
  const g = [];
  for (let r = 0; r < ROWS; r++) g.push(new Array(COLS).fill(T.EMPTY));
  const crystals = [], spawns = [];
  const rect = (c0, r0, c1, r1, t) => { for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) g[r][c] = t; };
  const ground = (c0, c1) => rect(c0, 13, c1, 14, T.GROUND);
  const plat = (c, r, len) => rect(c, r, c + len - 1, r, T.STONE);
  const brick = (c, r) => { g[r][c] = T.BRICK; };
  const q = (c, r) => { g[r][c] = T.Q; };
  const spikes = (c0, c1) => rect(c0, 12, c1, 12, T.SPIKE);
  const stairs = (c0, steps) => { for (let i = 0; i < steps; i++) rect(c0 + i, 12 - i, c0 + i, 12, T.STONE); };
  const cr = (c, r) => crystals.push({ x: c * TILE + TILE / 2, y: r * TILE + TILE / 2, taken: false, ph: hash(c * 3 + r) * 6 });
  const crRow = (c0, c1, r) => { for (let c = c0; c <= c1; c++) cr(c, r); };
  const en = (c, floorRow = 13) => spawns.push({ x: c * TILE + 3, y: floorRow * TILE - EN_H });

  // --- Start zone
  ground(0, 27);
  brick(14, 9); q(15, 9); brick(16, 9); q(17, 9); brick(18, 9);
  crRow(10, 12, 12);
  en(21);
  // Pit A (28-30)
  cr(28, 11); cr(29, 10); cr(30, 11);
  // --- Zone 2: enemies + spikes
  ground(31, 48);
  q(35, 9);
  en(37); en(40);
  spikes(44, 45); cr(44, 10); cr(45, 10);
  // Pit B (49-58) with floating platforms
  plat(50, 11, 2); plat(54, 9, 2); plat(57, 11, 2);
  cr(50, 10); cr(51, 10); cr(54, 8); cr(55, 8); cr(57, 10); cr(58, 10);
  // --- Zone 3: bonus blocks + stairs
  ground(59, 77);
  brick(61, 9); q(62, 9); g[9][63] = T.QHEART; q(64, 9); brick(65, 9);
  en(67); en(70); cr(68, 12); cr(69, 12);
  stairs(74, 4);
  // Pit C (78-81), jump from stair top
  cr(78, 8); cr(79, 7); cr(80, 7); cr(81, 8);
  // --- Zone 4: long run
  ground(82, 107);
  crRow(84, 86, 12);
  spikes(88, 90); cr(88, 10); cr(89, 10); cr(90, 10);
  en(94); en(97);
  q(100, 9); q(101, 9);
  // Pit D (108-111) with a bridge platform
  plat(109, 11, 2); cr(109, 10); cr(110, 10);
  // --- Zone 5: enemy gauntlet
  ground(112, 133);
  en(116); en(120); en(124);
  rect(118, 9, 122, 9, T.BRICK); q(120, 9);
  cr(119, 12); cr(121, 12);
  // Pit E (134-143) with platforms + platform enemy
  plat(135, 11, 3); plat(139, 9, 2); plat(142, 11, 2);
  en(136, 11);
  cr(136, 9); cr(139, 7); cr(140, 7); cr(142, 10); cr(143, 10);
  // --- Finale: stairs and the flag
  ground(144, COLS - 1);
  en(147); en(150);
  stairs(154, 7);
  cr(155, 10); cr(157, 8); cr(159, 6);
  g[12][165] = T.STONE; // flag base block
  cr(163, 11);

  let total = crystals.length;
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) if (g[r][c] === T.Q) total++;
  return { grid: g, crystals, spawns, total };
}

const FLAG_COL = 165;
const flagX = FLAG_COL * TILE;
const SIGNS = [
  { x: 6 * TILE, lines: ['← → — бег', 'ПРОБЕЛ — прыжок'] },
  { x: 152 * TILE, lines: ['ФИНИШ →'] },
];

// ---------------- Game state ----------------
let grid = [], crystals = [], spawns = [], totalCrystals = 0;
const enemies = [], particles = [], floats = [], bumps = [], pickups = [], pops = [];
let state = 'menu'; // menu | play | pause | dying | winAnim | won | over
let lives = 3, time = 0, crystalsGot = 0, finishTime = 0;
let deathT = 0, winT = 0, winPhase = 0;
let camX = 0, shakeT = 0, globalT = 0;
let muted = false;

const player = {
  x: 0, y: 0, w: PW, h: PH, vx: 0, vy: 0,
  face: 1, onGround: false, hitWall: false, landImpact: 0,
  coyote: 0, buffer: 0, jumping: false, invuln: 0,
  landT: 0, animPhase: 0, blinkT: 2,
};

function respawnPlayer(invuln) {
  player.x = 3 * TILE; player.y = 13 * TILE - PH;
  player.vx = 0; player.vy = 0; player.face = 1;
  player.onGround = true; player.coyote = 0; player.buffer = 0;
  player.jumping = false; player.invuln = invuln || 0;
  player.landT = 0; player.animPhase = 0;
}

function resetEnemies() {
  enemies.length = 0;
  for (const s of spawns) {
    enemies.push({ x: s.x, y: s.y, w: EN_W, h: EN_H, vx: 0, vy: 0, dir: -1, onGround: false, hitWall: false, dead: false, squash: 0, ph: hash(s.x) * 6 });
  }
}

function resetGame() {
  const L = buildLevel();
  grid = L.grid; crystals = L.crystals; spawns = L.spawns; totalCrystals = L.total;
  particles.length = 0; floats.length = 0; bumps.length = 0; pickups.length = 0; pops.length = 0;
  lives = 3; time = 0; crystalsGot = 0; finishTime = 0;
  deathT = 0; winT = 0; winPhase = 0; camX = 0; shakeT = 0;
  respawnPlayer(0);
  resetEnemies();
  state = 'play';
}

// ---------------- Input ----------------
const keys = new Set();
const jumpHeld = () => keys.has('Space') || keys.has('ArrowUp') || keys.has('KeyW');

window.addEventListener('keydown', (e) => {
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.repeat) return;
  keys.add(e.code);
  initAudio();
  if (e.code === 'KeyM') { muted = !muted; if (master) master.gain.value = muted ? 0 : 1; return; }
  if (e.code === 'KeyR') { resetGame(); return; }
  if (state === 'menu') {
    if (e.code === 'Space' || e.code === 'Enter') resetGame();
    return;
  }
  if ((state === 'won' || state === 'over') && (e.code === 'Space' || e.code === 'Enter')) { resetGame(); return; }
  if (e.code === 'KeyP' || e.code === 'Escape') {
    if (state === 'play') state = 'pause';
    else if (state === 'pause') state = 'play';
    return;
  }
  if (state === 'play' && (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW')) player.buffer = BUFFER;
});
window.addEventListener('keyup', (e) => keys.delete(e.code));
window.addEventListener('blur', () => { if (state === 'play') state = 'pause'; });
canvas.addEventListener('pointerdown', () => { initAudio(); if (state === 'menu') resetGame(); });

// ---------------- Audio (WebAudio synth) ----------------
let actx = null, master = null, audioFailed = false;
function initAudio() {
  if (actx || audioFailed) return;
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { audioFailed = true; return; }
    actx = new AC();
    master = actx.createGain();
    master.gain.value = muted ? 0 : 1;
    master.connect(actx.destination);
  } catch (err) { audioFailed = true; }
}
function playTone(freq, when, dur, type, vol, slide) {
  if (!actx) return;
  try {
    const o = actx.createOscillator(), gn = actx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, when);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, slide), when + dur);
    gn.gain.setValueAtTime(0.0001, when);
    gn.gain.linearRampToValueAtTime(vol, when + 0.012);
    gn.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    o.connect(gn); gn.connect(master);
    o.start(when); o.stop(when + dur + 0.05);
  } catch (err) { /* audio is optional */ }
}
const now = () => actx ? actx.currentTime : 0;
const sfxJump = () => playTone(300, now(), 0.16, 'square', 0.09, 640);
const sfxStomp = () => playTone(260, now(), 0.16, 'square', 0.13, 60);
const sfxBump = () => playTone(130, now(), 0.07, 'triangle', 0.12);
function sfxCrystal() { playTone(988, now(), 0.07, 'sine', 0.1); playTone(1319, now() + 0.07, 0.12, 'sine', 0.1); }
function sfxHeart() { [660, 880, 1175].forEach((f, i) => playTone(f, now() + i * 0.09, 0.12, 'triangle', 0.1)); }
function sfxDie() { playTone(400, now(), 0.6, 'sawtooth', 0.11, 55); playTone(200, now() + 0.05, 0.5, 'square', 0.07, 40); }
function sfxWin() { [523, 659, 784, 1047, 1319].forEach((f, i) => playTone(f, now() + i * 0.09, 0.16, 'square', 0.08)); }

// Tiny original chiptune loop (C-major arcade tune, 4 bars).
const EIGHTH = 60 / 132 / 2;
const LEAD = [
  [72, 1], [76, 1], [79, 1], [76, 1], [81, 2], [79, 2],
  [77, 1], [81, 1], [84, 1], [81, 1], [79, 2], [76, 2],
  [72, 1], [76, 1], [79, 1], [76, 1], [84, 2], [83, 1], [81, 1],
  [79, 1], [76, 1], [74, 1], [71, 1], [72, 4],
];
const BASS = [
  [48, 2], [48, 2], [55, 2], [55, 2], [53, 2], [53, 2], [57, 2], [57, 2],
  [48, 2], [48, 2], [55, 2], [55, 2], [50, 2], [50, 2], [43, 2], [43, 2],
];
const midiF = m => 440 * Math.pow(2, (m - 69) / 12);
const mLead = { i: 0, t: 0 }, mBass = { i: 0, t: 0 };
function tickMusic() {
  if (!actx || muted) return;
  if (!(state === 'play' || state === 'menu' || state === 'winAnim')) return;
  const cur = actx.currentTime, horizon = cur + 0.18;
  if (mLead.t < cur - 0.05) mLead.t = cur + 0.02;
  if (mBass.t < cur - 0.05) mBass.t = cur + 0.02;
  while (mLead.t < horizon) {
    const [n, d] = LEAD[mLead.i];
    if (n > 0) playTone(midiF(n), mLead.t, d * EIGHTH * 0.92, 'square', 0.042);
    mLead.t += d * EIGHTH; mLead.i = (mLead.i + 1) % LEAD.length;
  }
  while (mBass.t < horizon) {
    const [n, d] = BASS[mBass.i];
    if (n > 0) playTone(midiF(n), mBass.t, d * EIGHTH * 0.95, 'triangle', 0.06);
    mBass.t += d * EIGHTH; mBass.i = (mBass.i + 1) % BASS.length;
  }
}

// ---------------- Physics ----------------
function tileAt(c, r) {
  if (c < 0 || c >= COLS) return T.GROUND; // world walls
  if (r < 0 || r >= ROWS) return T.EMPTY;
  return grid[r][c];
}
const solidAt = (c, r) => isSolid(tileAt(c, r));

function moveX(e, dt) {
  e.hitWall = false;
  e.x += e.vx * dt;
  if (e.vx > 0) {
    const c = Math.floor((e.x + e.w) / TILE);
    for (let r = Math.floor(e.y / TILE); r * TILE < e.y + e.h; r++) {
      if (solidAt(c, r)) { e.x = c * TILE - e.w - 0.01; e.vx = 0; e.hitWall = true; break; }
    }
  } else if (e.vx < 0) {
    const c = Math.floor(e.x / TILE);
    for (let r = Math.floor(e.y / TILE); r * TILE < e.y + e.h; r++) {
      if (solidAt(c, r)) { e.x = (c + 1) * TILE + 0.01; e.vx = 0; e.hitWall = true; break; }
    }
  }
  if (e.x < 0) { e.x = 0; e.vx = 0; e.hitWall = true; }
  if (e.x + e.w > WORLD_W) { e.x = WORLD_W - e.w; e.vx = 0; e.hitWall = true; }
}

function moveY(e, dt, isPlayer) {
  e.y += e.vy * dt;
  if (e.vy > 0) {
    const r = Math.floor((e.y + e.h) / TILE);
    for (let c = Math.floor(e.x / TILE); c * TILE < e.x + e.w; c++) {
      if (solidAt(c, r)) {
        e.landImpact = e.vy;
        e.y = r * TILE - e.h - 0.01; e.vy = 0; e.onGround = true;
        break;
      }
    }
  } else if (e.vy < 0) {
    const r = Math.floor(e.y / TILE);
    let hit = -1;
    for (let c = Math.floor(e.x / TILE); c * TILE < e.x + e.w; c++) {
      if (solidAt(c, r)) { hit = c; break; }
    }
    if (hit >= 0) {
      e.y = (r + 1) * TILE + 0.01; e.vy = 0;
      if (isPlayer) {
        const cc = Math.floor((e.x + e.w / 2) / TILE);
        bumpBlock(solidAt(cc, r) ? cc : hit, r);
      }
    }
  }
}

function bumpBlock(c, r) {
  if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
  const t = grid[r][c];
  if (t === T.Q) {
    grid[r][c] = T.USED;
    bumps.push({ c, r, t: 0 });
    crystalsGot++;
    pops.push({ x: c * TILE + TILE / 2, y: r * TILE - 6, t: 0 });
    addFloat(c * TILE + TILE / 2, r * TILE - 14, '+1', '#7feaff');
    sfxCrystal();
  } else if (t === T.QHEART) {
    grid[r][c] = T.USED;
    bumps.push({ c, r, t: 0 });
    pickups.push({ x: c * TILE + 4, y: r * TILE - 26, ph: 0 });
    sfxBump();
  } else if (t === T.BRICK || t === T.USED) {
    bumps.push({ c, r, t: 0 });
    sfxBump();
  } else {
    sfxBump();
  }
}

// ---------------- Effects ----------------
function puff(x, y, n, color, spd) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, v = (0.3 + Math.random() * 0.7) * spd;
    particles.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - spd * 0.4, life: 0.35 + Math.random() * 0.35, t: 0, size: 2 + Math.random() * 3, color, grav: 700 });
  }
}
function sparkle(x, y) {
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    particles.push({ x, y, vx: Math.cos(a) * 90, vy: Math.sin(a) * 90, life: 0.4, t: 0, size: 2.5, color: '#aef4ff', grav: 0 });
  }
}
function dust(x, y) { puff(x, y, 6, 'rgba(190,160,120,0.9)', 70); }
function addFloat(x, y, txt, color) { floats.push({ x, y, txt, color, t: 0 }); }
function firework(x, y) {
  const cols = ['#ff6b8a', '#ffd94a', '#7feaff', '#9dff6b', '#d59bff'];
  const col = cols[Math.floor(Math.random() * cols.length)];
  for (let i = 0; i < 22; i++) {
    const a = (i / 22) * Math.PI * 2, v = 70 + Math.random() * 130;
    particles.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.7 + Math.random() * 0.4, t: 0, size: 2.5, color: col, grav: 220 });
  }
}

// ---------------- Update ----------------
function die(force) {
  if (!force && player.invuln > 0) return;
  if (state !== 'play') return;
  lives--;
  state = 'dying'; deathT = 0;
  player.vy = -580; player.vx = 0;
  shakeT = 0.3;
  sfxDie();
}

function startWin() {
  if (state !== 'play') return;
  state = 'winAnim'; winT = 0; winPhase = 0;
  finishTime = time;
  player.x = flagX + 4; // grab the pole
  player.vx = 0; player.vy = Math.max(player.vy, 60);
  sfxWin();
}

function updatePlayer(dt) {
  const p = player;
  const left = keys.has('ArrowLeft') || keys.has('KeyA');
  const right = keys.has('ArrowRight') || keys.has('KeyD');
  const acc = p.onGround ? MOVE_ACC : AIR_ACC;

  if (left && !right) { p.vx -= acc * dt; p.face = -1; }
  else if (right && !left) { p.vx += acc * dt; p.face = 1; }
  else {
    const f = (p.onGround ? FRICTION : 500) * dt;
    if (Math.abs(p.vx) <= f) p.vx = 0; else p.vx -= Math.sign(p.vx) * f;
  }
  p.vx = clamp(p.vx, -MAX_SPD, MAX_SPD);

  p.coyote = p.onGround ? COYOTE : Math.max(0, p.coyote - dt);
  p.buffer = Math.max(0, p.buffer - dt);
  if (p.buffer > 0 && p.coyote > 0) {
    p.vy = -JUMP_V; p.onGround = false; p.coyote = 0; p.buffer = 0; p.jumping = true;
    dust(p.x + p.w / 2, p.y + p.h);
    sfxJump();
  }
  if (p.jumping && !jumpHeld() && p.vy < -220) { p.vy = -220; p.jumping = false; }
  if (p.vy >= 0) p.jumping = false;

  p.vy = Math.min(p.vy + GRAV * dt, MAX_FALL);
  const wasGround = p.onGround;
  p.onGround = false;
  moveX(p, dt);
  moveY(p, dt, true);
  if (p.onGround && !wasGround) {
    p.landT = 0.13;
    if (p.landImpact > 420) dust(p.x + p.w / 2, p.y + p.h);
  }

  p.invuln = Math.max(0, p.invuln - dt);
  p.landT = Math.max(0, p.landT - dt);
  p.animPhase += Math.abs(p.vx) * dt * 0.055;
  p.blinkT -= dt;
  if (p.blinkT < -0.12) p.blinkT = 1.6 + Math.random() * 2.5;
}

function updateEnemies(dt) {
  for (const e of enemies) {
    if (e.dead) { e.squash -= dt; continue; }
    e.vx = e.dir * ESPD;
    e.vy = Math.min(e.vy + GRAV * dt, MAX_FALL);
    e.onGround = false;
    moveX(e, dt);
    if (e.hitWall) e.dir *= -1;
    moveY(e, dt, false);
    if (e.onGround) {
      const aheadX = e.dir > 0 ? e.x + e.w + 2 : e.x - 2;
      const cA = Math.floor(aheadX / TILE);
      const rFeet = Math.floor((e.y + e.h - 2) / TILE);
      const rBelow = Math.floor((e.y + e.h + 4) / TILE);
      if (!solidAt(cA, rBelow) || tileAt(cA, rFeet) === T.SPIKE) e.dir *= -1;
    }
    e.ph += dt * 8;
  }
}

function interact() {
  const p = player;
  // Enemies: stomp from above, deadly from the side.
  for (const e of enemies) {
    if (e.dead) continue;
    if (p.x < e.x + e.w && p.x + p.w > e.x && p.y < e.y + e.h && p.y + p.h > e.y) {
      if (p.vy > 0 && (p.y + p.h) - e.y < 16) {
        e.dead = true; e.squash = 0.5;
        p.vy = jumpHeld() ? -470 : -330;
        p.onGround = false;
        shakeT = 0.15;
        puff(e.x + e.w / 2, e.y + e.h / 2, 12, '#b79df2', 130);
        addFloat(e.x + e.w / 2, e.y - 8, 'БАМ!', '#ffffff');
        sfxStomp();
      } else if (p.invuln <= 0) { die(false); return; }
    }
  }
  // Spikes (forgiving hitbox: only the lower part of the tile is deadly).
  if (p.invuln <= 0) {
    const c0 = Math.floor(p.x / TILE), c1 = Math.floor((p.x + p.w - 1) / TILE);
    const r0 = Math.floor(p.y / TILE), r1 = Math.floor((p.y + p.h - 1) / TILE);
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
      if (tileAt(c, r) === T.SPIKE) {
        const sx = c * TILE + 3, sy = r * TILE + 15, sw = TILE - 6, sh = TILE - 15;
        if (p.x < sx + sw && p.x + p.w > sx && p.y < sy + sh && p.y + p.h > sy) { die(false); return; }
      }
    }
  }
  // Crystals
  for (const c of crystals) {
    if (c.taken) continue;
    if (Math.abs(p.x + p.w / 2 - c.x) < 24 && Math.abs(p.y + p.h / 2 - c.y) < 27) {
      c.taken = true; crystalsGot++;
      sparkle(c.x, c.y);
      addFloat(c.x, c.y - 12, '+1', '#7feaff');
      sfxCrystal();
    }
  }
  // Heart pickups
  for (let i = pickups.length - 1; i >= 0; i--) {
    const h = pickups[i];
    if (p.x < h.x + 24 && p.x + p.w > h.x && p.y < h.y + 24 && p.y + p.h > h.y) {
      pickups.splice(i, 1);
      lives++;
      sparkle(h.x + 12, h.y + 10);
      addFloat(h.x + 12, h.y - 4, '+1 ЖИЗНЬ', '#ff8fa3');
      sfxHeart();
    }
  }
  // Fell into a pit
  if (p.y > ROWS * TILE + 80) { die(true); return; }
  // Finish flag: the whole column triggers (touching the base block counts),
  // so the finish cannot be jumped over or blocked.
  if (p.x + p.w > flagX - 2) startWin();
}

function updateEffects(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const pt = particles[i];
    pt.t += dt;
    if (pt.t >= pt.life) { particles.splice(i, 1); continue; }
    pt.vy += pt.grav * dt;
    pt.x += pt.vx * dt; pt.y += pt.vy * dt;
  }
  for (let i = floats.length - 1; i >= 0; i--) {
    const f = floats[i];
    f.t += dt; f.y -= 34 * dt;
    if (f.t > 0.9) floats.splice(i, 1);
  }
  for (let i = bumps.length - 1; i >= 0; i--) {
    bumps[i].t += dt;
    if (bumps[i].t > 0.18) bumps.splice(i, 1);
  }
  for (let i = pops.length - 1; i >= 0; i--) {
    pops[i].t += dt;
    if (pops[i].t > 0.55) pops.splice(i, 1);
  }
  for (const h of pickups) h.ph += dt * 3;
  shakeT = Math.max(0, shakeT - dt);
}

function updateCamera(dt) {
  const target = clamp(player.x - 360, 0, WORLD_W - VIEW_W);
  camX += (target - camX) * Math.min(1, dt * 7);
}

let fireworkT = 0;
function update(dt) {
  globalT += dt;
  if (state === 'play') {
    time += dt;
    updatePlayer(dt);
    updateEnemies(dt);
    interact();
  } else if (state === 'dying') {
    deathT += dt;
    player.vy = Math.min(player.vy + GRAV * dt, MAX_FALL);
    player.y += player.vy * dt;
    if (deathT > 1.4) {
      if (lives > 0) { respawnPlayer(2); resetEnemies(); state = 'play'; }
      else state = 'over';
    }
  } else if (state === 'winAnim') {
    winT += dt;
    if (winPhase === 0) {
      // Slide down the pole onto the base block.
      player.y = Math.min(player.y + 190 * dt, 12 * TILE - PH);
      player.animPhase += dt * 6;
      if (player.y >= 12 * TILE - PH - 0.5) winPhase = 1;
    } else {
      // Hop off and walk to the gate.
      player.face = 1;
      player.x += 110 * dt;
      player.y = Math.min(player.y + 230 * dt, 13 * TILE - PH);
      player.animPhase += 110 * dt * 0.055;
      if (Math.random() < dt * 3) firework(flagX + (Math.random() * 220 - 60), 90 + Math.random() * 120);
      if (player.x > 169.6 * TILE || winT > 6) state = 'won';
    }
  } else if (state === 'won') {
    fireworkT -= dt;
    if (fireworkT <= 0) {
      fireworkT = 0.35;
      firework(camX + 120 + Math.random() * (VIEW_W - 240), 70 + Math.random() * 160);
    }
  }
  if (state !== 'pause') updateEffects(dt);
  updateCamera(dt);
  tickMusic();
}

// ---------------- Render: background ----------------
function drawBackground() {
  const grd = ctx.createLinearGradient(0, 0, 0, VIEW_H);
  grd.addColorStop(0, '#3f9bea');
  grd.addColorStop(0.6, '#8fd0f7');
  grd.addColorStop(1, '#d8f2ff');
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);

  // Sun
  const sx = VIEW_W - 150, sy = 86;
  const rg = ctx.createRadialGradient(sx, sy, 8, sx, sy, 95);
  rg.addColorStop(0, 'rgba(255,246,190,0.95)');
  rg.addColorStop(0.3, 'rgba(255,232,130,0.5)');
  rg.addColorStop(1, 'rgba(255,232,130,0)');
  ctx.fillStyle = rg;
  ctx.fillRect(sx - 95, sy - 95, 190, 190);
  ctx.fillStyle = '#fff3b8';
  circle(sx, sy, 26);

  // Distant crystal mountains (parallax 0.22)
  const off1 = camX * 0.22, seg1 = Math.floor(off1 / 230);
  for (let i = -1; i < 7; i++) {
    const k = seg1 + i, bx = k * 230 - off1;
    const h = 120 + hash(k * 3.7) * 100;
    ctx.fillStyle = 'rgba(168,182,230,0.75)';
    ctx.beginPath();
    ctx.moveTo(bx - 30, VIEW_H);
    ctx.lineTo(bx + 115, VIEW_H - h);
    ctx.lineTo(bx + 260, VIEW_H);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = 'rgba(235,242,255,0.85)';
    ctx.beginPath();
    ctx.moveTo(bx + 115, VIEW_H - h);
    ctx.lineTo(bx + 138, VIEW_H - h + 34);
    ctx.lineTo(bx + 115, VIEW_H - h + 26);
    ctx.lineTo(bx + 93, VIEW_H - h + 34);
    ctx.closePath();
    ctx.fill();
  }

  // Clouds, two layers
  for (const layer of [{ f: 0.28, y0: 46, sp: 320, s: 1, a: 0.8 }, { f: 0.5, y0: 96, sp: 380, s: 1.35, a: 0.95 }]) {
    const off = camX * layer.f + globalT * 7;
    const seg = Math.floor(off / layer.sp);
    ctx.fillStyle = `rgba(255,255,255,${layer.a})`;
    for (let i = -1; i < 5; i++) {
      const k = seg + i, bx = k * layer.sp - off;
      const y = layer.y0 + hash(k * 7.3) * 70, s = layer.s * (0.8 + hash(k * 2.9) * 0.5);
      circle(bx, y, 18 * s);
      circle(bx + 22 * s, y - 8 * s, 14 * s);
      circle(bx + 44 * s, y, 16 * s);
      ctx.fillRect(bx - 12 * s, y, 66 * s, 12 * s);
    }
  }

  // Green hills (parallax 0.55)
  const off2 = camX * 0.55, seg2 = Math.floor(off2 / 260);
  ctx.fillStyle = '#57b96b';
  for (let i = -1; i < 6; i++) {
    const k = seg2 + i, bx = k * 260 - off2;
    const h = 70 + hash(k * 5.1) * 70;
    ctx.beginPath();
    ctx.ellipse(bx + 130, VIEW_H, 170, h, 0, Math.PI, 0);
    ctx.fill();
  }
}

// ---------------- Render: tiles ----------------
function drawGroundTile(x, y, c, r) {
  const capped = r === 0 || grid[r - 1][c] !== T.GROUND;
  ctx.fillStyle = '#9c6238';
  ctx.fillRect(x, y, TILE, TILE);
  ctx.fillStyle = '#7c4b28';
  for (let i = 0; i < 3; i++) {
    const dx = hash(c * 13.3 + r * 7.1 + i) * 24 + 3;
    const dy = hash(c * 5.7 + r * 11.9 + i * 3) * 22 + 6;
    ctx.fillRect(x + dx, y + dy, 3, 3);
  }
  if (capped) {
    ctx.fillStyle = '#4cc257';
    ctx.fillRect(x, y, TILE, 10);
    ctx.fillStyle = '#2f9440';
    ctx.fillRect(x, y + 8, TILE, 3);
    ctx.fillStyle = '#6fe07c';
    for (let i = 0; i < 3; i++) {
      const dx = 4 + i * 10 + hash(c * 3.1 + i) * 5;
      ctx.fillRect(x + dx, y - 3 - hash(c * 1.7 + i) * 3, 2, 5);
    }
  }
}

function drawBrickTile(x, y) {
  ctx.fillStyle = '#c1613f';
  ctx.fillRect(x, y, TILE, TILE);
  ctx.fillStyle = '#8f3f24';
  ctx.fillRect(x, y + 10, TILE, 2);
  ctx.fillRect(x, y + 21, TILE, 2);
  ctx.fillRect(x + 15, y, 2, 10);
  ctx.fillRect(x + 7, y + 12, 2, 9);
  ctx.fillRect(x + 23, y + 12, 2, 9);
  ctx.fillRect(x + 15, y + 23, 2, 9);
  ctx.strokeStyle = 'rgba(60,25,12,0.6)';
  ctx.strokeRect(x + 0.5, y + 0.5, TILE - 1, TILE - 1);
}

function drawQTile(x, y, spent) {
  if (spent) {
    ctx.fillStyle = '#a9a297';
    ctx.fillRect(x, y, TILE, TILE);
    ctx.strokeStyle = '#6f695f';
    ctx.strokeRect(x + 1.5, y + 1.5, TILE - 3, TILE - 3);
    ctx.fillStyle = '#6f695f';
    ctx.fillRect(x + 13, y + 13, 6, 6);
    return;
  }
  const g = ctx.createLinearGradient(x, y, x, y + TILE);
  g.addColorStop(0, '#ffd94a');
  g.addColorStop(1, '#e8a020');
  ctx.fillStyle = g;
  ctx.fillRect(x, y, TILE, TILE);
  ctx.strokeStyle = '#a86a10';
  ctx.lineWidth = 2;
  ctx.strokeRect(x + 1, y + 1, TILE - 2, TILE - 2);
  ctx.lineWidth = 1;
  ctx.fillStyle = '#a86a10';
  ctx.fillRect(x + 3, y + 3, 3, 3); ctx.fillRect(x + TILE - 6, y + 3, 3, 3);
  ctx.fillRect(x + 3, y + TILE - 6, 3, 3); ctx.fillRect(x + TILE - 6, y + TILE - 6, 3, 3);
  ctx.fillStyle = `rgba(124,80,6,${0.75 + 0.25 * Math.sin(globalT * 5)})`;
  ctx.font = 'bold 20px "Trebuchet MS", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('?', x + TILE / 2, y + TILE / 2 + 1);
}

function drawStoneTile(x, y) {
  ctx.fillStyle = '#8fa0b8';
  ctx.fillRect(x, y, TILE, TILE);
  ctx.fillStyle = '#b6c3d6';
  ctx.fillRect(x, y, TILE, 5);
  ctx.strokeStyle = '#5d6b82';
  ctx.strokeRect(x + 0.5, y + 0.5, TILE - 1, TILE - 1);
  ctx.fillStyle = '#5d6b82';
  ctx.fillRect(x + 6, y + 14, 4, 4);
  ctx.fillRect(x + 22, y + 20, 4, 4);
}

function drawSpikeTile(x, y) {
  ctx.fillStyle = '#4a515f';
  ctx.fillRect(x, y + 26, TILE, 6);
  for (let i = 0; i < 2; i++) {
    const bx = x + i * 16;
    ctx.fillStyle = '#7c8598';
    ctx.beginPath();
    ctx.moveTo(bx + 1, y + 27);
    ctx.lineTo(bx + 8, y + 4);
    ctx.lineTo(bx + 15, y + 27);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#cfd6e4';
    ctx.beginPath();
    ctx.moveTo(bx + 8, y + 4);
    ctx.lineTo(bx + 11, y + 16);
    ctx.lineTo(bx + 8, y + 16);
    ctx.closePath();
    ctx.fill();
  }
}

function drawTiles() {
  const c0 = Math.max(0, Math.floor(camX / TILE) - 1);
  const c1 = Math.min(COLS - 1, c0 + Math.ceil(VIEW_W / TILE) + 2);
  const bumpMap = new Map();
  for (const b of bumps) bumpMap.set(b.r * 1000 + b.c, Math.sin(Math.min(1, b.t / 0.18) * Math.PI) * 9);
  for (let r = 0; r < ROWS; r++) {
    for (let c = c0; c <= c1; c++) {
      const t = grid[r][c];
      if (!t) continue;
      const x = c * TILE;
      let y = r * TILE;
      const off = bumpMap.get(r * 1000 + c);
      if (off) y -= off;
      if (t === T.GROUND) drawGroundTile(x, y, c, r);
      else if (t === T.BRICK) drawBrickTile(x, y);
      else if (t === T.Q || t === T.QHEART) drawQTile(x, y, false);
      else if (t === T.USED) drawQTile(x, y, true);
      else if (t === T.STONE) drawStoneTile(x, y);
      else if (t === T.SPIKE) drawSpikeTile(x, y);
    }
  }
}

// ---------------- Render: decor ----------------
function drawSigns() {
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (const s of SIGNS) {
    const w = 132, h = s.lines.length * 16 + 14;
    const x = s.x - w / 2 + TILE / 2, y = 13 * TILE - 46 - h;
    ctx.fillStyle = '#7a4e26';
    ctx.fillRect(s.x + TILE / 2 - 3, 13 * TILE - 50, 6, 50);
    ctx.fillStyle = '#b07a45';
    rr(x, y, w, h, 6); ctx.fill();
    ctx.strokeStyle = '#7a4e26';
    ctx.lineWidth = 2;
    rr(x, y, w, h, 6); ctx.stroke();
    ctx.lineWidth = 1;
    ctx.fillStyle = '#3d240e';
    ctx.font = 'bold 12px "Trebuchet MS", sans-serif';
    s.lines.forEach((ln, i) => ctx.fillText(ln, x + w / 2, y + 12 + i * 16));
  }
}

function drawFlag() {
  const px = flagX + 16;
  const topY = 4 * TILE;
  ctx.fillStyle = '#c9d2e0';
  ctx.fillRect(px - 3, topY, 6, 12 * TILE - topY);
  ctx.fillStyle = '#8b96a8';
  ctx.fillRect(px - 3, topY, 2, 12 * TILE - topY);
  ctx.fillStyle = '#ffd94a';
  circle(px, topY - 5, 7);
  const wave = Math.sin(globalT * 4) * 4;
  ctx.fillStyle = '#ff5d5d';
  ctx.beginPath();
  ctx.moveTo(px + 3, topY + 2);
  ctx.lineTo(px + 40 + wave, topY + 18);
  ctx.lineTo(px + 3, topY + 34);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  circle(px + 16, topY + 18, 5);
}

function drawGate() {
  const x = 169 * TILE, gy = 13 * TILE;
  ctx.fillStyle = '#9aa7bd';
  rr(x, gy - 150, 128, 150, 6); ctx.fill();
  ctx.fillStyle = '#7e8ba3';
  for (let i = 0; i < 4; i++) ctx.fillRect(x + 4 + i * 33, gy - 168, 22, 20);
  ctx.fillStyle = '#5d6b82';
  ctx.fillRect(x, gy - 152, 128, 6);
  ctx.fillStyle = '#3a3f4e';
  rr(x + 44, gy - 62, 40, 62, 16); ctx.fill();
  ctx.fillStyle = '#2b3448';
  circle(x + 100, gy - 108, 9);
  ctx.fillStyle = '#7feaff';
  circle(x + 100, gy - 108, 6);
  ctx.fillStyle = '#8b96a8';
  ctx.fillRect(x + 62, gy - 196, 4, 30);
  ctx.fillStyle = '#59e0ff';
  ctx.beginPath();
  ctx.moveTo(x + 66, gy - 196);
  ctx.lineTo(x + 92 + Math.sin(globalT * 4 + 1) * 3, gy - 188);
  ctx.lineTo(x + 66, gy - 180);
  ctx.closePath();
  ctx.fill();
}

// ---------------- Render: entities ----------------
function drawCrystalShape(x, y, s, ph) {
  const spin = 0.35 + 0.65 * Math.abs(Math.sin(globalT * 2.6 + ph));
  const bob = Math.sin(globalT * 2.2 + ph) * 3;
  ctx.save();
  ctx.translate(x, y + bob);
  ctx.scale(spin, 1);
  ctx.globalAlpha = 0.25;
  ctx.fillStyle = '#aef4ff';
  circle(0, 0, s * 1.5);
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#5fe3ff';
  ctx.beginPath();
  ctx.moveTo(0, -s); ctx.lineTo(s * 0.72, 0); ctx.lineTo(0, s); ctx.lineTo(-s * 0.72, 0);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.75)';
  ctx.beginPath();
  ctx.moveTo(0, -s * 0.55); ctx.lineTo(s * 0.34, 0); ctx.lineTo(0, s * 0.55); ctx.lineTo(-s * 0.34, 0);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

function drawCrystals() {
  const lo = camX - 60, hi = camX + VIEW_W + 60;
  for (const c of crystals) {
    if (c.taken || c.x < lo || c.x > hi) continue;
    drawCrystalShape(c.x, c.y, 11, c.ph);
  }
  for (const p of pops) {
    const k = p.t / 0.55;
    ctx.globalAlpha = 1 - k;
    drawCrystalShape(p.x, p.y - k * 34, 10, 0);
    ctx.globalAlpha = 1;
  }
}

function drawPickups() {
  for (const h of pickups) {
    const bob = Math.sin(h.ph) * 2.5;
    ctx.globalAlpha = 0.3;
    ctx.fillStyle = '#ffb3c0';
    circle(h.x + 12, h.y + 11 + bob, 16);
    ctx.globalAlpha = 1;
    heartShape(h.x + 12, h.y + 9 + bob, 20, '#ff5b74');
  }
}

function drawEnemy(e) {
  if (e.dead && e.squash <= 0) return;
  const cx = e.x + e.w / 2, bottom = e.y + e.h;
  ctx.save();
  ctx.translate(cx, bottom);
  if (e.dead) {
    ctx.globalAlpha = Math.max(0, e.squash * 2);
    ctx.scale(1.25, 0.3);
  } else {
    const wob = 1 + Math.sin(e.ph) * 0.05;
    ctx.scale(wob, 2 - wob);
  }
  ell(0, -11, 14, 11.5, '#8b5cf6');
  ell(0, -6, 12, 6, '#7343e0');
  const shuffle = e.dead ? 0 : Math.sin(e.ph * 2) * 2.5;
  ctx.fillStyle = '#4c2d99';
  ell(-7 + shuffle, -2, 4.5, 3, '#4c2d99');
  ell(7 - shuffle, -2, 4.5, 3, '#4c2d99');
  ell(-5, -15, 3.6, 4, '#ffffff');
  ell(5, -15, 3.6, 4, '#ffffff');
  const look = e.dir * 1.4;
  ell(-5 + look, -14.5, 1.8, 2.2, '#31184f');
  ell(5 + look, -14.5, 1.8, 2.2, '#31184f');
  ctx.strokeStyle = '#31184f';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-9, -21); ctx.lineTo(-2, -18.5);
  ctx.moveTo(9, -21); ctx.lineTo(2, -18.5);
  ctx.stroke();
  ctx.lineWidth = 1;
  ctx.restore();
}

function drawEnemies() {
  const lo = camX - 80, hi = camX + VIEW_W + 80;
  for (const e of enemies) if (e.x > lo && e.x < hi) drawEnemy(e);
}

// The hero: a little orange fox, drawn from primitives.
function drawFox(px, py, face, o) {
  const run = o.run || 0, t = o.t || 0;
  const squash = o.squash || 1, stretch = o.stretch || 1;
  ctx.save();
  ctx.translate(px + PW / 2, py + PH);
  ctx.scale(face, 1);
  ctx.scale(stretch, squash);

  // Tail
  const wag = Math.sin(t * 10) * (run > 0.5 ? 4 : 1.5);
  ell(-15, -11 + wag * 0.4, 6.5, 5.5, '#e8811f');
  ell(-19, -13 + wag * 0.6, 3.6, 3.2, '#fff1de');

  // Legs
  ctx.fillStyle = '#9c5a17';
  if (o.air) {
    rr(-8, -7, 6, 7, 2); ctx.fill();
    rr(3, -9, 6, 7, 2); ctx.fill();
  } else {
    const step = run > 0.05 ? Math.sin(o.phase * 6) * 3.5 : 0;
    rr(-8 + step, -6, 6, 6, 2); ctx.fill();
    rr(3 - step, -6, 6, 6, 2); ctx.fill();
  }

  // Body
  ell(0, -14, 12.5, 11.5, '#f5923e');
  ell(3, -11, 7, 6, '#ffe9d2');

  // Ears
  ctx.fillStyle = '#f5923e';
  ctx.beginPath(); ctx.moveTo(-10, -21); ctx.lineTo(-13, -33); ctx.lineTo(-3, -24); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(0, -23); ctx.lineTo(5, -34); ctx.lineTo(9, -22); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#8a4a12';
  ctx.beginPath(); ctx.moveTo(-9, -23); ctx.lineTo(-11, -30); ctx.lineTo(-5, -24); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(2, -24); ctx.lineTo(5, -31); ctx.lineTo(7, -23); ctx.closePath(); ctx.fill();

  // Scarf
  ctx.fillStyle = '#3fae5c';
  rr(-7, -9, 14, 4.5, 2); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-6, -7);
  ctx.lineTo(-13 - run * 3, -3 + Math.sin(t * 9) * 2);
  ctx.lineTo(-6, -3);
  ctx.closePath(); ctx.fill();

  // Face
  const blink = o.blink;
  ctx.fillStyle = '#2b1608';
  if (blink) {
    ctx.fillRect(1, -18, 4, 1.6);
    ctx.fillRect(7, -17, 4, 1.6);
  } else {
    circle(3, -17.5, 2);
    circle(9, -16.5, 2);
  }
  ell(9.5, -12, 5.5, 4.5, '#fff6ea');
  ctx.fillStyle = '#2b1608';
  circle(13, -12.5, 2.2);
  ctx.restore();
}

function drawPlayerSprite() {
  const p = player;
  if (state === 'dying') {
    ctx.save();
    ctx.translate(p.x + PW / 2, p.y + PH / 2);
    ctx.rotate(deathT * 9);
    ctx.translate(-(p.x + PW / 2), -(p.y + PH / 2));
    drawFox(p.x, p.y, p.face, { t: globalT, air: true });
    ctx.restore();
    return;
  }
  if (p.invuln > 0 && Math.floor(globalT * 12) % 2 === 0) ctx.globalAlpha = 0.35;
  let squash = 1, stretch = 1;
  if (p.landT > 0) { squash = 0.8 + 0.2 * (1 - p.landT / 0.13); stretch = 2 - squash; }
  else if (!p.onGround) {
    if (p.vy < -80) { stretch = 0.88; squash = 1.12; }
    else if (p.vy > 220) { stretch = 1.08; squash = 0.94; }
  }
  drawFox(p.x, p.y, p.face, {
    run: Math.abs(p.vx) / MAX_SPD,
    phase: p.animPhase,
    air: !p.onGround,
    squash, stretch,
    t: globalT,
    blink: p.blinkT < 0,
  });
  ctx.globalAlpha = 1;
}

function drawParticles() {
  for (const pt of particles) {
    ctx.globalAlpha = Math.max(0, 1 - pt.t / pt.life);
    ctx.fillStyle = pt.color;
    ctx.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size);
  }
  ctx.globalAlpha = 1;
}

function drawFloats() {
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = 'bold 14px "Trebuchet MS", sans-serif';
  for (const f of floats) {
    ctx.globalAlpha = Math.max(0, 1 - f.t / 0.9);
    ctx.fillStyle = 'rgba(10,20,40,0.7)';
    ctx.fillText(f.txt, f.x + 1, f.y + 1);
    ctx.fillStyle = f.color;
    ctx.fillText(f.txt, f.x, f.y);
  }
  ctx.globalAlpha = 1;
}

// ---------------- Render: HUD & overlays ----------------
function fmtTime(t) {
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return m + ':' + (s < 10 ? '0' : '') + s;
}

function drawHUD() {
  if (state === 'menu') return;
  ctx.save();
  ctx.fillStyle = 'rgba(15,25,45,0.55)';
  rr(12, 10, 372, 42, 10); ctx.fill();
  ctx.textBaseline = 'middle';

  drawCrystalShape(38, 31, 9, 0);
  ctx.textAlign = 'left';
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 19px "Trebuchet MS", sans-serif';
  ctx.fillText('× ' + crystalsGot + ' / ' + totalCrystals, 54, 32);

  heartShape(172, 29, 20, '#ff5b74');
  ctx.fillStyle = '#ffffff';
  ctx.fillText('× ' + Math.max(0, lives), 188, 32);

  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.font = 'bold 15px "Trebuchet MS", sans-serif';
  ctx.fillText('ВРЕМЯ ' + fmtTime(state === 'won' || state === 'winAnim' ? finishTime : time), 248, 32);

  ctx.textAlign = 'right';
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  ctx.font = '12px "Trebuchet MS", sans-serif';
  ctx.fillText('M — звук: ' + (muted ? 'выкл' : 'вкл') + '   ·   P — пауза   ·   R — заново', VIEW_W - 16, 26);
  ctx.restore();
}

function dim(a) {
  ctx.fillStyle = 'rgba(8,12,26,' + a + ')';
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
}

function centerText(txt, y, font, color) {
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(5,8,18,0.65)';
  ctx.fillText(txt, VIEW_W / 2 + 2, y + 2);
  ctx.fillStyle = color;
  ctx.fillText(txt, VIEW_W / 2, y);
}

function drawOverlays() {
  if (state === 'menu') {
    dim(0.62);
    // Hero portrait
    ctx.save();
    ctx.translate(VIEW_W / 2 - 24 * 3.4 / 2, 96);
    ctx.scale(3.4, 3.4);
    drawFox(0, Math.sin(globalT * 2) * 1.2, 1, { t: globalT, run: 0, phase: 0, blink: Math.sin(globalT * 1.3) > 0.96 });
    ctx.restore();
    centerText('РЫЖИК И КРИСТАЛЬНЫЙ ЛЕС', 250, 'bold 42px "Trebuchet MS", sans-serif', '#ffd94a');
    centerText('мини-платформер в духе классики', 290, '18px "Trebuchet MS", sans-serif', 'rgba(220,232,255,0.9)');
    centerText('← → или A / D — бег      ПРОБЕЛ, W или ↑ — прыжок', 340, '16px "Trebuchet MS", sans-serif', 'rgba(200,215,255,0.85)');
    centerText('Прыгай на врагов, бей блоки «?» снизу, собирай кристаллы и доберись до флага!', 368, '14px "Trebuchet MS", sans-serif', 'rgba(200,215,255,0.7)');
    const blink = Math.sin(globalT * 4) > -0.2;
    if (blink) centerText('НАЖМИ ПРОБЕЛ, ЧТОБЫ НАЧАТЬ', 416, 'bold 22px "Trebuchet MS", sans-serif', '#ffffff');
    return;
  }
  if (state === 'pause') {
    dim(0.55);
    centerText('ПАУЗА', 210, 'bold 46px "Trebuchet MS", sans-serif', '#ffffff');
    centerText('P — продолжить      R — заново', 260, '18px "Trebuchet MS", sans-serif', 'rgba(200,215,255,0.85)');
    return;
  }
  if (state === 'dying') {
    ctx.fillStyle = 'rgba(180,20,30,' + (0.25 * Math.sin(Math.min(1, deathT / 0.25) * Math.PI)) + ')';
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    if (deathT > 0.5 && lives > 0) {
      centerText('Ой! Осталось жизней: ' + lives, 200, 'bold 26px "Trebuchet MS", sans-serif', '#ffffff');
    }
    return;
  }
  if (state === 'over') {
    dim(0.7);
    centerText('ИГРА ОКОНЧЕНА', 195, 'bold 48px "Trebuchet MS", sans-serif', '#ff7a7a');
    centerText('Кристаллы: ' + crystalsGot + ' из ' + totalCrystals + '      Время: ' + fmtTime(time), 250, '20px "Trebuchet MS", sans-serif', 'rgba(220,232,255,0.9)');
    centerText('R или ПРОБЕЛ — попробовать ещё раз', 300, 'bold 20px "Trebuchet MS", sans-serif', '#ffffff');
    return;
  }
  if (state === 'won') {
    dim(0.6);
    centerText('ПОБЕДА!', 170, 'bold 56px "Trebuchet MS", sans-serif', '#ffd94a');
    const ratio = totalCrystals ? crystalsGot / totalCrystals : 0;
    const stars = ratio >= 0.999 ? 3 : ratio >= 0.6 ? 2 : 1;
    centerText('★'.repeat(stars) + '☆'.repeat(3 - stars), 222, '34px "Trebuchet MS", sans-serif', '#ffd94a');
    centerText('Кристаллы: ' + crystalsGot + ' из ' + totalCrystals, 268, '22px "Trebuchet MS", sans-serif', 'rgba(220,232,255,0.95)');
    centerText('Время: ' + fmtTime(finishTime) + '      Жизни: ' + lives, 300, '20px "Trebuchet MS", sans-serif', 'rgba(220,232,255,0.85)');
    centerText('R или ПРОБЕЛ — сыграть ещё раз', 352, 'bold 20px "Trebuchet MS", sans-serif', '#ffffff');
  }
}

// ---------------- Render root ----------------
function render() {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  drawBackground();
  ctx.save();
  const shX = shakeT > 0 ? (Math.random() * 2 - 1) * 7 * shakeT : 0;
  const shY = shakeT > 0 ? (Math.random() * 2 - 1) * 5 * shakeT : 0;
  ctx.translate(-Math.round(camX) + shX, shY);
  drawGate();
  drawTiles();
  drawSigns();
  drawFlag();
  drawCrystals();
  drawPickups();
  drawEnemies();
  drawPlayerSprite();
  drawParticles();
  drawFloats();
  ctx.restore();
  drawHUD();
  drawOverlays();
}

// ---------------- Main loop ----------------
let last = 0, acc = 0;
const STEP = 1 / 60;
function frame(ts) {
  requestAnimationFrame(frame);
  const t = ts / 1000;
  let dt = t - last;
  if (!(dt > 0) || dt > 0.25) dt = STEP;
  last = t;
  acc = Math.min(acc + dt, 0.12);
  let n = 0;
  while (acc >= STEP && n < 6) { update(STEP); acc -= STEP; n++; }
  render();
}

// Boot: build the world, show the menu.
resetGame();
state = 'menu';
requestAnimationFrame(frame);

// Debug/testing handle (used by the automated smoke test).
window.__game = {
  get state() { return state; },
  get player() { return player; },
  get lives() { return lives; },
  get crystals() { return crystalsGot; },
  get total() { return totalCrystals; },
  get time() { return time; },
  get enemies() { return enemies; },
  flagX,
};
