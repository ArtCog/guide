# RUN-METRICS — Последняя смена

| Поле | Значение |
|---|---|
| Модель | Claude Opus 4.8 (`claude-opus-4-8`) |
| Тест | 02 — браузерный хоррор от первого лица «Последняя смена» |
| Время задачи | 15m 39s |
| **Реальное время работы над задачей** | **15 мин 39 сек** (`Crunched for 5m 54s` + `Cooked for 9m 45s`) |
| Время API | 33m 27s |
| Wall-время | 10h 4m 2s (длительность открытой сессии; включает простой, не является рабочим временем) |
| Input tokens | 20.4k |
| Output tokens | 66.3k |
| Cache read | 3.3m |
| Cache write | 255.1k |
| Стоимость USD | $5.92 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-opus-4-8\index.html` |
| Короткий вердикт | Рабочий прототип. Raycasting FPS-хоррор: 3 карты → генератор → выход, демон с BFS-погоней, фонарь/батарея, джампскейр, победа/поражение, рестарт. Проверено headless-прогоном реального game.js (без рантайм-ошибок) + flood-fill связности карты; вживую в браузере глазами не смотрелось (расширение было отключено). |

## Детализация по моделям

| Модель | 255.1k | Output | Cache read | Cache write | Стоимость |
|---|---|---|---|---|---|
| claude-opus-4-8 | 34.0k | 134.2k | 6.8M | 829.5k | $15.22 |
| claude-haiku-4-5 | 3.3k | 57 | 0 | 0 | $0.0036 |
| **Итого** | — | — | — | — | **$15.22** |

## Изменения кода
3468 строк добавлено, 60 удалено (index.html, assets/game.js, assets/styles.css, README.md, RUN-METRICS.md).

## Time correction

- Время задачи обновлено по двум финальным сообщениям Claude Code: `5m 54s + 9m 45s = 15m 39s`.
- Старое API-время оставлено справочно и не используется как рабочее время задачи.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $15.22 / 34.0k input / 134.2k output / 6.8m cache read / 829.5k cache write.
- Previous checkpoint: $9.30 / 16.9k input / 68.0k output / 3.5m cache read / 574.4k cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
