/* ============================================================
   ПОСЛЕДНЯЯ СМЕНА — браузерный хоррор от первого лица
   Чистый JS + Canvas (raycasting) + Web Audio. Без зависимостей.
   ============================================================ */
(function () {
"use strict";

/* ---------- Константы рендера ---------- */
const W = 800, H = 450;
const FOV = 66 * Math.PI / 180;
const PLANE = Math.tan(FOV / 2);          // длина проекционной плоскости
const HALF = H / 2;

/* ---------- Освещение ---------- */
const AMBIENT     = 0.12;                  // тьма, но геометрия чуть угадывается
const FLASH_POWER = 3.2;
const FLASH_RANGE = 11;
const FLASH_CONE  = 0.9;                   // ширина конуса (в единицах cameraX)
const FOG_DIST    = 14;

/* ---------- Геймплей ---------- */
const PLAYER_R      = 0.22;
const WALK_SPEED    = 2.55;
const RUN_SPEED     = 3.7;
const TURN_KEY      = 2.4;                 // поворот стрелками (рад/с)
const MOUSE_SENS    = 0.0023;
const CATCH_DIST    = 0.55;

const BAT_MAX       = 100;
const BAT_DRAIN     = 3.6;                 // %/с при включённом фонаре
const BAT_REGEN     = 1.5;                 // %/с восстановление, когда выключен

const DEMON_BASE    = 1.35;                // клеток/с в начале
const DEMON_RAMP    = 0.011;              // ускорение в секунду
const DEMON_MAX     = 2.95;
const DEMON_SLOW    = 0.38;                // множитель скорости под фонарём
const DEMON_SLOWDUR = 0.9;                 // сколько держится замедление

/* ============================================================
   КАРТА УРОВНЯ (морг): центральный коридор + камеры/комнаты
   ============================================================ */
const MW = 25, MH = 17;
let MAP;            // MAP[y][x] : 0 пол, 1 бетон, 2 кафель, 9 дверь-выход
let level;

function buildLevel() {
  const g = [];
  for (let y = 0; y < MH; y++) g.push(new Array(MW).fill(1));

  const carve = (x, y) => { g[y][x] = 0; };
  // центральный коридор (ряды 7..9)
  for (let x = 1; x <= 23; x++) for (let y = 7; y <= 9; y++) carve(x, y);

  // комнаты: {x0,x1} по горизонтали; верх ряды 1..5, низ 11..15
  const cols = [ [1, 6], [8, 11], [13, 17], [19, 23] ];
  const doorX = [3, 9, 15, 21];
  cols.forEach(([x0, x1]) => {
    for (let x = x0; x <= x1; x++) {
      for (let y = 1; y <= 5; y++) carve(x, y);   // верх
      for (let y = 11; y <= 15; y++) carve(x, y); // низ
    }
  });
  // дверные проёмы к коридору
  doorX.forEach(dx => { carve(dx, 6); carve(dx, 10); });

  // визуальные типы стен: часть — «холодный кафель»
  for (let y = 0; y < MH; y++)
    for (let x = 0; x < MW; x++)
      if (g[y][x] === 1 && ((x * 7 + y * 5) % 4 === 0)) g[y][x] = 2;

  // дверь-выход в северной стене стартовой комнаты
  g[0][3] = 9;
  MAP = g;

  level = {
    spawn:  { x: 3.5, y: 4.6, a: Math.PI / 2 },     // смотрит на юг (в коридор)
    exit:   { x: 3.5, y: 1.05, open: false, cell: [3, 0] },
    cards: [
      { x: 15.5, y: 3.4,  taken: false },   // комната C (верх)
      { x: 9.5,  y: 13.4, taken: false },   // комната F (низ)
      { x: 21.5, y: 13.4, taken: false }    // комната H (низ)
    ],
    gen:   { x: 21.5, y: 3.4, on: false },  // комната D (верх-право)
    demonSpawn: { x: 15.5, y: 13.5 }        // комната G (низ) — далеко от игрока
  };
}

const isWall = (x, y) => {
  if (x < 0 || y < 0 || x >= MW || y >= MH) return true;
  const c = MAP[y | 0][x | 0];
  return c === 1 || c === 2 || c === 9;      // 9 (выход) блокирует всегда
};

/* ============================================================
   СОСТОЯНИЕ
   ============================================================ */
let player, demon, state, elapsed, cardsGot;
let flashOn, battery, batteryDead;
const keys = {};
let mouseLocked = false;
let lastToast = 0;

function resetGame() {
  buildLevel();
  player = {
    x: level.spawn.x, y: level.spawn.y, a: level.spawn.a,
    dx: 0, dy: 0, planeX: 0, planeY: 0
  };
  demon = {
    x: level.demonSpawn.x, y: level.demonSpawn.y,
    path: [], repathT: 0, slowT: 0, seenT: 0, wasVisible: false
  };
  updateDir();
  state = "play";
  elapsed = 0;
  cardsGot = 0;
  flashOn = true;
  battery = BAT_MAX;
  batteryDead = false;

  level.cards.forEach(c => c.taken = false);
  level.gen.on = false;
  level.exit.open = false;

  syncHUD();
  hide("startScreen"); hide("loseScreen"); hide("winScreen");
  show("hud");
  clearFx();
  Audio.start();
  Audio.setTension(0);
}

function updateDir() {
  player.dx = Math.cos(player.a);
  player.dy = Math.sin(player.a);
  player.planeX = -player.dy * PLANE;
  player.planeY =  player.dx * PLANE;
}

/* ============================================================
   ВВОД
   ============================================================ */
const scene = document.getElementById("scene");
const fx    = document.getElementById("fx");
const ctx   = scene.getContext("2d");
const fxx   = fx.getContext("2d");

document.addEventListener("keydown", e => {
  keys[e.code] = true;
  if (e.code === "KeyF" && state === "play") toggleFlash();
  if (e.code === "KeyE" && state === "play") interact();
  if (["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(e.code)) e.preventDefault();
});
document.addEventListener("keyup", e => { keys[e.code] = false; });

scene.addEventListener("click", () => {
  if (state === "play" && !mouseLocked) scene.requestPointerLock?.();
});
document.addEventListener("pointerlockchange", () => {
  mouseLocked = document.pointerLockElement === scene;
});
document.addEventListener("mousemove", e => {
  if (mouseLocked && state === "play") {
    player.a += e.movementX * MOUSE_SENS;
    updateDir();
  }
});

function toggleFlash() {
  if (batteryDead) return;
  flashOn = !flashOn;
  Audio.click();
}

/* ============================================================
   ВЗАИМОДЕЙСТВИЕ (E)
   ============================================================ */
function nearestInteractable() {
  let best = null, bd = 1.6 * 1.6;
  const test = (x, y, obj) => {
    const d = (x - player.x) ** 2 + (y - player.y) ** 2;
    if (d < bd) { bd = d; best = obj; }
  };
  level.cards.forEach((c, i) => { if (!c.taken) test(c.x, c.y, { kind: "card", i }); });
  if (cardsGot >= 3 && !level.gen.on) test(level.gen.x, level.gen.y, { kind: "gen" });
  if (level.gen.on) test(level.exit.x, level.exit.y, { kind: "exit" });
  return best;
}

function interact() {
  const t = nearestInteractable();
  if (!t) return;
  if (t.kind === "card") {
    level.cards[t.i].taken = true;
    cardsGot++;
    Audio.pickup();
    toast("КЛЮЧ-КАРТА " + cardsGot + " / 3", false);
    if (cardsGot >= 3) setObjective("Запусти генератор (комната справа-вверху)");
    else setObjective("Найдено карт: " + cardsGot + " / 3");
    syncHUD();
  } else if (t.kind === "gen") {
    level.gen.on = true;
    Audio.generator();
    toast("ГЕНЕРАТОР ЗАПУЩЕН", false);
    setObjective("Открой выход в стартовой комнате");
    syncHUD();
  } else if (t.kind === "exit") {
    level.exit.open = true;
    win();
  }
}

/* ============================================================
   ОБНОВЛЕНИЕ
   ============================================================ */
let lastT = 0;
function loop(t) {
  const dt = Math.min(0.05, (t - lastT) / 1000 || 0);
  lastT = t;
  if (state === "play") { update(dt); render(); }
  requestAnimationFrame(loop);
}

function update(dt) {
  elapsed += dt;

  /* ---- поворот стрелками ---- */
  if (keys.ArrowLeft)  { player.a -= TURN_KEY * dt; updateDir(); }
  if (keys.ArrowRight) { player.a += TURN_KEY * dt; updateDir(); }

  /* ---- движение ---- */
  const run = keys.ShiftLeft || keys.ShiftRight;
  const spd = (run ? RUN_SPEED : WALK_SPEED) * dt;
  let mx = 0, my = 0;
  if (keys.KeyW || keys.ArrowUp)   { mx += player.dx; my += player.dy; }
  if (keys.KeyS || keys.ArrowDown) { mx -= player.dx; my -= player.dy; }
  if (keys.KeyD) { mx -= player.dy; my += player.dx; }   // strafe (плоскость)
  if (keys.KeyA) { mx += player.dy; my -= player.dx; }
  const ml = Math.hypot(mx, my);
  if (ml > 0) { mx = mx / ml * spd; my = my / ml * spd; moveWithCollision(mx, my); }

  /* ---- батарея / фонарь ---- */
  const flashActive = flashOn && !batteryDead;
  if (flashActive) {
    battery -= BAT_DRAIN * dt;
    if (battery <= 0) { battery = 0; batteryDead = true; flashOn = false; Audio.click(); }
  } else if (!flashOn) {
    battery = Math.min(BAT_MAX, battery + BAT_REGEN * dt);
    if (batteryDead && battery > 12) batteryDead = false;   // «остыла»
  }

  /* ---- демон ---- */
  updateDemon(dt, flashActive);

  /* ---- HUD динамика ---- */
  syncBattery();

  /* ---- напряжение / звук по дистанции ---- */
  const dd = Math.hypot(demon.x - player.x, demon.y - player.y);
  const tension = clamp(1 - (dd - CATCH_DIST) / 9, 0, 1);
  Audio.setTension(tension);
  document.getElementById("damage").style.opacity = (tension * 0.5).toFixed(2);

  /* ---- поимка ---- */
  if (dd < CATCH_DIST) lose();
}

function moveWithCollision(mx, my) {
  const nx = player.x + mx, ny = player.y + my;
  // раздельная проверка осей + радиус игрока
  if (!isWall(nx + Math.sign(mx) * PLAYER_R, player.y)) player.x = nx;
  if (!isWall(player.x, ny + Math.sign(my) * PLAYER_R)) player.y = ny;
}

/* ---------- ИИ демона: BFS по сетке к игроку ---------- */
function updateDemon(dt, flashActive) {
  // замедление светом: демон в конусе фонаря + прямая видимость
  if (flashActive && demonInBeam()) demon.slowT = DEMON_SLOWDUR;
  demon.slowT = Math.max(0, demon.slowT - dt);

  let speed = Math.min(DEMON_MAX, DEMON_BASE + elapsed * DEMON_RAMP);
  if (demon.slowT > 0) speed *= DEMON_SLOW;

  // перестройка маршрута
  demon.repathT -= dt;
  if (demon.repathT <= 0) {
    demon.path = bfs(demon.x | 0, demon.y | 0, player.x | 0, player.y | 0);
    demon.repathT = 0.35;
  }

  // шаг к следующей клетке пути
  if (demon.path.length) {
    const cell = demon.path[0];
    const tx = cell[0] + 0.5, ty = cell[1] + 0.5;
    const ddx = tx - demon.x, ddy = ty - demon.y;
    const d = Math.hypot(ddx, ddy);
    if (d < 0.08) { demon.path.shift(); }
    else {
      const s = Math.min(d, speed * dt);
      demon.x += ddx / d * s;
      demon.y += ddy / d * s;
    }
  }
}

function demonInBeam() {
  const rx = demon.x - player.x, ry = demon.y - player.y;
  const dist = Math.hypot(rx, ry);
  if (dist > FLASH_RANGE) return false;
  // угол между направлением взгляда и демоном
  const dot = (rx * player.dx + ry * player.dy) / (dist || 1);
  if (dot < 0.72) return false;                 // ~вне конуса
  return hasLineOfSight(player.x, player.y, demon.x, demon.y);
}

function hasLineOfSight(x0, y0, x1, y1) {
  const dx = x1 - x0, dy = y1 - y0;
  const steps = Math.ceil(Math.hypot(dx, dy) * 8);
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    if (isWall(x0 + dx * t, y0 + dy * t)) return false;
  }
  return true;
}

function bfs(sx, sy, tx, ty) {
  if (sx === tx && sy === ty) return [];
  const q = [[sx, sy]];
  const prev = new Int32Array(MW * MH).fill(-1);
  const seen = new Uint8Array(MW * MH);
  const idx = (x, y) => y * MW + x;
  seen[idx(sx, sy)] = 1;
  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
  let found = false;
  while (q.length) {
    const [cx, cy] = q.shift();
    if (cx === tx && cy === ty) { found = true; break; }
    for (const [ox, oy] of dirs) {
      const nx = cx + ox, ny = cy + oy;
      if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
      if (seen[idx(nx, ny)]) continue;
      if (isWall(nx + 0.5, ny + 0.5)) continue;
      seen[idx(nx, ny)] = 1;
      prev[idx(nx, ny)] = idx(cx, cy);
      q.push([nx, ny]);
    }
  }
  if (!found) return [];
  const path = [];
  let cur = idx(tx, ty);
  while (cur !== idx(sx, sy) && cur !== -1) {
    path.push([cur % MW, (cur / MW) | 0]);
    cur = prev[cur];
  }
  path.reverse();
  return path;
}

/* ============================================================
   РЕНДЕР
   ============================================================ */
const zbuf = new Float32Array(W);

function render() {
  drawSkyFloor();
  drawWalls();
  drawSprites();
  drawFlashlightOverlay();
  updatePrompt();
}

/* ---- потолок и пол (тёмные градиенты) ---- */
function drawSkyFloor() {
  let g = ctx.createLinearGradient(0, 0, 0, HALF);
  g.addColorStop(0, "#0b0c0e");
  g.addColorStop(1, "#050506");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, HALF);

  g = ctx.createLinearGradient(0, HALF, 0, H);
  g.addColorStop(0, "#050505");
  g.addColorStop(1, "#0d0d0f");
  ctx.fillStyle = g;
  ctx.fillRect(0, HALF, W, HALF);
}

/* ---- стены (DDA raycasting) ---- */
function drawWalls() {
  const { x: px, y: py, dx, dy, planeX, planeY } = player;
  for (let x = 0; x < W; x++) {
    const cameraX = 2 * x / W - 1;
    const rdx = dx + planeX * cameraX;
    const rdy = dy + planeY * cameraX;

    let mapX = px | 0, mapY = py | 0;
    const ddx = rdx === 0 ? 1e30 : Math.abs(1 / rdx);
    const ddy = rdy === 0 ? 1e30 : Math.abs(1 / rdy);
    let stepX, stepY, sideX, sideY;
    if (rdx < 0) { stepX = -1; sideX = (px - mapX) * ddx; }
    else         { stepX =  1; sideX = (mapX + 1 - px) * ddx; }
    if (rdy < 0) { stepY = -1; sideY = (py - mapY) * ddy; }
    else         { stepY =  1; sideY = (mapY + 1 - py) * ddy; }

    let side = 0, cell = 0;
    for (let g = 0; g < 64; g++) {
      if (sideX < sideY) { sideX += ddx; mapX += stepX; side = 0; }
      else               { sideY += ddy; mapY += stepY; side = 1; }
      if (mapX < 0 || mapY < 0 || mapX >= MW || mapY >= MH) { cell = 1; break; }
      const c = MAP[mapY][mapX];
      if (c === 1 || c === 2 || c === 9) { cell = c; break; }
    }

    const dist = side === 0 ? (sideX - ddx) : (sideY - ddy);
    zbuf[x] = dist;
    const lh = Math.min(H * 6, H / (dist || 1e-4));
    let y0 = HALF - lh / 2;
    const yh = lh;

    // где именно луч попал в стену (для швов кафеля)
    const wallHit = side === 0 ? (py + dist * rdy) : (px + dist * rdx);
    const seam = wallHit - Math.floor(wallHit);

    // базовый цвет по типу
    let r, gg, b;
    if (cell === 9) {           // дверь-выход
      if (level.gen.on) { r = 30; gg = 120; b = 55; }   // зелёная, под питанием
      else              { r = 70; gg = 30; b = 30; }    // тёмно-красная, заперта
    } else if (cell === 2) {    // холодный кафель
      r = 165; gg = 172; b = 168;
    } else {                    // бетон
      r = 120; gg = 124; b = 132;
    }
    if (side === 1) { r *= 0.68; gg *= 0.68; b *= 0.68; }   // грани темнее

    const shade = computeLight(dist, x);
    let sh = shade;
    // шов между плитками — тонкая тёмная линия
    if (seam < 0.045 || seam > 0.955) sh *= 0.4;

    r = clamp(r * sh, 0, 255) | 0;
    gg = clamp(gg * sh, 0, 255) | 0;
    b = clamp(b * sh, 0, 255) | 0;

    // мерцающий зелёный отблеск двери-выхода
    if (cell === 9 && level.gen.on) gg = clamp(gg + 40 + 30 * Math.sin(elapsed * 6), 0, 255) | 0;

    ctx.fillStyle = "rgb(" + r + "," + gg + "," + b + ")";
    ctx.fillRect(x, y0, 1, yh + 1);
  }
}

/* ---- модель освещения: тьма + конус фонаря + туман ---- */
function computeLight(dist, x) {
  const cameraX = 2 * x / W - 1;
  let b = AMBIENT + (level.gen.on ? 0.05 : 0);
  if (flashOn && !batteryDead && battery > 0) {
    const cone = clamp(1 - Math.abs(cameraX) / FLASH_CONE, 0, 1);
    const df   = clamp(1 - dist / FLASH_RANGE, 0, 1);
    const batF = 0.4 + 0.6 * (battery / BAT_MAX);
    b += cone * df * FLASH_POWER * batF;      // линейный конус — шире и ярче
  }
  const fog = clamp(1.2 - dist / FOG_DIST, 0, 1);
  return clamp(b, 0, 1.7) * fog;
}

/* ---- спрайты: карты, генератор, демон (billboard + z-буфер) ---- */
function drawSprites() {
  const list = [];
  level.cards.forEach(c => { if (!c.taken)
    list.push({ x: c.x, y: c.y, kind: "card" }); });
  if (!level.gen.on || true)
    list.push({ x: level.gen.x, y: level.gen.y, kind: "gen" });
  list.push({ x: demon.x, y: demon.y, kind: "demon" });

  const { x: px, y: py, dx, dy, planeX, planeY } = player;
  const invDet = 1 / (planeX * dy - dx * planeY);

  // глубина + сортировка (дальние первыми)
  list.forEach(s => {
    const sx = s.x - px, sy = s.y - py;
    s.tX = invDet * (dy * sx - dx * sy);
    s.tY = invDet * (-planeY * sx + planeX * sy);
  });
  list.sort((a, b) => b.tY - a.tY);

  list.forEach(s => {
    if (s.tY <= 0.05) return;
    const screenX = (W / 2) * (1 + s.tX / s.tY);

    if (s.kind === "demon") drawDemon(s, screenX);
    else drawPickup(s, screenX);
  });
}

function drawPickup(s, screenX) {
  const kind = s.kind;
  const scaleY = kind === "gen" ? 0.95 : 0.42;
  const scaleX = kind === "gen" ? 0.85 : 0.30;
  const hgt = (H / s.tY) * scaleY;
  const wid = (H / s.tY) * scaleX;
  const floorY = HALF + (H / s.tY) * 0.5;
  const topY = floorY - hgt;
  const x0 = Math.floor(screenX - wid / 2);
  const x1 = Math.ceil(screenX + wid / 2);

  const light = clamp(computeLight(s.tY, Math.round(screenX)) + 0.25, 0.12, 1);

  for (let x = x0; x < x1; x++) {
    if (x < 0 || x >= W) continue;
    if (s.tY >= zbuf[x]) continue;   // за стеной
    let col;
    if (kind === "card") {
      col = "rgb(" + (int(230*light)) + "," + int(196*light) + "," + int(60*light) + ")";
    } else {
      // генератор: тёмный корпус + лампа
      const on = level.gen.on;
      const cr = int((on ? 60 : 80) * light), cg = int(66 * light), cb = int(70 * light);
      col = "rgb(" + cr + "," + cg + "," + cb + ")";
    }
    ctx.fillStyle = col;
    ctx.fillRect(x, topY, 1, hgt);
  }

  // светящийся ореол — чтобы предметы можно было найти в темноте
  const glow = ctx.createRadialGradient(screenX, topY + hgt * 0.4, 0, screenX, topY + hgt * 0.4, wid * 1.6);
  if (kind === "card") { glow.addColorStop(0, "rgba(233,201,74,.55)"); }
  else { glow.addColorStop(0, level.gen.on ? "rgba(60,200,90,.6)" : "rgba(200,50,40,.55)"); }
  glow.addColorStop(1, "rgba(0,0,0,0)");
  const prev = ctx.globalCompositeOperation;
  ctx.globalCompositeOperation = "lighter";
  ctx.fillStyle = glow;
  // рисуем ореол только если не полностью перекрыт
  if (s.tY < zbuf[clamp(Math.round(screenX),0,W-1)]) {
    ctx.beginPath();
    ctx.arc(screenX, topY + hgt * 0.4, wid * 1.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalCompositeOperation = prev;
}

/* ---- демон: тёмный силуэт, альфа зависит от света; глаза всегда светятся ---- */
function drawDemon(s, screenX) {
  const scaleY = 1.95, scaleX = 0.95;
  const hgt = (H / s.tY) * scaleY;
  const wid = (H / s.tY) * scaleX;
  const floorY = HALF + (H / s.tY) * 0.5;
  const topY = floorY - hgt;
  const cx = screenX;

  const centerCol = clamp(Math.round(screenX), 0, W - 1);
  const visible = s.tY < zbuf[centerCol];
  const light = computeLight(s.tY, centerCol);
  // тело: в темноте почти невидимо, фонарь «проявляет» его
  const bodyAlpha = clamp(0.12 + light * 1.4, 0.12, 1);

  // силуэт по вертикальным полосам с проверкой z-буфера
  for (let x = Math.floor(cx - wid / 2); x < Math.ceil(cx + wid / 2); x++) {
    if (x < 0 || x >= W) continue;
    if (s.tY >= zbuf[x]) continue;
    const u = (x - (cx - wid / 2)) / wid;      // 0..1 по ширине
    // профиль тела: узкие плечи -> ноги, «капюшон» сверху
    const edge = Math.abs(u - 0.5) * 2;         // 0 центр .. 1 край
    if (edge > 0.85) continue;                   // обрезаем в силуэт
    const shade = (1 - edge * 0.5);
    const r = int(24 * shade * (0.5 + light)), g = int(10 * shade), b = int(14 * shade * (0.5 + light));
    ctx.globalAlpha = bodyAlpha;
    ctx.fillStyle = "rgb(" + r + "," + g + "," + b + ")";
    // голова уже, чем тело
    let ty = topY, th = hgt;
    if (edge > 0.55) { ty = topY + hgt * 0.28; th = hgt * 0.72; }   // плечи ниже головы
    ctx.fillRect(x, ty, 1, th);
  }
  ctx.globalAlpha = 1;

  if (!visible) return;

  // бледное искажённое лицо (виден при свете)
  const faceY = topY + hgt * 0.11;
  const faceH = hgt * 0.16;
  const faceW = wid * 0.42;
  ctx.globalAlpha = clamp(light * 1.6, 0, 0.9);
  ctx.fillStyle = "rgb(150,150,142)";
  ctx.beginPath();
  ctx.ellipse(cx, faceY, faceW / 2, faceH, 0, 0, Math.PI * 2);
  ctx.fill();
  // рот-провал
  ctx.fillStyle = "rgba(10,0,0,.9)";
  ctx.beginPath();
  ctx.ellipse(cx, faceY + faceH * 0.55, faceW * 0.16, faceH * 0.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  // СВЕТЯЩИЕСЯ ГЛАЗА — всегда, даже в полной тьме
  const eyeY = faceY - faceH * 0.15;
  const eyeDx = faceW * 0.28;
  const eyeR = Math.max(1.5, wid * 0.05);
  const pulse = 0.7 + 0.3 * Math.sin(elapsed * 5);
  const prev = ctx.globalCompositeOperation;
  ctx.globalCompositeOperation = "lighter";
  [-1, 1].forEach(sgn => {
    const ex = cx + sgn * eyeDx;
    const gr = ctx.createRadialGradient(ex, eyeY, 0, ex, eyeY, eyeR * 3);
    gr.addColorStop(0, "rgba(255,240,220," + pulse + ")");
    gr.addColorStop(0.3, "rgba(230,40,20,.9)");
    gr.addColorStop(1, "rgba(120,0,0,0)");
    ctx.fillStyle = gr;
    ctx.beginPath();
    ctx.arc(ex, eyeY, eyeR * 3, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalCompositeOperation = prev;

  // стингер при внезапном появлении в конусе
  if (visible && light > 0.35) {
    if (!demon.wasVisible) { Audio.stinger(); demon.wasVisible = true; }
  } else {
    demon.wasVisible = false;
  }
}

/* ---- мягкий световой ореол фонаря поверх сцены ---- */
function drawFlashlightOverlay() {
  if (!(flashOn && !batteryDead && battery > 0)) return;
  const cx = W / 2, cy = H * 0.56;
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, H * 0.9);
  const a = 0.22 * (battery / BAT_MAX);
  g.addColorStop(0, "rgba(200,205,180," + a + ")");
  g.addColorStop(0.55, "rgba(120,120,110," + (a * 0.4).toFixed(3) + ")");
  g.addColorStop(1, "rgba(0,0,0,0)");
  const prev = ctx.globalCompositeOperation;
  ctx.globalCompositeOperation = "lighter";
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = prev;
}

/* ============================================================
   HUD
   ============================================================ */
function updatePrompt() {
  const p = document.getElementById("prompt");
  const t = nearestInteractable();
  if (!t) { p.classList.add("hidden"); return; }
  let msg;
  if (t.kind === "card") msg = "<b>[E]</b> Взять ключ-карту";
  else if (t.kind === "gen") msg = "<b>[E]</b> Запустить генератор";
  else msg = "<b>[E]</b> Открыть выход";
  p.innerHTML = msg;
  p.classList.remove("hidden");
}

function syncHUD() {
  document.querySelectorAll(".cardslot").forEach((el, i) => {
    el.classList.toggle("got", level.cards[i].taken);
  });
  const ps = document.getElementById("power");
  const pst = document.getElementById("powerState");
  if (level.gen.on) { ps.classList.add("on"); pst.textContent = "АКТИВЕН"; }
  else { ps.classList.remove("on"); pst.textContent = "ОТКЛЮЧЁН"; }
}

function syncBattery() {
  const fill = document.getElementById("batfill");
  const pct  = document.getElementById("batpct");
  fill.style.width = battery.toFixed(0) + "%";
  fill.classList.toggle("low", battery < 25 || batteryDead);
  pct.textContent = batteryDead ? "РАЗРЯД" : (battery | 0) + "%";
}

function toast(text, danger) {
  const el = document.getElementById("toast");
  el.textContent = text;
  el.classList.toggle("danger", !!danger);
  el.classList.add("show");
  const id = ++lastToast;
  setTimeout(() => { if (id === lastToast) el.classList.remove("show"); }, 2200);
}
function setObjective(t) { document.getElementById("objective").textContent = t; }

/* ============================================================
   ПОБЕДА / ПОРАЖЕНИЕ
   ============================================================ */
function win() {
  state = "win";
  Audio.stopTension();
  document.exitPointerLock?.();
  hide("hud");
  document.getElementById("winMsg").textContent =
    "Холодный воздух улицы. Ты выжил в эту смену. Время: " + elapsed.toFixed(0) + " сек.";
  show("winScreen");
}

function lose() {
  if (state !== "play") return;
  state = "lose";
  document.exitPointerLock?.();
  Audio.jumpscare();
  jumpscareSequence();
}

/* полноэкранный испуг: лицо демона -> тряска -> экран поражения */
function jumpscareSequence() {
  const start = performance.now();
  const dur = 1300;
  function frame(t) {
    const k = (t - start) / dur;
    if (k >= 1) {
      clearFx();
      hide("hud");
      const msgs = [
        "Твоя смена никогда не закончится.",
        "Ты стал одним из них.",
        "Никто не придёт утром.",
        "Холод забрал тебя."
      ];
      document.getElementById("loseMsg").textContent = msgs[(Math.random() * msgs.length) | 0];
      show("loseScreen");
      return;
    }
    drawJumpFace(k);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

function drawJumpFace(k) {
  const shake = (1 - k) * 26;
  const ox = (Math.random() - 0.5) * shake;
  const oy = (Math.random() - 0.5) * shake;
  fxx.save();
  fxx.clearRect(0, 0, W, H);
  // красная вспышка + пульс
  fxx.fillStyle = "rgba(" + (60 + 120 * (1 - k)) + ",0,0," + (0.6 + 0.4 * Math.sin(k * 40)) + ")";
  fxx.fillRect(0, 0, W, H);
  fxx.translate(W / 2 + ox, H / 2 + oy);
  const s = 1 + k * 1.4;               // лицо стремительно приближается
  fxx.scale(s, s);

  // голова
  fxx.fillStyle = "#c9c9bd";
  fxx.beginPath();
  fxx.ellipse(0, 0, 150, 200, 0, 0, Math.PI * 2);
  fxx.fill();
  // впадины-щёки
  fxx.fillStyle = "rgba(20,10,10,.5)";
  fxx.beginPath(); fxx.ellipse(-80, 40, 50, 90, 0.3, 0, Math.PI*2); fxx.fill();
  fxx.beginPath(); fxx.ellipse( 80, 40, 50, 90,-0.3, 0, Math.PI*2); fxx.fill();

  // глаза-провалы + горящие зрачки
  [-58, 58].forEach(ex => {
    fxx.fillStyle = "#000";
    fxx.beginPath(); fxx.ellipse(ex, -40, 42, 54, 0, 0, Math.PI * 2); fxx.fill();
    const gr = fxx.createRadialGradient(ex, -40, 0, ex, -40, 40);
    gr.addColorStop(0, "rgba(255,240,220,1)");
    gr.addColorStop(0.35, "rgba(240,40,20,.95)");
    gr.addColorStop(1, "rgba(120,0,0,0)");
    fxx.fillStyle = gr;
    fxx.beginPath(); fxx.arc(ex, -40, 40, 0, Math.PI * 2); fxx.fill();
  });

  // разинутый рот
  fxx.fillStyle = "#050000";
  fxx.beginPath(); fxx.ellipse(0, 110, 55, 85, 0, 0, Math.PI * 2); fxx.fill();
  fxx.strokeStyle = "rgba(120,110,100,.6)";
  fxx.lineWidth = 3;
  for (let i = -3; i <= 3; i++) {          // зубы
    fxx.beginPath();
    fxx.moveTo(i * 15, 30);
    fxx.lineTo(i * 15, 50 + Math.abs(i) * 4);
    fxx.stroke();
  }
  // трещины/вены
  fxx.strokeStyle = "rgba(90,0,0,.7)";
  fxx.lineWidth = 2;
  for (let i = 0; i < 8; i++) {
    fxx.beginPath();
    const a = i / 8 * Math.PI * 2;
    fxx.moveTo(Math.cos(a) * 60, Math.sin(a) * 90 - 30);
    fxx.lineTo(Math.cos(a) * 150, Math.sin(a) * 200 - 30);
    fxx.stroke();
  }
  fxx.restore();
}

function clearFx() { fxx.clearRect(0, 0, W, H); }

/* ============================================================
   ЗВУК (Web Audio, полностью процедурный)
   ============================================================ */
const Audio = (function () {
  let ac = null, master = null;
  let droneG = null, noiseG = null;
  let hbTimer = null, tension = 0, started = false;

  function ensure() {
    if (ac) return;
    try {
      ac = new (window.AudioContext || window.webkitAudioContext)();
      master = ac.createGain(); master.gain.value = 0.9; master.connect(ac.destination);
    } catch (e) { ac = null; }
  }

  function start() {
    ensure(); if (!ac) return;
    if (ac.state === "suspended") ac.resume();
    if (started) return; started = true;

    // низкий дрон
    droneG = ac.createGain(); droneG.gain.value = 0.06; droneG.connect(master);
    [52, 55.5].forEach(f => {
      const o = ac.createOscillator(); o.type = "sine"; o.frequency.value = f;
      const g = ac.createGain(); g.gain.value = 0.5; o.connect(g); g.connect(droneG); o.start();
    });
    // фильтрованный шум (вентиляция)
    const buf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const src = ac.createBufferSource(); src.buffer = buf; src.loop = true;
    const lp = ac.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 320;
    noiseG = ac.createGain(); noiseG.gain.value = 0.03;
    src.connect(lp); lp.connect(noiseG); noiseG.connect(master); src.start();

    scheduleHeart();
  }

  function scheduleHeart() {
    clearTimeout(hbTimer);
    const beat = () => {
      if (!ac || !started) return;
      if (tension > 0.12) { thump(); setTimeout(thump, 150 - tension * 40); }
      const interval = 1200 - tension * 800;   // чем ближе демон — тем быстрее
      hbTimer = setTimeout(beat, Math.max(300, interval));
    };
    beat();
  }
  function thump() {
    if (!ac) return;
    const o = ac.createOscillator(); o.type = "sine";
    const g = ac.createGain();
    o.frequency.setValueAtTime(65, ac.currentTime);
    o.frequency.exponentialRampToValueAtTime(35, ac.currentTime + 0.16);
    g.gain.setValueAtTime(0.0001, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.35 * (0.4 + tension), ac.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 0.22);
    o.connect(g); g.connect(master); o.start(); o.stop(ac.currentTime + 0.24);
  }

  function setTension(t) {
    tension = clamp(t, 0, 1);
    if (droneG) droneG.gain.value = 0.06 + tension * 0.10;
    if (noiseG) noiseG.gain.value = 0.03 + tension * 0.05;
  }
  function stopTension() { tension = 0; if (droneG) droneG.gain.value = 0.04; }

  function blip(freq, type, dur, vol) {
    if (!ac) return;
    const o = ac.createOscillator(); o.type = type || "square";
    const g = ac.createGain();
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(vol || 0.2, ac.currentTime + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + (dur || 0.15));
    o.connect(g); g.connect(master); o.start(); o.stop(ac.currentTime + (dur || 0.15) + 0.02);
  }
  const click   = () => blip(180, "square", 0.05, 0.12);
  const pickup  = () => { blip(660, "triangle", 0.1, 0.2); setTimeout(() => blip(990, "triangle", 0.14, 0.2), 90); };
  const generator = () => {
    blip(120, "sawtooth", 0.4, 0.25);
    if (!ac) return;
    const o = ac.createOscillator(); o.type = "sawtooth"; o.frequency.value = 58;
    const g = ac.createGain(); g.gain.value = 0.04;
    o.connect(g); g.connect(master); o.start();     // ровный гул после запуска
  };

  function stinger() {
    if (!ac) return;
    const o = ac.createOscillator(); o.type = "sawtooth";
    const g = ac.createGain();
    o.frequency.setValueAtTime(880, ac.currentTime);
    o.frequency.exponentialRampToValueAtTime(180, ac.currentTime + 0.3);
    g.gain.setValueAtTime(0.28, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 0.35);
    o.connect(g); g.connect(master); o.start(); o.stop(ac.currentTime + 0.36);
  }

  function jumpscare() {
    if (!ac) { ensure(); }
    if (!ac) return;
    stopTension();
    // диссонансный удар
    [110, 116, 220, 233].forEach(f => {
      const o = ac.createOscillator(); o.type = "sawtooth"; o.frequency.value = f;
      const g = ac.createGain();
      g.gain.setValueAtTime(0.3, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 1.2);
      o.connect(g); g.connect(master); o.start(); o.stop(ac.currentTime + 1.25);
    });
    // всплеск шума
    const buf = ac.createBuffer(1, ac.sampleRate * 0.6, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    const src = ac.createBufferSource(); src.buffer = buf;
    const g = ac.createGain(); g.gain.value = 0.5;
    src.connect(g); g.connect(master); src.start();
  }

  return { start, setTension, stopTension, click, pickup, generator, stinger, jumpscare };
})();

/* ============================================================
   УТИЛИТЫ / КНОПКИ
   ============================================================ */
function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
function int(v) { return clamp(v, 0, 255) | 0; }
function show(id) { document.getElementById(id).classList.remove("hidden"); }
function hide(id) { document.getElementById(id).classList.add("hidden"); }

document.getElementById("startBtn").addEventListener("click", () => {
  resetGame();
  scene.requestPointerLock?.();
});
document.getElementById("loseRestart").addEventListener("click", () => {
  resetGame(); scene.requestPointerLock?.();
});
document.getElementById("winRestart").addEventListener("click", () => {
  resetGame(); scene.requestPointerLock?.();
});

// первичная сборка (для фонового рендера под стартовым экраном)
buildLevel();
player = { x: level.spawn.x, y: level.spawn.y, a: level.spawn.a };
updateDir();
state = "menu"; elapsed = 0; cardsGot = 0; flashOn = true; battery = BAT_MAX; batteryDead = false;
demon = { x: level.demonSpawn.x, y: level.demonSpawn.y, path: [], repathT: 0, slowT: 0, wasVisible: false };
// лёгкий фоновый рендер под меню
(function bg(){ if(state==="menu"){ drawSkyFloor(); drawWalls(); drawFlashlightOverlay(); requestAnimationFrame(bg);} })();

requestAnimationFrame(loop);
})();
