// ===== Данные каталога — единый источник для каталога и корзины =====
// Все цены в долларах США. Используются для реального расчёта корзины.

const CATALOG = [
  {
    id: "luna-more",
    title: "Осколок Лунного моря",
    origin: "Луна",
    originShort: "Луна",
    type: "Каменный фрагмент",
    price: 18400,
    desc: "Пористый камень с мягким серым блеском, похожий на кусочек древнего лунного ландшафта.",
    group: "moon", // фильтр
    visual: "luna"
  },
  {
    id: "mars-granat",
    title: "Гранат Долины Маринер",
    origin: "Марс",
    originShort: "Марс",
    type: "Красный гранат",
    price: 12900,
    desc: "Глубокий красный камень с сухим марсианским оттенком.",
    group: "planet",
    visual: "mars"
  },
  {
    id: "europa-opal",
    title: "Ледяной опал Европы",
    origin: "Европа, спутник Юпитера",
    originShort: "Европа",
    type: "Светлый опал",
    price: 22100,
    desc: "Полупрозрачный камень с холодным голубым свечением.",
    group: "moon",
    visual: "europa"
  },
  {
    id: "titan-yantar",
    title: "Янтарное ядро Титана",
    origin: "Титан, спутник Сатурна",
    originShort: "Титан",
    type: "Янтарный минерал",
    price: 17600,
    desc: "Тёплый медовый камень, будто сохранённый в густой атмосфере Титана.",
    group: "moon",
    visual: "titan"
  },
  {
    id: "ceres-sol",
    title: "Соляной кристалл Цереры",
    origin: "Церера",
    originShort: "Церера",
    type: "Светлый кристалл",
    price: 9400,
    desc: "Сухой светлый кристалл с тонкими белыми прожилками.",
    group: "asteroid",
    visual: "ceres"
  },
  {
    id: "psyche-iron",
    title: "Железное сердце Психеи",
    origin: "Психея",
    originShort: "Психея",
    type: "Металлический фрагмент",
    price: 26500,
    desc: "Тяжёлый блестящий образец с никелево-железным оттенком.",
    group: "asteroid",
    visual: "psyche"
  },
  {
    id: "io-sera",
    title: "Серная призма Ио",
    origin: "Ио, спутник Юпитера",
    originShort: "Ио",
    type: "Жёлто-оранжевый кристалл",
    price: 11300,
    desc: "Яркий камень с вулканическим характером.",
    group: "moon",
    visual: "io"
  },
  {
    id: "enceladus-zhemchug",
    title: "Жемчужина Энцелада",
    origin: "Энцелад, спутник Сатурна",
    originShort: "Энцелад",
    type: "Перламутровая сфера",
    price: 19800,
    desc: "Холодный жемчужный образец, вдохновлённый ледяными гейзерами.",
    group: "moon",
    visual: "enceladus"
  }
];

// Форматирование цены: 18400 -> "18 400 $"
function formatPrice(value) {
  return value.toLocaleString("ru-RU").replace(/,/g, " ") + " $";
}

// Найти товар по id
function findItem(id) {
  return CATALOG.find((i) => i.id === id);
}

// Экспорт в window для использования в других скриптах
window.CATALOG = CATALOG;
window.formatPrice = formatPrice;
window.findItem = findItem;
