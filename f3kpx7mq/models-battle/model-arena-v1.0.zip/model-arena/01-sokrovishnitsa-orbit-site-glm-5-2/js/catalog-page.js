// ===== Рендер каталога и фильтр по происхождению =====

(function () {
  const grid = document.getElementById("catalog-grid");
  if (!grid) return;

  const countEl = document.getElementById("catalog-count");

  // Группы фильтра
  const FILTERS = [
    { id: "all", label: "Все образцы" },
    { id: "moon", label: "Спутники планет" },
    { id: "planet", label: "Планеты" },
    { id: "asteroid", label: "Астероиды" }
  ];

  let activeFilter = "all";

  function render() {
    const items = CATALOG.filter(
      (i) => activeFilter === "all" || i.group === activeFilter
    );

    grid.innerHTML = items
      .map(
        (i) => `
      <article class="card orig-${i.visual}" data-group="${i.group}">
        <div class="card__stage">
          <div class="stage-bg"></div>
          <div class="card__badge">${i.originShort}</div>
          <div class="stone"></div>
        </div>
        <div class="card__body">
          <div class="card__origin">${i.origin}</div>
          <h3 class="card__title">${i.title}</h3>
          <div class="card__type">${i.type}</div>
          <p class="card__desc">${i.desc}</p>
          <div class="card__footer">
            <div class="card__price"><small>Цена</small>${formatPrice(i.price)}</div>
            <button type="button" class="btn btn--ghost btn--small card__add" data-add="${i.id}" data-label="Добавить в заявку">Добавить в заявку</button>
          </div>
        </div>
      </article>`
      )
      .join("");

    if (countEl) {
      const forms = {
        one: "образец",
        few: "образца",
        many: "образцов"
      };
      const n = items.length;
      const form =
        n % 10 === 1 && n % 100 !== 11
          ? forms.one
          : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)
          ? forms.few
          : forms.many;
      countEl.textContent = `${n} ${form}`;
    }
  }

  // Делегирование кликов по кнопкам «добавить»
  grid.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-add]");
    if (btn) addToCart(btn.dataset.add);
  });

  // Делегирование фильтра
  const filterRoot = document.getElementById("filter-root");
  if (filterRoot) {
    filterRoot.innerHTML = FILTERS.map(
      (f) =>
        `<button class="filter__btn${f.id === activeFilter ? " is-active" : ""}" data-filter="${f.id}">${f.label}</button>`
    ).join("");
    filterRoot.addEventListener("click", (e) => {
      const b = e.target.closest("[data-filter]");
      if (!b) return;
      activeFilter = b.dataset.filter;
      filterRoot.querySelectorAll(".filter__btn").forEach((x) =>
        x.classList.toggle("is-active", x.dataset.filter === activeFilter)
      );
      render();
    });
  }

  render();
})();
