// ===== Корзина: хранение, расчёт, рендер, добавление =====
// Состояние хранится в localStorage: { id: quantity }

const STORAGE_KEY = "so_cart_v1";

function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function saveCart(cart) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
  } catch (e) {
    /* игнорируем */
  }
}

let cart = loadCart();

// Количество позиций (для бейджа в шапке)
function cartCount() {
  return Object.values(cart).reduce((s, q) => s + q, 0);
}

// Количество уникальных наименований
function cartKinds() {
  return Object.keys(cart).length;
}

// Сумма по позиции
function lineSum(item, qty) {
  return item.price * qty;
}

// Общий итог
function cartTotal() {
  let total = 0;
  for (const id in cart) {
    const item = findItem(id);
    if (item) total += item.price * cart[id];
  }
  return total;
}

// Добавить товар
function addToCart(id, qty = 1) {
  cart[id] = (cart[id] || 0) + qty;
  saveCart(cart);
  renderHeaderCount();
  renderCartPage();
  showToast("Добавлено в заявку: " + (findItem(id) ? findItem(id).title : ""));
  markAddedButton(id);
}

// Изменить количество (минимум 1)
function setQty(id, qty) {
  qty = Math.max(1, parseInt(qty, 10) || 1);
  cart[id] = qty;
  saveCart(cart);
  renderHeaderCount();
  renderCartPage();
}

// Удалить
function removeFromCart(id) {
  delete cart[id];
  saveCart(cart);
  renderHeaderCount();
  renderCartPage();
}

// Очистить
function clearCart() {
  cart = {};
  saveCart(cart);
  renderHeaderCount();
  renderCartPage();
}

// ===== Рендер бейджа в шапке =====
function renderHeaderCount() {
  document.querySelectorAll("[data-cart-count]").forEach((el) => {
    const n = cartCount();
    el.textContent = n;
    el.classList.toggle("is-zero", n === 0);
  });
}

// ===== Рендер страницы корзины (если есть контейнер) =====
function renderCartPage() {
  const root = document.getElementById("cart-root");
  if (!root) return;

  const ids = Object.keys(cart);

  if (ids.length === 0) {
    root.innerHTML = `
      <div class="cart-empty">
        <p>Заявка пуста. Выберите образец в каталоге — он появится здесь.</p>
        <a class="btn btn--ghost" href="catalog.html">Перейти в каталог</a>
      </div>`;
    return;
  }

  let html = '<div class="cart-items">';
  for (const id of ids) {
    const item = findItem(id);
    if (!item) continue;
    const qty = cart[id];
    const sum = lineSum(item, qty);
    html += `
      <div class="cart-row" data-id="${id}">
        <div class="cart-row__stone stone-obj stone-obj--${item.visual}"></div>
        <div class="cart-row__info">
          <h4>${item.title}</h4>
          <div class="cart-row__origin">${item.origin} · ${item.type}</div>
          <div class="cart-row__line">
            <span class="price">${formatPrice(item.price)} за образец</span>
            <span class="qty" role="group" aria-label="Количество">
              <button type="button" data-act="dec" aria-label="Уменьшить количество">−</button>
              <span data-qty>${qty}</span>
              <button type="button" data-act="inc" aria-label="Увеличить количество">+</button>
            </span>
            <button type="button" class="cart-row__remove" data-act="remove">Удалить</button>
          </div>
        </div>
        <div class="cart-row__right">
          <div class="cart-row__sum">${formatPrice(sum)}</div>
          <div class="cart-row__unit">${qty} × ${formatPrice(item.price)}</div>
        </div>
      </div>`;
  }
  html += "</div>";

  // Сводка
  const kinds = cartKinds();
  const total = cartTotal();
  html += `
    <aside class="cart-summary">
      <h3>Итог заявки</h3>
      <p class="cart-summary__sub">Запрос частной покупки. Оплата и доставка согласуются отдельно.</p>
      <div class="summary-line"><span>Уникальных образцов</span><span>${kinds}</span></div>
      <div class="summary-line"><span>Всего позиций</span><span>${cartCount()}</span></div>
      <div class="summary-total"><span>Сумма</span><strong>${formatPrice(total)}</strong></div>
      <button type="button" class="btn btn--gold btn--block" data-act="checkout">Запросить частную покупку</button>
      <button type="button" class="btn btn--ghost btn--block" style="margin-top:10px" data-act="clear">Очистить заявку</button>
      <p class="cart-summary__note">Это предварительная заявка, а не онлайн-оплата. Менеджер коллекции свяжется с вами для подтверждения происхождения, условий хранения и доставки.</p>
    </aside>`;

  root.innerHTML = html;
}

// Делегирование событий в корзине
document.addEventListener("click", (e) => {
  const row = e.target.closest(".cart-row");
  if (row) {
    const id = row.dataset.id;
    const act = e.target.dataset.act;
    if (act === "inc") setQty(id, (cart[id] || 1) + 1);
    else if (act === "dec") {
      const q = (cart[id] || 1) - 1;
      if (q < 1) removeFromCart(id);
      else setQty(id, q);
    } else if (act === "remove") removeFromCart(id);
  }
  // Глобальные кнопки корзины (вне строк)
  if (e.target.dataset && e.target.dataset.act === "checkout") openCheckoutModal();
  if (e.target.dataset && e.target.dataset.act === "clear") clearCart();
});

// ===== Кнопка «добавлено» на карточках =====
function markAddedButton(id) {
  document.querySelectorAll(`[data-add="${id}"]`).forEach((btn) => {
    const orig = btn.dataset.label || "Добавить в заявку";
    btn.textContent = "✓ В заявке";
    btn.classList.add("is-added");
    setTimeout(() => {
      btn.textContent = orig;
      btn.classList.remove("is-added");
    }, 1600);
  });
}

// ===== Тост =====
let toastTimer = null;
function showToast(msg) {
  let toast = document.getElementById("toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add("is-show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("is-show"), 2200);
}

// ===== Модальное окно запроса покупки =====
function openCheckoutModal() {
  let overlay = document.getElementById("checkout-modal");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "checkout-modal";
    overlay.className = "modal-overlay";
    overlay.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" aria-label="Запрос частной покупки">
        <div class="modal__form">
          <h3>Запрос частной покупки</h3>
          <p>Оставьте контакты — менеджер коллекции свяжется с вами для подтверждения образцов, происхождения и условий доставки.</p>
          <div class="modal__field">
            <label for="co-name">Имя</label>
            <input id="co-name" type="text" placeholder="Как к вам обращаться" autocomplete="name">
          </div>
          <div class="modal__field">
            <label for="co-email">Электронная почта</label>
            <input id="co-email" type="email" placeholder="name@example.com" autocomplete="email">
          </div>
          <div class="modal__field">
            <label for="co-phone">Телефон (необязательно)</label>
            <input id="co-phone" type="tel" placeholder="+7 ___ ___-__-__" autocomplete="tel">
          </div>
          <div class="modal__field">
            <label for="co-note">Комментарий</label>
            <textarea id="co-note" placeholder="Назначение коллекции, пожелания по доставке"></textarea>
          </div>
          <div class="modal__actions">
            <button type="button" class="btn btn--ghost" data-act="modal-close">Отмена</button>
            <button type="button" class="btn btn--gold" data-act="modal-submit">Отправить заявку</button>
          </div>
        </div>
        <div class="modal__success">
          <div class="mark">✓</div>
          <h3>Заявка отправлена</h3>
          <p>Сумма: <strong data-success-sum></strong>. Мы свяжемся в течение одного рабочего дня.</p>
          <div class="modal__actions" style="justify-content:center;margin-top:20px">
            <button type="button" class="btn btn--gold" data-act="modal-close">Закрыть</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay || e.target.dataset.act === "modal-close") closeModal();
      if (e.target.dataset.act === "modal-submit") submitCheckout();
    });
  }

  const sumEl = overlay.querySelector("[data-success-sum]");
  if (sumEl) sumEl.textContent = formatPrice(cartTotal());

  overlay.classList.add("is-open");
  overlay.querySelector(".modal__form").style.display = "";
  overlay.querySelector(".modal__success").classList.remove("is-show");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  const overlay = document.getElementById("checkout-modal");
  if (overlay) overlay.classList.remove("is-open");
  document.body.style.overflow = "";
}

function submitCheckout() {
  const overlay = document.getElementById("checkout-modal");
  if (!overlay) return;
  // Простая валидация
  const name = overlay.querySelector("#co-name").value.trim();
  const email = overlay.querySelector("#co-email").value.trim();
  if (!name || !email || !email.includes("@")) {
    showToast("Укажите имя и корректную почту");
    return;
  }
  // Здесь в реальном проекте — отправка на сервер.
  // Для локального сайта: показываем подтверждение и очищаем заявку.
  overlay.querySelector(".modal__form").style.display = "none";
  overlay.querySelector(".modal__success").classList.add("is-show");
  clearCart();
}

// Стартовая инициализация
document.addEventListener("DOMContentLoaded", () => {
  renderHeaderCount();
  renderCartPage();
});
