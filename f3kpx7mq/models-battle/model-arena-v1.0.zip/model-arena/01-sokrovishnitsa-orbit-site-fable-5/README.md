# 01 — Сокровищница Орбит — Fable 5

Результат первого теста: многостраничный сайт магазина редких камней Солнечной системы.

Модель: Claude Fable 5

Открыть:

```text
C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-fable-5\index.html
```

Метрики прогона:

```text
RUN-METRICS.md
```
