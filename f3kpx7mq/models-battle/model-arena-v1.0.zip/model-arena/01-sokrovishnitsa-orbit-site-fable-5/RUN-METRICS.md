# Метрики прогона

Тест: 01 — Сокровищница Орбит
Тип: многостраничный сайт магазина редких камней
Модель: Claude Fable 5
Статус: готово

Папка результата:
`C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-fable-5\`

Главный файл:
`C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-fable-5\index.html`

Метрики:
- Стоимость USD: $14.75
- Время API: 15м 16с
- Wall-время: 5ч 02м
- Input tokens: 15.8k
- Output tokens: 63.1k
- Cache read: 2.1M
- Cache write: 464.9k

Источник:
`_ОТЧЁТ_Claude-Fable-5.md`

Короткий вердикт:
Заполнить после ручной оценки на арене.
