/* ============================================================
   СОКРОВИЩНИЦА ОРБИТ — каталог, заявка (корзина), интерактив
   Чистый JS, без зависимостей. Хранение — localStorage.
   ============================================================ */

"use strict";

/* ---------- Данные каталога ---------- */

const CATALOG = [
  {
    id: "luna-sea",
    code: "ЛУН-01",
    name: "Осколок Лунного моря",
    origin: "Луна",
    group: "luna",
    type: "Тёмный каменный фрагмент",
    price: 18400,
    desc: "Пористый камень с мягким серым блеском, похожий на кусочек древнего лунного ландшафта."
  },
  {
    id: "mars-garnet",
    code: "МАР-02",
    name: "Гранат Долины Маринер",
    origin: "Марс",
    group: "mars",
    type: "Красный гранат",
    price: 12900,
    desc: "Глубокий красный камень с сухим марсианским оттенком."
  },
  {
    id: "europa-opal",
    code: "ЕВР-03",
    name: "Ледяной опал Европы",
    origin: "Европа, спутник Юпитера",
    group: "jupiter",
    type: "Светлый опал",
    price: 22100,
    desc: "Полупрозрачный камень с холодным голубым свечением."
  },
  {
    id: "titan-amber",
    code: "ТИТ-04",
    name: "Янтарное ядро Титана",
    origin: "Титан, спутник Сатурна",
    group: "saturn",
    type: "Янтарный минерал",
    price: 17600,
    desc: "Тёплый медовый камень, будто сохранённый в густой атмосфере Титана."
  },
  {
    id: "ceres-salt",
    code: "ЦЕР-05",
    name: "Соляной кристалл Цереры",
    origin: "Церера",
    group: "belt",
    type: "Светлый кристалл",
    price: 9400,
    desc: "Сухой светлый кристалл с тонкими белыми прожилками."
  },
  {
    id: "psyche-iron",
    code: "ПСХ-06",
    name: "Железное сердце Психеи",
    origin: "Психея",
    group: "belt",
    type: "Металлический фрагмент",
    price: 26500,
    desc: "Тяжёлый блестящий образец с никелево-железным оттенком."
  },
  {
    id: "io-sulfur",
    code: "ИО-07",
    name: "Серная призма Ио",
    origin: "Ио, спутник Юпитера",
    group: "jupiter",
    type: "Жёлто-оранжевый кристалл",
    price: 11300,
    desc: "Яркий камень с вулканическим характером."
  },
  {
    id: "enceladus-pearl",
    code: "ЭНЦ-08",
    name: "Жемчужина Энцелада",
    origin: "Энцелад, спутник Сатурна",
    group: "saturn",
    type: "Перламутровая сфера",
    price: 19800,
    desc: "Холодный жемчужный образец, вдохновлённый ледяными гейзерами."
  }
];

const byId = (id) => CATALOG.find((s) => s.id === id);

const fmtPrice = (n) => n.toLocaleString("ru-RU") + " $";

/* ---------- SVG-иллюстрации образцов (рисуются кодом, без картинок) ---------- */

const GEMS = {
  "luna-sea": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Осколок Лунного моря">
      <defs>
        <radialGradient id="g-luna" cx="38%" cy="30%" r="80%">
          <stop offset="0%" stop-color="#b7b5b0"/>
          <stop offset="55%" stop-color="#6f6e6a"/>
          <stop offset="100%" stop-color="#3a3937"/>
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="54" ry="10" fill="rgba(0,0,0,0.45)"/>
      <polygon points="64,120 46,88 60,56 94,42 132,50 152,80 144,112 112,126 80,126"
        fill="url(#g-luna)" stroke="rgba(233,228,214,0.15)" stroke-width="1"/>
      <circle cx="86" cy="78" r="8" fill="rgba(0,0,0,0.28)"/>
      <circle cx="118" cy="96" r="5.5" fill="rgba(0,0,0,0.24)"/>
      <circle cx="102" cy="60" r="4" fill="rgba(0,0,0,0.22)"/>
      <circle cx="130" cy="70" r="3" fill="rgba(0,0,0,0.2)"/>
      <path d="M62 62 Q86 44 122 48" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="1.4"/>
    </svg>`,
  "mars-garnet": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Гранат Долины Маринер">
      <defs>
        <linearGradient id="g-mars" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#a83a2c"/>
          <stop offset="55%" stop-color="#7c1f16"/>
          <stop offset="100%" stop-color="#4a100b"/>
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="48" ry="9" fill="rgba(0,0,0,0.45)"/>
      <polygon points="100,34 148,68 132,124 68,124 52,68" fill="url(#g-mars)"/>
      <polygon points="100,34 148,68 100,82" fill="rgba(255,255,255,0.10)"/>
      <polygon points="100,34 52,68 100,82" fill="rgba(255,255,255,0.05)"/>
      <polygon points="52,68 68,124 100,82" fill="rgba(0,0,0,0.22)"/>
      <polygon points="148,68 132,124 100,82" fill="rgba(0,0,0,0.12)"/>
      <polygon points="100,34 108,52 92,52" fill="rgba(255,255,255,0.28)"/>
      <polygon points="100,34 148,68 132,124 68,124 52,68" fill="none"
        stroke="rgba(233,200,180,0.25)" stroke-width="1"/>
    </svg>`,
  "europa-opal": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Ледяной опал Европы">
      <defs>
        <radialGradient id="g-europa" cx="45%" cy="35%" r="75%">
          <stop offset="0%" stop-color="#eef8fc"/>
          <stop offset="45%" stop-color="#b8dcea"/>
          <stop offset="80%" stop-color="#7fb1c8"/>
          <stop offset="100%" stop-color="#4f7f97"/>
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="50" ry="9" fill="rgba(0,0,0,0.45)"/>
      <ellipse cx="100" cy="88" rx="48" ry="41" fill="url(#g-europa)"/>
      <ellipse cx="100" cy="88" rx="48" ry="41" fill="none" stroke="rgba(233,244,250,0.4)" stroke-width="1"/>
      <path d="M64 78 Q88 92 132 74" fill="none" stroke="rgba(90,140,165,0.5)" stroke-width="1.1"/>
      <path d="M70 102 Q100 92 136 100" fill="none" stroke="rgba(90,140,165,0.35)" stroke-width="1"/>
      <ellipse cx="84" cy="68" rx="14" ry="9" fill="rgba(255,255,255,0.5)"/>
      <ellipse cx="116" cy="104" rx="9" ry="5" fill="rgba(190,230,245,0.35)"/>
    </svg>`,
  "titan-amber": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Янтарное ядро Титана">
      <defs>
        <radialGradient id="g-titan" cx="42%" cy="32%" r="80%">
          <stop offset="0%" stop-color="#eec06a"/>
          <stop offset="50%" stop-color="#c4832a"/>
          <stop offset="100%" stop-color="#6e3c0c"/>
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="48" ry="9" fill="rgba(0,0,0,0.45)"/>
      <path d="M56 92 Q54 52 98 46 Q146 42 148 88 Q150 122 104 128 Q60 132 56 92 Z" fill="url(#g-titan)"/>
      <circle cx="112" cy="92" r="5" fill="rgba(74,38,6,0.55)"/>
      <circle cx="90" cy="104" r="3.4" fill="rgba(74,38,6,0.45)"/>
      <circle cx="124" cy="72" r="2.6" fill="rgba(74,38,6,0.4)"/>
      <ellipse cx="86" cy="66" rx="17" ry="10" fill="rgba(255,235,190,0.4)"/>
      <path d="M56 92 Q54 52 98 46 Q146 42 148 88 Q150 122 104 128 Q60 132 56 92 Z"
        fill="none" stroke="rgba(238,192,106,0.3)" stroke-width="1"/>
    </svg>`,
  "ceres-salt": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Соляной кристалл Цереры">
      <defs>
        <linearGradient id="g-ceres" x1="0" y1="0" x2="0.4" y2="1">
          <stop offset="0%" stop-color="#f4f1e8"/>
          <stop offset="60%" stop-color="#d4cfbf"/>
          <stop offset="100%" stop-color="#a49e8b"/>
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="52" ry="9" fill="rgba(0,0,0,0.45)"/>
      <polygon points="80,126 66,74 84,48 98,74 98,126" fill="url(#g-ceres)" stroke="rgba(0,0,0,0.18)" stroke-width="0.8"/>
      <polygon points="102,126 98,62 118,38 136,66 128,126" fill="url(#g-ceres)" stroke="rgba(0,0,0,0.18)" stroke-width="0.8"/>
      <polygon points="132,126 136,90 150,78 156,98 150,126" fill="url(#g-ceres)" stroke="rgba(0,0,0,0.18)" stroke-width="0.8"/>
      <line x1="84" y1="52" x2="82" y2="122" stroke="rgba(255,255,255,0.65)" stroke-width="1"/>
      <line x1="117" y1="42" x2="107" y2="122" stroke="rgba(255,255,255,0.55)" stroke-width="1"/>
      <line x1="148" y1="82" x2="144" y2="122" stroke="rgba(255,255,255,0.5)" stroke-width="0.8"/>
    </svg>`,
  "psyche-iron": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Железное сердце Психеи">
      <defs>
        <linearGradient id="g-psyche" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#dfe2e7"/>
          <stop offset="50%" stop-color="#8d939c"/>
          <stop offset="100%" stop-color="#454b54"/>
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="136" rx="52" ry="9" fill="rgba(0,0,0,0.5)"/>
      <polygon points="100,30 150,88 100,132 50,88" fill="url(#g-psyche)"/>
      <polygon points="100,30 100,132 50,88" fill="rgba(0,0,0,0.22)"/>
      <polygon points="100,30 118,60 100,74 84,58" fill="rgba(255,255,255,0.3)"/>
      <polygon points="100,30 150,88 100,132 50,88" fill="none"
        stroke="rgba(233,228,214,0.28)" stroke-width="1"/>
      <line x1="50" y1="88" x2="150" y2="88" stroke="rgba(233,228,214,0.18)" stroke-width="0.8"/>
    </svg>`,
  "io-sulfur": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Серная призма Ио">
      <defs>
        <linearGradient id="g-io" x1="0" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stop-color="#f5cb4a"/>
          <stop offset="55%" stop-color="#dd8b23"/>
          <stop offset="100%" stop-color="#984a10"/>
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="48" ry="9" fill="rgba(0,0,0,0.45)"/>
      <polygon points="86,128 74,62 92,34 112,42 122,106 106,128" fill="url(#g-io)"/>
      <polygon points="92,34 112,42 104,58 88,52" fill="rgba(255,244,200,0.4)"/>
      <line x1="90" y1="50" x2="94" y2="124" stroke="rgba(120,60,10,0.4)" stroke-width="1.2"/>
      <polygon points="118,126 124,86 138,74 146,96 140,126" fill="url(#g-io)" opacity="0.9"/>
      <polygon points="86,128 74,62 92,34 112,42 122,106 106,128" fill="none"
        stroke="rgba(255,220,140,0.3)" stroke-width="1"/>
    </svg>`,
  "enceladus-pearl": `
    <svg viewBox="0 0 200 160" role="img" aria-label="Жемчужина Энцелада">
      <defs>
        <radialGradient id="g-enceladus" cx="40%" cy="32%" r="78%">
          <stop offset="0%" stop-color="#ffffff"/>
          <stop offset="55%" stop-color="#e6e4ec"/>
          <stop offset="100%" stop-color="#a7aec0"/>
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="134" rx="46" ry="9" fill="rgba(0,0,0,0.45)"/>
      <circle cx="100" cy="88" r="42" fill="url(#g-enceladus)"/>
      <circle cx="85" cy="72" r="10" fill="rgba(255,255,255,0.7)"/>
      <path d="M68 106 A40 40 0 0 0 128 110" fill="none" stroke="rgba(150,190,215,0.35)" stroke-width="2"/>
      <path d="M64 92 A40 40 0 0 1 82 58" fill="none" stroke="rgba(215,180,200,0.28)" stroke-width="2"/>
      <circle cx="100" cy="88" r="42" fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="0.8"/>
    </svg>`
};

/* ---------- Хранилище заявки ---------- */

const CART_KEY = "orbit-vault-cart";

function loadCart() {
  try {
    const raw = localStorage.getItem(CART_KEY);
    const data = raw ? JSON.parse(raw) : {};
    // отфильтровать несуществующие id
    return Object.fromEntries(
      Object.entries(data).filter(([id, qty]) => byId(id) && qty > 0)
    );
  } catch {
    return {};
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

let cart = loadCart();

const cartCount = () => Object.values(cart).reduce((s, q) => s + q, 0);
const cartTotal = () =>
  Object.entries(cart).reduce((s, [id, q]) => s + byId(id).price * q, 0);

function addToCart(id) {
  cart[id] = (cart[id] || 0) + 1;
  saveCart(cart);
  renderBadge();
  renderDrawerBody();
  showToast(`«${byId(id).name}» добавлен в заявку`);
}

function setQty(id, qty) {
  if (qty <= 0) delete cart[id];
  else cart[id] = qty;
  saveCart(cart);
  renderBadge();
  renderDrawerBody();
}

/* ---------- Тост ---------- */

let toastTimer = null;

function showToast(message) {
  let el = document.querySelector(".toast");
  if (!el) {
    el = document.createElement("div");
    el.className = "toast";
    el.setAttribute("role", "status");
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("is-visible"), 2600);
}

/* ---------- Панель заявки (корзина) ---------- */

let drawerMode = "list"; // list | form | success
let lastRequestNumber = "";

function injectDrawer() {
  const backdrop = document.createElement("div");
  backdrop.className = "drawer-backdrop";
  backdrop.hidden = true;
  backdrop.addEventListener("click", closeDrawer);

  const drawer = document.createElement("aside");
  drawer.className = "drawer";
  drawer.setAttribute("aria-hidden", "true");
  drawer.setAttribute("aria-label", "Заявка на частную покупку");
  drawer.innerHTML = `
    <div class="drawer-head">
      <h2>Заявка на покупку</h2>
      <button class="drawer-close" type="button" aria-label="Закрыть панель">&#10005;</button>
    </div>
    <div class="drawer-body" id="drawer-body"></div>
    <div class="drawer-foot" id="drawer-foot"></div>
  `;
  drawer.querySelector(".drawer-close").addEventListener("click", closeDrawer);

  document.body.append(backdrop, drawer);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeDrawer();
  });
}

function openDrawer() {
  drawerMode = drawerMode === "success" ? "list" : drawerMode;
  renderDrawerBody();
  const drawer = document.querySelector(".drawer");
  const backdrop = document.querySelector(".drawer-backdrop");
  backdrop.hidden = false;
  requestAnimationFrame(() => {
    backdrop.classList.add("is-open");
    drawer.classList.add("is-open");
  });
  drawer.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeDrawer() {
  const drawer = document.querySelector(".drawer");
  const backdrop = document.querySelector(".drawer-backdrop");
  if (!drawer) return;
  drawer.classList.remove("is-open");
  backdrop.classList.remove("is-open");
  drawer.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  setTimeout(() => { backdrop.hidden = true; }, 260);
  if (drawerMode === "form") drawerMode = "list";
}

function renderBadge() {
  document.querySelectorAll(".cart-count").forEach((el) => {
    el.textContent = String(cartCount());
  });
}

function renderDrawerBody() {
  const body = document.getElementById("drawer-body");
  const foot = document.getElementById("drawer-foot");
  if (!body || !foot) return;

  if (drawerMode === "success") {
    body.innerHTML = `
      <div class="drawer-empty" style="text-align:left; padding:32px 0;">
        <div class="form-success">
          <b>Заявка ${lastRequestNumber} принята.</b><br><br>
          Куратор свяжется с вами в течение 24 часов, подтвердит наличие образцов,
          экспортные разрешения и условия передачи. До этого момента ничего оплачивать не нужно.
        </div>
      </div>`;
    foot.innerHTML = `<button class="btn btn-ghost" type="button" id="drawer-done">Вернуться к каталогу</button>`;
    foot.querySelector("#drawer-done").addEventListener("click", () => {
      drawerMode = "list";
      closeDrawer();
    });
    return;
  }

  const entries = Object.entries(cart);

  if (entries.length === 0) {
    drawerMode = "list";
    body.innerHTML = `
      <div class="drawer-empty">
        <span class="serif">Заявка пока пуста</span>
        Добавьте образцы из каталога — мы подготовим их к частному показу.
      </div>`;
    foot.innerHTML = `<a class="btn btn-ghost" href="catalog.html">Открыть каталог</a>`;
    return;
  }

  if (drawerMode === "form") {
    body.innerHTML = `
      <form class="form-panel" id="request-form" novalidate>
        <p class="small muted" style="margin-bottom:22px;">
          Образцов в заявке: ${cartCount()} · предварительный итог ${fmtPrice(cartTotal())}
        </p>
        <div class="field">
          <label for="rq-name">Ваше имя</label>
          <input id="rq-name" name="name" type="text" required autocomplete="name" placeholder="Как к вам обращаться">
        </div>
        <div class="field">
          <label for="rq-contact">Почта или телефон</label>
          <input id="rq-contact" name="contact" type="text" required autocomplete="email" placeholder="Для связи с куратором">
        </div>
        <div class="field">
          <label for="rq-note">Комментарий</label>
          <textarea id="rq-note" name="note" placeholder="Пожелания к показу, доставке, оформлению"></textarea>
        </div>
      </form>`;
    foot.innerHTML = `
      <div style="display:grid; gap:10px;">
        <button class="btn btn-solid" type="submit" form="request-form">Отправить заявку</button>
        <button class="btn btn-ghost" type="button" id="back-to-list">Назад к списку</button>
      </div>`;

    foot.querySelector("#back-to-list").addEventListener("click", () => {
      drawerMode = "list";
      renderDrawerBody();
    });

    body.querySelector("#request-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const name = body.querySelector("#rq-name").value.trim();
      const contact = body.querySelector("#rq-contact").value.trim();
      if (!name || !contact) {
        showToast("Укажите имя и способ связи — куратору нужно кому-то ответить");
        return;
      }
      lastRequestNumber = "№ ОРБ-" + String(Math.floor(1000 + Math.random() * 9000));
      cart = {};
      saveCart(cart);
      renderBadge();
      drawerMode = "success";
      renderDrawerBody();
    });
    return;
  }

  // режим списка
  body.innerHTML = entries.map(([id, qty]) => {
    const s = byId(id);
    return `
      <div class="cart-row" data-id="${id}">
        <div>
          <div class="cr-name">${s.name}</div>
          <div class="cr-origin">${s.origin} · ${s.code}</div>
        </div>
        <div class="cr-price">${fmtPrice(s.price * qty)}</div>
        <div class="cr-controls">
          <div class="qty" aria-label="Количество">
            <button type="button" data-act="dec" aria-label="Убавить">&minus;</button>
            <span>${qty}</span>
            <button type="button" data-act="inc" aria-label="Прибавить">+</button>
          </div>
          <button type="button" class="cr-remove" data-act="remove">убрать</button>
        </div>
      </div>`;
  }).join("");

  foot.innerHTML = `
    <div class="cart-total-row">
      <span>Предварительный итог</span>
      <b>${fmtPrice(cartTotal())}</b>
    </div>
    <p class="cart-note">
      Финальная стоимость подтверждается куратором после проверки экспортных
      разрешений и условий доставки в климатическом кейсе.
    </p>
    <button class="btn btn-solid" type="button" id="to-request">Запросить частную покупку</button>`;

  foot.querySelector("#to-request").addEventListener("click", () => {
    drawerMode = "form";
    renderDrawerBody();
  });

  body.querySelectorAll(".cart-row").forEach((row) => {
    const id = row.dataset.id;
    row.addEventListener("click", (e) => {
      const act = e.target.dataset && e.target.dataset.act;
      if (!act) return;
      if (act === "inc") setQty(id, (cart[id] || 0) + 1);
      if (act === "dec") setQty(id, (cart[id] || 0) - 1);
      if (act === "remove") setQty(id, 0);
    });
  });
}

/* ---------- Карточка образца ---------- */

function specimenCard(s) {
  return `
    <article class="card" data-group="${s.group}">
      <div class="card-media">
        <span class="card-code">КАТ. ${s.code}</span>
        ${GEMS[s.id] || ""}
      </div>
      <div class="card-body">
        <div class="card-tax">${s.origin} · ${s.type}</div>
        <h3>${s.name}</h3>
        <p class="card-desc">${s.desc}</p>
        <div class="card-foot">
          <span class="card-price">${fmtPrice(s.price)}</span>
          <button class="btn btn-sm" type="button" data-add="${s.id}">В заявку</button>
        </div>
      </div>
    </article>`;
}

function bindAddButtons(scope) {
  (scope || document).querySelectorAll("[data-add]").forEach((btn) => {
    if (btn.dataset.bound) return; // защита от двойной привязки обработчика
    btn.dataset.bound = "1";
    btn.addEventListener("click", () => addToCart(btn.dataset.add));
  });
}

/* ---------- Страница «Каталог» ---------- */

function initCatalogPage() {
  const grid = document.getElementById("catalog-grid");
  if (!grid) return;

  grid.innerHTML = CATALOG.map(specimenCard).join("");
  bindAddButtons(grid);

  const filters = document.querySelectorAll(".filter-btn");
  filters.forEach((btn) => {
    btn.addEventListener("click", () => {
      filters.forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      const f = btn.dataset.filter;
      let shown = 0;
      grid.querySelectorAll(".card").forEach((card) => {
        const show = f === "all" || card.dataset.group === f;
        card.style.display = show ? "" : "none";
        if (show) shown++;
      });
      const counter = document.getElementById("catalog-counter");
      if (counter) {
        counter.textContent = `Показано образцов: ${shown} из ${CATALOG.length}`;
      }
    });
  });
}

/* ---------- Главная: витрина и герой ---------- */

function initHomePage() {
  const featured = document.getElementById("featured-grid");
  if (featured) {
    const ids = ["europa-opal", "psyche-iron", "luna-sea"];
    featured.innerHTML = ids.map((id) => specimenCard(byId(id))).join("");
    bindAddButtons(featured);
  }

  const heroGem = document.getElementById("hero-gem");
  if (heroGem) {
    const s = byId("europa-opal");
    heroGem.innerHTML = GEMS[s.id];
    const plaque = document.getElementById("hero-plaque");
    if (plaque) {
      plaque.innerHTML = `
        <div>
          <div class="name">${s.name}</div>
          <div class="origin">${s.origin} · КАТ. ${s.code}</div>
        </div>
        <div class="price">${fmtPrice(s.price)}</div>`;
    }
  }
}

/* ---------- Контактная форма ---------- */

function initContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = form.querySelector("#cf-name").value.trim();
    const contact = form.querySelector("#cf-contact").value.trim();
    if (!name || !contact) {
      showToast("Заполните имя и способ связи");
      return;
    }
    form.innerHTML = `
      <div class="form-success">
        <b>Сообщение отправлено.</b><br><br>
        Спасибо, ${name}. Куратор ответит в часы работы галереи — по будням и субботам
        с 11:00 до 20:00 по московскому времени.
      </div>`;
  });
}

/* ---------- Общая инициализация ---------- */

document.addEventListener("DOMContentLoaded", () => {
  injectDrawer();
  renderBadge();

  document.querySelectorAll(".cart-btn").forEach((btn) => {
    btn.addEventListener("click", openDrawer);
  });

  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", nav.classList.contains("is-open") ? "true" : "false");
    });
  }

  initCatalogPage();
  initHomePage();
  initContactForm();
  bindAddButtons(document.querySelector("main"));
});
