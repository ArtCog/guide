(() => {
  "use strict";

  // ============================================================
  // БАЗОВЫЕ КОНСТАНТЫ
  // ============================================================
  const TILE = 45;
  const ROWS = 12;
  const CANVAS_W = 960;
  const CANVAS_H = ROWS * TILE; // 540

  const GRAVITY = 0.9;
  const MAX_FALL_SPEED = 18;
  const MOVE_ACCEL = 0.65;
  const MOVE_MAX = 5.2;
  const FRICTION = 0.78;
  const AIR_FRICTION = 0.90;
  const JUMP_VELOCITY = -14.5;
  const JUMP_CUT_MULT = 0.5; // отпустил прыжок раньше — прыжок короче
  const STOMP_BOUNCE = -9;

  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");

  const hudCoins = document.getElementById("hud-coins");
  const hudTotal = document.getElementById("hud-total");
  const hudLives = document.getElementById("hud-lives");
  const hudTime = document.getElementById("hud-time");
  const overlay = document.getElementById("overlay");
  const overlayTitle = document.getElementById("overlay-title");
  const overlayText = document.getElementById("overlay-text");
  const overlayBtn = document.getElementById("overlay-btn");

  // ============================================================
  // ЗВУК (синтез через WebAudio, без внешних файлов)
  // ============================================================
  let audioCtx = null;
  function ensureAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
  }
  function beep(freq, dur, type = "square", vol = 0.16, delay = 0) {
    if (!audioCtx) return;
    const t0 = audioCtx.currentTime + delay;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(vol, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(gain).connect(audioCtx.destination);
    osc.start(t0);
    osc.stop(t0 + dur);
  }
  const sfx = {
    jump: () => beep(520, 0.14, "square", 0.14),
    coin: () => { beep(880, 0.08, "square", 0.12); beep(1320, 0.10, "square", 0.10, 0.05); },
    stomp: () => beep(180, 0.12, "sawtooth", 0.16),
    block: () => { beep(300, 0.06, "square", 0.15); beep(600, 0.08, "square", 0.12, 0.05); },
    hurt: () => beep(120, 0.35, "sawtooth", 0.18),
    win: () => { [523, 659, 784, 1047].forEach((f, i) => beep(f, 0.18, "square", 0.14, i * 0.12)); },
  };

  // ============================================================
  // ПОСТРОЕНИЕ УРОВНЯ
  // Уровень собирается из простых помощников, а не из ASCII-карты —
  // так легче гарантировать, что каждая яма и каждый прыжок
  // физически проходимы (см. расчёт дальности прыжка ниже).
  // ============================================================
  function makeLevel() {
    const solids = [];      // сплошные тайлы: земля, платформы, блоки
    const coins = [];
    const enemies = [];
    const spikes = [];
    const movingPlatforms = [];
    let flag = null;
    let playerStart = { x: TILE * 1.5, y: TILE * 9 };

    const GROUND_TOP_ROW = 10; // земля занимает строки 10 и 11 (2 тайла толщиной)

    function px(col) { return col * TILE; }
    function py(row) { return row * TILE; }

    // Полоса земли от колонки x1 до x2 (не включая x2)
    function ground(x1, x2) {
      for (let c = x1; c < x2; c++) {
        solids.push({ x: px(c), y: py(GROUND_TOP_ROW), w: TILE, h: TILE * 2, type: "ground" });
      }
    }
    // Одиночный сплошной блок земли/лестницы на произвольной строке
    function block(col, row) {
      solids.push({ x: px(col), y: py(row), w: TILE, h: TILE, type: "ground" });
    }
    // Плавающая платформа шириной n тайлов на строке row, начиная с col
    function platform(col, row, n) {
      for (let i = 0; i < n; i++) {
        solids.push({ x: px(col + i), y: py(row), w: TILE, h: TILE, type: "platform" });
      }
    }
    // Блок-вопрос: даёт бонус при ударе снизу
    function qblock(col, row, bonus = 3) {
      solids.push({ x: px(col), y: py(row), w: TILE, h: TILE, type: "block", used: false, bonus });
    }
    function coin(col, row) {
      coins.push({ x: px(col) + TILE / 2, y: py(row) + TILE / 2, taken: false, phase: Math.random() * Math.PI * 2 });
    }
    function spike(col, row) {
      spikes.push({ x: px(col) + 4, y: py(row) + TILE * 0.5, w: TILE - 8, h: TILE * 0.5 });
    }
    function enemy(colStart, colEnd, row) {
      enemies.push({
        x: px(colStart), y: py(row) - 34, w: 32, h: 34,
        vx: 1.6, minX: px(colStart), maxX: px(colEnd) - 32,
        alive: true, squashT: 0,
      });
    }
    function movingPlatform(colStart, colEnd, row, w, axis, speed) {
      movingPlatforms.push({
        x: px(colStart), y: py(row), w: TILE * w, h: TILE * 0.6,
        minX: px(colStart), maxX: px(colEnd), minY: py(row), maxY: py(row),
        axis, speed, dir: 1, dx: 0, dy: 0, type: "moving",
      });
    }

    // ---- Секция 1: старт, обучение (0-13) ----
    ground(0, 14);
    coin(4, 8); coin(5, 8); coin(6, 8);
    enemy(9, 13, GROUND_TOP_ROW);

    // ---- Яма №1 (3 тайла — комфортно прыгается) ----
    // (14,15,16 — пусто)

    // ---- Секция 2: земля + лесенка блоков (17-29) ----
    ground(17, 30);
    block(19, 9);
    block(20, 9); block(20, 8);
    block(21, 9); block(21, 8); block(21, 7);
    block(22, 9); block(22, 8);
    block(23, 9);
    coin(21, 6);
    coin(19, 8); coin(23, 8);
    qblock(25, 8);
    coin(25, 6);
    enemy(26, 29, GROUND_TOP_ROW);

    // ---- Яма №2 (3 тайла) ----
    // (30,31,32 — пусто)

    // ---- Секция 3: земля с шипами (33-40) ----
    ground(33, 41);
    spike(36, GROUND_TOP_ROW - 1);
    spike(37, GROUND_TOP_ROW - 1);
    coin(36, 7); coin(37, 7);
    qblock(39, 8);

    // ---- Большая пропасть с плавающими платформами (41-55) ----
    platform(43, 8, 2);
    coin(43, 7); coin(44, 7);
    platform(47, 6, 2);
    coin(47, 5); coin(48, 5);
    platform(51, 8, 2);
    coin(51, 7); coin(52, 7);

    // ---- Секция 4: земля продолжается (55-64), движущаяся платформа над пропастью ----
    ground(55, 57);
    // пропасть (57..63)
    movingPlatform(57, 62, 9, 2, "x", 1.3);
    ground(64, 76);
    enemy(65, 68, GROUND_TOP_ROW);
    enemy(70, 74, GROUND_TOP_ROW);
    spike(72, GROUND_TOP_ROW - 1);
    qblock(66, 8);
    qblock(69, 8, 5);
    coin(66, 6); coin(67, 6); coin(68, 6);

    // ---- Яма №3 перед финишем (2 тайла) ----
    // (76,77 — пусто)

    // ---- Финишная площадка (78-90) ----
    ground(78, 91);
    for (let c = 80; c <= 86; c += 2) coin(c, 8);
    flag = { x: px(88), y: py(GROUND_TOP_ROW) - TILE * 4, w: 10, h: TILE * 4, topY: py(GROUND_TOP_ROW) - TILE * 4 };

    const width = px(91);
    return { solids, coins, enemies, spikes, movingPlatforms, flag, playerStart, width, totalCoins: coins.length };
  }

  // ============================================================
  // Расчёт дальности прыжка (для проверки проходимости ям) —
  // время полёта v/g * 2, помноженное на макс. скорость движения.
  // При GRAVITY=0.9, JUMP_VELOCITY=-14.5, MOVE_MAX=5.2 получаем
  // максимум ~167px по горизонтали и ~117px по высоте прыжка —
  // все ямы и уступы уровня спроектированы внутри этих значений.
  // ============================================================

  // ============================================================
  // СОСТОЯНИЕ ИГРЫ
  // ============================================================
  let level = null;
  let player = null;
  let camera = { x: 0 };
  let keys = {};
  let particles = [];
  let popups = [];
  let coinCount = 0;
  let lives = 3;
  let elapsed = 0;
  let state = "start"; // start | playing | won | lost
  let clouds = [];
  let hills = [];
  let flagRaised = 0;

  function newPlayer() {
    return {
      x: level.playerStart.x, y: level.playerStart.y,
      w: 30, h: 42, vx: 0, vy: 0,
      onGround: false, facing: 1, standingOn: null,
      hurtTimer: 0, animT: 0, squash: 1,
    };
  }

  function resetAll() {
    level = makeLevel();
    player = newPlayer();
    camera.x = 0;
    coinCount = 0;
    lives = 3;
    elapsed = 0;
    particles = [];
    popups = [];
    flagRaised = 0;
    state = "playing";

    clouds = [];
    for (let i = 0; i < 14; i++) {
      clouds.push({ x: Math.random() * level.width * 1.2, y: 30 + Math.random() * 140, s: 0.6 + Math.random() * 0.8 });
    }
    hills = [];
    for (let i = 0; i < 10; i++) {
      hills.push({ x: i * 420 + Math.random() * 100, r: 90 + Math.random() * 70 });
    }

    hudTotal.textContent = level.totalCoins;
    updateHud();
    overlay.classList.add("hidden");
  }

  function respawnAfterDeath() {
    player.x = level.playerStart.x;
    player.y = level.playerStart.y;
    player.vx = 0; player.vy = 0;
    player.hurtTimer = 60;
  }

  function loseLife() {
    if (player.hurtTimer > 0) return;
    lives--;
    sfx.hurt();
    popups.push({ x: player.x + player.w / 2, y: player.y, text: "-1 ЖИЗНЬ", t: 0, color: "#ff5566" });
    if (lives <= 0) {
      state = "lost";
      showOverlay("Поражение!", `Собрано кристаллов: ${coinCount} из ${level.totalCoins}. Нажмите R, чтобы начать заново.`, "Начать заново (R)");
    } else {
      respawnAfterDeath();
    }
  }

  function win() {
    if (state !== "playing") return;
    state = "won";
    sfx.win();
    showOverlay("Победа!", `Уровень пройден за ${elapsed.toFixed(1)} с. Кристаллов: ${coinCount} из ${level.totalCoins}.`, "Играть снова (R)");
  }

  function showOverlay(title, text, btnLabel) {
    overlayTitle.textContent = title;
    overlayText.textContent = text;
    overlayBtn.textContent = btnLabel;
    overlay.classList.remove("hidden");
  }

  function updateHud() {
    hudCoins.textContent = coinCount;
    hudLives.textContent = Math.max(0, lives);
    hudTime.textContent = elapsed.toFixed(1);
  }

  // ============================================================
  // КОЛЛИЗИИ
  // ============================================================
  function overlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function activeSolids() {
    // движущиеся платформы добавляются как обычные solid-прямоугольники
    return level.solids.concat(level.movingPlatforms);
  }

  function moveEntityX(e, dx, solids) {
    e.x += dx;
    for (const s of solids) {
      if (overlap(e, s)) {
        if (dx > 0) e.x = s.x - e.w;
        else if (dx < 0) e.x = s.x + s.w;
      }
    }
  }

  function moveEntityY(e, dy, solids, onLand, onHead) {
    e.y += dy;
    e.onGround = false;
    for (const s of solids) {
      if (overlap(e, s)) {
        if (dy > 0) {
          e.y = s.y - e.h;
          e.vy = 0;
          e.onGround = true;
          if (onLand) onLand(s);
        } else if (dy < 0) {
          e.y = s.y + s.h;
          e.vy = 0;
          if (onHead) onHead(s);
        }
      }
    }
  }

  // ============================================================
  // ОБНОВЛЕНИЕ ДВИЖУЩИХСЯ ПЛАТФОРМ
  // ============================================================
  function updateMovingPlatforms(dt) {
    for (const mp of level.movingPlatforms) {
      const prevX = mp.x, prevY = mp.y;
      if (mp.axis === "x") {
        mp.x += mp.speed * mp.dir * dt;
        if (mp.x < mp.minX) { mp.x = mp.minX; mp.dir = 1; }
        if (mp.x + mp.w > mp.maxX + TILE) { mp.x = mp.maxX + TILE - mp.w; mp.dir = -1; }
      } else {
        mp.y += mp.speed * mp.dir * dt;
        if (mp.y < mp.minY) { mp.y = mp.minY; mp.dir = 1; }
        if (mp.y > mp.maxY) { mp.y = mp.maxY; mp.dir = -1; }
      }
      mp.dx = mp.x - prevX;
      mp.dy = mp.y - prevY;
    }
  }

  // ============================================================
  // ОБНОВЛЕНИЕ ИГРОКА
  // ============================================================
  function updatePlayer(dt) {
    if (player.hurtTimer > 0) player.hurtTimer -= dt;

    // Если стоим на движущейся платформе — едем вместе с ней
    if (player.standingOn && player.standingOn.type === "moving") {
      player.x += player.standingOn.dx;
      player.y += player.standingOn.dy;
    }

    const left = keys["ArrowLeft"] || keys["KeyA"];
    const right = keys["ArrowRight"] || keys["KeyD"];
    const jumpPressed = keys["Space"] || keys["ArrowUp"] || keys["KeyW"];

    if (left && !right) {
      player.vx -= MOVE_ACCEL * dt;
      player.facing = -1;
    } else if (right && !left) {
      player.vx += MOVE_ACCEL * dt;
      player.facing = 1;
    } else {
      player.vx *= player.onGround ? Math.pow(FRICTION, dt) : Math.pow(AIR_FRICTION, dt);
      if (Math.abs(player.vx) < 0.05) player.vx = 0;
    }
    player.vx = Math.max(-MOVE_MAX, Math.min(MOVE_MAX, player.vx));

    if (jumpPressed && player.onGround && player.jumpLock !== true) {
      player.vy = JUMP_VELOCITY;
      player.onGround = false;
      player.jumpLock = true;
      sfx.jump();
    }
    if (!jumpPressed) player.jumpLock = false;
    if (!jumpPressed && player.vy < 0) player.vy *= JUMP_CUT_MULT;

    player.vy += GRAVITY * dt;
    if (player.vy > MAX_FALL_SPEED) player.vy = MAX_FALL_SPEED;

    const solids = activeSolids();
    moveEntityX(player, player.vx * dt, solids);
    player.standingOn = null;
    moveEntityY(player, player.vy * dt, solids,
      (s) => { player.standingOn = s; },
      (s) => { if (s.type === "block") hitBlock(s); }
    );

    // Границы уровня
    if (player.x < 0) player.x = 0;
    if (player.x + player.w > level.width) player.x = level.width - player.w;

    // Падение в яму
    if (player.y > CANVAS_H + 60) {
      loseLife();
      return;
    }

    // Монеты
    for (const c of level.coins) {
      if (!c.taken) {
        const dx = (c.x) - (player.x + player.w / 2);
        const dy = (c.y) - (player.y + player.h / 2);
        if (Math.abs(dx) < TILE * 0.55 && Math.abs(dy) < TILE * 0.55) {
          c.taken = true;
          coinCount++;
          sfx.coin();
          popups.push({ x: c.x, y: c.y, text: "+1", t: 0, color: "#ffe066" });
        }
      }
    }

    // Шипы
    for (const sp of level.spikes) {
      if (overlap(player, sp)) { loseLife(); return; }
    }

    // Враги
    for (const en of level.enemies) {
      if (!en.alive) continue;
      if (overlap(player, en)) {
        const stomping = player.vy > 0 && (player.y + player.h - player.vy * dt) <= en.y + en.h * 0.5;
        if (stomping) {
          en.alive = false;
          en.squashT = 20;
          player.vy = STOMP_BOUNCE;
          sfx.stomp();
          popups.push({ x: en.x + en.w / 2, y: en.y, text: "+50", t: 0, color: "#8be99b" });
        } else {
          loseLife();
          return;
        }
      }
    }

    // Финиш
    if (level.flag && player.x + player.w > level.flag.x && player.x < level.flag.x + level.flag.w + 20 &&
        player.y + player.h > level.flag.topY) {
      win();
    }

    player.animT += dt;
  }

  function hitBlock(s) {
    if (s.used) return;
    s.used = true;
    coinCount += s.bonus;
    sfx.block();
    popups.push({ x: s.x + TILE / 2, y: s.y - 10, text: "+" + s.bonus, t: 0, color: "#ffe066" });
  }

  function updateEnemies(dt) {
    for (const en of level.enemies) {
      if (!en.alive) {
        if (en.squashT > 0) en.squashT -= dt;
        continue;
      }
      en.x += en.vx * dt;
      if (en.x < en.minX) { en.x = en.minX; en.vx *= -1; }
      if (en.x > en.maxX) { en.x = en.maxX; en.vx *= -1; }
    }
  }

  function updateParticlesAndPopups(dt) {
    for (const p of popups) { p.t += dt; p.y -= 0.6 * dt; }
    popups = popups.filter(p => p.t < 45);
  }

  // ============================================================
  // ОТРИСОВКА
  // ============================================================
  function draw() {
    ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);

    // Небо
    const sky = ctx.createLinearGradient(0, 0, 0, CANVAS_H);
    sky.addColorStop(0, "#5ec8f0");
    sky.addColorStop(1, "#bdeaff");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    // Солнце
    ctx.fillStyle = "#fff3b0";
    ctx.beginPath();
    ctx.arc(CANVAS_W - 100, 90, 46, 0, Math.PI * 2);
    ctx.fill();

    // Дальние холмы (параллакс 0.3)
    ctx.fillStyle = "#8fd39a";
    for (const h of hills) {
      const sx = h.x - camera.x * 0.3;
      if (sx < -200 || sx > CANVAS_W + 200) continue;
      ctx.beginPath();
      ctx.arc(sx, CANVAS_H - 340, h.r, Math.PI, 0);
      ctx.fill();
    }
    // Облака (параллакс 0.5)
    ctx.fillStyle = "#ffffffcc";
    for (const c of clouds) {
      const sx = c.x - camera.x * 0.5;
      if (sx < -100 || sx > CANVAS_W + 100) continue;
      drawCloud(sx, c.y, c.s);
    }

    ctx.save();
    ctx.translate(-camera.x, 0);

    // Тайлы
    for (const s of level.solids) {
      if (s.x + s.w < camera.x - 20 || s.x > camera.x + CANVAS_W + 20) continue;
      drawTile(s);
    }
    // Шипы
    ctx.fillStyle = "#7d8596";
    for (const sp of level.spikes) {
      const n = Math.round(sp.w / 14);
      const step = sp.w / n;
      for (let i = 0; i < n; i++) {
        ctx.beginPath();
        ctx.moveTo(sp.x + i * step, sp.y + sp.h);
        ctx.lineTo(sp.x + i * step + step / 2, sp.y);
        ctx.lineTo(sp.x + i * step + step, sp.y + sp.h);
        ctx.closePath();
        ctx.fill();
      }
    }
    // Движущиеся платформы
    for (const mp of level.movingPlatforms) drawMovingPlatform(mp);

    // Монеты
    for (const c of level.coins) if (!c.taken) drawCoin(c);

    // Флаг
    if (level.flag) drawFlag(level.flag);

    // Враги
    for (const en of level.enemies) drawEnemy(en);

    // Игрок
    drawPlayer();

    // Всплывающий текст
    for (const p of popups) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, 1 - p.t / 45);
      ctx.fillStyle = p.color;
      ctx.font = "bold 16px Trebuchet MS";
      ctx.textAlign = "center";
      ctx.fillText(p.text, p.x, p.y);
      ctx.restore();
    }

    ctx.restore();

    // Красная вспышка при уроне
    if (player.hurtTimer > 0) {
      ctx.fillStyle = `rgba(255,0,0,${0.15 * (player.hurtTimer / 60)})`;
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }
  }

  function drawCloud(x, y, s) {
    ctx.beginPath();
    ctx.arc(x, y, 18 * s, 0, Math.PI * 2);
    ctx.arc(x + 22 * s, y - 8 * s, 22 * s, 0, Math.PI * 2);
    ctx.arc(x + 46 * s, y, 18 * s, 0, Math.PI * 2);
    ctx.fill();
  }

  function drawTile(s) {
    if (s.type === "ground") {
      const grd = ctx.createLinearGradient(s.x, s.y, s.x, s.y + s.h);
      grd.addColorStop(0, "#7bc96f");
      grd.addColorStop(0.18, "#5aa852");
      grd.addColorStop(0.18, "#9a6b3f");
      grd.addColorStop(1, "#7a5230");
      ctx.fillStyle = grd;
      ctx.fillRect(s.x, s.y, s.w, s.h);
      ctx.strokeStyle = "#00000022";
      ctx.strokeRect(s.x + 0.5, s.y + 0.5, s.w - 1, s.h - 1);
    } else if (s.type === "platform") {
      ctx.fillStyle = "#b5773f";
      ctx.fillRect(s.x, s.y, s.w, s.h);
      ctx.fillStyle = "#8a5a2c";
      ctx.fillRect(s.x, s.y + s.h - 6, s.w, 6);
      ctx.strokeStyle = "#00000033";
      ctx.strokeRect(s.x + 0.5, s.y + 0.5, s.w - 1, s.h - 1);
    } else if (s.type === "block") {
      if (s.used) {
        ctx.fillStyle = "#7a6a55";
        ctx.fillRect(s.x, s.y, s.w, s.h);
        ctx.strokeStyle = "#00000033";
        ctx.strokeRect(s.x + 0.5, s.y + 0.5, s.w - 1, s.h - 1);
      } else {
        const grd = ctx.createLinearGradient(s.x, s.y, s.x, s.y + s.h);
        grd.addColorStop(0, "#ffd85c");
        grd.addColorStop(1, "#f0a02a");
        ctx.fillStyle = grd;
        ctx.fillRect(s.x, s.y, s.w, s.h);
        ctx.strokeStyle = "#00000044";
        ctx.strokeRect(s.x + 0.5, s.y + 0.5, s.w - 1, s.h - 1);
        ctx.fillStyle = "#7a4a10";
        ctx.font = "bold 22px Trebuchet MS";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("?", s.x + s.w / 2, s.y + s.h / 2 + 2);
      }
    }
  }

  function drawMovingPlatform(mp) {
    ctx.fillStyle = "#5c8dd6";
    ctx.fillRect(mp.x, mp.y, mp.w, mp.h);
    ctx.fillStyle = "#3f6bb0";
    ctx.fillRect(mp.x, mp.y + mp.h - 5, mp.w, 5);
    ctx.strokeStyle = "#ffffff55";
    ctx.strokeRect(mp.x + 0.5, mp.y + 0.5, mp.w - 1, mp.h - 1);
  }

  function drawCoin(c) {
    const t = performance.now() / 200 + c.phase;
    const scaleX = Math.abs(Math.cos(t));
    ctx.save();
    ctx.translate(c.x, c.y);
    ctx.scale(Math.max(0.15, scaleX), 1);
    const grd = ctx.createRadialGradient(0, 0, 1, 0, 0, 12);
    grd.addColorStop(0, "#fff6c8");
    grd.addColorStop(1, "#ffc93c");
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#d18e00";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }

  function drawFlag(f) {
    ctx.fillStyle = "#c9c9c9";
    ctx.fillRect(f.x, f.topY, 6, f.h);
    ctx.beginPath();
    ctx.fillStyle = state === "won" ? "#8be99b" : "#ff5566";
    const waveT = performance.now() / 300;
    ctx.moveTo(f.x + 6, f.topY + 8);
    ctx.quadraticCurveTo(f.x + 34 + Math.sin(waveT) * 4, f.topY + 18, f.x + 6, f.topY + 34);
    ctx.closePath();
    ctx.fill();
    // основание
    ctx.fillStyle = "#999";
    ctx.fillRect(f.x - 8, f.topY + f.h - 6, 22, 6);
  }

  function drawEnemy(en) {
    if (!en.alive && en.squashT <= 0) return;
    ctx.save();
    const cx = en.x + en.w / 2, cy = en.y + en.h;
    if (!en.alive) {
      // сплющенный труп
      ctx.translate(cx, cy);
      ctx.scale(1.3, 0.3);
      ctx.fillStyle = "#8a5aa8";
      ctx.beginPath();
      ctx.arc(0, 0, en.w / 2, Math.PI, 0);
      ctx.fill();
      ctx.restore();
      return;
    }
    const bob = Math.sin(performance.now() / 150 + en.x) * 2;
    ctx.translate(en.x + en.w / 2, en.y + en.h / 2 + bob);
    // тело — фиолетовый шипастый шарик (не является чужим персонажем)
    ctx.fillStyle = "#8a5aa8";
    ctx.beginPath();
    ctx.arc(0, 4, en.w / 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#6d3e8a";
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 9, -en.h / 2 + 6);
      ctx.lineTo(i * 9 - 4, -en.h / 2 - 6);
      ctx.lineTo(i * 9 + 4, -en.h / 2 - 6);
      ctx.closePath();
      ctx.fill();
    }
    // глаза
    const dir = en.vx >= 0 ? 1 : -1;
    ctx.fillStyle = "#fff";
    ctx.beginPath(); ctx.arc(-6 * dir, 2, 5, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(6 * dir, 2, 5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(-6 * dir + dir * 2, 2, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(6 * dir + dir * 2, 2, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawPlayer() {
    ctx.save();
    if (player.hurtTimer > 0 && Math.floor(player.hurtTimer / 4) % 2 === 0) {
      ctx.globalAlpha = 0.4;
    }
    const cx = player.x + player.w / 2;
    const cy = player.y + player.h / 2;
    const moving = Math.abs(player.vx) > 0.3;
    const runCycle = Math.sin(player.animT * 0.6) * (player.onGround && moving ? 6 : 0);

    ctx.translate(cx, cy);
    ctx.scale(player.facing, 1);

    // squash & stretch по вертикальной скорости
    const stretch = player.onGround ? 1 : Math.max(0.85, Math.min(1.15, 1 - player.vy * 0.01));
    ctx.scale(1 / stretch, stretch);

    // ноги
    ctx.fillStyle = "#2b3a67";
    ctx.fillRect(-10, 10 + runCycle * 0.2, 8, 10);
    ctx.fillRect(2, 10 - runCycle * 0.2, 8, 10);

    // тело — оригинальный "кристальный путешественник"
    ctx.fillStyle = "#ff8a3d";
    ctx.beginPath();
    ctx.moveTo(-13, 10);
    ctx.quadraticCurveTo(-15, -12, 0, -14);
    ctx.quadraticCurveTo(15, -12, 13, 10);
    ctx.closePath();
    ctx.fill();

    // рюкзак-кристалл
    ctx.fillStyle = "#5ec8f0";
    ctx.beginPath();
    ctx.moveTo(-13 * -1, -2);
    ctx.lineTo(-13 * -1 + 6, -8);
    ctx.lineTo(-13 * -1 + 6, 4);
    ctx.closePath();
    ctx.fill();

    // голова
    ctx.fillStyle = "#ffd9a0";
    ctx.beginPath();
    ctx.arc(0, -22, 11, 0, Math.PI * 2);
    ctx.fill();

    // очки-гогглы
    ctx.fillStyle = "#2b3a67";
    ctx.beginPath();
    ctx.arc(4, -23, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#bdeaff";
    ctx.beginPath();
    ctx.arc(5, -23, 3, 0, Math.PI * 2);
    ctx.fill();

    // кепка
    ctx.fillStyle = "#e0512f";
    ctx.beginPath();
    ctx.arc(0, -27, 11, Math.PI, 0);
    ctx.fill();
    ctx.fillRect(-2, -30, 14, 6);

    ctx.restore();
  }

  // ============================================================
  // ГЛАВНЫЙ ЦИКЛ
  // ============================================================
  let lastTime = performance.now();
  function frame(now) {
    let dtMs = now - lastTime;
    lastTime = now;
    let dt = dtMs / (1000 / 60);
    dt = Math.max(0.001, Math.min(dt, 2.5));

    if (state === "playing") {
      elapsed += dt / 60; // используем тот же clamped dt, что и физика — таймер не скачет после просадки FPS/сворачивания вкладки
      updateMovingPlatforms(dt);
      updatePlayer(dt);
      updateEnemies(dt);
      updateParticlesAndPopups(dt);

      camera.x = player.x + player.w / 2 - CANVAS_W / 2;
      camera.x = Math.max(0, Math.min(camera.x, level.width - CANVAS_W));

      updateHud();
    }

    draw();
    requestAnimationFrame(frame);
  }

  // ============================================================
  // ВВОД
  // ============================================================
  window.addEventListener("keydown", (e) => {
    ensureAudio();
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    keys[e.code] = true;
    if (e.code === "KeyR") {
      resetAll();
    }
    if (state === "start" && (e.code === "Space")) {
      resetAll();
    }
  });
  window.addEventListener("keyup", (e) => {
    keys[e.code] = false;
  });
  overlayBtn.addEventListener("click", () => {
    ensureAudio();
    resetAll();
  });

  // ============================================================
  // СТАРТ
  // ============================================================
  level = makeLevel();
  player = newPlayer();
  hudTotal.textContent = level.totalCoins;
  showOverlay("Прыг-Скок: Кристальный поход", "Соберите кристаллы и доберитесь до флага в конце уровня. Пробел — начать.", "Начать игру (Space)");

  requestAnimationFrame(frame);
})();
