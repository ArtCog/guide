# Метрики прогона

Тест: 01 — Сокровищница Орбит
Тип: многостраничный сайт магазина редких камней
Модель: Claude Sonnet 5
Статус: готово

Папка результата:
`C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-sonnet-5\`

Главный файл:
`C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-sonnet-5\index.html`

Метрики:
- Стоимость USD: $4.20
- Время API: 15м 6с
- Wall-время: 4ч 58м 28с
- Input tokens: 16,700
- Output tokens: 83,100
- Cache read: 2,600,000
- Cache write: 352,700

Источник:
`BENCHMARK-REPORT.md`

Короткий вердикт:
Заполнить после ручной оценки на арене.
