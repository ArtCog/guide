/* ===========================================================
   СОКРОВИЩНИЦА ОРБИТ — логика заявки на приобретение и навигации
   Данные заявки хранятся в localStorage и доступны на всех страницах.
   =========================================================== */
(function () {
  'use strict';

  var CART_KEY = 'orbitTreasuryRequest';

  function getCart() {
    try {
      return JSON.parse(window.localStorage.getItem(CART_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function persistCart(cart) {
    window.localStorage.setItem(CART_KEY, JSON.stringify(cart));
    renderCart();
  }

  function addToCart(item, qty) {
    var cart = getCart();
    var existing = null;
    for (var i = 0; i < cart.length; i++) {
      if (cart[i].id === item.id) existing = cart[i];
    }
    if (existing) {
      existing.qty += qty;
    } else {
      cart.push({ id: item.id, name: item.name, origin: item.origin, price: item.price, qty: qty });
    }
    persistCart(cart);
  }

  function setQty(id, qty) {
    var cart = getCart();
    if (qty <= 0) {
      cart = cart.filter(function (i) { return i.id !== id; });
    } else {
      cart.forEach(function (i) { if (i.id === id) i.qty = qty; });
    }
    persistCart(cart);
  }

  function removeFromCart(id) {
    persistCart(getCart().filter(function (i) { return i.id !== id; }));
  }

  function cartTotal(cart) {
    return cart.reduce(function (sum, i) { return sum + i.price * i.qty; }, 0);
  }

  function formatPrice(n) {
    return '$' + Math.round(n).toLocaleString('ru-RU');
  }

  function renderCart() {
    var cart = getCart();
    var totalQty = cart.reduce(function (s, i) { return s + i.qty; }, 0);

    document.querySelectorAll('[data-cart-count]').forEach(function (el) {
      el.textContent = String(totalQty);
    });

    var itemsEl = document.getElementById('cart-items');
    var emptyEl = document.getElementById('cart-empty');
    var totalEl = document.getElementById('cart-total');

    if (itemsEl) {
      itemsEl.innerHTML = '';
      if (cart.length === 0) {
        if (emptyEl) emptyEl.style.display = 'block';
      } else {
        if (emptyEl) emptyEl.style.display = 'none';
        cart.forEach(function (item) {
          var row = document.createElement('div');
          row.className = 'cart-item';
          row.innerHTML =
            '<div class="cart-item-top">' +
              '<div>' +
                '<div class="cart-item-name">' + escapeHtml(item.name) + '</div>' +
                '<div class="cart-item-origin">' + escapeHtml(item.origin) + '</div>' +
              '</div>' +
              '<button type="button" class="cart-item-remove" data-remove="' + item.id + '">Убрать</button>' +
            '</div>' +
            '<div class="cart-item-bottom">' +
              '<div class="qty-control">' +
                '<button type="button" data-dec="' + item.id + '">–</button>' +
                '<input type="text" readonly value="' + item.qty + '">' +
                '<button type="button" data-inc="' + item.id + '">+</button>' +
              '</div>' +
              '<div class="cart-item-price">' + formatPrice(item.price * item.qty) + '</div>' +
            '</div>';
          itemsEl.appendChild(row);
        });
      }
    }
    if (totalEl) totalEl.textContent = formatPrice(cartTotal(cart));

    renderRequestSummary(cart);
  }

  function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // --- delegated clicks for +/- and remove inside the drawer ---
  document.addEventListener('click', function (e) {
    var dec = e.target.closest('[data-dec]');
    var inc = e.target.closest('[data-inc]');
    var rem = e.target.closest('[data-remove]');
    if (dec) {
      var cart1 = getCart();
      var item1 = cart1.filter(function (i) { return i.id === dec.getAttribute('data-dec'); })[0];
      if (item1) setQty(item1.id, item1.qty - 1);
    }
    if (inc) {
      var cart2 = getCart();
      var item2 = cart2.filter(function (i) { return i.id === inc.getAttribute('data-inc'); })[0];
      if (item2) setQty(item2.id, item2.qty + 1);
    }
    if (rem) {
      removeFromCart(rem.getAttribute('data-remove'));
    }
  });

  function initDrawer() {
    var toggle = document.getElementById('cart-toggle');
    var drawer = document.getElementById('cart-drawer');
    var overlay = document.getElementById('cart-overlay');
    var closeBtn = document.getElementById('cart-close');
    if (!drawer || !overlay) return;

    function open() { drawer.classList.add('open'); overlay.classList.add('open'); }
    function close() { drawer.classList.remove('open'); overlay.classList.remove('open'); }

    if (toggle) toggle.addEventListener('click', open);
    if (closeBtn) closeBtn.addEventListener('click', close);
    overlay.addEventListener('click', close);

    drawer.dataset.open = 'ready';
    window.__orbitOpenCart = open;
  }

  function initNavToggle() {
    var btn = document.getElementById('nav-toggle');
    if (!btn) return;
    btn.addEventListener('click', function () {
      document.body.classList.toggle('nav-open');
    });
    document.querySelectorAll('.main-nav a').forEach(function (a) {
      a.addEventListener('click', function () { document.body.classList.remove('nav-open'); });
    });
  }

  function markActiveNav() {
    var path = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.main-nav a').forEach(function (a) {
      if (a.getAttribute('href') === path) a.classList.add('active');
    });
  }

  function initCatalogCards() {
    document.querySelectorAll('.specimen-card[data-id]').forEach(function (card) {
      var id = card.getAttribute('data-id');
      var name = card.getAttribute('data-name');
      var origin = card.getAttribute('data-origin');
      var price = parseFloat(card.getAttribute('data-price'));
      var qtyInput = card.querySelector('.qty-control input');
      var addBtn = card.querySelector('.add-btn');
      var decBtn = card.querySelector('[data-qty-dec]');
      var incBtn = card.querySelector('[data-qty-inc]');

      if (decBtn) decBtn.addEventListener('click', function () {
        qtyInput.value = String(Math.max(1, parseInt(qtyInput.value, 10) - 1));
      });
      if (incBtn) incBtn.addEventListener('click', function () {
        qtyInput.value = String(Math.min(20, parseInt(qtyInput.value, 10) + 1));
      });
      if (addBtn) addBtn.addEventListener('click', function () {
        var qty = parseInt(qtyInput.value, 10) || 1;
        addToCart({ id: id, name: name, origin: origin, price: price }, qty);
        qtyInput.value = '1';
        var original = addBtn.textContent;
        addBtn.textContent = 'Добавлено ✓';
        addBtn.classList.add('added');
        if (window.__orbitOpenCart) window.__orbitOpenCart();
        setTimeout(function () {
          addBtn.textContent = original;
          addBtn.classList.remove('added');
        }, 1600);
      });
    });
  }

  function renderRequestSummary(cart) {
    var summaryEl = document.getElementById('request-summary');
    if (!summaryEl) return;
    var tbody = summaryEl.querySelector('tbody');
    if (cart.length === 0) {
      summaryEl.classList.remove('visible');
      return;
    }
    summaryEl.classList.add('visible');
    tbody.innerHTML = '';
    cart.forEach(function (item) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>' + escapeHtml(item.name) + ' × ' + item.qty + '</td><td>' + formatPrice(item.price * item.qty) + '</td>';
      tbody.appendChild(tr);
    });
    var totalRow = document.createElement('tr');
    totalRow.className = 'total-row';
    totalRow.innerHTML = '<td>Итого к заявке</td><td>' + formatPrice(cartTotal(cart)) + '</td>';
    tbody.appendChild(totalRow);
  }

  function initForms() {
    document.querySelectorAll('form[data-confirm-form]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var confirmEl = document.getElementById(form.getAttribute('data-confirm-form'));
        form.style.display = 'none';
        if (confirmEl) confirmEl.classList.add('visible');
        if (form.id === 'request-form') {
          window.localStorage.removeItem(CART_KEY);
          var summaryEl = document.getElementById('request-summary');
          if (summaryEl) summaryEl.classList.remove('visible');
          renderCart();
        }
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initDrawer();
    initNavToggle();
    markActiveNav();
    initCatalogCards();
    initForms();
    renderCart();
  });
})();
