# 01 — Сокровищница Орбит — Sonnet 5

Результат первого теста: многостраничный сайт магазина редких камней Солнечной системы.

Модель: Claude Sonnet 5

Открыть:

```text
C:\Users\magme\TEST FABLE VS OPUS VS SONNET\01-sokrovishnitsa-orbit-site-sonnet-5\index.html
```

Метрики прогона:

```text
RUN-METRICS.md
```
