# RUN-METRICS

- Модель: Claude Sonnet 5 (claude-sonnet-5)
- Тест: 02 — «Последняя смена», хоррор-игра от первого лица (raycasting-прототип)
- Время задачи: 13m 30s
- Время API: 34m 52s
- Wall-время (CLI-сессия, из скриншота пользователя): 10h 2m 55s — включает время всей CLI-сессии, не только этой задачи
- Реальное время на задачу (по таймстемпам лога сессии, от первого сообщения до финальной сдачи): 4ч 26м 04с (12:46:09 → 17:12:12 UTC, 2026-07-02). Внутри этого интервала — большие паузы бездействия (крупнейшая ~3ч 02м, между 13:50 и 16:52, когда сессия висела без активности/фоновая задача была прервана по таймауту). За вычетом пауз бездействия чистое активное время ≈ 20м 40с, что близко совпадает со «Время API: 34m 52s».
- Input tokens: 21.5k
- Output tokens: 81.9k
- Cache read: 6.7m
- Cache write: 311.4k
- Стоимость USD: $5.15
- Путь к index.html: `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-sonnet-5\index.html`
- Короткий вердикт: Рабочий прототип — raycasting-движок на canvas, ИИ демона (BFS pathfinding), процедурный звук на Web Audio API, полный цикл (3 ключ-карты → генератор → выход), победа/поражение с рестартом. Логика проверена автоматизированным CDP-тестом headless-Chrome (движение, коллизии, батарея, таймер демона — без ошибок в консоли); визуально человеком в браузере не просмотрено (расширение claude-in-chrome было недоступно в сессии).

## Time correction

- Время задачи обновлено по финальному сообщению Claude Code: `Cooked for 13m 30s`.
- Старое API-время оставлено справочно и не используется как рабочее время задачи.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $9.35 / 34.9k input / 164.9k output / 9.3m cache read / 664.1k cache write.
- Previous checkpoint: $4.20 / 16.7k input / 83.1k output / 2.6m cache read / 352.7k cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
