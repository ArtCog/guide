'use strict';

/* ============================================================
   ПОСЛЕДНЯЯ СМЕНА — pseudo-3D horror prototype
   Raycasting engine (no external assets, no libraries)
   ============================================================ */

// ---------- Map ----------
const MAP_W = 15, MAP_H = 11;

function buildMap() {
  const g = [];
  for (let y = 0; y < MAP_H; y++) g.push(new Array(MAP_W).fill(1));

  // outer ring corridor (donut loop)
  for (let x = 1; x <= 13; x++) { g[1][x] = 0; g[9][x] = 0; }
  for (let y = 1; y <= 9; y++) { g[y][1] = 0; g[y][13] = 0; }

  // north room (procedure room) + doorway
  g[2][7] = 0;
  for (let y = 3; y <= 4; y++) for (let x = 6; x <= 8; x++) g[y][x] = 0;

  // south room (generator room) + doorway
  g[8][7] = 0;
  for (let y = 6; y <= 7; y++) for (let x = 6; x <= 8; x++) g[y][x] = 0;

  // east room (cold storage) + doorway
  g[5][12] = 0;
  for (let y = 4; y <= 6; y++) for (let x = 10; x <= 11; x++) g[y][x] = 0;

  // west room (records room) + doorway
  g[5][2] = 0;
  for (let y = 4; y <= 6; y++) for (let x = 3; x <= 4; x++) g[y][x] = 0;

  // exit door, embedded in the border wall
  g[5][0] = 2; // locked until generator active

  return g;
}

function getWallTheme(mx, my) {
  if (my === 5 && mx === 0) return 'door';
  if (mx >= 5 && mx <= 9 && my >= 1 && my <= 5) return 'tile';   // procedure room zone
  if (mx >= 9 && mx <= 13 && my >= 3 && my <= 7) return 'steel'; // cold storage zone
  return 'concrete';
}

const THEME_COLORS = {
  concrete: [72, 68, 62],
  tile:     [48, 72, 62],
  steel:    [54, 68, 82],
  door:     [96, 64, 18]
};

// ---------- DOM ----------
const viewCanvas = document.getElementById('viewCanvas');
const fxCanvas = document.getElementById('fxCanvas');
const vctx = viewCanvas.getContext('2d');
const fctx = fxCanvas.getContext('2d');

const RENDER_W = 800, RENDER_H = 450;
viewCanvas.width = RENDER_W; viewCanvas.height = RENDER_H;
fxCanvas.width = RENDER_W; fxCanvas.height = RENDER_H;

const FOV = 75 * Math.PI / 180;
const PROJ_DIST = (RENDER_W / 2) / Math.tan(FOV / 2);

const batteryFill = document.getElementById('batteryFill');
const genStatus = document.getElementById('genStatus');
const promptEl = document.getElementById('prompt');
const heartbeatFlash = document.getElementById('heartbeatFlash');
const keyEls = [document.getElementById('key0'), document.getElementById('key1'), document.getElementById('key2')];

const startScreen = document.getElementById('startScreen');
const loseScreen = document.getElementById('loseScreen');
const winScreen = document.getElementById('winScreen');
const demonFaceEl = document.getElementById('demonFace');

// ---------- Audio ----------
const Audio1 = {
  ctx: null, master: null, ambientNodes: null,
  heartbeatTimer: 0, heartbeatInterval: 1.1,

  init() {
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.55;
    this.master.connect(this.ctx.destination);
    this.startAmbient();
  },

  startAmbient() {
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = 48;
    const gain = ctx.createGain();
    gain.gain.value = 0.05;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.02;
    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(); lfo.start();
    this.ambientNodes = { osc, gain, lfo };
  },

  noiseBurst(duration, freqStart, freqEnd, gainVal) {
    const ctx = this.ctx;
    const bufferSize = ctx.sampleRate * duration;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(freqStart, ctx.currentTime);
    filter.frequency.linearRampToValueAtTime(freqEnd, ctx.currentTime + duration);
    const g = ctx.createGain();
    g.gain.value = gainVal;
    src.connect(filter); filter.connect(g); g.connect(this.master);
    src.start();
    return src;
  },

  click(freq, dur, vol) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
    osc.connect(g); g.connect(this.master);
    osc.start(); osc.stop(ctx.currentTime + dur);
  },

  flashlightToggle() { this.click(220, 0.06, 0.15); },

  pickup() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.18);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.2, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
    osc.connect(g); g.connect(this.master);
    osc.start(); osc.stop(ctx.currentTime + 0.25);
  },

  generatorStart() {
    if (!this.ctx) return;
    this.noiseBurst(1.2, 80, 300, 0.25);
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(40, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(90, ctx.currentTime + 1.0);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.001, ctx.currentTime);
    g.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 1.0);
    osc.connect(g); g.connect(this.master);
    osc.start(); osc.stop(ctx.currentTime + 3);
  },

  hiss() { if (this.ctx) this.noiseBurst(0.4, 800, 200, 0.12); },

  heartbeat() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(70, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + 0.15);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.4, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
    osc.connect(g); g.connect(this.master);
    osc.start(); osc.stop(ctx.currentTime + 0.25);
  },

  updateHeartbeat(dist, dt) {
    if (!this.ctx) return;
    if (dist > 5.5) return;
    const proximity = 1 - Math.min(dist / 5.5, 1);
    this.heartbeatInterval = 1.15 - proximity * 0.85;
    this.heartbeatTimer -= dt;
    if (this.heartbeatTimer <= 0) {
      this.heartbeat();
      this.heartbeatTimer = this.heartbeatInterval;
    }
  },

  jumpscare() {
    if (!this.ctx) return;
    this.noiseBurst(1.4, 1200, 60, 0.5);
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 1.3);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.4, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.4);
    osc.connect(g); g.connect(this.master);
    osc.start(); osc.stop(ctx.currentTime + 1.5);
  },

  win() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    [523, 659, 784].forEach((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine'; osc.frequency.value = f;
      const g = ctx.createGain();
      const t0 = ctx.currentTime + i * 0.18;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(0.2, t0 + 0.05);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.6);
      osc.connect(g); g.connect(this.master);
      osc.start(t0); osc.stop(t0 + 0.7);
    });
  },

  footstep() { this.click(90 + Math.random() * 20, 0.04, 0.05); }
};

// ---------- Game state ----------
let state = 'start'; // start | playing | won | lost
let grid, player, demon, keys, generator, exitCell;
let elapsedTime = 0;
let lastTime = 0;
let flickerPhase = 0;

const input = { forward: false, back: false, left: false, right: false, turnL: false, turnR: false };
let pointerLocked = false;

function resetGame() {
  grid = buildMap();

  player = {
    x: 2.5, y: 1.5,
    angle: 0,
    radius: 0.22,
    speed: 2.6,
    flashlightOn: false,
    battery: 100
  };

  keys = [
    { x: 7.5, y: 3.5, collected: false, id: 0, bob: Math.random() * 10 },
    { x: 10.5, y: 5.5, collected: false, id: 1, bob: Math.random() * 10 },
    { x: 3.5, y: 5.5, collected: false, id: 2, bob: Math.random() * 10 }
  ];

  generator = { x: 7.5, y: 6.5, active: false };
  exitCell = { x: 0.5, y: 5.5 };

  demon = {
    x: 12.5, y: 9.5,
    speed: 0.95,
    path: [],
    repathTimer: 0,
    catchRadius: 0.55,
    wasLit: false,
    active: false, // grace period before hunting starts
    graceTimer: 5.5,
    flinchTimer: 0,
    visible: false
  };

  elapsedTime = 0;
  keyEls.forEach(el => el.classList.remove('collected'));
  genStatus.textContent = 'ВЫКЛЮЧЕН';
  genStatus.classList.remove('on');
  batteryFill.style.width = '100%';
  batteryFill.classList.remove('low');
  heartbeatFlash.style.background = 'rgba(139,0,0,0)';
}

// ---------- Input ----------
window.addEventListener('keydown', (e) => {
  switch (e.code) {
    case 'KeyW': case 'ArrowUp': input.forward = true; break;
    case 'KeyS': case 'ArrowDown': input.back = true; break;
    case 'KeyA': input.left = true; break;
    case 'KeyD': input.right = true; break;
    case 'ArrowLeft': input.turnL = true; break;
    case 'ArrowRight': input.turnR = true; break;
    case 'KeyF': toggleFlashlight(); break;
    case 'KeyE': tryInteract(); break;
  }
  if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)) e.preventDefault();
});

window.addEventListener('keyup', (e) => {
  switch (e.code) {
    case 'KeyW': case 'ArrowUp': input.forward = false; break;
    case 'KeyS': case 'ArrowDown': input.back = false; break;
    case 'KeyA': input.left = false; break;
    case 'KeyD': input.right = false; break;
    case 'ArrowLeft': input.turnL = false; break;
    case 'ArrowRight': input.turnR = false; break;
  }
});

viewCanvas.addEventListener('click', () => {
  if (state === 'playing' && !pointerLocked) {
    requestPointerLockSafe();
  }
});

function requestPointerLockSafe() {
  const result = viewCanvas.requestPointerLock();
  if (result && typeof result.catch === 'function') result.catch(() => {});
}

document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === viewCanvas;
});

document.addEventListener('mousemove', (e) => {
  if (!pointerLocked || state !== 'playing') return;
  player.angle += e.movementX * 0.0028;
});

function toggleFlashlight() {
  if (state !== 'playing') return;
  if (player.battery <= 0) { player.flashlightOn = false; return; }
  player.flashlightOn = !player.flashlightOn;
  Audio1.flashlightToggle();
}

function tryInteract() {
  if (state !== 'playing') return;
  const dg = Math.hypot(player.x - generator.x, player.y - generator.y);
  if (dg < 1.3 && !generator.active) {
    const collected = keys.filter(k => k.collected).length;
    if (collected >= 3) {
      generator.active = true;
      grid[5][0] = 0; // unlock exit door
      genStatus.textContent = 'ВКЛЮЧЁН';
      genStatus.classList.add('on');
      Audio1.generatorStart();
    }
  }
}

// ---------- Collision ----------
function isWalkable(cx, cy) {
  if (cx < 0 || cy < 0 || cx >= MAP_W || cy >= MAP_H) return false;
  return grid[cy][cx] === 0;
}

function tryMovePlayer(dx, dy) {
  const r = player.radius;
  let nx = player.x + dx;
  let ny = player.y + dy;

  // X axis
  if (dx !== 0) {
    const checkX = dx > 0 ? nx + r : nx - r;
    if (isWalkable(Math.floor(checkX), Math.floor(player.y - r)) &&
        isWalkable(Math.floor(checkX), Math.floor(player.y + r))) {
      player.x = nx;
    }
  }
  // Y axis
  if (dy !== 0) {
    const checkY = dy > 0 ? ny + r : ny - r;
    if (isWalkable(Math.floor(player.x - r), Math.floor(checkY)) &&
        isWalkable(Math.floor(player.x + r), Math.floor(checkY))) {
      player.y = ny;
    }
  }
}

// ---------- Demon AI (BFS pathing on grid) ----------
function bfsPath(sx, sy, tx, ty) {
  if (sx === tx && sy === ty) return [];
  const visited = Array.from({ length: MAP_H }, () => new Array(MAP_W).fill(false));
  const prev = Array.from({ length: MAP_H }, () => new Array(MAP_W).fill(null));
  const q = [[sx, sy]];
  visited[sy][sx] = true;
  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
  let found = false;
  while (q.length) {
    const [cx, cy] = q.shift();
    if (cx === tx && cy === ty) { found = true; break; }
    for (const [dx, dy] of dirs) {
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= MAP_W || ny >= MAP_H) continue;
      if (visited[ny][nx] || grid[ny][nx] !== 0) continue;
      visited[ny][nx] = true;
      prev[ny][nx] = [cx, cy];
      q.push([nx, ny]);
    }
  }
  if (!found) return [];
  const path = [];
  let cur = [tx, ty];
  while (cur && !(cur[0] === sx && cur[1] === sy)) {
    path.unshift(cur);
    cur = prev[cur[1]][cur[0]];
  }
  return path;
}

function updateDemon(dt) {
  if (demon.graceTimer > 0) {
    demon.graceTimer -= dt;
    return;
  }
  demon.active = true;

  demon.repathTimer -= dt;
  if (demon.repathTimer <= 0) {
    demon.repathTimer = 0.55;
    const path = bfsPath(Math.floor(demon.x), Math.floor(demon.y), Math.floor(player.x), Math.floor(player.y));
    demon.path = path.map(([cx, cy]) => ({ x: cx + 0.5, y: cy + 0.5 }));
  }

  // difficulty scaling over time
  const baseSpeed = 0.95 + Math.min(elapsedTime / 40, 1.0) * 0.85;

  // check illumination
  const dx = demon.x - player.x, dy = demon.y - player.y;
  const dist = Math.hypot(dx, dy);
  let angleToDemon = Math.atan2(dy, dx) - player.angle;
  while (angleToDemon > Math.PI) angleToDemon -= Math.PI * 2;
  while (angleToDemon < -Math.PI) angleToDemon += Math.PI * 2;
  const lit = player.flashlightOn && dist < 6.5 && Math.abs(angleToDemon) < (FOV * 0.4) && hasLineOfSight(player.x, player.y, demon.x, demon.y);

  if (lit && !demon.wasLit) {
    Audio1.hiss();
    demon.flinchTimer = 0.5;
  }
  demon.wasLit = lit;

  let speed = baseSpeed;
  if (lit) speed *= 0.32;
  if (demon.flinchTimer > 0) { demon.flinchTimer -= dt; speed *= 0.1; }

  if (demon.path.length > 0) {
    const target = demon.path[0];
    const tdx = target.x - demon.x, tdy = target.y - demon.y;
    const tdist = Math.hypot(tdx, tdy);
    if (tdist < 0.12) {
      demon.path.shift();
    } else {
      demon.x += (tdx / tdist) * speed * dt;
      demon.y += (tdy / tdist) * speed * dt;
    }
  }
}

function hasLineOfSight(x0, y0, x1, y1) {
  const dist = Math.hypot(x1 - x0, y1 - y0);
  const steps = Math.ceil(dist * 4);
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const sx = x0 + (x1 - x0) * t;
    const sy = y0 + (y1 - y0) * t;
    if (grid[Math.floor(sy)][Math.floor(sx)] !== 0) return false;
  }
  return true;
}

// ---------- Update loop ----------
function update(dt) {
  elapsedTime += dt;
  flickerPhase += dt;

  // rotation
  const turnSpeed = 2.1;
  if (input.turnL) player.angle -= turnSpeed * dt;
  if (input.turnR) player.angle += turnSpeed * dt;

  // movement
  let mx = 0, my = 0;
  const cos = Math.cos(player.angle), sin = Math.sin(player.angle);
  if (input.forward) { mx += cos; my += sin; }
  if (input.back) { mx -= cos; my -= sin; }
  if (input.left) { mx += Math.cos(player.angle - Math.PI / 2); my += Math.sin(player.angle - Math.PI / 2); }
  if (input.right) { mx += Math.cos(player.angle + Math.PI / 2); my += Math.sin(player.angle + Math.PI / 2); }
  const mlen = Math.hypot(mx, my);
  if (mlen > 0.001) {
    mx = (mx / mlen) * player.speed * dt;
    my = (my / mlen) * player.speed * dt;
    tryMovePlayer(mx, my);
  }

  // battery
  if (player.flashlightOn) {
    player.battery -= 3.0 * dt;
    if (player.battery <= 0) { player.battery = 0; player.flashlightOn = false; }
  }
  batteryFill.style.width = player.battery + '%';
  batteryFill.classList.toggle('low', player.battery < 20);

  // key pickups
  keys.forEach((k, i) => {
    if (k.collected) return;
    k.bob += dt * 3;
    if (Math.hypot(player.x - k.x, player.y - k.y) < 0.55) {
      k.collected = true;
      keyEls[i].classList.add('collected');
      Audio1.pickup();
    }
  });

  updateDemon(dt);

  // heartbeat / dread audio + screen flash
  const demonDist = Math.hypot(player.x - demon.x, player.y - demon.y);
  Audio1.updateHeartbeat(demon.active ? demonDist : 999, dt);
  if (demon.active && demonDist < 5.5) {
    const t = 1 - Math.min(demonDist / 5.5, 1);
    heartbeatFlash.style.background = `rgba(120,0,0,${(t * 0.22).toFixed(3)})`;
  } else {
    heartbeatFlash.style.background = 'rgba(139,0,0,0)';
  }

  // interact prompt
  updatePrompt();

  // catch check
  if (demon.active && demonDist < demon.catchRadius) {
    triggerLose();
    return;
  }

  // win check
  const collected = keys.filter(k => k.collected).length;
  if (generator.active && Math.floor(player.x) === 0 && Math.floor(player.y) === 5) {
    triggerWin();
  }
}

function updatePrompt() {
  const dg = Math.hypot(player.x - generator.x, player.y - generator.y);
  const collected = keys.filter(k => k.collected).length;
  if (dg < 1.4 && !generator.active) {
    promptEl.textContent = collected >= 3
      ? 'Нажмите [E] — включить генератор'
      : `Генератор: нужно 3 ключ-карты (у вас ${collected}/3)`;
    promptEl.classList.add('visible');
  } else if (generator.active && Math.hypot(player.x - exitCell.x, player.y - exitCell.y) < 2.2) {
    promptEl.textContent = 'Выход открыт — идите к двери';
    promptEl.classList.add('visible');
  } else {
    promptEl.classList.remove('visible');
  }
}

// ---------- Rendering ----------
let ceilingGrad, floorGrad;
function buildGradients() {
  ceilingGrad = vctx.createLinearGradient(0, 0, 0, RENDER_H / 2);
  ceilingGrad.addColorStop(0, '#020203');
  ceilingGrad.addColorStop(1, '#0c0c10');
  floorGrad = vctx.createLinearGradient(0, RENDER_H / 2, 0, RENDER_H);
  floorGrad.addColorStop(0, '#100d0a');
  floorGrad.addColorStop(1, '#050403');
}
buildGradients();

const AMBIENT_RANGE = 3.4, AMBIENT_MAX = 0.16;
const FLASH_RANGE = 7.5, FLASH_MAX = 1.0;

let zbuffer = new Float32Array(RENDER_W);

function render() {
  vctx.clearRect(0, 0, RENDER_W, RENDER_H);
  fctx.clearRect(0, 0, RENDER_W, RENDER_H);

  // screen shake near demon
  let shakeX = 0, shakeY = 0;
  if (demon.active) {
    const d = Math.hypot(player.x - demon.x, player.y - demon.y);
    if (d < 3.5) {
      const s = (1 - d / 3.5) * 4;
      shakeX = (Math.random() - 0.5) * s;
      shakeY = (Math.random() - 0.5) * s;
    }
  }
  vctx.save();
  vctx.translate(shakeX, shakeY);

  vctx.fillStyle = ceilingGrad;
  vctx.fillRect(0, 0, RENDER_W, RENDER_H / 2);
  vctx.fillStyle = floorGrad;
  vctx.fillRect(0, RENDER_H / 2, RENDER_W, RENDER_H / 2);

  const flicker = 0.9 + Math.sin(flickerPhase * 13.1) * 0.03 + (Math.random() - 0.5) * 0.02;

  for (let col = 0; col < RENDER_W; col++) {
    const cameraX = (col / RENDER_W) * 2 - 1;
    const rayAngleOffset = cameraX * (FOV / 2);
    const rayAngle = player.angle + rayAngleOffset;
    const rayDirX = Math.cos(rayAngle), rayDirY = Math.sin(rayAngle);

    let mapX = Math.floor(player.x), mapY = Math.floor(player.y);
    const deltaDistX = Math.abs(1 / (rayDirX || 1e-9));
    const deltaDistY = Math.abs(1 / (rayDirY || 1e-9));
    const stepX = rayDirX < 0 ? -1 : 1;
    const stepY = rayDirY < 0 ? -1 : 1;
    let sideDistX = rayDirX < 0 ? (player.x - mapX) * deltaDistX : (mapX + 1 - player.x) * deltaDistX;
    let sideDistY = rayDirY < 0 ? (player.y - mapY) * deltaDistY : (mapY + 1 - player.y) * deltaDistY;

    let hit = false, side = 0, steps = 0;
    while (!hit && steps < 40) {
      if (sideDistX < sideDistY) { sideDistX += deltaDistX; mapX += stepX; side = 0; }
      else { sideDistY += deltaDistY; mapY += stepY; side = 1; }
      steps++;
      if (mapX < 0 || mapY < 0 || mapX >= MAP_W || mapY >= MAP_H) { hit = true; break; }
      if (grid[mapY][mapX] !== 0) hit = true;
    }

    const rawDist = side === 0 ? (sideDistX - deltaDistX) : (sideDistY - deltaDistY);
    const dist = Math.max(0.05, rawDist * Math.cos(rayAngleOffset));
    zbuffer[col] = dist;

    const lineHeight = Math.min(RENDER_H * 3, (PROJ_DIST * 1.0) / dist);
    const drawStart = Math.max(0, RENDER_H / 2 - lineHeight / 2);
    const drawEnd = Math.min(RENDER_H, RENDER_H / 2 + lineHeight / 2);

    const theme = (mapX >= 0 && mapY >= 0 && mapX < MAP_W && mapY < MAP_H) ? getWallTheme(mapX, mapY) : 'concrete';
    const base = THEME_COLORS[theme] || THEME_COLORS.concrete;
    const sideMul = side === 1 ? 0.68 : 1.0;

    const ambient = Math.max(0, 1 - dist / AMBIENT_RANGE) * AMBIENT_MAX;
    const flash = player.flashlightOn ? Math.max(0, 1 - dist / FLASH_RANGE) * FLASH_MAX : 0;
    let light = Math.min(1, (ambient + flash)) * flicker;

    let r = base[0] * sideMul * light;
    let g = base[1] * sideMul * light;
    let b = base[2] * sideMul * light;

    if (theme === 'door') { r *= 1.4; g *= 1.05; b *= 0.5; }

    vctx.fillStyle = `rgb(${r|0},${g|0},${b|0})`;
    vctx.fillRect(col, drawStart, 1.5, drawEnd - drawStart);
  }

  renderSprites();
  vctx.restore();

  // flashlight glow overlay
  if (player.flashlightOn) {
    const grad = fctx.createRadialGradient(RENDER_W / 2, RENDER_H / 2 + 20, 10, RENDER_W / 2, RENDER_H / 2 + 20, RENDER_W * 0.42);
    grad.addColorStop(0, 'rgba(255,244,214,0.16)');
    grad.addColorStop(1, 'rgba(255,244,214,0)');
    fctx.fillStyle = grad;
    fctx.fillRect(0, 0, RENDER_W, RENDER_H);
  }
}

function renderSprites() {
  const sprites = [];
  keys.forEach(k => { if (!k.collected) sprites.push({ type: 'key', obj: k, x: k.x, y: k.y }); });
  if (!generator.active) sprites.push({ type: 'genOff', x: generator.x, y: generator.y });
  else sprites.push({ type: 'genOn', x: generator.x, y: generator.y });
  if (demon.graceTimer <= 0) sprites.push({ type: 'demon', x: demon.x, y: demon.y });

  sprites.forEach(s => {
    const dx = s.x - player.x, dy = s.y - player.y;
    s.dist = Math.hypot(dx, dy);
    s.angle = Math.atan2(dy, dx) - player.angle;
    while (s.angle > Math.PI) s.angle -= Math.PI * 2;
    while (s.angle < -Math.PI) s.angle += Math.PI * 2;
  });
  sprites.sort((a, b) => b.dist - a.dist);

  sprites.forEach(s => {
    if (Math.abs(s.angle) > FOV / 2 + 0.5) return;
    const corrDist = Math.max(0.1, s.dist * Math.cos(s.angle));
    const screenX = RENDER_W / 2 + Math.tan(s.angle) * PROJ_DIST;

    if (s.type === 'demon') drawDemon(s, screenX, corrDist);
    else if (s.type === 'key') drawKeycard(s, screenX, corrDist);
    else drawGenerator(s, screenX, corrDist, s.type === 'genOn');
  });
}

function visibleRanges(screenX, halfWidth, dist) {
  const left = Math.max(0, Math.floor(screenX - halfWidth));
  const right = Math.min(RENDER_W - 1, Math.ceil(screenX + halfWidth));
  const ranges = [];
  let runStart = null;
  for (let col = left; col <= right; col++) {
    const vis = dist < zbuffer[col];
    if (vis && runStart === null) runStart = col;
    if (!vis && runStart !== null) { ranges.push([runStart, col - 1]); runStart = null; }
  }
  if (runStart !== null) ranges.push([runStart, right]);
  return ranges;
}

function lightAt(dist) {
  const ambient = Math.max(0, 1 - dist / AMBIENT_RANGE) * AMBIENT_MAX;
  const flash = player.flashlightOn ? Math.max(0, 1 - dist / FLASH_RANGE) * FLASH_MAX : 0;
  return Math.min(1, ambient + flash);
}

function drawKeycard(s, screenX, dist) {
  const size = Math.min(RENDER_H, (PROJ_DIST * 0.32) / dist);
  const bobOffset = Math.sin(s.obj.bob) * size * 0.08;
  const top = RENDER_H / 2 + size * 0.35 + bobOffset;
  const ranges = visibleRanges(screenX, size * 0.35, dist);
  const light = Math.max(lightAt(dist), 0.18);
  ranges.forEach(([l, r]) => {
    vctx.save();
    vctx.beginPath();
    vctx.rect(l, 0, r - l + 1, RENDER_H);
    vctx.clip();
    vctx.fillStyle = `rgba(${212*light|0},${175*light|0},${55*light|0},1)`;
    vctx.shadowColor = 'rgba(255,215,0,0.9)';
    vctx.shadowBlur = 14;
    roundRect(vctx, screenX - size * 0.35, top - size * 0.22, size * 0.7, size * 0.44, size * 0.06);
    vctx.fill();
    vctx.restore();
  });
}

function drawGenerator(s, screenX, dist, on) {
  const size = Math.min(RENDER_H, (PROJ_DIST * 0.9) / dist);
  const top = RENDER_H / 2 + size * 0.05;
  const ranges = visibleRanges(screenX, size * 0.32, dist);
  const light = Math.max(lightAt(dist), 0.12);
  ranges.forEach(([l, r]) => {
    vctx.save();
    vctx.beginPath();
    vctx.rect(l, 0, r - l + 1, RENDER_H);
    vctx.clip();
    vctx.fillStyle = `rgb(${30*light|0},${30*light|0},${32*light|0})`;
    vctx.fillRect(screenX - size * 0.3, top - size * 0.35, size * 0.6, size * 0.6);
    const glow = on ? `rgba(70,${220*light|0},80,0.9)` : `rgba(${200*light|0},30,20,0.9)`;
    vctx.fillStyle = glow;
    vctx.shadowColor = glow;
    vctx.shadowBlur = on ? 18 : 8;
    vctx.fillRect(screenX - size * 0.12, top - size * 0.22, size * 0.24, size * 0.08);
    vctx.restore();
  });
}

function drawDemon(s, screenX, dist) {
  const dx = s.x - player.x, dy = s.y - player.y;
  const angleToDemon = Math.atan2(dy, dx) - player.angle;
  const lit = player.flashlightOn && dist < 6.5 && Math.abs(angleToDemon) < FOV * 0.4 &&
              hasLineOfSight(player.x, player.y, demon.x, demon.y);
  demon.visible = lit || dist < AMBIENT_RANGE + 0.8;
  if (!demon.visible) return;

  const height = Math.min(RENDER_H * 2.6, (PROJ_DIST * 2.15) / dist);
  const width = height * 0.42;
  const bottom = RENDER_H / 2 + height * 0.42;
  const top = bottom - height;

  const ranges = visibleRanges(screenX, width * 0.55, dist);
  const visStrength = lit ? 1 : Math.max(0.1, (AMBIENT_RANGE + 0.8 - dist) / (AMBIENT_RANGE + 0.8)) * 0.55;
  // faint rim visibility even when not directly lit, so the silhouette can be glimpsed in near-darkness
  const rimStrength = Math.max(visStrength, dist < AMBIENT_RANGE + 1.2 ? 0.22 : 0);

  ranges.forEach(([l, r]) => {
    vctx.save();
    vctx.beginPath();
    vctx.rect(l, 0, r - l + 1, RENDER_H);
    vctx.clip();

    // body — kept dark but with enough base value to read as a silhouette against pure black
    vctx.fillStyle = `rgba(${34 * visStrength + 4},${22 * visStrength + 3},${30 * visStrength + 4},1)`;
    vctx.beginPath();
    vctx.moveTo(screenX - width * 0.5, bottom);
    vctx.lineTo(screenX - width * 0.28, top + height * 0.28);
    vctx.lineTo(screenX, top);
    vctx.lineTo(screenX + width * 0.28, top + height * 0.28);
    vctx.lineTo(screenX + width * 0.5, bottom);
    vctx.closePath();
    vctx.fill();
    // dim rim outline for silhouette definition against the background
    vctx.strokeStyle = `rgba(120,40,55,${rimStrength * 0.7})`;
    vctx.lineWidth = Math.max(1, width * 0.025);
    vctx.stroke();

    // arms
    vctx.strokeStyle = `rgba(${26 * visStrength + 3},${18 * visStrength + 2},${26 * visStrength + 3},0.95)`;
    vctx.lineWidth = Math.max(1, width * 0.08);
    vctx.beginPath();
    vctx.moveTo(screenX - width * 0.42, top + height * 0.35);
    vctx.lineTo(screenX - width * 0.7, bottom - height * 0.05);
    vctx.moveTo(screenX + width * 0.42, top + height * 0.35);
    vctx.lineTo(screenX + width * 0.7, bottom - height * 0.05);
    vctx.stroke();

    // eyes — always at least faintly visible (classic "eyes in the dark")
    const eyeGlow = Math.max(visStrength, dist < AMBIENT_RANGE + 1.2 ? 0.35 : 0);
    if (eyeGlow > 0.05) {
      const eyeY = top + height * 0.16;
      const eyeSpacing = width * 0.14;
      const eyeR = Math.max(1.5, width * 0.045);
      [-1, 1].forEach(side => {
        const ex = screenX + side * eyeSpacing;
        const grad = vctx.createRadialGradient(ex, eyeY, 0, ex, eyeY, eyeR * 4);
        grad.addColorStop(0, `rgba(255,60,30,${eyeGlow})`);
        grad.addColorStop(1, 'rgba(255,60,30,0)');
        vctx.fillStyle = grad;
        vctx.beginPath();
        vctx.arc(ex, eyeY, eyeR * 4, 0, Math.PI * 2);
        vctx.fill();
        vctx.fillStyle = `rgba(255,140,60,${Math.min(1, eyeGlow + 0.3)})`;
        vctx.beginPath();
        vctx.arc(ex, eyeY, eyeR, 0, Math.PI * 2);
        vctx.fill();
      });
    }

    // jagged mouth when close & lit
    if (lit && dist < 3.0) {
      const mouthY = top + height * 0.24;
      vctx.strokeStyle = `rgba(200,20,20,${visStrength})`;
      vctx.lineWidth = Math.max(1, width * 0.03);
      vctx.beginPath();
      const teeth = 6;
      for (let i = 0; i <= teeth; i++) {
        const tx = screenX - width * 0.12 + (width * 0.24) * (i / teeth);
        const ty = mouthY + (i % 2 === 0 ? 0 : width * 0.06);
        if (i === 0) vctx.moveTo(tx, ty); else vctx.lineTo(tx, ty);
      }
      vctx.stroke();
    }

    vctx.restore();
  });
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ---------- Demon face for lose screen ----------
function drawDemonFaceOverlay() {
  demonFaceEl.innerHTML = '';
  const c = document.createElement('canvas');
  c.width = 320; c.height = 320;
  demonFaceEl.appendChild(c);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, 320, 320);

  const grad = ctx.createRadialGradient(160, 160, 20, 160, 160, 200);
  grad.addColorStop(0, '#1a0505');
  grad.addColorStop(1, '#000');
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(160, 170, 190, 0, Math.PI * 2); ctx.fill();

  // head shape
  ctx.fillStyle = '#0a0708';
  ctx.beginPath();
  ctx.moveTo(160, 40);
  ctx.bezierCurveTo(90, 60, 70, 160, 100, 250);
  ctx.bezierCurveTo(120, 300, 200, 300, 220, 250);
  ctx.bezierCurveTo(250, 160, 230, 60, 160, 40);
  ctx.closePath();
  ctx.fill();

  // eyes
  [-1, 1].forEach(side => {
    const ex = 160 + side * 38, ey = 140;
    const g = ctx.createRadialGradient(ex, ey, 2, ex, ey, 40);
    g.addColorStop(0, 'rgba(255,40,20,1)');
    g.addColorStop(1, 'rgba(255,40,20,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(ex, ey, 40, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff3c0';
    ctx.beginPath(); ctx.ellipse(ex, ey, 9, 5, 0, 0, Math.PI * 2); ctx.fill();
  });

  // jagged mouth
  ctx.strokeStyle = '#8a0000';
  ctx.lineWidth = 4;
  ctx.beginPath();
  const teeth = 10;
  for (let i = 0; i <= teeth; i++) {
    const tx = 110 + (140) * (i / teeth);
    const ty = 220 + (i % 2 === 0 ? 0 : 22);
    if (i === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
  }
  ctx.stroke();
}

// ---------- State transitions ----------
function triggerLose() {
  state = 'lost';
  document.exitPointerLock && document.exitPointerLock();
  Audio1.jumpscare();
  drawDemonFaceOverlay();
  loseScreen.classList.remove('hidden');
}

function triggerWin() {
  state = 'won';
  document.exitPointerLock && document.exitPointerLock();
  Audio1.win();
  winScreen.classList.remove('hidden');
}

function startGame() {
  Audio1.init();
  resetGame();
  state = 'playing';
  startScreen.classList.add('hidden');
  loseScreen.classList.add('hidden');
  winScreen.classList.add('hidden');
  requestPointerLockSafe();
  lastTime = performance.now();
  requestAnimationFrame(loop);
}

document.getElementById('btnStart').addEventListener('click', startGame);
document.getElementById('btnRestartLose').addEventListener('click', startGame);
document.getElementById('btnRestartWin').addEventListener('click', startGame);

// ---------- Main loop ----------
function loop(now) {
  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;

  if (state === 'playing') {
    update(dt);
    render();
  }

  if (state === 'playing' || state === 'lost' || state === 'won') {
    if (state === 'playing') requestAnimationFrame(loop);
  }
}
