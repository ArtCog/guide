/*
 * Анализатор удержания YouTube-ролика
 * -----------------------------------
 * Чистый браузерный JS без внешних зависимостей.
 * ZIP распаковывается нативным DecompressionStream('deflate-raw'),
 * поэтому CDN не нужен, а ручная загрузка CSV — запасной режим.
 *
 * Файл написан так, чтобы «чистые» функции (parseZip, parseCSV, classify,
 * buildModel, analyse) можно было импортировать в Node для верификации.
 */
(function (global) {
  'use strict';

  /* =========================================================================
   *  1. ZIP (нативно, через DecompressionStream)
   * ========================================================================= */

  async function inflateRaw(bytes) {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('DecompressionStream недоступен в этом окружении');
    }
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([bytes]).stream().pipeThrough(ds);
    const ab = await new Response(stream).arrayBuffer();
    return new Uint8Array(ab);
  }

  function decodeZipName(nameBytes, flag) {
    // Бит 11 общего флага => имя в UTF-8. Иначе — best-effort (часто CP437/OEM).
    const utf8 = (flag & 0x800) !== 0;
    try {
      return new TextDecoder(utf8 ? 'utf-8' : 'utf-8', { fatal: false }).decode(nameBytes);
    } catch (_) {
      return String.fromCharCode.apply(null, nameBytes);
    }
  }

  // Разбор ZIP через центральный каталог — надёжнее сканирования локальных заголовков.
  async function parseZip(buf) {
    const dv = new DataView(buf);
    const u8 = new Uint8Array(buf);
    const EOCD_SIG = 0x06054b50;

    let eocd = -1;
    const minPos = Math.max(0, u8.length - 22 - 65536);
    for (let i = u8.length - 22; i >= minPos; i--) {
      if (dv.getUint32(i, true) === EOCD_SIG) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Не найден конец ZIP-архива (EOCD). Возможно, это не ZIP.');

    const cdCount = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const out = [];

    for (let n = 0; n < cdCount; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break; // сигнатура записи каталога
      const flag = dv.getUint16(p + 8, true);
      const method = dv.getUint16(p + 10, true);
      const compSize = dv.getUint32(p + 20, true);
      const fnLen = dv.getUint16(p + 28, true);
      const extraLen = dv.getUint16(p + 30, true);
      const commentLen = dv.getUint16(p + 32, true);
      const localOff = dv.getUint32(p + 42, true);
      const name = decodeZipName(u8.subarray(p + 46, p + 46 + fnLen), flag);

      // Локальный заголовок: у него собственные длины имени/extra.
      const lhFnLen = dv.getUint16(localOff + 26, true);
      const lhExtraLen = dv.getUint16(localOff + 28, true);
      const dataStart = localOff + 30 + lhFnLen + lhExtraLen;
      const comp = u8.subarray(dataStart, dataStart + compSize);

      let data;
      if (method === 0) data = comp.slice();
      else if (method === 8) data = await inflateRaw(comp);
      else throw new Error('Неподдерживаемый метод сжатия ZIP: ' + method);

      if (!/\/$/.test(name)) out.push({ name: name, bytes: data });
      p += 46 + fnLen + extraLen + commentLen;
    }
    if (!out.length) throw new Error('В ZIP не найдено файлов.');
    return out;
  }

  /* =========================================================================
   *  2. Декодирование байтов в текст (детект BOM / кодировки)
   * ========================================================================= */

  function decodeBytes(bytes) {
    if (bytes.length >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) {
      return new TextDecoder('utf-8').decode(bytes.subarray(3));
    }
    if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) {
      return new TextDecoder('utf-16le').decode(bytes.subarray(2));
    }
    if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) {
      return new TextDecoder('utf-16be').decode(bytes.subarray(2));
    }
    // По умолчанию — UTF-8 без падения на битых байтах (требование: не бросать ошибку).
    return new TextDecoder('utf-8', { fatal: false }).decode(bytes);
  }

  /* =========================================================================
   *  3. CSV-парсер (учитывает кавычки, авто-детект разделителя)
   * ========================================================================= */

  function detectDelimiter(text) {
    const candidates = [',', ';', '\t', '|'];
    const counts = { ',': 0, ';': 0, '\t': 0, '|': 0 };
    let inQ = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === '"') inQ = !inQ;
      else if (ch === '\n' && !inQ) break;          // считаем только по первой строке
      else if (!inQ && counts.hasOwnProperty(ch)) counts[ch]++;
    }
    let best = ',', bestN = -1;
    for (const c of candidates) if (counts[c] > bestN) { bestN = counts[c]; best = c; }
    return bestN > 0 ? best : ',';
  }

  function parseDelimited(text, delim) {
    const rows = [];
    let field = '', row = [], inQ = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (inQ) {
        if (ch === '"') {
          if (text[i + 1] === '"') { field += '"'; i++; }
          else inQ = false;
        } else field += ch;
      } else if (ch === '"') {
        inQ = true;
      } else if (ch === delim) {
        row.push(field); field = '';
      } else if (ch === '\n') {
        row.push(field); rows.push(row); field = ''; row = [];
      } else if (ch === '\r') {
        // пропускаем — обработаем \n
      } else field += ch;
    }
    if (field.length || row.length) { row.push(field); rows.push(row); }
    return rows;
  }

  function parseCSV(text) {
    const clean = text.replace(/^﻿/, '');
    const delim = detectDelimiter(clean);
    const rows = parseDelimited(clean, delim).filter(r => r.length && !(r.length === 1 && r[0].trim() === ''));
    if (!rows.length) return { header: [], rows: [], delimiter: delim };
    const header = rows[0].map(h => h.trim());
    return { header: header, rows: rows.slice(1), delimiter: delim };
  }

  // Разбор числа с учётом десятичной запятой (немецкий формат).
  function toNumber(raw, decimalComma) {
    if (raw == null) return NaN;
    let s = String(raw).trim().replace(/[\s ]/g, '');
    if (s === '' || s === '-' || /^(n\/?a|nan|null)$/i.test(s)) return NaN;
    if (decimalComma) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(/,/g, '');
    const n = parseFloat(s);
    return n;
  }

  /* =========================================================================
   *  4. Классификатор отчёта (по колонкам, а не по имени файла)
   * ========================================================================= */

  const TYPE = {
    ABSOLUTE: 'RETENTION_ABSOLUTE',
    RELATIVE: 'RETENTION_RELATIVE',
    SEGMENTED: 'RETENTION_SEGMENTED',
    ACTIVITY: 'ACTIVITY_RAW',
    EMPTY: 'EMPTY',
    UNKNOWN: 'UNKNOWN'
  };

  const TYPE_LABEL = {
    RETENTION_ABSOLUTE: 'Абсолютная кривая удержания',
    RETENTION_RELATIVE: 'Относительное удержание (шумный сигнал)',
    RETENTION_SEGMENTED: 'Удержание по сегментам аудитории',
    ACTIVITY_RAW: 'Сырые счётчики активности',
    EMPTY: 'Нет данных',
    UNKNOWN: 'Не распознан'
  };

  function findCol(headerLower, subs) {
    return headerLower.findIndex(c => subs.some(s => c.includes(s)));
  }

  function classify(parsed) {
    const header = parsed.header;
    const hl = header.map(h => h.toLowerCase());
    const decimalComma = parsed.delimiter === ';';

    const posIdx = findCol(hl, ['videoposition', 'position']);
    const retIdx = findCol(hl, ['zuschauerbindung', 'audience retention', 'retention', 'bindung']);
    const relIdx = findCol(hl, ['vergleich', 'relative to other', 'compared to', 'im vergleich']);
    const startedIdx = findCol(hl, ['gestartet', 'playback started', 'plays started', 'starts']);
    const endedIdx = findCol(hl, ['beendet', 'playback ended', 'stopped', 'playbacks ended']);
    const rewatchIdx = findCol(hl, ['angesehen', 'wie oft', 'times each', 'watched', 'replay']);

    const used = new Set([posIdx, retIdx, relIdx, startedIdx, endedIdx, rewatchIdx].filter(i => i >= 0));

    // Категориальная колонка = не позиция/удержание/активность и содержит строки.
    let catIdx = -1;
    for (let i = 0; i < header.length; i++) {
      if (used.has(i)) continue;
      const sample = parsed.rows.slice(0, 8).map(r => r[i]).filter(v => v != null && String(v).trim() !== '');
      if (!sample.length) continue;
      const nonNumeric = sample.filter(v => isNaN(toNumber(v, decimalComma))).length;
      if (nonNumeric >= Math.ceil(sample.length / 2)) { catIdx = i; break; }
    }

    let type;
    if (!parsed.rows.length) type = TYPE.EMPTY;
    else if (endedIdx >= 0 || startedIdx >= 0 || rewatchIdx >= 0) type = TYPE.ACTIVITY;
    else if (catIdx >= 0 && retIdx >= 0) type = TYPE.SEGMENTED;
    else if (relIdx >= 0 && retIdx >= 0) type = TYPE.RELATIVE;
    else if (retIdx >= 0 && posIdx >= 0) type = TYPE.ABSOLUTE;
    else type = TYPE.UNKNOWN;

    return {
      type: type, posIdx: posIdx, retIdx: retIdx, relIdx: relIdx, catIdx: catIdx,
      startedIdx: startedIdx, endedIdx: endedIdx, rewatchIdx: rewatchIdx,
      decimalComma: decimalComma, header: header, dataRows: parsed.rows.length
    };
  }

  /* =========================================================================
   *  5. Извлечение серий из распознанного файла
   * ========================================================================= */

  function extractCurve(parsed, cls) {
    // Одна серия: [{pos, ret}] отсортировано по позиции.
    const pts = [];
    for (const r of parsed.rows) {
      const pos = toNumber(r[cls.posIdx], cls.decimalComma);
      const ret = toNumber(r[cls.retIdx], cls.decimalComma);
      if (!isNaN(pos) && !isNaN(ret)) pts.push({ pos: pos, ret: ret });
    }
    pts.sort((a, b) => a.pos - b.pos);
    return pts;
  }

  function extractSegmented(parsed, cls) {
    // Несколько серий по значению категориальной колонки.
    const map = new Map();
    for (const r of parsed.rows) {
      const cat = (r[cls.catIdx] || '').trim();
      const pos = toNumber(r[cls.posIdx], cls.decimalComma);
      const ret = toNumber(r[cls.retIdx], cls.decimalComma);
      if (!cat || isNaN(pos) || isNaN(ret)) continue;
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat).push({ pos: pos, ret: ret });
    }
    for (const arr of map.values()) arr.sort((a, b) => a.pos - b.pos);
    return map;
  }

  function extractActivity(parsed, cls) {
    const out = [];
    for (const r of parsed.rows) {
      const pos = toNumber(r[cls.posIdx], cls.decimalComma);
      if (isNaN(pos)) continue;
      out.push({
        pos: pos,
        started: cls.startedIdx >= 0 ? toNumber(r[cls.startedIdx], cls.decimalComma) : NaN,
        ended: cls.endedIdx >= 0 ? toNumber(r[cls.endedIdx], cls.decimalComma) : NaN,
        rewatch: cls.rewatchIdx >= 0 ? toNumber(r[cls.rewatchIdx], cls.decimalComma) : NaN
      });
    }
    out.sort((a, b) => a.pos - b.pos);
    return out;
  }

  /* =========================================================================
   *  6. Русские подписи сегментов
   * ========================================================================= */

  function ruSeries(name) {
    const n = name.toLowerCase();
    if (/wiederkehr|returning/.test(n)) return 'Возвращающиеся';
    if (/gelegentlich|casual/.test(n)) return 'Случайные';
    if (/regelm|regular/.test(n)) return 'Регулярные';
    if (/ohne abo|nicht-?abonn|non-?sub/.test(n)) return 'Без подписки';
    if (/abonn|subscrib/.test(n)) return 'Подписчики';
    if (/bezahl|paid/.test(n)) return 'Платный трафик';
    if (/organis|organic/.test(n)) return 'Органика';
    if (/neu|new/.test(n)) return 'Новые';
    return name;
  }

  function classifySegmentGroup(seriesNames) {
    const j = seriesNames.map(s => s.toLowerCase()).join(' | ');
    if (/abonn|subscrib|ohne abo|non-?sub/.test(j)) {
      return { key: 'subs', title: 'Подписчики и неподписчики', expect: ['Подписчики', 'Без подписки'] };
    }
    if (/wiederkehr|returning/.test(j)) {
      return { key: 'newret', title: 'Новые и возвращающиеся зрители', expect: ['Новые', 'Возвращающиеся'] };
    }
    if (/gelegentlich|casual|regelm|regular/.test(j)) {
      return { key: 'ncr', title: 'Новые, случайные и регулярные зрители', expect: ['Новые', 'Случайные', 'Регулярные'] };
    }
    if (/organis|bezahl|paid|organic/.test(j)) {
      return { key: 'orgpaid', title: 'Органический и платный трафик', expect: ['Органика', 'Платный трафик'] };
    }
    return { key: 'other', title: 'Сегментация: ' + seriesNames.map(ruSeries).join(' / '), expect: seriesNames.map(ruSeries) };
  }

  /* =========================================================================
   *  7. Сборка единой модели из всех файлов
   * ========================================================================= */

  function buildModel(files) {
    // files: [{name, parsed, cls, error?}]
    const model = {
      mainCurve: null, mainSource: null,
      relative: null, relativeSource: null,
      activity: null, activitySource: null,
      segments: [],           // [{group, seriesMap, sourceName}]
      files: files
    };

    // Главная кривая: лучший ABSOLUTE (максимум точек; при равенстве — имя ближе к «all/alle/gesamt/total»).
    const absCandidates = files
      .filter(f => f.cls && f.cls.type === TYPE.ABSOLUTE)
      .map(f => ({ f: f, curve: extractCurve(f.parsed, f.cls) }))
      .filter(c => c.curve.length);
    if (absCandidates.length) {
      absCandidates.sort((a, b) => {
        const an = /alle|all|gesamt|total|общ/i.test(a.f.name) ? 1 : 0;
        const bn = /alle|all|gesamt|total|общ/i.test(b.f.name) ? 1 : 0;
        if (b.curve.length !== a.curve.length) return b.curve.length - a.curve.length;
        return bn - an;
      });
      model.mainCurve = absCandidates[0].curve;
      model.mainSource = absCandidates[0].f.name;
    }

    // Относительный сигнал (шумный) — берём кривую из RELATIVE-файла для справки.
    const relFile = files.find(f => f.cls && f.cls.type === TYPE.RELATIVE && f.parsed.rows.length);
    if (relFile) {
      const pts = [];
      for (const r of relFile.parsed.rows) {
        const pos = toNumber(r[relFile.cls.posIdx], relFile.cls.decimalComma);
        const rel = toNumber(r[relFile.cls.relIdx], relFile.cls.decimalComma);
        if (!isNaN(pos) && !isNaN(rel)) pts.push({ pos: pos, rel: rel });
      }
      if (pts.length) { pts.sort((a, b) => a.pos - b.pos); model.relative = pts; model.relativeSource = relFile.name; }
      // Если главной кривой не было — восстановим из абсолютной колонки relative-файла.
      if (!model.mainCurve && relFile.cls.retIdx >= 0) {
        const c = extractCurve(relFile.parsed, relFile.cls);
        if (c.length) { model.mainCurve = c; model.mainSource = relFile.name + ' (абсолютная колонка)'; }
      }
    }

    // Активность (сырые счётчики).
    const actFile = files.find(f => f.cls && f.cls.type === TYPE.ACTIVITY && f.parsed.rows.length);
    if (actFile) { model.activity = extractActivity(actFile.parsed, actFile.cls); model.activitySource = actFile.name; }

    // Сегменты.
    for (const f of files) {
      if (!f.cls || f.cls.type !== TYPE.SEGMENTED) continue;
      const seriesMap = extractSegmented(f.parsed, f.cls);
      if (!seriesMap.size) continue;
      const group = classifySegmentGroup([...seriesMap.keys()]);
      model.segments.push({ group: group, seriesMap: seriesMap, sourceName: f.name });
    }

    return model;
  }

  /* =========================================================================
   *  8. Аналитика
   * ========================================================================= */

  function curveMap(curve) {
    const m = new Map();
    for (const p of curve) m.set(p.pos, p.ret);
    return m;
  }

  function valueAt(curve, cmap, pos) {
    if (cmap.has(pos)) return cmap.get(pos);
    // ближайшая по позиции
    let best = null, bestD = Infinity;
    for (const p of curve) { const d = Math.abs(p.pos - pos); if (d < bestD) { bestD = d; best = p; } }
    return best ? best.ret : NaN;
  }

  function keyPoints(curve) {
    const marks = [0, 1, 5, 10, 25, 50, 75, 90, 99];
    const cmap = curveMap(curve);
    let prev = null;
    return marks.map(p => {
      const ret = valueAt(curve, cmap, p);
      const delta = prev == null ? null : ret - prev;
      prev = ret;
      return { pos: p, ret: ret, delta: delta };
    });
  }

  function sharpestDrops(curve, n) {
    const steps = [];
    for (let i = 0; i < curve.length - 1; i++) {
      const drop = curve[i].ret - curve[i + 1].ret; // >0 => падение
      if (drop > 0) steps.push({ from: curve[i].pos, to: curve[i + 1].pos, drop: drop, level: curve[i + 1].ret });
    }
    steps.sort((a, b) => b.drop - a.drop);
    // Убираем соседние дубли, чтобы не показывать одну зону несколько раз.
    const picked = [];
    for (const s of steps) {
      if (picked.some(p => Math.abs(p.from - s.from) <= 1)) continue;
      picked.push(s);
      if (picked.length >= (n || 5)) break;
    }
    return picked;
  }

  function endPoints(activity, curve, n) {
    n = n || 6;
    if (activity && activity.some(a => !isNaN(a.ended))) {
      const total = activity.reduce((s, a) => s + (isNaN(a.ended) ? 0 : a.ended), 0);
      const rows = activity
        .filter(a => !isNaN(a.ended) && a.ended > 0)
        .map(a => ({ pos: a.pos, count: a.ended, share: total ? a.ended / total : 0 }))
        .sort((a, b) => b.count - a.count)
        .slice(0, n);
      return { source: 'raw', total: total, rows: rows };
    }
    // Фолбэк: без сырых счётчиков используем самые резкие падения кривой.
    const drops = sharpestDrops(curve, n).map(d => ({ pos: d.from, drop: d.drop, level: d.level }));
    return { source: 'curve', rows: drops };
  }

  function rewatchPoints(curve, activity, n) {
    n = n || 6;
    // Основной сигнал: рост кривой (люди пересматривают/перематывают на этот момент).
    const rises = [];
    for (let i = 1; i < curve.length; i++) {
      const rise = curve[i].ret - curve[i - 1].ret;
      if (rise > 0) rises.push({ pos: curve[i].pos, rise: rise, level: curve[i].ret });
    }
    rises.sort((a, b) => b.rise - a.rise);
    const picked = [];
    for (const r of rises) {
      if (picked.some(p => Math.abs(p.pos - r.pos) <= 1)) continue;
      picked.push(r);
      if (picked.length >= n) break;
    }
    // Доп. сигнал: локальные всплески «Wiedergabe gestartet» (перемотки-входы), кроме позиции 0.
    let jumps = [];
    if (activity && activity.some(a => !isNaN(a.started))) {
      for (let i = 1; i < activity.length - 1; i++) {
        const a = activity[i];
        if (isNaN(a.started)) continue;
        const prev = activity[i - 1].started, next = activity[i + 1].started;
        if (a.started > prev && a.started > next && a.pos !== 0) {
          jumps.push({ pos: a.pos, started: a.started });
        }
      }
      jumps.sort((a, b) => b.started - a.started);
      jumps = jumps.slice(0, n);
    }
    return { rises: picked, jumps: jumps };
  }

  function averageRetention(curve) {
    if (!curve.length) return NaN;
    // Трапеции по позиции — грубая оценка средней доли просмотра.
    let area = 0, span = 0;
    for (let i = 0; i < curve.length - 1; i++) {
      const w = curve[i + 1].pos - curve[i].pos;
      area += (curve[i].ret + curve[i + 1].ret) / 2 * w;
      span += w;
    }
    return span ? area / span : curve.reduce((s, p) => s + p.ret, 0) / curve.length;
  }

  function seriesAvg(pts) { return pts.length ? averageRetention(pts) : NaN; }

  function analyse(model) {
    const a = { hasCurve: !!(model.mainCurve && model.mainCurve.length) };
    if (a.hasCurve) {
      const c = model.mainCurve;
      a.keyPoints = keyPoints(c);
      a.drops = sharpestDrops(c, 6);
      a.ends = endPoints(model.activity, c, 6);
      a.rewatch = rewatchPoints(c, model.activity, 6);
      a.avg = averageRetention(c);
      a.start = c[0].ret;
      a.end = c[c.length - 1].ret;
      const cmap = curveMap(c);
      a.at10 = valueAt(c, cmap, 10);
      a.at50 = valueAt(c, cmap, 50);
    }
    return a;
  }

  /* =========================================================================
   *  9. Рекомендации и ограничения (только на основе чисел)
   * ========================================================================= */

  function buildRecommendations(model, a) {
    const recs = [];
    if (!a.hasCurve) {
      recs.push('Нет абсолютной кривой удержания — по имеющимся файлам содержательные рекомендации по удержанию построить нельзя. Экспортируйте отчёт «Zuschauerbindung / Absolute audience retention».');
      return recs;
    }
    const c = model.mainCurve;
    const cmap = curveMap(c);

    // Заход / первые ~5%.
    const at0 = c[0].ret, at5 = valueAt(c, cmap, 5);
    if (!isNaN(at0) && !isNaN(at5)) {
      const dropIntro = at0 - at5;
      recs.push(`Первые ~5% ролика: удержание ${fmt(at0)}% → ${fmt(at5)}% (−${fmt(dropIntro)} пп). ` +
        (dropIntro >= 25
          ? 'Это резкий обрыв на заходе — стоит проверить первые секунды: обещание, темп, отсутствие «раскачки». Что именно там — видно только на самом видео.'
          : 'Заход относительно плавный; главная работа с удержанием — дальше по ролику.'));
    }

    // Самая резкая просадка.
    if (a.drops && a.drops.length) {
      const d = a.drops[0];
      recs.push(`Самая резкая просадка — между позициями ${fmt(d.from)}% и ${fmt(d.to)}%: −${fmt(d.drop)} пп (до ${fmt(d.level)}%). ` +
        'Посмотрите, что в ролике приходится на эту долю, и подумайте, что могло оттолкнуть. Причину инструмент назвать не может — нет доступа к видео.');
    }

    // Точки массового выхода.
    if (a.ends && a.ends.source === 'raw' && a.ends.rows.length) {
      const e = a.ends.rows.filter(r => r.pos !== 0 && r.pos < (c[c.length - 1].pos)).slice(0, 2);
      const list = (e.length ? e : a.ends.rows.slice(0, 2))
        .map(r => `${fmt(r.pos)}% (${Math.round(r.count)} чел., ${fmt(r.share * 100)}% выходов)`).join(', ');
      if (list) recs.push('Больше всего зрителей заканчивают просмотр около: ' + list + '. Это сырые счётчики — самый надёжный сигнал, с него и начинайте разбор.');
    }

    // Пересматриваемые моменты (сильные).
    if (a.rewatch && a.rewatch.rises.length) {
      const r = a.rewatch.rises[0];
      recs.push(`Момент около ${fmt(r.pos)}% пересматривают (кривая растёт на +${fmt(r.rise)} пп). Это работает — найдите, что там, и делайте больше такого.`);
    }

    // Сегменты: заметная разница подписчиков/неподписчиков или новых/возвращающихся.
    for (const seg of model.segments) {
      const entries = [...seg.seriesMap.entries()].map(([k, v]) => ({ name: ruSeries(k), avg: seriesAvg(v) }))
        .filter(x => !isNaN(x.avg));
      if (entries.length >= 2) {
        entries.sort((x, y) => y.avg - x.avg);
        const hi = entries[0], lo = entries[entries.length - 1];
        const gap = hi.avg - lo.avg;
        if (gap >= 5) {
          recs.push(`${seg.group.title}: «${hi.name}» держатся в среднем на ${fmt(gap)} пп лучше, чем «${lo.name}» ` +
            `(${fmt(hi.avg)}% против ${fmt(lo.avg)}%). Стоит понять, чем ролик слабее для «${lo.name}».`);
        }
      }
    }

    // Средняя доля vs ориентир.
    if (!isNaN(a.avg)) {
      recs.push(`Оценка средней доли просмотра по площади кривой ≈ ${fmt(a.avg)}% (ориентир для образовательного контента ~40–50%). ` +
        'Точный AVD/APV берите из YouTube Studio — это приблизительная оценка, не замена.');
    }
    return recs;
  }

  function buildLimitations(model, a) {
    const lim = [
      'Позиции даны в процентах длительности, а не в секундах: без самого видео нельзя перевести их в точные таймкоды.',
      'Нет видео, сценария, глав и таймкодов — поэтому нельзя утверждать, ЧТО происходило в конкретной точке (например «здесь началась реклама» или «здесь автор назвал цену»). Инструмент говорит только «на этой доле есть просадка/рост».',
      'Средняя доля просмотра здесь — грубая оценка по площади под кривой. Истинные AVD/APV показывает только YouTube Studio.'
    ];
    if (model.relative) {
      lim.push('Относительный сигнал («Im Vergleich zu anderen Videos») подключён только справочно: на малых когортах и в хвосте он шумный и прыгает между экспортами, поэтому выводы на нём не строятся.');
    }
    // Каких данных не хватает по факту.
    const missing = [];
    const emptyFiles = model.files.filter(f => f.cls && f.cls.type === TYPE.EMPTY);
    if (emptyFiles.length) missing.push('пустые CSV (нет данных): ' + emptyFiles.map(f => f.name).join(', '));
    if (!model.activity) missing.push('нет файла сырых счётчиков (Aktivitäten im Detail) — точки выхода оценены по кривой, а не по числу людей');
    // Незаполненные ожидаемые серии в сегментах.
    for (const seg of model.segments) {
      const present = new Set([...seg.seriesMap.keys()].map(ruSeries));
      const absent = (seg.group.expect || []).filter(e => !present.has(e));
      if (absent.length) missing.push(`${seg.group.title}: нет данных для «${absent.join('», «')}»`);
    }
    const haveSegKinds = new Set(model.segments.map(s => s.group.key));
    if (!haveSegKinds.has('subs')) missing.push('нет сравнения подписчиков и неподписчиков');
    if (!haveSegKinds.has('newret')) missing.push('нет сравнения новых и возвращающихся зрителей');
    if (!haveSegKinds.has('ncr')) missing.push('нет сравнения новых/случайных/регулярных зрителей');
    if (missing.length) lim.push('Чего не хватило в этом архиве: ' + missing.join('; ') + '.');
    lim.push('Малые когорты сегментов могут шуметь — небольшую разницу между группами не стоит принимать за уверенный вывод.');
    return lim;
  }

  /* =========================================================================
   *  10. Форматирование
   * ========================================================================= */

  function fmt(x, dec) {
    if (x == null || isNaN(x)) return '—';
    return Number(x).toLocaleString('ru-RU', { minimumFractionDigits: dec == null ? 0 : dec, maximumFractionDigits: dec == null ? 1 : dec });
  }
  function fmtInt(x) { return isNaN(x) ? '—' : Math.round(x).toLocaleString('ru-RU'); }

  /* =========================================================================
   *  Экспорт чистых функций (для Node-верификации)
   * ========================================================================= */

  const API = {
    parseZip, decodeBytes, parseCSV, detectDelimiter, toNumber, classify,
    extractCurve, extractSegmented, extractActivity, buildModel, analyse,
    keyPoints, sharpestDrops, endPoints, rewatchPoints, averageRetention,
    buildRecommendations, buildLimitations, TYPE, TYPE_LABEL, ruSeries, classifySegmentGroup
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (typeof window !== 'undefined') { global.__RA = API; }

  /* =========================================================================
   *  11. UI (только в браузере)
   * ========================================================================= */
  if (typeof document === 'undefined') return;

  const SERIES_COLORS = ['#38e0c0', '#f5a524', '#7aa2ff', '#f45b8f', '#a0e548', '#c792ea'];

  // -- SVG line chart -------------------------------------------------------
  function renderChart(container, series, opts) {
    opts = opts || {};
    const W = 1000, H = opts.height || 380;
    const m = { top: 22, right: 20, bottom: 42, left: 46 };
    const iw = W - m.left - m.right, ih = H - m.top - m.bottom;
    let maxX = 100;
    for (const s of series) for (const p of s.points) if (p.pos > maxX) maxX = p.pos;
    const x = px => m.left + (px / maxX) * iw;
    const y = py => m.top + (1 - py / 100) * ih;

    const parts = [];
    parts.push(`<svg viewBox="0 0 ${W} ${H}" class="svg-chart" preserveAspectRatio="xMidYMid meet" role="img">`);

    // сетка Y
    for (const gy of [0, 25, 50, 75, 100]) {
      parts.push(`<line x1="${m.left}" y1="${y(gy)}" x2="${W - m.right}" y2="${y(gy)}" class="grid"/>`);
      parts.push(`<text x="${m.left - 8}" y="${y(gy) + 4}" class="axis-y">${gy}%</text>`);
    }
    // сетка X
    for (let gx = 0; gx <= maxX; gx += 10) {
      parts.push(`<line x1="${x(gx)}" y1="${m.top}" x2="${x(gx)}" y2="${H - m.bottom}" class="grid grid--v"/>`);
      parts.push(`<text x="${x(gx)}" y="${H - m.bottom + 18}" class="axis-x">${gx}%</text>`);
    }

    // серии
    series.forEach((s, si) => {
      const color = s.color || SERIES_COLORS[si % SERIES_COLORS.length];
      const pts = s.points.filter(p => !isNaN(p.pos) && !isNaN(p.ret));
      if (!pts.length) return;
      if (s.fill) {
        let d = `M ${x(pts[0].pos)} ${y(0)} `;
        for (const p of pts) d += `L ${x(p.pos)} ${y(p.ret)} `;
        d += `L ${x(pts[pts.length - 1].pos)} ${y(0)} Z`;
        parts.push(`<path d="${d}" fill="${color}" fill-opacity="0.10"/>`);
      }
      const line = pts.map((p, i) => `${i ? 'L' : 'M'} ${x(p.pos).toFixed(1)} ${y(p.ret).toFixed(1)}`).join(' ');
      parts.push(`<path d="${line}" fill="none" stroke="${color}" stroke-width="${s.width || 2.4}" ${s.dashed ? 'stroke-dasharray="5 4"' : ''} stroke-linejoin="round"/>`);
    });

    // маркеры ключевых точек (на первой серии)
    if (opts.markers && series[0]) {
      const cmap = curveMap(series[0].points);
      for (const mk of opts.markers) {
        const ret = valueAt(series[0].points, cmap, mk);
        if (isNaN(ret)) continue;
        parts.push(`<circle cx="${x(mk)}" cy="${y(ret)}" r="3.5" class="marker"/>`);
      }
    }

    // ось X подпись
    parts.push(`<text x="${m.left + iw / 2}" y="${H - 6}" class="axis-title">Позиция в ролике, % длительности</text>`);

    // hover-слой
    parts.push(`<line class="hover-line" x1="0" y1="${m.top}" x2="0" y2="${H - m.bottom}" style="display:none"/>`);
    parts.push(`<rect x="${m.left}" y="${m.top}" width="${iw}" height="${ih}" fill="transparent" class="hover-rect"/>`);
    parts.push('</svg>');

    container.innerHTML = parts.join('');
    attachHover(container.querySelector('svg'), series, { x, y, m, iw, maxX }, opts.readout);
  }

  function attachHover(svg, series, geom, readoutEl) {
    if (!svg) return;
    const line = svg.querySelector('.hover-line');
    const rect = svg.querySelector('.hover-rect');
    if (!rect) return;
    rect.addEventListener('mousemove', ev => {
      const box = svg.getBoundingClientRect();
      const sx = (ev.clientX - box.left) / box.width * 1000;
      const pos = Math.round(Math.max(0, Math.min(geom.maxX, (sx - geom.m.left) / geom.iw * geom.maxX)));
      line.setAttribute('x1', geom.x(pos)); line.setAttribute('x2', geom.x(pos)); line.style.display = '';
      if (readoutEl) {
        const rows = series.map((s, i) => {
          const cmap = curveMap(s.points);
          const v = valueAt(s.points, cmap, pos);
          return `<span class="ro-item"><i style="background:${s.color || SERIES_COLORS[i % SERIES_COLORS.length]}"></i>${s.name}: <b>${fmt(v)}%</b></span>`;
        }).join('');
        readoutEl.innerHTML = `<b>${pos}%</b> ${rows}`;
      }
    });
    rect.addEventListener('mouseleave', () => { line.style.display = 'none'; if (readoutEl) readoutEl.innerHTML = ''; });
  }

  // -- Рендер таблиц и панелей ---------------------------------------------
  function el(id) { return document.getElementById(id); }

  function renderKPIs(model, a) {
    const cards = [];
    const push = (label, value, sub) => cards.push(
      `<div class="kpi"><div class="kpi__val">${value}</div><div class="kpi__label">${label}</div>${sub ? `<div class="kpi__sub">${sub}</div>` : ''}</div>`);
    const withData = model.files.filter(f => f.cls && f.cls.type !== TYPE.EMPTY && f.cls.type !== TYPE.UNKNOWN && !f.error).length;
    if (a.hasCurve) {
      push('Старт (0%)', fmt(a.start) + '%', 'удержание в начале');
      push('На 10%', fmt(a.at10) + '%');
      push('На 50%', fmt(a.at50) + '%');
      push('Финал', fmt(a.end) + '%', 'у конца ролика');
      push('Средняя доля', '≈' + fmt(a.avg) + '%', 'оценка по площади');
    }
    push('Файлов', model.files.length, withData + ' с данными');
    el('kpiRow').innerHTML = cards.join('');
  }

  function renderMainChart(model, a) {
    if (!a.hasCurve) { el('panelCurve').classList.add('hidden'); return; }
    el('curveSource').textContent = 'источник: ' + model.mainSource;
    const wrap = el('mainChart');
    const readout = document.createElement('div');
    readout.className = 'readout';
    const series = [{ name: 'Удержание', points: model.mainCurve, color: '#38e0c0', width: 2.8, fill: true }];
    renderChart(wrap, series, { markers: [0, 1, 5, 10, 25, 50, 75, 90, 99], readout: readout });
    wrap.appendChild(readout);
  }

  function renderKeyPoints(a) {
    if (!a.hasCurve) return;
    const rows = a.keyPoints.map(k =>
      `<tr><td>${k.pos}%</td><td class="num"><b>${fmt(k.ret)}%</b></td><td class="num ${k.delta < 0 ? 'neg' : k.delta > 0 ? 'pos' : ''}">${k.delta == null ? '—' : (k.delta > 0 ? '+' : '') + fmt(k.delta) + ' пп'}</td></tr>`).join('');
    el('keyPointsTable').innerHTML =
      `<thead><tr><th>Позиция</th><th class="num">Удержание</th><th class="num">Δ к пред.</th></tr></thead><tbody>${rows}</tbody>`;
  }

  function renderDrops(a) {
    if (!a.hasCurve) return;
    const rows = a.drops.map((d, i) =>
      `<tr><td>${i + 1}</td><td>${fmt(d.from)}% → ${fmt(d.to)}%</td><td class="num neg">−${fmt(d.drop)} пп</td><td class="num">${fmt(d.level)}%</td></tr>`).join('');
    el('dropsTable').innerHTML =
      `<thead><tr><th>#</th><th>Зона</th><th class="num">Падение</th><th class="num">До уровня</th></tr></thead><tbody>${rows}</tbody>`;
  }

  function renderEnds(model, a) {
    if (!a.hasCurve) return;
    const e = a.ends;
    if (e.source === 'raw') {
      el('endsSource').textContent = 'сырые счётчики «Wiedergabe beendet» — надёжный сигнал';
      const lastPos = model.mainCurve[model.mainCurve.length - 1].pos;
      const rows = e.rows.map(r => {
        let note = '';
        if (r.pos === 0) note = 'моментальный отток';
        else if (r.pos >= lastPos - 1) note = 'естественный конец';
        return `<tr><td>${fmt(r.pos)}%</td><td class="num">${fmtInt(r.count)}</td><td class="num">${fmt(r.share * 100)}%</td><td class="note">${note}</td></tr>`;
      }).join('');
      el('endsTable').innerHTML =
        `<thead><tr><th>Позиция</th><th class="num">Закончили</th><th class="num">Доля выходов</th><th></th></tr></thead><tbody>${rows}</tbody>`;
    } else {
      el('endsSource').textContent = 'нет сырых счётчиков — оценка по кривой';
      const rows = e.rows.map(r =>
        `<tr><td>${fmt(r.pos)}%</td><td class="num neg">−${fmt(r.drop)} пп</td><td class="num">${fmt(r.level)}%</td></tr>`).join('');
      el('endsTable').innerHTML =
        `<thead><tr><th>Позиция</th><th class="num">Падение</th><th class="num">До уровня</th></tr></thead><tbody>${rows}</tbody>`;
    }
  }

  function renderRewatch(model, a) {
    if (!a.hasCurve) return;
    const r = a.rewatch;
    el('rewatchSource').textContent = model.activity ? 'рост кривой + всплески перемоток' : 'рост кривой удержания';
    const riseRows = r.rises.map(x =>
      `<tr><td>${fmt(x.pos)}%</td><td class="num pos">+${fmt(x.rise)} пп</td><td class="num">${fmt(x.level)}%</td></tr>`).join('');
    let html = `<thead><tr><th>Позиция</th><th class="num">Рост</th><th class="num">Уровень</th></tr></thead><tbody>${riseRows || '<tr><td colspan="3" class="muted">Ростов кривой не обнаружено</td></tr>'}</tbody>`;
    el('rewatchTable').innerHTML = html;
  }

  function renderSegments(model) {
    const cont = el('segmentsContainer');
    if (!model.segments.length) {
      cont.innerHTML = '<p class="muted">В архиве нет CSV с разбивкой по сегментам аудитории.</p>';
      return;
    }
    const blocks = model.segments.map((seg, idx) => {
      const entries = [...seg.seriesMap.entries()];
      const series = entries.map(([name, pts], i) => ({
        name: ruSeries(name), points: pts, color: SERIES_COLORS[i % SERIES_COLORS.length], width: 2.4
      }));
      const avgRows = series.map(s =>
        `<tr><td><i class="dot" style="background:${s.color}"></i>${s.name}</td><td class="num">${fmt(seriesAvg(s.points))}%</td><td class="num">${fmt(valueAt(s.points, curveMap(s.points), 0))}%</td><td class="num">${fmt(valueAt(s.points, curveMap(s.points), 50))}%</td></tr>`).join('');
      const present = new Set(series.map(s => s.name));
      const absent = (seg.group.expect || []).filter(e => !present.has(e));
      const missNote = absent.length ? `<p class="muted small">Нет данных для: ${absent.join(', ')}.</p>` : '';
      return `<div class="segment" data-seg="${idx}">
        <h3>${seg.group.title}</h3>
        <div class="segment__chart" id="segChart${idx}"></div>
        <table class="data-table data-table--compact">
          <thead><tr><th>Серия</th><th class="num">Ср. доля</th><th class="num">Старт</th><th class="num">50%</th></tr></thead>
          <tbody>${avgRows}</tbody>
        </table>
        ${missNote}
        <p class="muted small">Источник: ${seg.sourceName}</p>
      </div>`;
    });
    cont.innerHTML = blocks.join('');
    model.segments.forEach((seg, idx) => {
      const entries = [...seg.seriesMap.entries()];
      const series = entries.map(([name, pts], i) => ({
        name: ruSeries(name), points: pts, color: SERIES_COLORS[i % SERIES_COLORS.length], width: 2.4
      }));
      renderChart(el('segChart' + idx), series, { height: 300 });
    });
  }

  function renderFiles(model) {
    const rows = model.files.map(f => {
      let type, status, detail;
      if (f.error) {
        type = 'Ошибка чтения'; status = 'err'; detail = f.error;
      } else if (f.cls.type === TYPE.EMPTY) {
        type = TYPE_LABEL[TYPE.EMPTY]; status = 'empty'; detail = 'файл содержит только заголовок';
      } else {
        type = TYPE_LABEL[f.cls.type] || f.cls.type;
        status = f.cls.type === TYPE.UNKNOWN ? 'warn' : 'ok';
        detail = f.cls.header.join(' · ');
      }
      const badge = { ok: 'проанализирован', empty: 'нет данных', warn: 'не распознан', err: 'ошибка' }[status];
      return `<tr>
        <td class="fname" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</td>
        <td>${type}</td>
        <td class="num">${f.error ? '—' : f.cls.dataRows}</td>
        <td><span class="badge badge--${status}">${badge}</span></td>
        <td class="detail muted small">${escapeHtml(detail)}</td>
      </tr>`;
    }).join('');
    el('filesTable').innerHTML =
      `<thead><tr><th>Файл</th><th>Что понято</th><th class="num">Строк</th><th>Статус</th><th>Колонки / детали</th></tr></thead><tbody>${rows}</tbody>`;
  }

  function renderRecsLimits(model, a) {
    el('recsList').innerHTML = buildRecommendations(model, a).map(r => `<li>${escapeHtml(r)}</li>`).join('');
    el('limitsList').innerHTML = buildLimitations(model, a).map(r => `<li>${escapeHtml(r)}</li>`).join('');
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // -- Оркестрация ----------------------------------------------------------
  function setStatus(msg, kind) {
    const bar = el('statusBar');
    bar.className = 'statusbar' + (kind ? ' statusbar--' + kind : '');
    bar.textContent = msg;
    bar.classList.remove('hidden');
  }

  function processParsedFiles(rawFiles) {
    // rawFiles: [{name, text}]
    const files = rawFiles.map(rf => {
      try {
        const parsed = parseCSV(rf.text);
        const cls = classify(parsed);
        return { name: rf.name, parsed: parsed, cls: cls };
      } catch (e) {
        return { name: rf.name, error: e.message || String(e) };
      }
    });
    // Только .csv (на случай мусора в архиве).
    const csvFiles = files.filter(f => /\.csv$/i.test(f.name) || (f.cls && f.cls.header.length));
    const model = buildModel(csvFiles);
    const a = analyse(model);

    renderKPIs(model, a);
    renderMainChart(model, a);
    renderKeyPoints(a);
    renderDrops(a);
    renderEnds(model, a);
    renderRewatch(model, a);
    renderSegments(model);
    renderFiles(model);
    renderRecsLimits(model, a);

    el('emptyState').classList.add('hidden');
    el('dashboard').classList.remove('hidden');

    const withData = csvFiles.filter(f => f.cls && f.cls.type !== TYPE.EMPTY && f.cls.type !== TYPE.UNKNOWN && !f.error).length;
    setStatus(`Готово: прочитано ${csvFiles.length} CSV, распознано с данными — ${withData}. ` +
      (a.hasCurve ? `Главная кривая: ${model.mainSource}.` : 'Абсолютная кривая удержания не найдена.'), 'ok');
  }

  async function handleZip(file) {
    setStatus('Читаю ZIP: ' + file.name + ' …');
    try {
      const buf = await file.arrayBuffer();
      const entries = await parseZip(buf);
      const rawFiles = entries
        .filter(e => /\.csv$/i.test(e.name))
        .map(e => ({ name: baseName(e.name), text: decodeBytes(e.bytes) }));
      if (!rawFiles.length) { setStatus('В ZIP не найдено CSV-файлов.', 'err'); return; }
      processParsedFiles(rawFiles);
    } catch (e) {
      setStatus('Не удалось распаковать ZIP в браузере: ' + (e.message || e) +
        ' — воспользуйтесь запасным режимом (загрузка CSV вручную).', 'err');
    }
  }

  async function handleCsvs(fileList) {
    const arr = [...fileList].filter(f => /\.csv$/i.test(f.name));
    if (!arr.length) { setStatus('Выберите хотя бы один CSV-файл.', 'err'); return; }
    setStatus('Читаю ' + arr.length + ' CSV …');
    try {
      const rawFiles = await Promise.all(arr.map(async f => ({
        name: baseName(f.name), text: decodeBytes(new Uint8Array(await f.arrayBuffer()))
      })));
      processParsedFiles(rawFiles);
    } catch (e) {
      setStatus('Ошибка чтения CSV: ' + (e.message || e), 'err');
    }
  }

  function baseName(p) { return String(p).split(/[\\/]/).pop(); }

  // -- Слушатели ------------------------------------------------------------
  function init() {
    const dz = el('dropzone'), zipInput = el('zipInput'), csvInput = el('csvInput');
    dz.addEventListener('click', () => zipInput.click());
    dz.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); zipInput.click(); } });
    zipInput.addEventListener('change', e => { if (e.target.files[0]) handleZip(e.target.files[0]); });
    csvInput.addEventListener('change', e => { if (e.target.files.length) handleCsvs(e.target.files); });

    ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('dropzone--over'); }));
    ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('dropzone--over'); }));
    dz.addEventListener('drop', e => {
      const files = [...e.dataTransfer.files];
      const zip = files.find(f => /\.zip$/i.test(f.name));
      const csvs = files.filter(f => /\.csv$/i.test(f.name));
      if (zip) handleZip(zip);
      else if (csvs.length) handleCsvs(csvs);
      else setStatus('Перетащите ZIP или CSV-файлы.', 'err');
    });
  }

  // Отладочный хук: позволяет скриптовать дашборд (и прогонять smoke-тесты).
  global.__RA_UI = { processParsedFiles: processParsedFiles, handleZip: handleZip, handleCsvs: handleCsvs, renderChart: renderChart };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})(typeof window !== 'undefined' ? window : globalThis);
