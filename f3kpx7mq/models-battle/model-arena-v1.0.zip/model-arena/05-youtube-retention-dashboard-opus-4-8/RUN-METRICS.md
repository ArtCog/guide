# RUN-METRICS — тест 04 «Анализатор удержания YouTube»

| Поле | Значение |
|---|---|
| Модель | Claude Opus 4.8 (`claude-opus-4-8`), Claude Code |
| Тест | 04 — локальный дашборд анализа ZIP/CSV из YouTube Studio |
| Время задачи | 6m 53s |
| Input tokens | 18.8k |
| Output tokens | 75.1k |
| Cache read | 2.9m |
| Cache write | 200.0k |
| Стоимость USD | $5.51 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\04-youtube-retention-dashboard-opus-4-8\index.html` |
| Короткий вердикт | Рабочий браузерный анализатор ZIP/CSV с нативной распаковкой ZIP, ручным CSV-режимом, классификацией отчетов и проверкой на реальном архиве. Методология частично опиралась на внешний skill `youtube-video-analysis`. |

**Источник метрик:** данные пользователя из вкладки `Usage` Claude Code после выполнения теста.
`6m 53s` — время выполнения именно четвертого задания, строка `Churned for 6m 53s`.

**Важно по времени:** `Total duration (API): 1h 47m 54s` и `Total duration (wall): 1d 4h 32m`
не используются как время задачи. Это общие длительности сессии/ожидания, а не чистое время выполнения теста.

**Разбивка стоимости по скрину/статистике:** `claude-opus-4-8` — $29.46;
`claude-haiku-4-5` — $0.0099. Общая стоимость сессии: $29.47.

## Подход модели

Opus 4.8 явно понял задачу как бенчмарк и отказался от уточняющих вопросов, чтобы
не загрязнять сравнение моделей. Сначала подключил `youtube-video-analysis`, затем
прочитал реальный ZIP, выписал структуру всех 9 CSV, после этого создал проект:
`index.html`, `assets/styles.css`, `assets/script.js`, `README.md`, `REPORT.md`.

В отчете указано, что модель проверяла две вещи:
- чистую логику `parseZip → parseCSV → classify → buildModel → analyse`;
- браузерный рендер через `jsdom`, 18/18 проверок.

## Проверка на «мухлеж»

Признаков чтения предыдущей работы Fable 5 или готового отчета из арены в логе и
проекте не найдено. В основной код не зашиты итоговые числа конкретного архива
типа `91.87`, `51.24`, `902`, `447`, `777`, `35.74`; эти числа находятся в
`REPORT.md` как результат анализа предоставленного ZIP.

Но есть методологическое загрязнение бенчмарка: Opus 4.8 явно взял доменную базу
из skill `youtube-video-analysis`, включая иерархию надежности сигналов:
`сырые счетчики > абсолютная кривая > относительная кривая`. Это не скрытый обман,
потому что модель сама написала об этом в финальном отчете, но при сравнении
«чистой силы модели» этот факт нужно проговорить зрителю.

Вывод: результат выглядит как реальная работа с данными, а не подмена статичным
отчетом. Основная оговорка — модель пользовалась внешней доменной методологией.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $29.47 / 69.7k input / 317.2k output / 16.8m cache read / 1.3m cache write.
- Previous checkpoint: $23.96 / 52.9k input / 242.1k output / 13.9m cache read / 1.1m cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
