const test = require('node:test');
const assert = require('node:assert/strict');
const Rules = require('../rules.js');

test('cards are collected once and counted toward the objective', () => {
  const state = Rules.createState();
  assert.equal(Rules.collectCard(state, 'red'), true);
  assert.equal(Rules.collectCard(state, 'red'), false);
  assert.equal(Rules.collectCard(state, 'blue'), true);
  assert.equal(state.cards.length, 2);
});

test('generator stays locked until all three cards are collected', () => {
  const state = Rules.createState();
  Rules.collectCard(state, 'red');
  Rules.collectCard(state, 'blue');
  assert.deepEqual(Rules.activateGenerator(state), { ok: false, reason: 'cards' });
  Rules.collectCard(state, 'yellow');
  assert.deepEqual(Rules.activateGenerator(state), { ok: true });
  assert.equal(state.generatorOn, true);
});

test('exit requires the generator and wins once power is restored', () => {
  const state = Rules.createState();
  assert.deepEqual(Rules.useExit(state), { ok: false, reason: 'generator' });
  state.generatorOn = true;
  assert.deepEqual(Rules.useExit(state), { ok: true });
  assert.equal(state.status, 'won');
});

test('battery drains only while the flashlight is active and clamps at zero', () => {
  const state = Rules.createState();
  state.flashlightOn = false;
  Rules.drainBattery(state, 10, 2.4);
  assert.equal(state.battery, 100);
  state.flashlightOn = true;
  Rules.drainBattery(state, 10, 2.4);
  assert.equal(state.battery, 76);
  Rules.drainBattery(state, 100, 2.4);
  assert.equal(state.battery, 0);
  assert.equal(state.flashlightOn, false);
});

test('flashlight slows but never stops the demon', () => {
  assert.equal(Rules.demonSpeedMultiplier(false), 1);
  assert.equal(Rules.demonSpeedMultiplier(true), 0.38);
  assert.ok(Rules.demonSpeedMultiplier(true) > 0);
});

test('demon contact uses a strict danger radius', () => {
  assert.equal(Rules.isCaught(2, 2, 2.5, 2.5, 0.72), true);
  assert.equal(Rules.isCaught(2, 2, 3, 3, 0.72), false);
});

test('reset restores every mutable objective field', () => {
  const state = Rules.createState();
  Rules.collectCard(state, 'red');
  state.generatorOn = true;
  state.battery = 4;
  state.flashlightOn = false;
  state.status = 'lost';
  Rules.resetState(state);
  assert.deepEqual(state, Rules.createState());
});
