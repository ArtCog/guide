import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdir, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const port = 9223;
const root = path.resolve(import.meta.dirname, '..');
const gameUrl = process.env.GAME_URL || pathToFileURL(path.join(root, 'index.html')).href;
const artifactDir = path.join(import.meta.dirname, 'test-artifacts');
const profile = path.join(os.tmpdir(), `last-shift-chrome-${Date.now()}`);
await mkdir(artifactDir, { recursive: true });

const chrome = spawn(chromePath, [
  '--headless=new',
  '--disable-gpu',
  '--disable-extensions',
  '--disable-background-networking',
  '--mute-audio',
  `--remote-debugging-port=${port}`,
  `--user-data-dir=${profile}`,
  '--window-size=1280,720',
  gameUrl
], { stdio: 'ignore', windowsHide: true });

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function pollJson(url, predicate, timeout = 10000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    try {
      const response = await fetch(url);
      const value = await response.json();
      if (predicate(value)) return value;
    } catch {}
    await sleep(100);
  }
  throw new Error(`Timed out waiting for ${url}`);
}

let socket;
let nextId = 1;
const pending = new Map();
const exceptions = [];

function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    socket.send(JSON.stringify({ id, method, params }));
  });
}

function evaluate(expression) {
  return send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
    .then((response) => {
      if (response.exceptionDetails) throw new Error(response.exceptionDetails.text);
      return response.result.value;
    });
}

async function key(code, keyValue, hold = 45) {
  await send('Input.dispatchKeyEvent', { type: 'keyDown', code, key: keyValue, windowsVirtualKeyCode: keyValue.charCodeAt(0) });
  await sleep(hold);
  await send('Input.dispatchKeyEvent', { type: 'keyUp', code, key: keyValue, windowsVirtualKeyCode: keyValue.charCodeAt(0) });
}

async function screenshot(name) {
  const result = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  await writeFile(path.join(artifactDir, name), Buffer.from(result.data, 'base64'));
}

try {
  const pages = await pollJson(`http://127.0.0.1:${port}/json/list`, (list) => Array.isArray(list) && list.some((page) => page.type === 'page'));
  const page = pages.find((item) => item.type === 'page');
  socket = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
  });
  socket.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const operation = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) operation.reject(new Error(message.error.message));
      else operation.resolve(message.result);
    }
    if (message.method === 'Runtime.exceptionThrown') exceptions.push(message.params.exceptionDetails.text);
  });
  await send('Runtime.enable');
  await send('Page.enable');
  await sleep(700);

  const initial = await evaluate(`({
    title: document.title,
    canvas: !!document.querySelector('#game'),
    startVisible: document.querySelector('#start-screen').classList.contains('active'),
    debug: !!window.__horrorDebug
  })`);
  assert.deepEqual(initial, { title: 'Последняя смена', canvas: true, startVisible: true, debug: true });
  await screenshot('01-start-screen.png');

  await evaluate(`document.querySelector('#start-button').click(); window.__horrorDebug.forceResume(); true`);
  await sleep(250);
  let state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.started, true);
  assert.equal(state.status, 'playing');

  const beforeMove = state.player.x;
  await key('KeyW', 'w', 420);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.ok(state.player.x > beforeMove + 0.25, 'W should move the player forward');

  const beforeAngle = state.player.angle;
  await key('ArrowRight', 'ArrowRight', 260);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.ok(state.player.angle > beforeAngle + 0.2, 'ArrowRight should turn the camera');

  await evaluate(`window.__horrorDebug.setAngle(0); window.__horrorDebug.forceResume()`);
  await sleep(650);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.ok(state.battery < 100, 'active flashlight should drain battery');
  await key('KeyF', 'f');
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.flashlightOn, false);
  await key('KeyF', 'f');

  await evaluate(`window.__horrorDebug.teleport('generator'); window.__horrorDebug.forceResume()`);
  await key('KeyE', 'e');
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.generatorOn, false, 'generator should be gated before cards');

  await evaluate(`window.__horrorDebug.teleport('exit'); window.__horrorDebug.forceResume()`);
  await key('KeyE', 'e');
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.status, 'playing', 'exit should be gated before generator');

  for (const id of ['red', 'blue', 'yellow']) {
    await evaluate(`window.__horrorDebug.teleport('${id}'); window.__horrorDebug.forceResume()`);
    await key('KeyE', 'e');
  }
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.deepEqual(state.cards.sort(), ['blue', 'red', 'yellow']);
  assert.equal(state.demon.awake, true);

  await evaluate(`window.__horrorDebug.teleport('generator'); window.__horrorDebug.forceResume()`);
  await key('KeyE', 'e');
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.generatorOn, true);

  await evaluate(`window.__horrorDebug.teleport('exit'); window.__horrorDebug.forceResume()`);
  await key('KeyE', 'e');
  await sleep(120);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.status, 'won');
  assert.equal(await evaluate(`document.querySelector('#result-screen').classList.contains('victory')`), true);
  await screenshot('02-victory.png');

  await evaluate(`document.querySelector('#restart-button').click(); window.__horrorDebug.forceResume()`);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.status, 'playing');
  assert.deepEqual(state.cards, []);

  await evaluate(`window.__horrorDebug.setAngle(0); window.__horrorDebug.setDemonNear(2.4); window.__horrorDebug.forceResume()`);
  await sleep(90);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.demon.awake, true);
  assert.equal(state.demon.slowed, true, 'flashlight should slow a visible demon');
  await screenshot('03-demon-in-corridor.png');

  await evaluate(`window.__horrorDebug.forceDefeat(); window.__horrorDebug.forceResume()`);
  await sleep(1150);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.status, 'lost');
  assert.equal(await evaluate(`document.querySelector('#result-title').textContent`), 'ВАС НАШЛИ');
  await screenshot('04-defeat.png');

  await evaluate(`document.querySelector('#restart-button').click(); window.__horrorDebug.forceResume()`);
  state = await evaluate(`window.__horrorDebug.getState()`);
  assert.equal(state.status, 'playing');
  assert.equal(state.generatorOn, false);
  assert.ok(state.battery > 99.9, 'restart should restore a full battery');
  assert.equal(exceptions.length, 0, `browser exceptions: ${exceptions.join('; ')}`);

  console.log(JSON.stringify({
    result: 'PASS',
    checks: 19,
    screenshots: ['01-start-screen.png', '02-victory.png', '03-demon-in-corridor.png', '04-defeat.png'],
    browser: 'Google Chrome headless',
    exceptions: exceptions.length
  }, null, 2));
} finally {
  if (socket) socket.close();
  chrome.kill();
  await sleep(150);
  await rm(profile, { recursive: true, force: true });
}
