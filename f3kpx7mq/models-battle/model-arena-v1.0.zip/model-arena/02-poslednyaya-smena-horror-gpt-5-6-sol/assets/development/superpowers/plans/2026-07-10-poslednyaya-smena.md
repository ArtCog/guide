# «Последняя смена» Implementation Plan

> **For agentic workers:** Execute inline in this session. This standalone deliverable is not a Git repository, so worktree, commit, and branch steps do not apply.

**Goal:** Build and verify a complete 2–3 minute first-person browser horror game.

**Architecture:** A dependency-free Canvas raycaster renders a grid-based mortuary. Pure CommonJS/browser-compatible rules are tested in Node; the browser layer owns input, audio, rendering, pathfinding, overlays, and debug-only verification hooks.

**Tech Stack:** HTML5 Canvas, CSS, vanilla JavaScript, Web Audio API, Node built-in test runner.

## Global Constraints

- All files remain under the user-specified result folder.
- `index.html` launches without a build step or network dependency.
- All visible game text is Russian.
- No gore or detailed blood.
- Keyboard, mouse, flashlight battery, three cards, generator, exit, demon, victory, defeat, and restart are mandatory.

---

### Task 1: Deterministic game rules

**Files:**
- Create: `tests/rules.test.js`
- Create: `rules.js`

**Interfaces:**
- Produces: `GameRules.createState()`, `collectCard()`, `activateGenerator()`, `useExit()`, `drainBattery()`, `demonSpeedMultiplier()`, `isCaught()`, and `resetState()`.

- [ ] Write Node assertions for card uniqueness, generator/exit gating, battery depletion, flashlight slowing, catch distance, and reset.
- [ ] Run `node --test tests/rules.test.js`; verify it fails because `rules.js` is absent.
- [ ] Implement the minimum pure rules module using a browser global plus `module.exports`.
- [ ] Run the same command; expect all tests to pass.

### Task 2: Playable raycast game

**Files:**
- Create: `index.html`
- Create: `styles.css`
- Create: `game.js`

**Interfaces:**
- Consumes: `window.GameRules`.
- Produces: start, pause, update, render, interaction, demon pursuit, audio, victory/defeat, restart, and `window.__horrorDebug` verification methods.

- [ ] Create semantic overlays, HUD, Canvas, Russian controls, and script loading order.
- [ ] Add the responsive mortuary visual system: institutional typography, dark palette, grain, scanlines, damage vignette, and clear interactive states.
- [ ] Implement the grid level, DDA raycaster, wall/door textures, sprites, collision, keyboard/mouse turning, flashlight cone, battery, interactions, and progression.
- [ ] Implement BFS demon pursuit, line-of-sight flashlight slow, sprite animation, proximity effects, jumpscare, audio synthesis, defeat, victory, and complete reset.
- [ ] Run `node --check rules.js` and `node --check game.js`; expect exit code 0.

### Task 3: Documentation and browser verification

**Files:**
- Create: `README.md`
- Create: `RUN-METRICS.md`

- [ ] Document direct opening, optional local server, controls, objective, and audio/pointer-lock behavior.
- [ ] Start a hidden local HTTP server and open the game in the in-app browser.
- [ ] Verify load, start, movement, turning, flashlight toggle/drain, three pickups, generator gating, generator activation, exit gating, victory, demon pursuit/contact defeat, and restart.
- [ ] Inspect a gameplay screenshot for first-person perspective, corridor geometry, flashlight, HUD, and demon appearance.
- [ ] Re-run Node tests and syntax checks after browser fixes.
- [ ] Fill metrics honestly; mark unavailable API accounting values as unavailable and record measured wall time plus verification verdict.
