# «Последняя смена» — Game Design Specification

## Goal

Build a self-contained Russian-language browser horror game that lasts roughly 2–3 minutes and has a complete playable loop: explore, collect three key cards, activate the generator, unlock the exit, and escape while avoiding a pursuing demon.

## Technical approach

- Use a dependency-free HTML5 Canvas raycaster to create a first-person view.
- Keep runtime assets and code local so `index.html` can run directly from disk.
- Use JavaScript modules by responsibility: deterministic game rules, raycasting/rendering, input/audio, and application bootstrap.
- Use Web Audio synthesis and procedural Canvas art; no external network resources.

## Level and progression

- One compact grid-based mortuary floor with connected corridors, an autopsy room, cold storage, records room, generator room, and exit lobby.
- The player starts near the security desk after a blackout.
- Three colored key cards are placed in separate rooms.
- The generator can only be activated after all three cards are collected.
- The exit opens only after the generator is running.
- The intended route and pursuit pressure produce a 2–3 minute first playthrough.

## Player controls

- `WASD` or arrow keys: move and strafe.
- Mouse movement after pointer lock, or left/right arrow fallback: turn the camera.
- `F`: toggle flashlight.
- `E`: interact with cards, generator, and exit.
- `Esc`: release pointer lock/pause mouse control.

The player is never rendered. Collision prevents walking through walls and closed doors.

## Flashlight

- The flashlight creates a visible cone and central bloom in the first-person renderer.
- Battery drains only while the light is on and cannot recharge.
- The HUD shows charge as a percentage and a visual bar.
- Direct sustained illumination slows the demon temporarily but never damages or removes it.

## Demon

- The demon awakens after the first key card is collected, with a brief warning-free reveal.
- It navigates the walkable grid toward the player and accelerates as objectives are completed.
- It is shown as a tall distorted silhouette with a pale mask, glowing eyes, unnatural limb proportions, and distance-scaled animation.
- Close proximity triggers screen distortion, louder breathing/heartbeat, and a rapid lunge into the camera.
- Contact causes defeat; there is no combat.

## Horror presentation

- Near-black blue-gray palette with dirty institutional walls, numbered doors, intermittent emergency lighting, film grain, chromatic aberration, and subtle camera sway.
- Procedural audio provides electrical hum, footsteps, distant knocks, flashlight clicks, generator rumble, heartbeat, pursuit noise, and a defeat sting.
- Event pacing uses restrained messages, flickers, distant sightings, and the demon reveal instead of gore.

## Interface and screens

- Minimal HUD: battery, `КЛЮЧ-КАРТЫ 0/3`, generator state, and contextual interaction prompt.
- Start overlay explains controls and begins only after a click so pointer lock and audio are permitted.
- Defeat and victory overlays contain a Russian result message and a restart button.
- Restart resets all objectives, battery, demon state, player state, audio, and overlays without requiring a page refresh.

## Rule interfaces and testing

- Pure game-rule functions expose card collection, generator activation, exit activation, battery drain, flashlight slow, demon contact, victory, and reset behavior.
- A Node-based test file validates these rules before the browser implementation is completed.
- Browser verification covers initial load, movement, turning, flashlight drain/toggle, all three card pickups, generator gating, exit gating, demon pursuit/contact defeat, victory, and both restart paths.
- Debug-only URL flags may be used to place the browser near objectives during verification; they must not alter normal play.

## Deliverables

- `index.html`: required launch file.
- `styles.css`: overlays and HUD presentation.
- `game.js`: browser bootstrap, loop, input, audio, and rendering.
- `rules.js`: deterministic game rules shared by runtime and tests.
- `tests/rules.test.mjs`: automated rule checks.
- `README.md`: direct-open and optional local-server instructions.
- `RUN-METRICS.md`: requested model, timing, token, cost, path, and verdict fields; unavailable API accounting values are reported honestly as unavailable.

## Constraints

- All output stays under `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-gpt-5-6-sol\`.
- All visible game text is Russian.
- No detailed gore or blood.
- No external dependencies or network requests.
- Desktop keyboard and mouse are the primary supported controls.
