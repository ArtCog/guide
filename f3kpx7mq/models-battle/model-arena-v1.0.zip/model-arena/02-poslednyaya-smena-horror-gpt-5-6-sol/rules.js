(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.GameRules = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function createState() {
    return {
      cards: [],
      generatorOn: false,
      battery: 100,
      flashlightOn: true,
      status: 'playing'
    };
  }

  function collectCard(state, id) {
    if (state.cards.includes(id)) return false;
    state.cards.push(id);
    return true;
  }

  function activateGenerator(state) {
    if (state.cards.length < 3) return { ok: false, reason: 'cards' };
    state.generatorOn = true;
    return { ok: true };
  }

  function useExit(state) {
    if (!state.generatorOn) return { ok: false, reason: 'generator' };
    state.status = 'won';
    return { ok: true };
  }

  function drainBattery(state, seconds, rate) {
    if (!state.flashlightOn || state.battery <= 0) return state.battery;
    state.battery = Math.max(0, state.battery - seconds * rate);
    if (state.battery === 0) state.flashlightOn = false;
    return state.battery;
  }

  function demonSpeedMultiplier(inFlashlight) {
    return inFlashlight ? 0.38 : 1;
  }

  function isCaught(px, py, dx, dy, radius) {
    return Math.hypot(px - dx, py - dy) < radius;
  }

  function resetState(state) {
    Object.keys(state).forEach((key) => delete state[key]);
    Object.assign(state, createState());
    return state;
  }

  return {
    createState,
    collectCard,
    activateGenerator,
    useExit,
    drainBattery,
    demonSpeedMultiplier,
    isCaught,
    resetState
  };
});
