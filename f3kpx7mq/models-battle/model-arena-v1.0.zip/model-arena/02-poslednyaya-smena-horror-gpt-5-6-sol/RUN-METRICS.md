# Run Metrics

- **модель**: `gpt-5.6-sol`
- **тест**: 02 — браузерная хоррор-игра «Последняя смена»
- **время API**: недоступно в среде сессии
- **время задачи**: 00:14:02
- **wall-время**: 00:14:02
- **input tokens**: 170 775 без cache read
- **output tokens**: 40 339
- **tokens без кэша, всего**: 211 114
- **cache read**: 2 897 152 (не включены в число токенов выше)
- **cache write**: недоступно в среде сессии
- **стоимость USD**: $3.512621
- **расчёт стоимости**: $0.853875 uncached input + $1.448576 cache read + $1.210170 output = $3.512621
- **примечание к стоимости**: cache-write tokens журнал сессии не раскрывает, поэтому возможная надбавка за запись кэша не поддаётся точному расчёту и в $3.512621 не включена
- **путь к index.html**: `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-gpt-5-6-sol\index.html`
- **короткий вердикт**: PASS — автономная игра запускается; 7/7 тестов правил и 19/19 браузерных проверок пройдены в Google Chrome без исключений консоли.

## Browser verification

- Browser: Google Chrome headless (real installed browser, CDP automation)
- Resolution: 1280×720
- Verified: load/start, keyboard movement, keyboard camera turn, flashlight drain and toggle, generator lock, exit lock, three unique key-card pickups, demon activation, generator activation, victory, demon flashlight slow, contact defeat, victory restart, defeat restart, clean browser console.
- Launch route: direct local `file://.../index.html` (no server required).
- Visual artifacts: `assets/test-artifacts/01-start-screen.png`, `02-victory.png`, `03-demon-in-corridor.png`, `04-defeat.png`.
- Note: the in-app browser control channel rejected this session's sandbox metadata before opening the page, so verification used the locally installed Google Chrome directly. This still exercised the game in a real browser engine.
