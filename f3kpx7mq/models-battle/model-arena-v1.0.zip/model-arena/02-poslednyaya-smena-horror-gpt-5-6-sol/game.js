(function () {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d', { alpha: false });
  const WIDTH = canvas.width;
  const HEIGHT = canvas.height;
  const FOV = Math.PI / 3;
  const MAP_W = 24;
  const MAP_H = 20;
  const keys = Object.create(null);
  const zBuffer = new Float32Array(WIDTH);

  const ui = {
    start: document.getElementById('start-screen'),
    startButton: document.getElementById('start-button'),
    result: document.getElementById('result-screen'),
    resultKicker: document.getElementById('result-kicker'),
    resultTitle: document.getElementById('result-title'),
    resultCopy: document.getElementById('result-copy'),
    restart: document.getElementById('restart-button'),
    hud: document.getElementById('hud'),
    batteryFill: document.getElementById('battery-fill'),
    batteryText: document.getElementById('battery-text'),
    cards: document.getElementById('cards'),
    generator: document.getElementById('generator'),
    objective: document.getElementById('objective'),
    prompt: document.getElementById('prompt'),
    message: document.getElementById('message'),
    danger: document.getElementById('danger'),
    pause: document.getElementById('pause')
  };

  const map = Array.from({ length: MAP_H }, (_, y) =>
    Array.from({ length: MAP_W }, (_, x) => (x === 0 || y === 0 || x === MAP_W - 1 || y === MAP_H - 1 ? '#' : '.'))
  );

  function verticalWall(x, gaps) {
    for (let y = 1; y < MAP_H - 1; y += 1) if (!gaps.includes(y)) map[y][x] = '#';
  }

  function horizontalWall(y, gaps) {
    for (let x = 1; x < MAP_W - 1; x += 1) if (!gaps.includes(x)) map[y][x] = '#';
  }

  verticalWall(6, [3, 10, 16]);
  verticalWall(12, [5, 14]);
  verticalWall(18, [2, 8, 17]);
  horizontalWall(6, [3, 9, 15, 21]);
  horizontalWall(12, [5, 10, 16, 20]);
  horizontalWall(17, [2, 8, 14, 19, 22]);

  const roomNames = [
    { x: 3.2, y: 2.2, text: 'ПОСТ ОХРАНЫ' },
    { x: 3.2, y: 9.1, text: 'ХОЛОДИЛЬНЫЕ КАМЕРЫ' },
    { x: 9.2, y: 9.1, text: 'АРХИВ' },
    { x: 15.1, y: 9.1, text: 'СЕКЦИОННАЯ' },
    { x: 21.1, y: 14.6, text: 'ГЕНЕРАТОРНАЯ' }
  ];

  const objectBlueprints = [
    { id: 'red', kind: 'card', x: 3.6, y: 9.2, label: 'КРАСНАЯ КЛЮЧ-КАРТА', color: '#c84649' },
    { id: 'blue', kind: 'card', x: 9.2, y: 9.2, label: 'СИНЯЯ КЛЮЧ-КАРТА', color: '#5e9fb0' },
    { id: 'yellow', kind: 'card', x: 15.3, y: 15.1, label: 'ЖЁЛТАЯ КЛЮЧ-КАРТА', color: '#c7ae59' },
    { id: 'generator', kind: 'generator', x: 21.0, y: 15.0, label: 'ЗАПУСТИТЬ ГЕНЕРАТОР' },
    { id: 'exit', kind: 'exit', x: 22.35, y: 2.5, label: 'ОТКРЫТЬ ВЫХОД' }
  ];

  let rules;
  let objects;
  let player;
  let demon;
  let started = false;
  let paused = false;
  let lastTime = performance.now();
  let elapsed = 0;
  let messageUntil = 0;
  let interactable = null;
  let flicker = 0;
  let flashPulse = 0;
  let jumpscare = 0;
  let chasePath = [];
  let pathTimer = 0;
  let stepTimer = 0;
  let beatTimer = 0;
  let screenShake = 0;
  let audio = null;

  function resetWorld() {
    rules = GameRules.createState();
    objects = objectBlueprints.map((item) => ({ ...item, active: true }));
    player = { x: 2.45, y: 2.5, angle: 0, bob: 0, moving: false };
    demon = { x: 21.4, y: 18.25, awake: false, seen: false, phase: Math.random() * 10, slowed: false };
    elapsed = 0;
    messageUntil = 0;
    interactable = null;
    flicker = 0;
    flashPulse = 0;
    jumpscare = 0;
    chasePath = [];
    pathTimer = 0;
    stepTimer = 0;
    beatTimer = 0;
    screenShake = 0;
    paused = false;
    ui.result.classList.remove('active', 'victory');
    ui.pause.classList.add('hidden');
    updateHud();
  }

  function cell(x, y) {
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    if (ix < 0 || iy < 0 || ix >= MAP_W || iy >= MAP_H) return '#';
    return map[iy][ix];
  }

  function canWalk(x, y, radius = 0.19) {
    return cell(x - radius, y - radius) !== '#' && cell(x + radius, y - radius) !== '#' &&
      cell(x - radius, y + radius) !== '#' && cell(x + radius, y + radius) !== '#';
  }

  function normalizeAngle(angle) {
    while (angle > Math.PI) angle -= Math.PI * 2;
    while (angle < -Math.PI) angle += Math.PI * 2;
    return angle;
  }

  function distance(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function hasLineOfSight(ax, ay, bx, by) {
    const length = Math.hypot(bx - ax, by - ay);
    const steps = Math.ceil(length * 8);
    for (let i = 1; i < steps; i += 1) {
      const t = i / steps;
      if (cell(ax + (bx - ax) * t, ay + (by - ay) * t) === '#') return false;
    }
    return true;
  }

  function initAudio() {
    if (audio) {
      if (audio.context.state === 'suspended') audio.context.resume();
      return;
    }
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const context = new AudioCtx();
    const master = context.createGain();
    master.gain.value = 0.34;
    master.connect(context.destination);

    const hum = context.createOscillator();
    const humGain = context.createGain();
    hum.type = 'sawtooth';
    hum.frequency.value = 38;
    humGain.gain.value = 0.018;
    hum.connect(humGain).connect(master);
    hum.start();

    const air = context.createBufferSource();
    const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i += 1) data[i] = (Math.random() * 2 - 1) * 0.12;
    air.buffer = buffer;
    air.loop = true;
    const airFilter = context.createBiquadFilter();
    airFilter.type = 'lowpass';
    airFilter.frequency.value = 260;
    const airGain = context.createGain();
    airGain.gain.value = 0.026;
    air.connect(airFilter).connect(airGain).connect(master);
    air.start();

    audio = { context, master, humGain, airGain };
  }

  function tone(freq, duration = 0.12, volume = 0.08, type = 'sine', slide = 1) {
    if (!audio) return;
    const now = audio.context.currentTime;
    const oscillator = audio.context.createOscillator();
    const gain = audio.context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(freq, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(gain).connect(audio.master);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  function noiseBurst(duration = 0.15, volume = 0.08, cutoff = 900) {
    if (!audio) return;
    const count = Math.floor(audio.context.sampleRate * duration);
    const buffer = audio.context.createBuffer(1, count, audio.context.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < count; i += 1) data[i] = Math.random() * 2 - 1;
    const source = audio.context.createBufferSource();
    const filter = audio.context.createBiquadFilter();
    const gain = audio.context.createGain();
    filter.type = 'lowpass';
    filter.frequency.value = cutoff;
    gain.gain.setValueAtTime(volume, audio.context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.context.currentTime + duration);
    source.buffer = buffer;
    source.connect(filter).connect(gain).connect(audio.master);
    source.start();
  }

  function showMessage(text, seconds = 2.2) {
    ui.message.textContent = text;
    ui.message.classList.add('visible');
    messageUntil = elapsed + seconds;
  }

  function requestMouseLock() {
    if (!canvas.requestPointerLock) return;
    try {
      const request = canvas.requestPointerLock();
      if (request && typeof request.catch === 'function') request.catch(() => {});
    } catch {}
  }

  function updateHud() {
    if (!rules) return;
    const battery = Math.ceil(rules.battery);
    ui.batteryText.textContent = `${battery}%${rules.flashlightOn ? '' : ' · ВЫКЛ.'}`;
    ui.batteryFill.style.width = `${battery}%`;
    ui.batteryFill.style.backgroundColor = battery < 22 ? '#bd3236' : '#a9d7b3';
    ui.cards.textContent = `КЛЮЧ-КАРТЫ · ${rules.cards.length}/3`;
    ui.generator.textContent = `ГЕНЕРАТОР: ${rules.generatorOn ? 'ВКЛ.' : 'ВЫКЛ.'}`;
    ui.generator.style.color = rules.generatorOn ? '#a9d7b3' : '';
    if (rules.generatorOn) ui.objective.textContent = 'ДОБЕРИТЕСЬ ДО ВЫХОДА';
    else if (rules.cards.length === 3) ui.objective.textContent = 'ЗАПУСТИТЕ ГЕНЕРАТОР';
    else ui.objective.textContent = 'НАЙДИТЕ КЛЮЧ-КАРТЫ';
  }

  function startGame() {
    if (!rules) resetWorld();
    started = true;
    paused = false;
    ui.start.classList.remove('active');
    ui.result.classList.remove('active');
    ui.hud.classList.remove('hidden');
    ui.pause.classList.add('hidden');
    initAudio();
    requestMouseLock();
    showMessage('СВЕТ АВАРИЙНОГО ПИТАНИЯ ПОГАС', 2.8);
    lastTime = performance.now();
  }

  function restartGame() {
    resetWorld();
    started = true;
    ui.hud.classList.remove('hidden');
    initAudio();
    requestMouseLock();
    showMessage('03:17 · СМЕНА НАЧАЛАСЬ СНОВА', 2.1);
    lastTime = performance.now();
  }

  function toggleFlashlight() {
    if (!started || paused || rules.status !== 'playing') return;
    if (rules.battery <= 0) {
      showMessage('БАТАРЕЯ РАЗРЯЖЕНА', 1.3);
      tone(45, 0.08, 0.05, 'square', 0.6);
      return;
    }
    rules.flashlightOn = !rules.flashlightOn;
    flashPulse = 0.28;
    tone(rules.flashlightOn ? 420 : 160, 0.055, 0.055, 'square', 0.75);
    updateHud();
  }

  function nearestInteractable() {
    let best = null;
    let bestDistance = 1.25;
    for (const object of objects) {
      if (!object.active) continue;
      const d = distance(player, object);
      if (d < bestDistance) {
        best = object;
        bestDistance = d;
      }
    }
    return best;
  }

  function interact() {
    if (!started || paused || rules.status !== 'playing') return;
    const object = nearestInteractable();
    if (!object) return;

    if (object.kind === 'card') {
      if (GameRules.collectCard(rules, object.id)) {
        object.active = false;
        tone(660, 0.22, 0.1, 'triangle', 1.45);
        noiseBurst(0.1, 0.04, 1500);
        showMessage(`${object.label} ПОЛУЧЕНА`, 2);
        flicker = 0.8;
        if (!demon.awake) {
          demon.awake = true;
          setTimeout(() => {
            if (started && rules.status === 'playing') {
              noiseBurst(0.8, 0.16, 430);
              tone(54, 0.9, 0.14, 'sawtooth', 0.5);
              showMessage('В КОРИДОРЕ КТО-ТО ДЫШИТ', 2.5);
            }
          }, 650);
        }
      }
    } else if (object.kind === 'generator') {
      const result = GameRules.activateGenerator(rules);
      if (!result.ok) {
        showMessage(`НУЖНЫ ВСЕ КЛЮЧ-КАРТЫ · ${rules.cards.length}/3`, 1.7);
        tone(90, 0.12, 0.07, 'square', 0.55);
      } else {
        object.label = 'ГЕНЕРАТОР РАБОТАЕТ';
        tone(62, 1.1, 0.16, 'sawtooth', 1.12);
        flicker = 1.5;
        showMessage('ПИТАНИЕ ВОССТАНОВЛЕНО · ВЫХОД РАЗБЛОКИРОВАН', 3);
        if (audio) audio.humGain.gain.setTargetAtTime(0.045, audio.context.currentTime, 0.4);
      }
    } else if (object.kind === 'exit') {
      const result = GameRules.useExit(rules);
      if (!result.ok) {
        showMessage('ЭЛЕКТРОЗАМОК ОБЕСТОЧЕН', 1.7);
        tone(78, 0.18, 0.07, 'square', 0.6);
      } else {
        winGame();
      }
    }
    updateHud();
  }

  function winGame() {
    rules.status = 'won';
    document.exitPointerLock?.();
    tone(246, 0.7, 0.1, 'sine', 1.8);
    ui.result.classList.add('active', 'victory');
    ui.resultKicker.textContent = '04:02 · НАРУЖНАЯ ДВЕРЬ ОТКРЫТА';
    ui.resultTitle.textContent = 'ВЫ ВЫБРАЛИСЬ';
    ui.resultCopy.textContent = 'За спиной хлопнула дверь. Изнутри кто-то трижды постучал.';
  }

  function beginDefeat() {
    if (rules.status !== 'playing') return;
    rules.status = 'jumpscare';
    jumpscare = 0.95;
    screenShake = 1;
    noiseBurst(0.7, 0.28, 1800);
    tone(96, 0.8, 0.22, 'sawtooth', 0.24);
  }

  function finishDefeat() {
    rules.status = 'lost';
    document.exitPointerLock?.();
    ui.result.classList.remove('victory');
    ui.result.classList.add('active');
    ui.resultKicker.textContent = 'ЗАПИСЬ С КАМЕРЫ · СИГНАЛ ПОТЕРЯН';
    ui.resultTitle.textContent = 'ВАС НАШЛИ';
    ui.resultCopy.textContent = 'В морге снова тихо. Вашу смену никто не закончил.';
  }

  function updatePlayer(dt) {
    let forward = 0;
    let strafe = 0;
    if (keys.KeyW || keys.ArrowUp) forward += 1;
    if (keys.KeyS || keys.ArrowDown) forward -= 1;
    if (keys.KeyA) strafe -= 1;
    if (keys.KeyD) strafe += 1;
    if (keys.ArrowLeft) player.angle -= 1.8 * dt;
    if (keys.ArrowRight) player.angle += 1.8 * dt;

    const magnitude = Math.hypot(forward, strafe) || 1;
    forward /= magnitude;
    strafe /= magnitude;
    const speed = 2.25 * dt;
    const dx = (Math.cos(player.angle) * forward + Math.cos(player.angle + Math.PI / 2) * strafe) * speed;
    const dy = (Math.sin(player.angle) * forward + Math.sin(player.angle + Math.PI / 2) * strafe) * speed;
    if (canWalk(player.x + dx, player.y)) player.x += dx;
    if (canWalk(player.x, player.y + dy)) player.y += dy;
    player.moving = Math.abs(dx) + Math.abs(dy) > 0.001;

    if (player.moving) {
      player.bob += dt * 10;
      stepTimer -= dt;
      if (stepTimer <= 0) {
        noiseBurst(0.045, 0.025, 180);
        stepTimer = 0.43;
      }
    }
  }

  function findPath(sx, sy, tx, ty) {
    const startX = Math.floor(sx);
    const startY = Math.floor(sy);
    const targetX = Math.floor(tx);
    const targetY = Math.floor(ty);
    const queue = [[startX, startY]];
    const seen = new Set([`${startX},${startY}`]);
    const parent = new Map();
    const directions = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    let found = false;

    for (let head = 0; head < queue.length; head += 1) {
      const [x, y] = queue[head];
      if (x === targetX && y === targetY) { found = true; break; }
      for (const [dx, dy] of directions) {
        const nx = x + dx;
        const ny = y + dy;
        const key = `${nx},${ny}`;
        if (nx < 1 || ny < 1 || nx >= MAP_W - 1 || ny >= MAP_H - 1 || map[ny][nx] === '#' || seen.has(key)) continue;
        seen.add(key);
        parent.set(key, [x, y]);
        queue.push([nx, ny]);
      }
    }

    if (!found) return [];
    const path = [[targetX, targetY]];
    let cursor = [targetX, targetY];
    while (cursor[0] !== startX || cursor[1] !== startY) {
      cursor = parent.get(`${cursor[0]},${cursor[1]}`);
      if (!cursor) return [];
      path.push(cursor);
    }
    return path.reverse();
  }

  function demonInFlashlight() {
    if (!rules.flashlightOn || rules.battery <= 0 || !demon.awake) return false;
    const dx = demon.x - player.x;
    const dy = demon.y - player.y;
    const d = Math.hypot(dx, dy);
    const angle = Math.abs(normalizeAngle(Math.atan2(dy, dx) - player.angle));
    return d < 8.5 && angle < 0.32 && hasLineOfSight(player.x, player.y, demon.x, demon.y);
  }

  function updateDemon(dt) {
    if (!demon.awake || rules.status !== 'playing') return;
    demon.phase += dt * (demon.slowed ? 3 : 7);
    demon.slowed = demonInFlashlight();
    pathTimer -= dt;
    if (pathTimer <= 0) {
      chasePath = findPath(demon.x, demon.y, player.x, player.y);
      pathTimer = 0.3;
    }

    if (chasePath.length > 1) {
      const target = { x: chasePath[1][0] + 0.5, y: chasePath[1][1] + 0.5 };
      const dx = target.x - demon.x;
      const dy = target.y - demon.y;
      const d = Math.hypot(dx, dy) || 1;
      const baseSpeed = 1.08 + rules.cards.length * 0.13 + (rules.generatorOn ? 0.26 : 0);
      const speed = baseSpeed * GameRules.demonSpeedMultiplier(demon.slowed) * dt;
      demon.x += dx / d * Math.min(speed, d);
      demon.y += dy / d * Math.min(speed, d);
    }

    const proximity = distance(player, demon);
    ui.danger.classList.toggle('hot', proximity < 3.1);
    if (proximity < 6) {
      beatTimer -= dt;
      if (beatTimer <= 0) {
        tone(47, 0.12, Math.min(0.15, 0.04 + (6 - proximity) * 0.018), 'sine', 0.72);
        setTimeout(() => tone(42, 0.1, 0.045, 'sine', 0.7), 115);
        beatTimer = Math.max(0.28, proximity * 0.11);
      }
    }
    if (GameRules.isCaught(player.x, player.y, demon.x, demon.y, 0.72)) beginDefeat();
  }

  function update(dt) {
    if (!started || paused) return;
    elapsed += dt;
    if (messageUntil && elapsed > messageUntil) ui.message.classList.remove('visible');
    if (flicker > 0) flicker -= dt;
    if (flashPulse > 0) flashPulse -= dt;
    if (screenShake > 0) screenShake = Math.max(0, screenShake - dt * 1.2);

    if (rules.status === 'jumpscare') {
      jumpscare -= dt;
      if (jumpscare <= 0) finishDefeat();
      return;
    }
    if (rules.status !== 'playing') return;

    updatePlayer(dt);
    GameRules.drainBattery(rules, dt, demon.slowed ? 0.72 : 0.48);
    updateDemon(dt);
    interactable = nearestInteractable();
    if (interactable) {
      let label = interactable.label;
      if (interactable.kind === 'generator' && rules.generatorOn) label = 'ГЕНЕРАТОР РАБОТАЕТ';
      if (interactable.kind === 'exit' && !rules.generatorOn) label = 'ВЫХОД ОБЕСТОЧЕН';
      ui.prompt.textContent = label;
      ui.prompt.classList.add('visible');
    } else {
      ui.prompt.classList.remove('visible');
    }
    updateHud();
  }

  function castRay(rayAngle) {
    const dirX = Math.cos(rayAngle);
    const dirY = Math.sin(rayAngle);
    let mapX = Math.floor(player.x);
    let mapY = Math.floor(player.y);
    const deltaX = Math.abs(1 / (dirX || 0.000001));
    const deltaY = Math.abs(1 / (dirY || 0.000001));
    const stepX = dirX < 0 ? -1 : 1;
    const stepY = dirY < 0 ? -1 : 1;
    let sideX = dirX < 0 ? (player.x - mapX) * deltaX : (mapX + 1 - player.x) * deltaX;
    let sideY = dirY < 0 ? (player.y - mapY) * deltaY : (mapY + 1 - player.y) * deltaY;
    let side = 0;

    for (let guard = 0; guard < 64; guard += 1) {
      if (sideX < sideY) { sideX += deltaX; mapX += stepX; side = 0; }
      else { sideY += deltaY; mapY += stepY; side = 1; }
      if (mapY < 0 || mapX < 0 || mapY >= MAP_H || mapX >= MAP_W || map[mapY][mapX] === '#') break;
    }

    const rawDistance = side === 0
      ? (mapX - player.x + (1 - stepX) / 2) / (dirX || 0.000001)
      : (mapY - player.y + (1 - stepY) / 2) / (dirY || 0.000001);
    const corrected = Math.max(0.001, rawDistance * Math.cos(rayAngle - player.angle));
    const hitX = player.x + dirX * rawDistance;
    const hitY = player.y + dirY * rawDistance;
    const texture = side === 0 ? hitY - Math.floor(hitY) : hitX - Math.floor(hitX);
    return { distance: corrected, rawDistance, side, mapX, mapY, texture };
  }

  function wallColor(hit, brightness, stripe) {
    const boundaryExit = hit.mapX === MAP_W - 1 && hit.mapY === 2;
    const doorPanel = boundaryExit || ((hit.mapX * 13 + hit.mapY * 7) % 19 === 0 && hit.texture > 0.12 && hit.texture < 0.88);
    let r = doorPanel ? 41 : 48;
    let g = doorPanel ? 50 : 57;
    let b = doorPanel ? 50 : 55;
    if (stripe) { r += 20; g += 18; b += 12; }
    if (hit.side) brightness *= 0.76;
    return `rgb(${Math.floor(r * brightness)},${Math.floor(g * brightness)},${Math.floor(b * brightness)})`;
  }

  function renderWorld() {
    const bob = player.moving ? Math.sin(player.bob) * 3 : 0;
    const shakeX = screenShake ? (Math.random() - 0.5) * 16 * screenShake : 0;
    const shakeY = screenShake ? (Math.random() - 0.5) * 12 * screenShake : 0;
    ctx.save();
    ctx.translate(shakeX, shakeY + bob);

    const ceiling = ctx.createLinearGradient(0, 0, 0, HEIGHT / 2);
    ceiling.addColorStop(0, rules.generatorOn ? '#111918' : '#05090a');
    ceiling.addColorStop(1, '#0a0e0f');
    ctx.fillStyle = ceiling;
    ctx.fillRect(-20, -20, WIDTH + 40, HEIGHT / 2 + 20);
    const floor = ctx.createLinearGradient(0, HEIGHT / 2, 0, HEIGHT + 20);
    floor.addColorStop(0, '#0d1112');
    floor.addColorStop(1, '#020405');
    ctx.fillStyle = floor;
    ctx.fillRect(-20, HEIGHT / 2, WIDTH + 40, HEIGHT / 2 + 30);

    ctx.strokeStyle = 'rgba(99,111,107,.08)';
    for (let y = HEIGHT / 2 + 20; y < HEIGHT; y += 34) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(WIDTH, y); ctx.stroke();
    }

    const flickering = flicker > 0 && Math.random() < 0.43;
    for (let x = 0; x < WIDTH; x += 2) {
      const cameraX = x / WIDTH - 0.5;
      const rayAngle = player.angle + cameraX * FOV;
      const hit = castRay(rayAngle);
      zBuffer[x] = hit.distance;
      zBuffer[x + 1] = hit.distance;
      const wallHeight = Math.min(HEIGHT * 2.1, HEIGHT / hit.distance);
      const top = HEIGHT / 2 - wallHeight / 2;
      const center = Math.abs(cameraX * 2);
      let beam = rules.flashlightOn ? Math.max(0, 1 - center * center * 1.45) : 0;
      beam *= Math.max(0, 1 - hit.distance / 13);
      const emergency = rules.generatorOn ? 0.34 : 0.16;
      let brightness = emergency + beam * 1.38;
      if (flickering) brightness *= 0.13;
      if (flashPulse > 0) brightness *= 1.35;
      const stripeY = (HEIGHT / 2 - top) / Math.max(1, wallHeight);
      const stripe = stripeY > 0.54 && stripeY < 0.6;
      ctx.fillStyle = wallColor(hit, Math.min(1.55, brightness), stripe);
      ctx.fillRect(x, top, 2, wallHeight);

      const seam = hit.texture < 0.025 || hit.texture > 0.975;
      if (seam) {
        ctx.fillStyle = `rgba(2,4,4,${Math.min(.75, .16 + hit.distance * .03)})`;
        ctx.fillRect(x, top, 2, wallHeight);
      }
      if (wallHeight > 95 && hit.texture > .47 && hit.texture < .485 && (hit.mapX + hit.mapY) % 4 === 0) {
        ctx.fillStyle = `rgba(8,10,10,${Math.min(.7, 1 / hit.distance)})`;
        ctx.fillRect(x, top + wallHeight * .23, 2, wallHeight * .5);
      }
    }

    renderSprites();
    renderFlashlightOverlay(flickering);
    ctx.restore();

    if (rules.status === 'jumpscare') renderJumpscare();
  }

  function projectSprite(object) {
    const dirX = Math.cos(player.angle);
    const dirY = Math.sin(player.angle);
    const planeX = -dirY * Math.tan(FOV / 2);
    const planeY = dirX * Math.tan(FOV / 2);
    const spriteX = object.x - player.x;
    const spriteY = object.y - player.y;
    const invDet = 1 / (planeX * dirY - dirX * planeY);
    const transformX = invDet * (dirY * spriteX - dirX * spriteY);
    const transformY = invDet * (-planeY * spriteX + planeX * spriteY);
    if (transformY <= 0.12) return null;
    return { x: WIDTH / 2 * (1 + transformX / transformY), depth: transformY };
  }

  function renderSprites() {
    const sprites = objects.filter((o) => o.active).concat(demon.awake ? [{ ...demon, kind: 'demon' }] : []);
    sprites.sort((a, b) => distance(player, b) - distance(player, a));
    for (const object of sprites) {
      const projection = projectSprite(object);
      if (!projection) continue;
      const centerX = Math.max(0, Math.min(WIDTH - 1, Math.floor(projection.x)));
      if (projection.depth > zBuffer[centerX] + 0.35) continue;
      if (object.kind === 'demon') drawDemon(projection.x, projection.depth);
      else if (object.kind === 'card') drawCard(object, projection.x, projection.depth);
      else if (object.kind === 'generator') drawGenerator(projection.x, projection.depth);
      else if (object.kind === 'exit') drawExit(projection.x, projection.depth);
    }
  }

  function drawCard(object, x, depth) {
    const size = Math.min(120, 54 / depth);
    const y = HEIGHT / 2 + size * 1.4 + Math.sin(elapsed * 2.4 + object.x) * 4;
    ctx.save();
    ctx.translate(x, y);
    ctx.shadowBlur = 18 / Math.max(1, depth);
    ctx.shadowColor = object.color;
    ctx.fillStyle = '#101616';
    ctx.strokeStyle = object.color;
    ctx.lineWidth = Math.max(1, size * .06);
    ctx.rotate(-0.08);
    ctx.fillRect(-size * .65, -size * .42, size * 1.3, size * .84);
    ctx.strokeRect(-size * .65, -size * .42, size * 1.3, size * .84);
    ctx.fillStyle = object.color;
    ctx.fillRect(-size * .5, -size * .24, size * .33, size * .2);
    ctx.fillRect(-size * .5, size * .12, size * .75, size * .05);
    ctx.fillRect(-size * .5, size * .24, size * .52, size * .04);
    ctx.restore();
  }

  function drawGenerator(x, depth) {
    const size = Math.min(280, 190 / depth);
    const y = HEIGHT / 2 + size * .27;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = '#19201f';
    ctx.strokeStyle = '#60716a';
    ctx.lineWidth = Math.max(1, size * .014);
    ctx.fillRect(-size * .55, -size * .48, size * 1.1, size * .96);
    ctx.strokeRect(-size * .55, -size * .48, size * 1.1, size * .96);
    ctx.fillStyle = '#080b0b';
    ctx.fillRect(-size * .38, -size * .3, size * .76, size * .31);
    ctx.fillStyle = rules.generatorOn ? '#72df91' : '#b73539';
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = size * .1;
    ctx.beginPath(); ctx.arc(size * .25, -size * .15, size * .045, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#87918c';
    for (let i = -2; i <= 2; i += 1) {
      ctx.beginPath(); ctx.moveTo(-size * .35, size * (.13 + i * .055)); ctx.lineTo(size * .35, size * (.13 + i * .055)); ctx.stroke();
    }
    ctx.restore();
  }

  function drawExit(x, depth) {
    const height = Math.min(HEIGHT * 1.4, HEIGHT * .95 / depth);
    const width = height * .48;
    const y = HEIGHT / 2 - height / 2;
    ctx.save();
    ctx.fillStyle = rules.generatorOn ? '#263d34' : '#171d1d';
    ctx.strokeStyle = rules.generatorOn ? '#95d0a5' : '#4d5854';
    ctx.lineWidth = Math.max(2, width * .025);
    ctx.fillRect(x - width / 2, y, width, height);
    ctx.strokeRect(x - width / 2, y, width, height);
    ctx.fillStyle = '#080b0b';
    ctx.fillRect(x - width * .34, y + height * .09, width * .68, height * .17);
    ctx.fillStyle = rules.generatorOn ? '#8de6a4' : '#a72b31';
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 12;
    ctx.fillRect(x + width * .29, y + height * .49, width * .06, height * .06);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#8d9993';
    ctx.font = `bold ${Math.max(7, width * .105)}px Arial Narrow`;
    ctx.textAlign = 'center';
    ctx.fillText('ВЫХОД', x, y + height * .19);
    ctx.restore();
  }

  function drawDemon(x, depth) {
    const height = Math.min(HEIGHT * 2.7, HEIGHT * 1.62 / depth);
    const width = height * .42;
    const sway = Math.sin(demon.phase) * width * .025;
    const y = HEIGHT / 2 - height * .56 + Math.abs(Math.sin(demon.phase * .5)) * height * .02;
    const lit = demon.slowed;
    demon.seen = true;
    ctx.save();
    ctx.translate(x + sway, y);
    ctx.shadowColor = lit ? 'rgba(186,211,199,.4)' : 'rgba(0,0,0,.9)';
    ctx.shadowBlur = lit ? 20 : 45;
    ctx.fillStyle = lit ? '#0a0d0d' : '#020303';

    ctx.beginPath();
    ctx.moveTo(-width * .15, height * .27);
    ctx.quadraticCurveTo(-width * .34, height * .5, -width * .26, height * .93);
    ctx.lineTo(-width * .13, height * .95);
    ctx.lineTo(-width * .04, height * .55);
    ctx.lineTo(width * .03, height * .55);
    ctx.lineTo(width * .13, height * .96);
    ctx.lineTo(width * .27, height * .94);
    ctx.quadraticCurveTo(width * .35, height * .5, width * .14, height * .27);
    ctx.closePath();
    ctx.fill();

    ctx.lineWidth = Math.max(3, width * .09);
    ctx.lineCap = 'round';
    ctx.strokeStyle = ctx.fillStyle;
    ctx.beginPath();
    ctx.moveTo(-width * .13, height * .31);
    ctx.lineTo(-width * (.34 + Math.sin(demon.phase) * .025), height * .73);
    ctx.lineTo(-width * .29, height * .92);
    ctx.moveTo(width * .13, height * .31);
    ctx.lineTo(width * (.35 - Math.sin(demon.phase) * .025), height * .72);
    ctx.lineTo(width * .3, height * .91);
    ctx.stroke();

    ctx.shadowBlur = lit ? 10 : 24;
    ctx.fillStyle = lit ? '#a8aea7' : '#727872';
    ctx.beginPath();
    ctx.ellipse(0, height * .16, width * .145, height * .145, Math.sin(demon.phase * .23) * .05, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(22,24,23,.86)';
    ctx.beginPath();
    ctx.ellipse(0, height * .19, width * .09, height * .085, 0, 0, Math.PI * 2);
    ctx.fill();

    const eyeY = height * .135;
    ctx.fillStyle = lit ? '#e8fff1' : '#d6fff0';
    ctx.shadowColor = '#b5ffe0';
    ctx.shadowBlur = Math.max(8, width * .09);
    ctx.beginPath(); ctx.ellipse(-width * .055, eyeY, width * .029, height * .013, -.12, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(width * .055, eyeY, width * .029, height * .013, .12, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = 'rgba(25,27,25,.8)';
    ctx.lineWidth = Math.max(1, width * .012);
    ctx.beginPath();
    ctx.moveTo(-width * .105, height * .085); ctx.lineTo(-width * .04, height * .2);
    ctx.moveTo(width * .09, height * .07); ctx.lineTo(width * .025, height * .22);
    ctx.stroke();
    ctx.restore();
  }

  function renderFlashlightOverlay(flickering) {
    const intensity = rules.flashlightOn && !flickering ? Math.max(.22, rules.battery / 100) : 0;
    const gradient = ctx.createRadialGradient(WIDTH / 2, HEIGHT * .48, 18, WIDTH / 2, HEIGHT * .48, WIDTH * .55);
    gradient.addColorStop(0, `rgba(198,218,204,${0.08 * intensity})`);
    gradient.addColorStop(.22, 'rgba(0,0,0,0)');
    gradient.addColorStop(.53, `rgba(0,0,0,${.35 + (1 - intensity) * .2})`);
    gradient.addColorStop(1, `rgba(0,0,0,${.94 - intensity * .08})`);
    ctx.fillStyle = gradient;
    ctx.fillRect(-20, -20, WIDTH + 40, HEIGHT + 40);
  }

  function renderJumpscare() {
    const progress = 1 - jumpscare / .95;
    ctx.save();
    ctx.fillStyle = `rgba(${Math.floor(50 + progress * 60)},0,3,${0.2 + progress * .35})`;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);
    const scale = 1 + progress * 3.4;
    ctx.translate(WIDTH / 2 + (Math.random() - .5) * 24, HEIGHT / 2 + (Math.random() - .5) * 18);
    ctx.scale(scale, scale);
    ctx.fillStyle = '#090b0a';
    ctx.beginPath(); ctx.ellipse(0, 0, 104, 155, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#aaa9a1';
    ctx.beginPath(); ctx.ellipse(0, -12, 58, 82, -.04, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#111';
    ctx.beginPath(); ctx.ellipse(0, 17, 31, 39, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#eafff4';
    ctx.shadowColor = '#c5ffe7'; ctx.shadowBlur = 22;
    ctx.beginPath(); ctx.ellipse(-24, -30, 10, 5, -.15, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(23, -30, 10, 5, .15, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function render() {
    if (!rules) return;
    renderWorld();
  }

  function frame(now) {
    const dt = Math.min(0.05, (now - lastTime) / 1000 || 0);
    lastTime = now;
    update(dt);
    render();
    requestAnimationFrame(frame);
  }

  window.addEventListener('keydown', (event) => {
    keys[event.code] = true;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(event.code)) event.preventDefault();
    if (event.code === 'KeyF' && !event.repeat) toggleFlashlight();
    if (event.code === 'KeyE' && !event.repeat) interact();
  });
  window.addEventListener('keyup', (event) => { keys[event.code] = false; });
  window.addEventListener('blur', () => Object.keys(keys).forEach((key) => { keys[key] = false; }));
  document.addEventListener('mousemove', (event) => {
    if (document.pointerLockElement === canvas && started && !paused && rules.status === 'playing') {
      player.angle = normalizeAngle(player.angle + event.movementX * .00225);
    }
  });
  document.addEventListener('pointerlockchange', () => {
    if (!started || rules.status !== 'playing') return;
    paused = document.pointerLockElement !== canvas;
    ui.pause.classList.toggle('hidden', !paused);
  });
  canvas.addEventListener('click', () => {
    if (started && rules.status === 'playing' && document.pointerLockElement !== canvas) requestMouseLock();
  });
  ui.pause.addEventListener('click', requestMouseLock);
  ui.startButton.addEventListener('click', startGame);
  ui.restart.addEventListener('click', restartGame);

  resetWorld();
  requestAnimationFrame(frame);

  window.__horrorDebug = {
    getState() {
      return {
        ...rules,
        cards: [...rules.cards],
        player: { ...player },
        demon: { ...demon },
        started,
        paused,
        interactable: interactable?.id || null
      };
    },
    start: startGame,
    restart: restartGame,
    interact,
    toggleFlashlight,
    setAngle(angle) { player.angle = angle; },
    teleport(id) {
      const object = objects.find((item) => item.id === id);
      if (!object) throw new Error(`Unknown object: ${id}`);
      player.x = object.x - .55;
      player.y = object.y;
      player.angle = 0;
      interactable = object;
      return { x: player.x, y: player.y };
    },
    setDemonNear(distanceFromPlayer = 1.2) {
      demon.awake = true;
      demon.x = player.x + Math.cos(player.angle) * distanceFromPlayer;
      demon.y = player.y + Math.sin(player.angle) * distanceFromPlayer;
      return { x: demon.x, y: demon.y };
    },
    forceDefeat() {
      demon.awake = true;
      demon.x = player.x + .2;
      demon.y = player.y;
      beginDefeat();
    },
    forceResume() { paused = false; ui.pause.classList.add('hidden'); },
    map: map.map((row) => row.join(''))
  };
})();
