# YouTube Retention Dashboard Design

## Purpose

Build a local, browser-only Russian-language dashboard that accepts a YouTube Studio ZIP export or multiple CSV files and produces a numerical retention analysis without inventing video context.

## Architecture

The application is a static site. `index.html` provides the semantic shell, `styles.css` owns the dense responsive visual system, `js/analyzer.js` contains pure parsing/classification/analysis functions, and `js/app.js` coordinates file input, ZIP extraction, rendering, charts, and user feedback. A vendored JSZip build avoids a runtime CDN dependency; manual CSV upload remains available when ZIP processing fails.

## Data flow

1. The user drops or selects a ZIP/CSV set.
2. Browser file bytes are decoded as UTF-8 with BOM handling and a Windows-1252 fallback; common mojibake is repaired conservatively.
3. A quote-aware delimiter parser reads CSV rows and treats header-only files as valid `empty` reports.
4. Reports are classified from normalized file names and column signatures, with column signatures taking precedence when names are damaged.
5. The general retention curve and activity-detail report drive key points, sharp one-point drops, ending moments, and replay moments. Segment reports drive pair/group comparisons.
6. Recommendations cite measured values and use conditional language. Missing context is always disclosed.

## Report types

- `overall`: position + absolute retention without a segment column.
- `activity`: position + starts + ends + moment-view count.
- `subscriber`: position + subscription status + retention.
- `newReturning`: position + new/returning segment + retention.
- `viewerLoyalty`: position + new/occasional/regular segment + retention.
- `traffic`: position + audience/traffic segment + retention.
- `benchmark`: position + retention + comparison-to-other-videos.
- `unknown`: readable CSV that does not match a supported signature.

Empty known reports preserve their inferred type and display `нет данных`, never an error.

## Analysis rules

- Key points use exact or linearly interpolated retention at 0, 1, 5, 10, 25, 50, 75, 90, and 99 percent of video position.
- Sharp drops rank adjacent retention deltas from most negative; each item shows the interval, both values, and percentage-point change.
- Ending and replay lists rank the corresponding activity counts and show position plus count.
- Segment comparison uses weighted mean retention over available positions plus differences at 1%, 25%, 50%, 75%, and 99% when present.
- Recommendations cover hook, pace, middle, ending, and structure only when data support a numerical observation. They never label unseen content.

## Interface

Visual direction: an editorial analytics control room—warm off-white canvas, near-black ink, electric cyan for retention, vermilion for losses, squared panels, tabular numerals, and restrained motion. The top strip immediately shows import state, recognized files, and primary metrics. The main grid prioritizes the retention curve, key points, anomalies, segment comparisons, recommendations, and limitations. Mobile layout becomes a single readable column.

## Error handling

- ZIP library unavailable or invalid ZIP: show a direct failure message and keep CSV fallback active.
- Empty ZIP/no CSV: show a recoverable warning.
- Empty CSV: list as `нет данных`.
- Malformed rows: skip unusable rows, keep the report visible, and report ignored-row counts.
- No overall curve: render available inventory/comparisons and explain which analysis blocks require it.

## Verification

Node tests cover quoted commas, delimiters, mojibake normalization, report classification, empty files, key-point interpolation, sharp drops, activity ranking, segment comparison, and recommendation honesty. A real-archive integration test verifies nine discovered reports, two empty reports, and expected values from `Alle.csv`. Browser verification covers initial state, ZIP upload, visible summary, chart/table/list rendering, responsive layout, and console errors.

