# YouTube Retention Dashboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a working local Russian browser dashboard for ZIP/CSV YouTube retention analysis.

**Architecture:** A static browser app separates pure parsing and analytics from DOM rendering. JSZip is vendored locally; Node's built-in test runner tests the pure module and the supplied real ZIP fixture.

**Tech Stack:** HTML5, CSS Grid, vanilla JavaScript, Canvas 2D, JSZip, Node.js built-in test runner.

## Global Constraints

- Store every created file under `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\05-youtube-retention-dashboard-gpt-5-6-sol\`.
- All UI text is Russian; code and documentation are English.
- No Google API, authorization, server, fabricated data, or fabricated content explanations.
- Empty CSV is a valid `нет данных` state.
- ZIP and multi-CSV upload both remain available.

---

### Task 1: Parser and classifier

**Files:**
- Create: `tests/analyzer.test.js`
- Create: `js/analyzer.js`

**Interfaces:**
- Produces: `parseCsv(text)`, `normalizeText(text)`, `classifyReport(fileName, headers)`, `buildReport(fileName, text)`.

- [ ] Write tests for quoted commas, semicolon delimiters, German headers, damaged names, and header-only CSV.
- [ ] Run `node --test tests/analyzer.test.js` and confirm failures because the module is missing.
- [ ] Implement CSV parsing and signature-based classification.
- [ ] Re-run the test command and confirm the parser/classifier cases pass.

### Task 2: Numerical analysis

**Files:**
- Modify: `tests/analyzer.test.js`
- Modify: `js/analyzer.js`

**Interfaces:**
- Consumes: normalized report rows from Task 1.
- Produces: `analyzeReports(reports)` with `curve`, `keyPoints`, `drops`, `endings`, `rewatches`, `comparisons`, `recommendations`, and `limitations`.

- [ ] Add failing tests for interpolation, adjacent drops, activity ranking, comparisons, and content-honest recommendations.
- [ ] Confirm the new tests fail for missing analysis functions.
- [ ] Implement numeric extraction, rankings, comparisons, and evidence-based recommendation generation.
- [ ] Run all tests and confirm they pass.

### Task 3: Real ZIP integration

**Files:**
- Modify: `tests/analyzer.test.js`
- Create: `vendor/jszip.min.js`

**Interfaces:**
- Consumes: supplied ZIP fixture and `buildReport`.
- Produces: verified compatibility with the actual YouTube Studio export.

- [ ] Vendor JSZip and add an async integration test reading every CSV entry from the supplied ZIP.
- [ ] Confirm the test fails before ZIP wiring is complete.
- [ ] Wire the local JSZip module into the integration test.
- [ ] Verify 9 CSV reports, 2 empty reports, and known key-point values.

### Task 4: Dashboard interface

**Files:**
- Create: `index.html`
- Create: `styles.css`
- Create: `js/app.js`

**Interfaces:**
- Consumes: browser `File` objects, global `JSZip`, and global `RetentionAnalyzer`.
- Produces: upload controls, report inventory, Canvas chart, metrics, tables, lists, comparisons, recommendations, and limitations.

- [ ] Add a DOM contract test that asserts required regions and Russian labels in `index.html`; confirm it fails.
- [ ] Build the semantic HTML shell and dense responsive CSS.
- [ ] Implement ZIP/CSV input, analysis rendering, accessible chart/table output, and recoverable errors.
- [ ] Run tests and inspect the dashboard at desktop and mobile widths.

### Task 5: Documentation and final verification

**Files:**
- Create: `README.md`
- Create: `RUN-METRICS.md`

**Interfaces:**
- Produces: launch/upload instructions and evidence-based run metrics.

- [ ] Document direct `index.html` launch and optional local HTTP server.
- [ ] Record model run scope, files, test counts, fixture facts, and known instability.
- [ ] Run the full Node suite, a real ZIP browser import, a syntax check, and a final file-scope audit.
- [ ] Verify every requested capability against the rendered dashboard and report only evidenced results.

