const { test, expect } = require('@playwright/test');
const path = require('node:path');
const os = require('node:os');
const { pathToFileURL } = require('node:url');

const fixture = 'C:\\Projects\\Video\\2026-fable-opus-sonnet-test\\tests\\fixtures\\youtube-retention-claude-openrouter.zip';

test('loads the supplied ZIP and renders every analysis block', async ({ page }) => {
  const consoleErrors = [];
  page.on('console', (message) => { if (message.type() === 'error') consoleErrors.push(message.text()); });
  await page.goto('/index.html');
  await expect(page.getByRole('heading', { name: 'Анализатор удержания ролика' })).toBeVisible();
  await expect(page.getByText('Сначала данные.')).toBeVisible();

  await page.locator('#zip-input').setInputFiles(fixture);
  await expect(page.locator('#system-state-text')).toHaveText('Анализ готов');
  await expect(page.locator('.report-item')).toHaveCount(9);
  await expect(page.locator('.report-status.empty')).toHaveCount(2);
  await expect(page.locator('#metric-middle')).toHaveText('34,08%');
  await expect(page.locator('#metric-drop')).toHaveText('-19,49 п.п.');
  await expect(page.locator('#metric-end')).toHaveText('9,53%');
  await expect(page.locator('#retention-chart .chart-line')).toHaveCount(1);
  await expect(page.locator('#keypoints-body tr')).toHaveCount(9);
  await expect(page.locator('#drops-list .rank-item')).toHaveCount(8);
  await expect(page.locator('#endings-list .rank-item')).toHaveCount(8);
  await expect(page.locator('#rewatches-list .rank-item')).toHaveCount(8);
  await expect(page.locator('.comparison-card')).toHaveCount(3);
  await expect(page.locator('.comparison-card').filter({ hasText: 'Новые, случайные и регулярные' })).toContainText('Нет данных для сегмента: Регулярные зрители.');
  await expect(page.locator('.recommendation-item')).toHaveCount(5);
  await expect(page.locator('#limitations-list li')).toHaveCount(4);
  await page.screenshot({ path: path.join(os.tmpdir(), 'retention-dashboard-loaded.png'), fullPage: true });
  expect(consoleErrors).toEqual([]);
});

test('manual CSV fallback works and mobile layout has no horizontal overflow', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/index.html');
  await page.locator('#csv-input').setInputFiles([
    {
      name: 'Alle.csv',
      mimeType: 'text/csv',
      buffer: Buffer.from('Videoposition (in %),Absolute Zuschauerbindung (%)\n0,90\n1,70\n50,35\n99,12')
    },
    {
      name: 'Überspringbare Videoanzeige.csv',
      mimeType: 'text/csv',
      buffer: Buffer.from('Videoposition (in %),Absolute Zuschauerbindung (%),Im Vergleich zu anderen Videos (%)\n')
    }
  ]);
  await expect(page.locator('#system-state-text')).toHaveText('Анализ готов');
  await expect(page.locator('.report-item')).toHaveCount(2);
  await expect(page.locator('.report-status.empty')).toHaveCount(1);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(1);
  await expect(page.getByRole('button', { name: 'Загрузить ZIP' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Выбрать CSV' })).toBeVisible();
});

test('direct file opening loads local dependencies without a server', async ({ page }) => {
  const indexUrl = pathToFileURL(path.join(__dirname, '..', 'index.html')).href;
  await page.goto(indexUrl);
  await expect(page.getByRole('heading', { name: 'Анализатор удержания ролика' })).toBeVisible();
  const dependencies = await page.evaluate(() => ({ jszip: typeof window.JSZip, analyzer: typeof window.RetentionAnalyzer }));
  expect(dependencies).toEqual({ jszip: 'function', analyzer: 'object' });
  await page.locator('#csv-input').setInputFiles({
    name: 'Alle.csv',
    mimeType: 'text/csv',
    buffer: Buffer.from('Videoposition (in %),Absolute Zuschauerbindung (%)\n0,90\n50,35\n99,12')
  });
  await expect(page.locator('#system-state-text')).toHaveText('Анализ готов');
  await expect(page.locator('#metric-middle')).toHaveText('35%');
});

test('invalid ZIP produces a Russian recoverable error', async ({ page }) => {
  await page.goto('/index.html');
  await page.locator('#zip-input').setInputFiles({
    name: 'broken.zip',
    mimeType: 'application/zip',
    buffer: Buffer.from('this is not a zip archive')
  });
  await expect(page.locator('#system-state-text')).toHaveText('Ошибка импорта');
  await expect(page.locator('#import-message-text')).toContainText('Не удалось распаковать ZIP');
  await expect(page.locator('#import-message-text')).toContainText('Можно выбрать CSV вручную');
});

test('drop area does not nest button semantics around real buttons', async ({ page }) => {
  await page.goto('/index.html');
  await expect(page.locator('#dropzone')).not.toHaveAttribute('role', 'button');
  await expect(page.locator('#dropzone')).not.toHaveAttribute('tabindex', '0');
  await expect(page.locator('#dropzone button')).toHaveCount(2);
});

test('drag and drop still imports CSV after accessibility cleanup', async ({ page }) => {
  await page.goto('/index.html');
  await page.evaluate(() => {
    const transfer = new DataTransfer();
    transfer.items.add(new File([
      'Videoposition (in %),Absolute Zuschauerbindung (%)\n0,90\n50,35\n99,12'
    ], 'Alle.csv', { type: 'text/csv' }));
    document.getElementById('dropzone').dispatchEvent(new DragEvent('drop', { bubbles: true, dataTransfer: transfer }));
  });
  await expect(page.locator('#system-state-text')).toHaveText('Анализ готов');
  await expect(page.locator('#metric-middle')).toHaveText('35%');
});
