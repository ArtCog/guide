const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const Analyzer = require('../js/analyzer.js');

test('parseCsv handles a quoted comma and trims BOM', () => {
  const parsed = Analyzer.parseCsv('\uFEFFposition,ended,"views, per moment"\n0,12,"1,234"\n1,8,"2,345"');
  assert.deepEqual(parsed.headers, ['position', 'ended', 'views, per moment']);
  assert.equal(parsed.rows[1]['views, per moment'], '2,345');
});

test('parseCsv detects semicolon delimiter and preserves decimal comma', () => {
  const parsed = Analyzer.parseCsv('Videoposition (in %);Absolute Zuschauerbindung (%)\n0;91,87\n1;72,38');
  assert.equal(parsed.delimiter, ';');
  assert.equal(parsed.rows[0]['Absolute Zuschauerbindung (%)'], '91,87');
});

test('normalizeText repairs common UTF-8 mojibake', () => {
  assert.equal(Analyzer.normalizeText('Ãœberspringbare Videoanzeige'), 'Überspringbare Videoanzeige');
  assert.equal(Analyzer.normalizeText('regelmÃ¤ÃŸige Zuschauer'), 'regelmäßige Zuschauer');
});

test('classifyReport uses German column signatures and damaged file names', () => {
  assert.equal(
    Analyzer.classifyReport('Abonnenten.csv', ['Videoposition (in %)', 'Abostatus', 'Absolute Zuschauerbindung (%)']),
    'subscriber'
  );
  assert.equal(
    Analyzer.classifyReport('Neue und wiederkehrende Zuschauer.csv', ['Videoposition (in %)', 'Neue und wiederkehrende Zuschauer', 'Absolute Zuschauerbindung (%)']),
    'newReturning'
  );
  assert.equal(
    Analyzer.classifyReport('Neue, gelegentliche und regelmÃ¤ÃŸige Zuschauer.csv', ['Videoposition (in %)', 'Zuschauer nach Wiedergabeverhalten', 'Absolute Zuschauerbindung (%)']),
    'viewerLoyalty'
  );
  assert.equal(
    Analyzer.classifyReport('AktivitÃ¤ten im Detail.csv', ['Videoposition (in %)', 'Wiedergabe gestartet', 'Wiedergabe beendet', 'Anzahl, wie oft jeder Moment angesehen wurde']),
    'activity'
  );
});

test('buildReport treats a header-only known CSV as empty data, not an error', () => {
  const report = Analyzer.buildReport(
    'Überspringbare Videoanzeige.csv',
    'Videoposition (in %),Absolute Zuschauerbindung (%),Im Vergleich zu anderen Videos (%)\n'
  );
  assert.equal(report.type, 'adSkippable');
  assert.equal(report.status, 'empty');
  assert.equal(report.rowCount, 0);
});

test('getKeyPoints interpolates missing requested positions', () => {
  const curve = [
    { position: 0, retention: 100 },
    { position: 10, retention: 80 },
    { position: 20, retention: 70 }
  ];
  const points = Analyzer.getKeyPoints(curve, [0, 5, 20]);
  assert.deepEqual(points, [
    { position: 0, retention: 100 },
    { position: 5, retention: 90 },
    { position: 20, retention: 70 }
  ]);
});

test('findSharpDrops ranks adjacent percentage-point losses', () => {
  const drops = Analyzer.findSharpDrops([
    { position: 0, retention: 92 },
    { position: 1, retention: 72 },
    { position: 2, retention: 67 },
    { position: 3, retention: 69 },
    { position: 4, retention: 60 }
  ], 3);
  assert.deepEqual(drops.map((item) => [item.toPosition, item.delta]), [[1, -20], [4, -9], [2, -5]]);
});

test('analyzeReports ranks endings and rewatches and compares segments', () => {
  const reports = [
    Analyzer.buildReport('Alle.csv', 'Videoposition (in %),Absolute Zuschauerbindung (%)\n0,92\n1,72\n50,34\n99,10'),
    Analyzer.buildReport('Aktivitäten im Detail.csv', 'Videoposition (in %),Wiedergabe gestartet,Wiedergabe beendet,"Anzahl, wie oft jeder Moment angesehen wurde"\n0,800,90,820\n1,20,40,640\n99,,77,85'),
    Analyzer.buildReport('Abonnenten.csv', 'Videoposition (in %),Abostatus,Absolute Zuschauerbindung (%)\n0,Abonnenten,81\n0,Nutzer ohne Abo,92\n50,Abonnenten,40\n50,Nutzer ohne Abo,30')
  ];
  const result = Analyzer.analyzeReports(reports);
  assert.equal(result.endings[0].position, 0);
  assert.equal(result.endings[0].value, 90);
  assert.equal(result.rewatches[0].position, 0);
  assert.equal(result.comparisons.subscriber.groups.length, 2);
  assert.equal(result.comparisons.subscriber.groups[0].points.length > 0, true);
});

test('segment comparison reports expected groups missing from the CSV', () => {
  const report = Analyzer.buildReport(
    'Neue, gelegentliche und regelmäßige Zuschauer.csv',
    'Videoposition (in %),Zuschauer nach Wiedergabeverhalten,Absolute Zuschauerbindung (%)\n0,Neue Zuschauer,92\n0,Gelegentliche Zuschauer,88\n50,Neue Zuschauer,34\n50,Gelegentliche Zuschauer,29'
  );
  const comparison = Analyzer.buildComparison(report);
  assert.deepEqual(comparison.missingSegments, ['Регулярные зрители']);
});

test('recommendations are numerical and do not invent unseen video events', () => {
  const report = Analyzer.buildReport(
    'Alle.csv',
    'Videoposition (in %),Absolute Zuschauerbindung (%)\n0,92\n1,72\n5,52\n25,44\n50,34\n75,26\n90,19\n99,10'
  );
  const result = Analyzer.analyzeReports([report]);
  const copy = result.recommendations.map((item) => `${item.title} ${item.text}`).join(' ');
  assert.match(copy, /92/);
  assert.match(copy, /52/);
  assert.doesNotMatch(copy.toLowerCase(), /реклам|о цене|автор говорил/);
  assert.match(result.limitations.join(' '), /контекст/i);
});

test('supplied YouTube Studio ZIP produces nine reports and expected retention facts', async () => {
  const JSZip = require('../vendor/jszip.min.js');
  const fixture = 'C:\\Projects\\Video\\2026-fable-opus-sonnet-test\\tests\\fixtures\\youtube-retention-claude-openrouter.zip';
  const zip = await JSZip.loadAsync(fs.readFileSync(fixture));
  const entries = Object.values(zip.files).filter((entry) => !entry.dir && /\.csv$/i.test(entry.name));
  const reports = await Promise.all(entries.map(async (entry) => Analyzer.buildReport(entry.name, await entry.async('string'))));
  const result = Analyzer.analyzeReports(reports);
  assert.equal(reports.length, 9);
  assert.equal(reports.filter((report) => report.status === 'empty').length, 2);
  assert.equal(reports.find((report) => report.fileName === 'Alle.csv').rowCount, 100);
  assert.equal(result.keyPoints.find((point) => point.position === 0).retention, 91.87);
  assert.equal(result.keyPoints.find((point) => point.position === 99).retention, 9.53);
  assert.equal(result.drops[0].delta, -19.49);
  assert.deepEqual(Object.keys(result.comparisons).sort(), ['newReturning', 'subscriber', 'viewerLoyalty']);
  assert.deepEqual(result.comparisons.viewerLoyalty.missingSegments, ['Регулярные зрители']);
});

test('index.html contains the required Russian dashboard regions', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  for (const text of ['Анализатор удержания ролика', 'Загрузить ZIP', 'Выбрать CSV', 'С данными', 'Ключевые точки', 'Что улучшить в следующем ролике', 'Ограничения анализа']) {
    assert.equal(html.includes(text), true, `Missing UI label: ${text}`);
  }
});
