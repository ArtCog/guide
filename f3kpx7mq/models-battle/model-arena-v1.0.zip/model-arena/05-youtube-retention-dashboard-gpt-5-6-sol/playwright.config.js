const { defineConfig } = require('@playwright/test');
const os = require('node:os');
const path = require('node:path');

module.exports = defineConfig({
  testDir: './tests',
  testMatch: 'browser.spec.js',
  timeout: 30_000,
  fullyParallel: false,
  reporter: 'list',
  outputDir: path.join(os.tmpdir(), 'retention-dashboard-playwright'),
  use: {
    baseURL: 'http://127.0.0.1:8769',
    browserName: 'chromium',
    channel: 'chrome',
    headless: true,
    viewport: { width: 1440, height: 1000 }
  },
  webServer: {
    command: 'python -m http.server 8769 --bind 127.0.0.1',
    url: 'http://127.0.0.1:8769/index.html',
    reuseExistingServer: true,
    timeout: 10_000
  }
});
