# Video Retention Analyzer

A local, browser-only dashboard for analyzing one video's YouTube Studio retention export. The interface is in Russian. No Google API, account, upload, backend, or build step is required.

## Quick start

### Option 1 — open directly

Double-click `index.html`, or right-click it and choose a current Chrome, Edge, or Firefox browser.

### Option 2 — use a local HTTP server (recommended)

Open PowerShell and run:

```powershell
Set-Location 'C:\Users\magme\TEST FABLE VS OPUS VS SONNET\05-youtube-retention-dashboard-gpt-5-6-sol'
python -m http.server 8769 --bind 127.0.0.1
```

Then open:

```text
http://127.0.0.1:8769/index.html
```

Stop the server with `Ctrl+C`.

## Load data

### ZIP mode

1. Click **«Загрузить ZIP»**.
2. Select a YouTube Studio ZIP containing CSV reports.
3. Wait for the top-right status to change to **«Анализ готов»**.

The ZIP reader is included locally in `vendor/jszip.min.js`; it does not depend on a CDN.

### Manual CSV fallback

1. Click **«Выбрать CSV»**.
2. Select one or several CSV files at once.
3. The dashboard classifies and analyzes every selected file.

You can also drag a ZIP or CSV files onto the upload area.

## What is analyzed

- Overall retention curve and nine key positions: 0%, 1%, 5%, 10%, 25%, 50%, 75%, 90%, and 99%.
- Largest adjacent retention losses in percentage points.
- Most frequent playback-ending and moment-view positions when activity details exist.
- Subscribers versus non-subscribers.
- New versus returning viewers.
- New, occasional, and regular viewers.
- Evidence-based recommendations for hook, pace, middle, ending, and structure.
- Explicit limitations when video context is unavailable.

Header-only CSV reports are shown as **«нет данных»** and do not stop the analysis. German headers, UTF-8 BOM, common mojibake in names, comma/semicolon/tab delimiters, UTF-8, and Windows-1252 fallback decoding are supported.

If a segment report exists but one expected group has no rows (for example, no regular-viewer rows), the dashboard names that missing segment explicitly instead of displaying a fabricated zero.

## Privacy

All file reading, ZIP extraction, parsing, and analysis happen in the browser. Files are not sent anywhere.

## Files

- `index.html` — main entry point and semantic dashboard shell.
- `styles.css` — responsive visual system.
- `js/analyzer.js` — pure CSV classification and numerical analysis.
- `js/app.js` — file loading, ZIP handling, SVG chart, and UI rendering.
- `vendor/jszip.min.js` — local JSZip 3.10.1 build.
- `tests/` — Node and browser verification.
- `RUN-METRICS.md` — implementation and verification evidence.

## Optional developer verification

The application itself needs no Node installation. To rerun tests:

```powershell
npm install
npm test
npm run test:browser
```

The browser suite starts/reuses `http://127.0.0.1:8769` and uses the supplied fixture path from this task.

## Known limits

- Very large ZIP archives are unpacked in browser memory.
- Rare encodings other than UTF-8 and Windows-1252 may need conversion before upload.
- The browser cannot convert position percentages to timestamps without the video's duration.
- A changed YouTube Studio export schema may require additional column aliases.
- Causes of drops cannot be identified confidently without the video, script, chapters, or timestamps.
