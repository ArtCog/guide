# Run Metrics

## Arena metrics

- Cost USD: ~$6.37
- Task time: 22m 44s
- API time: unavailable
- Wall time: 4h 50m 56s
- Input tokens: 359 437
- Output tokens: 57 521
- Cache read: 5 695 232
- Cache write: unavailable
- Verdict: ZIP and CSV analyzer; 12 local tests and 6 headless-Chrome browser tests passed. Cost is API-equivalent with discounted cached input; cache-write data was not available.

The arena uses active execution time and uncached input plus output as the token total. The wall time includes a 4h 28m pause between user turns and is therefore reference-only.

## Execution record

| Metric | Value |
|---|---|
| Initial implementation | 2026-07-10 |
| Last verification | 2026-07-11 |
| Execution mode | Single Codex agent, no sub-agents |
| Model | `gpt-5.6-sol` (confirmed by local Codex session telemetry) |
| Output scope | One requested result directory only |
| Application architecture | Static client-side HTML/CSS/JavaScript |
| Runtime API calls | None |
| Build step required | No |
| Production dependencies | JSZip 3.10.1, vendored locally |
| Random/demo data | None |
| Usage cutoff | Immediately before the cost-estimation request, after the implementation and continuation pass |

## Model usage, API-equivalent cost, and elapsed time

Local Codex session telemetry was read after the implementation and continuation pass. The counters below stop at the final dashboard response on 2026-07-11, before the separate request to calculate cost.

| Token category | Count |
|---|---:|
| Input tokens, total | 6,054,669 |
| Cached input tokens (included in input total) | 5,695,232 |
| Uncached input tokens | 359,437 |
| Output tokens | 57,521 |
| Reasoning output tokens (subset of output; not added again) | 13,648 |
| Total tokens | **6,112,190** |

The large total is mainly repeated cached context across agent/tool turns. Only 359,437 input tokens were not reported as cached.

### API-dollar estimate

Current OpenAI standard API prices for `gpt-5.6-sol`, per 1M tokens:

| Category | Rate |
|---|---:|
| Uncached input | $5.00 |
| Cached input | $0.50 |
| Cache write | $6.25 |
| Output | $30.00 |

Source: <https://developers.openai.com/api/docs/pricing>

Base calculation using the categories exposed by local telemetry:

```text
uncached input: 359,437 / 1,000,000 × $5.00  = $1.7972
cached input: 5,695,232 / 1,000,000 × $0.50 = $2.8476
output:          57,521 / 1,000,000 × $30.00 = $1.7256
                                                    -------
API-equivalent total                               = $6.3704
```

The telemetry does not expose `cache_write_tokens` separately. If every uncached input token were conservatively treated at the $6.25 cache-write rate instead of the $5.00 ordinary-input rate, the total would be **$6.8197**.

**Recorded estimate: approximately $6.4 API-equivalent, with a conservative range of $6.37–$6.82.** This is a pricing equivalent, not necessarily an additional invoice charge: Codex subscription usage may be accounted for through plan limits or credits instead of direct API billing.

### Time

| Work interval | Elapsed time |
|---|---:|
| Initial implementation: 2026-07-10 21:28:01Z → 21:46:15Z | 18m 14s |
| Continuation/QA: 2026-07-11 02:14:27Z → 02:18:57Z | 4m 30s |
| Active execution time | **22m 44s** |
| Full wall-clock span, including the pause between user turns | **4h 50m 56s** |
| Inactive pause between turns | 4h 28m 12s |

In Europe/Berlin local time, the full span was approximately 23:28 on July 10 to 04:19 on July 11.

## Supplied fixture facts

Fixture: `C:\Projects\Video\2026-fable-opus-sonnet-test\tests\fixtures\youtube-retention-claude-openrouter.zip`

| Metric | Verified value |
|---|---:|
| CSV entries discovered | 9 |
| Reports containing rows | 7 |
| Header-only reports marked `нет данных` | 2 |
| Overall-curve rows | 100 |
| Segment comparison groups rendered | 3 report families |
| Retention at 0% position | 91.87% |
| Retention at 50% position | 34.08% |
| Retention at 99% position | 9.53% |
| Largest adjacent drop | -19.49 percentage points, 0–1% position |

These values are test assertions derived from the supplied ZIP, not hardcoded UI data. Loading another compatible export replaces them.

## Verification results

### Analyzer and integration suite

Command:

```powershell
node --test tests\analyzer.test.js
```

Result: **12 passed, 0 failed**.

Coverage includes:

- quote-aware CSV parsing;
- semicolon delimiter and decimal comma;
- UTF-8 mojibake repair;
- German column classification;
- header-only empty reports;
- interpolated key positions;
- sharp-drop ranking;
- endings and rewatches;
- segment comparisons;
- explicit detection of expected audience segments missing from a report;
- non-fabricated recommendation copy;
- full supplied-ZIP integration;
- required Russian interface regions.

### Syntax checks

Commands:

```powershell
node --check js\analyzer.js
node --check js\app.js
```

Result: **both passed**.

### Live browser suite

Command after installing dev dependencies:

```powershell
npm run test:browser
```

Result: **6 passed, 0 failed** in headless Chrome.

Verified in the browser:

- initial no-demo-data state;
- real ZIP upload;
- 9 report inventory entries and 2 `нет данных` statuses;
- summary values, SVG curve, 9 key points, and three 8-item rankings;
- all three requested audience comparisons;
- 5 recommendations and 4 limitations;
- no browser-console errors;
- manual multi-CSV fallback;
- 390 px mobile viewport with no horizontal overflow.
- direct `file://` opening with local JSZip/analyzer dependencies and CSV import.
- localized recovery from an invalid ZIP;
- accessible upload semantics without nested button roles;
- drag-and-drop CSV import after the accessibility cleanup.

Visual QA used a full-page 1440 px screenshot after importing the supplied ZIP. The chart, tables, rankings, comparison cards, recommendations, and limitations rendered without overlap.

## Artifact metrics

| File | Approximate lines before final documentation pass |
|---|---:|
| `index.html` | 208 |
| `styles.css` | 368 |
| `js/analyzer.js` | 414 |
| `js/app.js` | 307 |
| `tests/analyzer.test.js` | 127 |
| `tests/browser.spec.js` | 55 |

Vendored JSZip size: **97,630 bytes**. SHA-256:

```text
ACC7E41455A80765B5FD9C7EE1B8078A6D160BBBCA455AEAE854DE65C947D59E
```

## Known instability and boundaries

- ZIP extraction depends on available browser memory; unusually large archives may be slow or fail.
- Encoding fallback covers UTF-8 and Windows-1252 plus common mojibake, not every legacy encoding.
- Classification is signature-based and resilient to damaged names, but a future YouTube schema with entirely new headers may appear as `Неизвестный отчёт`.
- Direct `file://` opening is supported by current mainstream browsers; a local HTTP server is the most predictable launch method.
- The analysis intentionally does not name unseen events or infer causal explanations from retention alone.
