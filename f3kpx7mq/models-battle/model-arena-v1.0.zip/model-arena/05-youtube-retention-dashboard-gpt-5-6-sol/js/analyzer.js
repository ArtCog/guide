(function attachRetentionAnalyzer(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.RetentionAnalyzer = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function createRetentionAnalyzer() {
  'use strict';

  const KEY_POSITIONS = [0, 1, 5, 10, 25, 50, 75, 90, 99];
  const SEGMENT_POSITIONS = [1, 25, 50, 75, 99];
  const CP1252_REVERSE = new Map([
    [0x20ac, 0x80], [0x201a, 0x82], [0x0192, 0x83], [0x201e, 0x84], [0x2026, 0x85],
    [0x2020, 0x86], [0x2021, 0x87], [0x02c6, 0x88], [0x2030, 0x89], [0x0160, 0x8a],
    [0x2039, 0x8b], [0x0152, 0x8c], [0x017d, 0x8e], [0x2018, 0x91], [0x2019, 0x92],
    [0x201c, 0x93], [0x201d, 0x94], [0x2022, 0x95], [0x2013, 0x96], [0x2014, 0x97],
    [0x02dc, 0x98], [0x2122, 0x99], [0x0161, 0x9a], [0x203a, 0x9b], [0x0153, 0x9c],
    [0x017e, 0x9e], [0x0178, 0x9f]
  ]);

  const REPORT_META = {
    overall: { label: 'Общая кривая удержания', tone: 'cyan' },
    activity: { label: 'Активности по моментам', tone: 'orange' },
    subscriber: { label: 'Подписчики и неподписчики', tone: 'violet' },
    newReturning: { label: 'Новые и возвращающиеся', tone: 'blue' },
    viewerLoyalty: { label: 'Новые, случайные и регулярные', tone: 'green' },
    traffic: { label: 'Органический и платный трафик', tone: 'slate' },
    benchmark: { label: 'Сравнение с другими видео', tone: 'slate' },
    adSkippable: { label: 'Пропускаемая видеореклама', tone: 'slate' },
    adDiscovery: { label: 'Реклама Video Discovery', tone: 'slate' },
    unknown: { label: 'Неизвестный отчёт', tone: 'slate' }
  };

  const EXPECTED_SEGMENTS = {
    subscriber: [
      { label: 'Подписчики', patterns: [/^abonnenten$/, /^subscribers?$/, /^подписчики$/] },
      { label: 'Неподписчики', patterns: [/ohne abo/, /nicht abonnenten/, /non subscribers?/, /неподписчики/] }
    ],
    newReturning: [
      { label: 'Новые зрители', patterns: [/neue zuschauer/, /new viewers?/, /новые зрители/] },
      { label: 'Возвращающиеся зрители', patterns: [/wiederkehrende zuschauer/, /returning viewers?/, /возвращающиеся зрители/] }
    ],
    viewerLoyalty: [
      { label: 'Новые зрители', patterns: [/neue zuschauer/, /new viewers?/, /новые зрители/] },
      { label: 'Случайные зрители', patterns: [/gelegentliche zuschauer/, /occasional viewers?/, /случайные зрители/] },
      { label: 'Регулярные зрители', patterns: [/regelmassige zuschauer/, /regular viewers?/, /регулярные зрители/] }
    ]
  };

  function normalizeText(input) {
    let value = String(input == null ? '' : input).replace(/^\uFEFF/, '');
    for (let pass = 0; pass < 2 && /(?:Ã.|Â.|â.|ð.|�)/.test(value); pass += 1) {
      try {
        const bytes = [];
        let convertible = true;
        for (const char of value) {
          const code = char.codePointAt(0);
          if (code <= 0xff) bytes.push(code);
          else if (CP1252_REVERSE.has(code)) bytes.push(CP1252_REVERSE.get(code));
          else { convertible = false; break; }
        }
        if (!convertible) break;
        const repaired = new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(bytes));
        if (repaired === value) break;
        value = repaired;
      } catch (_) {
        break;
      }
    }
    return value;
  }

  function asciiKey(input) {
    return normalizeText(input)
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9а-яё]+/gi, ' ')
      .trim();
  }

  function countDelimiter(line, delimiter) {
    let count = 0;
    let quoted = false;
    for (let i = 0; i < line.length; i += 1) {
      if (line[i] === '"') {
        if (quoted && line[i + 1] === '"') i += 1;
        else quoted = !quoted;
      } else if (!quoted && line[i] === delimiter) count += 1;
    }
    return count;
  }

  function detectDelimiter(text) {
    const firstLine = String(text).split(/\r?\n/, 1)[0] || '';
    return [',', ';', '\t']
      .map((delimiter) => ({ delimiter, count: countDelimiter(firstLine, delimiter) }))
      .sort((a, b) => b.count - a.count)[0].delimiter;
  }

  function parseDelimited(text, delimiter) {
    const records = [];
    let row = [];
    let field = '';
    let quoted = false;
    const source = String(text).replace(/^\uFEFF/, '');

    for (let i = 0; i < source.length; i += 1) {
      const char = source[i];
      if (char === '"') {
        if (quoted && source[i + 1] === '"') { field += '"'; i += 1; }
        else quoted = !quoted;
      } else if (!quoted && char === delimiter) {
        row.push(field);
        field = '';
      } else if (!quoted && (char === '\n' || char === '\r')) {
        if (char === '\r' && source[i + 1] === '\n') i += 1;
        row.push(field);
        if (row.some((value) => value.trim() !== '')) records.push(row);
        row = [];
        field = '';
      } else {
        field += char;
      }
    }
    row.push(field);
    if (row.some((value) => value.trim() !== '')) records.push(row);
    return records;
  }

  function parseCsv(text) {
    const source = normalizeText(text);
    if (!source.trim()) return { headers: [], rows: [], delimiter: ',', skippedRows: 0 };
    const delimiter = detectDelimiter(source);
    const records = parseDelimited(source, delimiter);
    const rawHeaders = records.shift() || [];
    const headers = rawHeaders.map((header, index) => normalizeText(header).trim() || `Колонка ${index + 1}`);
    const rows = [];
    let skippedRows = 0;

    for (const record of records) {
      if (record.length > headers.length) { skippedRows += 1; continue; }
      const row = {};
      headers.forEach((header, index) => { row[header] = normalizeText(record[index] || '').trim(); });
      if (Object.values(row).some(Boolean)) rows.push(row);
    }
    return { headers, rows, delimiter, skippedRows };
  }

  function resolveColumns(headers) {
    const columns = {};
    for (const header of headers) {
      const key = asciiKey(header);
      if (!columns.position && /(videoposition|video position|position)/.test(key)) columns.position = header;
      if (!columns.retention && /(absolute zuschauerbindung|absolute.*retention|audience retention)/.test(key)) columns.retention = header;
      if (!columns.started && /(wiedergabe gestartet|playback started|views started)/.test(key)) columns.started = header;
      if (!columns.ended && /(wiedergabe beendet|playback ended|views ended)/.test(key)) columns.ended = header;
      if (!columns.rewatches && /(wie oft jeder moment angesehen|times each moment|moment.*view)/.test(key)) columns.rewatches = header;
      if (!columns.benchmark && /(vergleich zu anderen videos|compared to other videos)/.test(key)) columns.benchmark = header;
      if (!columns.subscriber && /(abostatus|subscription status)/.test(key)) columns.subscriber = header;
      if (!columns.newReturning && /(neue und wiederkehrende zuschauer|new and returning)/.test(key)) columns.newReturning = header;
      if (!columns.viewerLoyalty && /(wiedergabeverhalten|viewing behavior)/.test(key)) columns.viewerLoyalty = header;
      if (!columns.traffic && /(zielgruppentyp|audience type|traffic type)/.test(key)) columns.traffic = header;
    }
    return columns;
  }

  function classifyReport(fileName, headers) {
    const name = asciiKey(fileName);
    const columns = resolveColumns(headers || []);
    if (columns.started || columns.ended || columns.rewatches || /aktivitaten im detail/.test(name)) return 'activity';
    if (columns.subscriber || /(abonnenten|nicht abonnenten)/.test(name)) return 'subscriber';
    if (columns.newReturning || /(neue und wiederkehrende|new and returning)/.test(name)) return 'newReturning';
    if (columns.viewerLoyalty || /(gelegentliche.*regelmassige|occasional.*regular)/.test(name)) return 'viewerLoyalty';
    if (columns.traffic || /(organischer und bezahlter traffic|organic and paid)/.test(name)) return 'traffic';
    if (/uberspringbare videoanzeige|skippable video ad/.test(name)) return 'adSkippable';
    if (/video discovery anzeige|video discovery ad/.test(name)) return 'adDiscovery';
    if (columns.benchmark) return 'benchmark';
    if (columns.position && columns.retention) return 'overall';
    if (/^alle(?: csv)?$|overall/.test(name)) return 'overall';
    return 'unknown';
  }

  function buildReport(fileName, text) {
    try {
      const parsed = parseCsv(text);
      const type = classifyReport(fileName, parsed.headers);
      return {
        fileName: normalizeText(fileName),
        type,
        typeLabel: REPORT_META[type].label,
        tone: REPORT_META[type].tone,
        status: parsed.rows.length ? 'ready' : 'empty',
        rowCount: parsed.rows.length,
        skippedRows: parsed.skippedRows,
        headers: parsed.headers,
        rows: parsed.rows,
        columns: resolveColumns(parsed.headers)
      };
    } catch (error) {
      return {
        fileName: normalizeText(fileName), type: 'unknown', typeLabel: REPORT_META.unknown.label,
        tone: 'slate', status: 'error', rowCount: 0, skippedRows: 0, headers: [], rows: [], columns: {},
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  function toNumber(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    let source = String(value == null ? '' : value).trim().replace(/[\s%]/g, '');
    if (!source) return null;
    if (source.includes(',') && source.includes('.')) {
      source = source.lastIndexOf(',') > source.lastIndexOf('.')
        ? source.replace(/\./g, '').replace(',', '.')
        : source.replace(/,/g, '');
    } else if (source.includes(',')) source = source.replace(',', '.');
    const number = Number(source);
    return Number.isFinite(number) ? number : null;
  }

  function round(value, digits = 2) {
    const factor = 10 ** digits;
    return Math.round((value + Number.EPSILON) * factor) / factor;
  }

  function curveFromReport(report) {
    if (!report || report.status !== 'ready') return [];
    const { position, retention } = report.columns;
    if (!position || !retention) return [];
    return report.rows
      .map((row) => ({ position: toNumber(row[position]), retention: toNumber(row[retention]) }))
      .filter((point) => point.position != null && point.retention != null)
      .sort((a, b) => a.position - b.position);
  }

  function retentionAt(curve, requestedPosition) {
    if (!curve.length || requestedPosition < curve[0].position || requestedPosition > curve[curve.length - 1].position) return null;
    const exact = curve.find((point) => point.position === requestedPosition);
    if (exact) return exact.retention;
    for (let i = 1; i < curve.length; i += 1) {
      const left = curve[i - 1];
      const right = curve[i];
      if (left.position < requestedPosition && right.position > requestedPosition) {
        const ratio = (requestedPosition - left.position) / (right.position - left.position);
        return left.retention + ((right.retention - left.retention) * ratio);
      }
    }
    return null;
  }

  function getKeyPoints(curve, positions = KEY_POSITIONS) {
    return positions.map((position) => {
      const retention = retentionAt(curve, position);
      return retention == null ? null : { position, retention: round(retention) };
    }).filter(Boolean);
  }

  function findSharpDrops(curve, limit = 8) {
    const drops = [];
    for (let i = 1; i < curve.length; i += 1) {
      const delta = round(curve[i].retention - curve[i - 1].retention);
      if (delta < 0) drops.push({
        fromPosition: curve[i - 1].position,
        toPosition: curve[i].position,
        fromRetention: round(curve[i - 1].retention),
        toRetention: round(curve[i].retention),
        delta
      });
    }
    return drops.sort((a, b) => a.delta - b.delta).slice(0, limit);
  }

  function rankActivity(report, columnName, limit = 8) {
    if (!report || report.status !== 'ready' || !report.columns.position || !columnName) return [];
    return report.rows
      .map((row) => ({ position: toNumber(row[report.columns.position]), value: toNumber(row[columnName]) }))
      .filter((item) => item.position != null && item.value != null && item.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, limit);
  }

  function buildComparison(report) {
    if (!report || report.status !== 'ready') return null;
    const segmentColumn = report.columns[report.type];
    const { position, retention } = report.columns;
    if (!segmentColumn || !position || !retention) return null;
    const grouped = new Map();
    for (const row of report.rows) {
      const name = normalizeText(row[segmentColumn]).trim();
      const point = { position: toNumber(row[position]), retention: toNumber(row[retention]) };
      if (!name || point.position == null || point.retention == null) continue;
      if (!grouped.has(name)) grouped.set(name, []);
      grouped.get(name).push(point);
    }
    const groups = Array.from(grouped, ([name, curve]) => {
      curve.sort((a, b) => a.position - b.position);
      return {
        name,
        average: round(curve.reduce((sum, point) => sum + point.retention, 0) / curve.length),
        points: getKeyPoints(curve, SEGMENT_POSITIONS),
        curve
      };
    });
    const spreads = SEGMENT_POSITIONS.map((positionValue) => {
      const values = groups.map((group) => ({ name: group.name, value: retentionAt(group.curve, positionValue) })).filter((item) => item.value != null);
      if (values.length < 2) return null;
      const high = values.reduce((best, item) => item.value > best.value ? item : best);
      const low = values.reduce((best, item) => item.value < best.value ? item : best);
      return { position: positionValue, high: high.name, low: low.name, difference: round(high.value - low.value), highValue: round(high.value), lowValue: round(low.value) };
    }).filter(Boolean);
    const expected = EXPECTED_SEGMENTS[report.type] || [];
    const normalizedGroupNames = groups.map((group) => asciiKey(group.name));
    const missingSegments = expected
      .filter((segment) => !normalizedGroupNames.some((name) => segment.patterns.some((pattern) => pattern.test(name))))
      .map((segment) => segment.label);
    return { type: report.type, label: report.typeLabel, groups, spreads, missingSegments };
  }

  function pointValue(keyPoints, position) {
    const point = keyPoints.find((item) => item.position === position);
    return point ? point.retention : null;
  }

  function formatNumber(value) {
    return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 }).format(value);
  }

  function buildRecommendations(curve, keyPoints, drops, endings) {
    if (!curve.length) return [{
      title: 'Нужна общая кривая',
      text: 'В загруженных файлах не найдена непустая общая кривая удержания. Загрузите соответствующий CSV, чтобы получить рекомендации по хуку, темпу, середине и финалу.'
    }];
    const recommendations = [];
    const start = pointValue(keyPoints, 0);
    const five = pointValue(keyPoints, 5);
    const p25 = pointValue(keyPoints, 25);
    const p75 = pointValue(keyPoints, 75);
    const p90 = pointValue(keyPoints, 90);
    const p99 = pointValue(keyPoints, 99);

    if (start != null && five != null) recommendations.push({
      title: 'Хук',
      text: `Между 0% и 5% позиции удержание изменилось с ${formatNumber(start)}% до ${formatNumber(five)}% (${formatNumber(five - start)} п.п.). В следующем ролике быстрее сформулируйте обещание и сократите всё, что не помогает зрителю понять ценность первых секунд.`
    });

    const bodyDrop = drops.find((drop) => drop.fromPosition >= 5 && drop.toPosition <= 90) || drops[0];
    if (bodyDrop) recommendations.push({
      title: 'Темп',
      text: `Самый заметный найденный интервал после начала: ${formatNumber(bodyDrop.fromPosition)}–${formatNumber(bodyDrop.toPosition)}% позиции, ${formatNumber(bodyDrop.fromRetention)}% → ${formatNumber(bodyDrop.toRetention)}% (${formatNumber(bodyDrop.delta)} п.п.). Проверьте этот участок по видео и решите, можно ли раньше дать результат, убрать повтор или усилить визуальную смену; сами данные причину не называют.`
    });

    if (p25 != null && p75 != null) recommendations.push({
      title: 'Середина',
      text: `От четверти до трёх четвертей ролика удержание изменилось с ${formatNumber(p25)}% до ${formatNumber(p75)}% (${formatNumber(p75 - p25)} п.п.). Разбейте середину на короткие смысловые этапы с явным прогрессом и промежуточными результатами.`
    });

    if (p90 != null && p99 != null) {
      const topEnding = endings[0];
      const extra = topEnding ? ` Максимум завершений в детализации: ${formatNumber(topEnding.value)} на позиции ${formatNumber(topEnding.position)}%.` : '';
      recommendations.push({
        title: 'Финал',
        text: `На участке 90–99% удержание изменилось с ${formatNumber(p90)}% до ${formatNumber(p99)}% (${formatNumber(p99 - p90)} п.п.). Перенесите главный итог и следующий шаг до длинного завершения.${extra}`
      });
    }

    const notableDrops = drops.filter((drop) => drop.delta <= -2).length;
    recommendations.push({
      title: 'Структура',
      text: `Среди ранжированных интервалов найдено ${notableDrops} просадок не слабее 2 п.п. Используйте их как чек-лист для просмотра исходного видео: отметьте обещание блока, его результат и переход. Без сценария нельзя достоверно определить, что именно было в этих местах.`
    });
    return recommendations;
  }

  function analyzeReports(reports) {
    const ready = reports.filter((report) => report.status === 'ready');
    const overall = ready.find((report) => report.type === 'overall') || ready.find((report) => report.type === 'benchmark');
    const activity = ready.find((report) => report.type === 'activity');
    const curve = curveFromReport(overall);
    const keyPoints = getKeyPoints(curve);
    const drops = findSharpDrops(curve);
    const endings = rankActivity(activity, activity && activity.columns.ended);
    const rewatches = rankActivity(activity, activity && activity.columns.rewatches);
    const comparisons = {};
    for (const type of ['subscriber', 'newReturning', 'viewerLoyalty']) {
      const comparison = buildComparison(ready.find((report) => report.type === type));
      if (comparison) comparisons[type] = comparison;
    }
    const recommendations = buildRecommendations(curve, keyPoints, drops, endings);
    const start = pointValue(keyPoints, 0);
    const middle = pointValue(keyPoints, 50);
    const end = pointValue(keyPoints, 99);
    return {
      reports,
      curve,
      keyPoints,
      drops,
      endings,
      rewatches,
      comparisons,
      recommendations,
      summary: {
        sourceFile: overall ? overall.fileName : null,
        start,
        middle,
        end,
        totalLoss: start != null && end != null ? round(end - start) : null,
        reportCount: reports.length,
        readyCount: ready.length,
        emptyCount: reports.filter((report) => report.status === 'empty').length,
        errorCount: reports.filter((report) => report.status === 'error').length
      },
      limitations: [
        'В анализе нет видео, сценария, глав и таймкодов. Данные показывают, где меняется поведение зрителей, но не объясняют причину.',
        'Позиция указана в процентах длины ролика. Без длительности видео её нельзя надёжно перевести в минуты и секунды.',
        'Сравнения сегментов описывают различия в данных, а не доказывают причинно-следственную связь.',
        'Резкая просадка — повод открыть соответствующий участок видео и проверить контекст, а не готовый диагноз содержания.'
      ]
    };
  }

  return {
    KEY_POSITIONS,
    REPORT_META,
    normalizeText,
    parseCsv,
    resolveColumns,
    classifyReport,
    buildReport,
    toNumber,
    curveFromReport,
    getKeyPoints,
    findSharpDrops,
    buildComparison,
    analyzeReports
  };
});
