(function runDashboard() {
  'use strict';

  const Analyzer = window.RetentionAnalyzer;
  const $ = (id) => document.getElementById(id);
  const elements = {
    zipInput: $('zip-input'), csvInput: $('csv-input'), zipButton: $('zip-button'), csvButton: $('csv-button'),
    dropzone: $('dropzone'), resetButton: $('reset-button'), systemState: $('system-state'),
    systemStateText: $('system-state-text'), importMessage: $('import-message'), importMessageText: $('import-message-text'),
    emptyWorkspace: $('empty-workspace'), dashboardContent: $('dashboard-content'), reportList: $('report-list'),
    metricReports: $('metric-reports'), metricReportsNote: $('metric-reports-note'), metricMiddle: $('metric-middle'),
    metricDrop: $('metric-drop'), metricDropNote: $('metric-drop-note'), metricEnd: $('metric-end'),
    chart: $('retention-chart'), chartWrap: $('chart-wrap'), chartTooltip: $('chart-tooltip'), chartEmpty: $('chart-empty'),
    curveCaption: $('curve-caption'), keypointsBody: $('keypoints-body'), dropsList: $('drops-list'),
    endingsList: $('endings-list'), rewatchesList: $('rewatches-list'), comparisonGrid: $('comparison-grid'),
    recommendationList: $('recommendation-list'), limitationsList: $('limitations-list')
  };
  const format = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 2 });
  const formatInteger = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });

  function node(tag, className, text) {
    const item = document.createElement(tag);
    if (className) item.className = className;
    if (text != null) item.textContent = text;
    return item;
  }

  function setState(state, text) {
    elements.systemState.dataset.state = state;
    elements.systemStateText.textContent = text;
  }

  function setMessage(text, tone = '') {
    elements.importMessage.dataset.tone = tone;
    elements.importMessageText.textContent = text;
  }

  function decodeCsv(buffer) {
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(buffer);
    } catch (_) {
      return new TextDecoder('windows-1252').decode(buffer);
    }
  }

  async function reportsFromZip(file) {
    if (!window.JSZip) throw new Error('Модуль распаковки ZIP не загрузился. Используйте запасной режим выбора CSV.');
    let zip;
    try {
      zip = await window.JSZip.loadAsync(await file.arrayBuffer());
    } catch (_) {
      throw new Error('Не удалось распаковать ZIP. Проверьте, что файл не повреждён и действительно содержит экспорт YouTube Studio.');
    }
    const entries = Object.values(zip.files).filter((entry) => !entry.dir && /\.csv$/i.test(entry.name));
    if (!entries.length) throw new Error('В ZIP не найдено CSV-файлов.');
    return Promise.all(entries.map(async (entry) => Analyzer.buildReport(entry.name, await entry.async('string'))));
  }

  async function reportsFromCsv(files) {
    const csvFiles = Array.from(files).filter((file) => /\.csv$/i.test(file.name));
    if (!csvFiles.length) throw new Error('Не выбрано ни одного CSV-файла.');
    return Promise.all(csvFiles.map(async (file) => Analyzer.buildReport(file.name, decodeCsv(await file.arrayBuffer()))));
  }

  async function importFiles(files, forcedMode) {
    const list = Array.from(files || []);
    if (!list.length) return;
    const zipFile = list.find((file) => /\.zip$/i.test(file.name));
    const mode = forcedMode || (zipFile ? 'zip' : 'csv');
    setState('loading', 'Читаю файлы');
    setMessage(mode === 'zip' ? 'Распаковываю ZIP и определяю типы CSV…' : 'Читаю CSV и определяю типы отчётов…');
    try {
      const reports = mode === 'zip' ? await reportsFromZip(zipFile || list[0]) : await reportsFromCsv(list);
      const analysis = Analyzer.analyzeReports(reports);
      renderDashboard(analysis);
      const emptyCopy = analysis.summary.emptyCount ? ` · ${analysis.summary.emptyCount} без данных` : '';
      setMessage(`Готово: найдено ${analysis.summary.reportCount}, проанализировано ${analysis.summary.readyCount}${emptyCopy}.`, 'success');
      setState('ready', 'Анализ готов');
    } catch (error) {
      console.error(error);
      setState('error', 'Ошибка импорта');
      setMessage(`${error.message || error} Можно выбрать CSV вручную.`, 'error');
    } finally {
      elements.zipInput.value = '';
      elements.csvInput.value = '';
    }
  }

  function renderDashboard(analysis) {
    elements.emptyWorkspace.classList.add('is-hidden');
    elements.dashboardContent.classList.remove('is-hidden');
    renderMetrics(analysis);
    renderReports(analysis.reports);
    renderChart(analysis);
    renderKeyPoints(analysis);
    renderRankList(elements.dropsList, analysis.drops, 'drop');
    renderRankList(elements.endingsList, analysis.endings, 'ending');
    renderRankList(elements.rewatchesList, analysis.rewatches, 'rewatch');
    renderComparisons(analysis.comparisons);
    renderRecommendations(analysis.recommendations);
    renderLimitations(analysis.limitations);
  }

  function renderMetrics(analysis) {
    const { summary, drops } = analysis;
    elements.metricReports.textContent = `${summary.readyCount}/${summary.reportCount}`;
    elements.metricReportsNote.textContent = summary.emptyCount ? `${summary.emptyCount} без данных` : 'все содержат данные';
    elements.metricMiddle.textContent = summary.middle == null ? '—' : `${format.format(summary.middle)}%`;
    elements.metricEnd.textContent = summary.end == null ? '—' : `${format.format(summary.end)}%`;
    if (drops.length) {
      elements.metricDrop.textContent = `${format.format(drops[0].delta)} п.п.`;
      elements.metricDropNote.textContent = `${format.format(drops[0].fromPosition)}–${format.format(drops[0].toPosition)}% позиции`;
    } else {
      elements.metricDrop.textContent = '—';
      elements.metricDropNote.textContent = 'недостаточно точек';
    }
  }

  function renderReports(reports) {
    elements.reportList.replaceChildren();
    reports.forEach((report) => {
      const item = node('div', 'report-item');
      const dot = node('span', 'report-dot');
      dot.dataset.tone = report.tone;
      const copy = node('div', 'report-copy');
      copy.append(node('strong', '', report.typeLabel), node('span', '', report.fileName));
      const labels = { ready: `${report.rowCount} строк`, empty: 'нет данных', error: 'ошибка' };
      const status = node('span', `report-status ${report.status}`, labels[report.status]);
      if (report.skippedRows) status.title = `Пропущено некорректных строк: ${report.skippedRows}`;
      item.append(dot, copy, status);
      elements.reportList.append(item);
    });
  }

  function renderChart(analysis) {
    const svg = elements.chart;
    svg.replaceChildren();
    elements.chartTooltip.classList.add('is-hidden');
    if (!analysis.curve.length) {
      elements.chartEmpty.classList.remove('is-hidden');
      elements.curveCaption.textContent = 'Источник общей кривой не найден.';
      return;
    }
    elements.chartEmpty.classList.add('is-hidden');
    elements.curveCaption.textContent = `Источник: ${analysis.summary.sourceFile} · ${analysis.curve.length} точек · значения в процентах`;
    const NS = 'http://www.w3.org/2000/svg';
    const width = 1000, height = 360, left = 58, right = 22, top = 18, bottom = 48;
    const plotWidth = width - left - right, plotHeight = height - top - bottom;
    const yMax = Math.max(100, Math.ceil(Math.max(...analysis.curve.map((point) => point.retention)) / 20) * 20);
    const x = (value) => left + (value / 99) * plotWidth;
    const y = (value) => top + (1 - value / yMax) * plotHeight;
    const svgNode = (tag, attrs = {}, text) => {
      const el = document.createElementNS(NS, tag);
      Object.entries(attrs).forEach(([key, value]) => el.setAttribute(key, value));
      if (text != null) el.textContent = text;
      return el;
    };
    [0, 25, 50, 75, 100].filter((value) => value <= yMax).forEach((value) => {
      svg.append(svgNode('line', { x1: left, x2: width - right, y1: y(value), y2: y(value), class: 'chart-grid' }));
      svg.append(svgNode('text', { x: left - 10, y: y(value) + 4, 'text-anchor': 'end', class: 'chart-axis-label' }, `${value}%`));
    });
    [0, 25, 50, 75, 99].forEach((value) => {
      svg.append(svgNode('line', { x1: x(value), x2: x(value), y1: top, y2: height - bottom, class: 'chart-grid' }));
      svg.append(svgNode('text', { x: x(value), y: height - 19, 'text-anchor': 'middle', class: 'chart-axis-label' }, `${value}%`));
    });
    const linePoints = analysis.curve.map((point) => `${x(point.position)},${y(point.retention)}`).join(' ');
    const areaPoints = `${x(analysis.curve[0].position)},${height - bottom} ${linePoints} ${x(analysis.curve.at(-1).position)},${height - bottom}`;
    svg.append(svgNode('polygon', { points: areaPoints, class: 'chart-area' }));
    svg.append(svgNode('polyline', { points: linePoints, class: 'chart-line' }));
    analysis.keyPoints.forEach((point) => svg.append(svgNode('circle', { cx: x(point.position), cy: y(point.retention), r: 4, class: 'chart-point' })));
    analysis.drops.slice(0, 3).forEach((drop) => svg.append(svgNode('rect', { x: x(drop.toPosition) - 5, y: y(drop.toRetention) - 5, width: 10, height: 10, class: 'chart-drop', transform: `rotate(45 ${x(drop.toPosition)} ${y(drop.toRetention)})` })));
    const hoverLine = svgNode('line', { x1: left, x2: left, y1: top, y2: height - bottom, class: 'chart-hover-line', visibility: 'hidden' });
    const hit = svgNode('rect', { x: left, y: top, width: plotWidth, height: plotHeight, class: 'chart-hit' });
    svg.append(hoverLine, hit);
    hit.addEventListener('pointermove', (event) => {
      const rect = svg.getBoundingClientRect();
      const localX = ((event.clientX - rect.left) / rect.width) * width;
      const targetPosition = Math.max(0, Math.min(99, ((localX - left) / plotWidth) * 99));
      const nearest = analysis.curve.reduce((best, point) => Math.abs(point.position - targetPosition) < Math.abs(best.position - targetPosition) ? point : best);
      const chartX = x(nearest.position);
      hoverLine.setAttribute('x1', chartX);
      hoverLine.setAttribute('x2', chartX);
      hoverLine.setAttribute('visibility', 'visible');
      elements.chartTooltip.innerHTML = `<strong>${format.format(nearest.retention)}%</strong>позиция ${format.format(nearest.position)}%`;
      elements.chartTooltip.style.left = `${Math.min(rect.width - 150, Math.max(6, (chartX / width) * rect.width + 8))}px`;
      elements.chartTooltip.style.top = `${Math.max(8, (y(nearest.retention) / height) * rect.height - 42)}px`;
      elements.chartTooltip.classList.remove('is-hidden');
    });
    hit.addEventListener('pointerleave', () => {
      hoverLine.setAttribute('visibility', 'hidden');
      elements.chartTooltip.classList.add('is-hidden');
    });
  }

  function renderKeyPoints(analysis) {
    elements.keypointsBody.replaceChildren();
    if (!analysis.keyPoints.length) {
      const row = node('tr');
      const cell = node('td', '', 'Нет общей кривой');
      cell.colSpan = 3;
      row.append(cell);
      elements.keypointsBody.append(row);
      return;
    }
    const start = analysis.keyPoints.find((point) => point.position === 0)?.retention ?? analysis.keyPoints[0].retention;
    analysis.keyPoints.forEach((point) => {
      const row = node('tr');
      const delta = point.retention - start;
      const deltaCell = node('td', delta < 0 ? 'delta-negative' : '', `${delta > 0 ? '+' : ''}${format.format(delta)} п.п.`);
      row.append(node('td', '', `${format.format(point.position)}%`), node('td', '', `${format.format(point.retention)}%`), deltaCell);
      elements.keypointsBody.append(row);
    });
  }

  function renderRankList(container, items, kind) {
    container.replaceChildren();
    if (!items.length) {
      container.append(node('div', 'empty-block', kind === 'drop' ? 'Недостаточно данных общей кривой.' : 'Отчёт активности не найден или не содержит данных.'));
      return;
    }
    const max = Math.max(...items.map((item) => kind === 'drop' ? Math.abs(item.delta) : item.value));
    items.forEach((item, index) => {
      const row = node('div', 'rank-item');
      const bar = node('span', 'rank-bar');
      const amount = kind === 'drop' ? Math.abs(item.delta) : item.value;
      bar.style.setProperty('--bar-width', `${Math.max(4, (amount / max) * 100)}%`);
      const main = node('div', 'rank-main');
      if (kind === 'drop') {
        main.append(node('strong', '', `${format.format(item.fromPosition)}–${format.format(item.toPosition)}% позиции`), node('span', '', `${format.format(item.fromRetention)}% → ${format.format(item.toRetention)}%`));
      } else {
        main.append(node('strong', '', `${format.format(item.position)}% позиции`), node('span', '', kind === 'ending' ? 'завершений просмотра' : 'просмотров момента'));
      }
      const value = kind === 'drop' ? `${format.format(item.delta)} п.п.` : formatInteger.format(item.value);
      row.append(bar, node('span', 'rank-index', String(index + 1).padStart(2, '0')), main, node('span', 'rank-value', value));
      container.append(row);
    });
  }

  function renderComparisons(comparisons) {
    elements.comparisonGrid.replaceChildren();
    const ordered = ['subscriber', 'newReturning', 'viewerLoyalty'];
    let rendered = 0;
    ordered.forEach((type) => {
      const comparison = comparisons[type];
      if (!comparison) return;
      rendered += 1;
      const card = node('article', 'comparison-card');
      card.append(node('h3', '', comparison.label));
      const maxSpread = comparison.spreads.reduce((best, item) => !best || item.difference > best.difference ? item : best, null);
      let insight = maxSpread
        ? `Максимальный разрыв в контрольных точках — ${format.format(maxSpread.difference)} п.п. на позиции ${maxSpread.position}% (${maxSpread.high} выше ${maxSpread.low}).`
        : 'Недостаточно общих контрольных точек для численного разрыва.';
      if (comparison.missingSegments.length) insight += ` Нет данных для сегмента: ${comparison.missingSegments.join(', ')}.`;
      card.append(node('p', 'comparison-insight', insight));
      const averages = node('div', 'segment-averages');
      comparison.groups.forEach((group) => averages.append(node('span', 'segment-chip', `${group.name}: ср. ${format.format(group.average)}%`)));
      card.append(averages);
      const table = node('table', 'comparison-table');
      const thead = node('thead');
      const headerRow = node('tr');
      headerRow.append(node('th', '', 'Позиция'));
      comparison.groups.forEach((group) => { const th = node('th', '', group.name); th.title = group.name; headerRow.append(th); });
      thead.append(headerRow);
      const tbody = node('tbody');
      [1, 25, 50, 75, 99].forEach((position) => {
        const row = node('tr');
        row.append(node('td', '', `${position}%`));
        comparison.groups.forEach((group) => {
          const point = group.points.find((item) => item.position === position);
          row.append(node('td', '', point ? `${format.format(point.retention)}%` : '—'));
        });
        tbody.append(row);
      });
      table.append(thead, tbody);
      card.append(table);
      elements.comparisonGrid.append(card);
    });
    if (!rendered) elements.comparisonGrid.append(node('div', 'empty-block', 'Сегментные CSV не найдены. Сравнения появятся, если загрузить соответствующие отчёты YouTube Studio.'));
  }

  function renderRecommendations(recommendations) {
    elements.recommendationList.replaceChildren();
    recommendations.forEach((recommendation) => {
      const item = node('article', 'recommendation-item');
      item.append(node('h3', '', recommendation.title), node('p', '', recommendation.text));
      elements.recommendationList.append(item);
    });
  }

  function renderLimitations(limitations) {
    elements.limitationsList.replaceChildren();
    limitations.forEach((limitation) => elements.limitationsList.append(node('li', '', limitation)));
  }

  function resetDashboard() {
    elements.dashboardContent.classList.add('is-hidden');
    elements.emptyWorkspace.classList.remove('is-hidden');
    elements.chart.replaceChildren();
    setState('idle', 'Ожидаю данные');
    setMessage('После загрузки здесь появится сводка распознанных отчётов.');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  elements.zipButton.addEventListener('click', (event) => { event.stopPropagation(); elements.zipInput.click(); });
  elements.csvButton.addEventListener('click', (event) => { event.stopPropagation(); elements.csvInput.click(); });
  elements.zipInput.addEventListener('change', () => importFiles(elements.zipInput.files, 'zip'));
  elements.csvInput.addEventListener('change', () => importFiles(elements.csvInput.files, 'csv'));
  elements.resetButton.addEventListener('click', resetDashboard);
  ['dragenter', 'dragover'].forEach((name) => elements.dropzone.addEventListener(name, (event) => { event.preventDefault(); elements.dropzone.classList.add('is-dragging'); }));
  ['dragleave', 'drop'].forEach((name) => elements.dropzone.addEventListener(name, (event) => { event.preventDefault(); elements.dropzone.classList.remove('is-dragging'); }));
  elements.dropzone.addEventListener('drop', (event) => importFiles(event.dataTransfer.files));
})();
