# RUN METRICS

Тест: 02 — Последняя смена
Тип: браузерная хоррор-игра от первого лица
Модель: GPT-5.6
Статус: готово к ручной оценке в арене
Папка результата: `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-gpt-5-6\`
Главный файл: `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\02-poslednyaya-smena-horror-gpt-5-6\index.html`
Стоимость USD:
Время задачи: ~8 мин (оценка, без телеметрии платформы)
Время API: ~8 мин (оценка)
Wall-время: ~8 мин (оценка)
Input tokens: ~45k (оценка)
Output tokens: ~18k (оценка)
Cache read:
Cache write:
Короткий вердикт: Canvas-псевдо-3D хоррор без внешних зависимостей; метрики времени и токенов оценочные, требуется ручная оценка атмосферы и удобства прохождения.
