import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  activateGenerator,
  catchPlayer,
  collectKeycard,
  createGameState,
  tryExit
} from '../game-state.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

test('generator stays locked before three keycards', () => {
  const state = createGameState();
  assert.equal(activateGenerator(state), false);
  assert.equal(state.generatorOn, false);
});

test('player wins after three keycards, generator and exit', () => {
  const state = createGameState();
  ['red', 'blue', 'white'].forEach((id) => collectKeycard(state, id));
  assert.equal(activateGenerator(state), true);
  assert.equal(tryExit(state), true);
  assert.equal(state.phase, 'won');
});

test('generator can only be activated once', () => {
  const state = createGameState();
  ['red', 'blue', 'white'].forEach((id) => collectKeycard(state, id));
  assert.equal(activateGenerator(state), true);
  assert.equal(activateGenerator(state), false);
});

test('demon catch ends the current run', () => {
  const state = createGameState();
  catchPlayer(state);
  assert.equal(state.phase, 'lost');
});

test('playable shell exposes canvas, flashlight, restart and game module', () => {
  const file = path.join(root, 'index.html');
  assert.equal(fs.existsSync(file), true);
  const html = fs.readFileSync(file, 'utf8');
  assert.match(html, /id="gameCanvas"/);
  assert.match(html, /id="flashlightButton"/);
  assert.match(html, /id="flashlightLabel"/);
  assert.match(html, /id="restartButton"/);
  assert.match(html, /src="game\.js"/);
});
