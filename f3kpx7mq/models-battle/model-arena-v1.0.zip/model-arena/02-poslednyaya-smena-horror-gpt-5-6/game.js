import { activateGenerator, catchPlayer, collectKeycard, createGameState, restartGame, tryExit } from './game-state.js';

const canvas = document.querySelector('#gameCanvas');
const ctx = canvas.getContext('2d');
const batteryValue = document.querySelector('#batteryValue');
const batteryFill = document.querySelector('#batteryFill');
const keycardValue = document.querySelector('#keycardValue');
const generatorValue = document.querySelector('#generatorValue');
const objective = document.querySelector('#objective');
const interaction = document.querySelector('#interaction');
const flashlightButton = document.querySelector('#flashlightButton');
const flashlightLabel = document.querySelector('#flashlightLabel');
const ending = document.querySelector('#ending');
const endingKicker = document.querySelector('#endingKicker');
const endingTitle = document.querySelector('#endingTitle');
const endingText = document.querySelector('#endingText');
const restartButton = document.querySelector('#restartButton');

const map = [
  '###############', '#.............#', '#.###.#####.#.#', '#.#...#...#.#.#', '#.#.###.#.#.#.#',
  '#...#...#.#...#', '###.#.###.###.#', '#...#.#.....#.#', '#.###.#.###.#.#', '#.....#.#...#.#',
  '#.#####.#.###.#', '#.......#.....#', '#.###########.#', '#.............#', '###############'
];
const cards = [
  { id:'red', x:5.5, y:1.5, color:'#d4473c', name:'КРАСНАЯ КАРТА' },
  { id:'blue', x:11.5, y:3.5, color:'#67a4c9', name:'СИНЯЯ КАРТА' },
  { id:'white', x:1.5, y:13.5, color:'#ece9df', name:'БЕЛАЯ КАРТА' }
];
const generator = { x:13.25, y:13.2, name:'ГЕНЕРАТОР' };
const exitDoor = { x:13.25, y:1.4, name:'ВЫХОД' };
const start = { x:1.5, y:1.5, angle:0 };
const player = { ...start };
const demonStart = { x:9.5, y:11.5 };
const demon = { ...demonStart, active:false, pulse:0 };
const keys = new Set();
let state = createGameState();
let lastTime = performance.now();
let started = false;
let nearest = null;
let wallDepth = [];
const FOV = Math.PI / 3;

function resetWorld() {
  restartGame(state);
  Object.assign(player, start);
  Object.assign(demon, demonStart, { active:false, pulse:0 });
  started = false;
  ending.hidden = true;
  interaction.textContent = 'Кликните по экрану, чтобы войти в смену';
  syncHud();
}

function cell(x, y) { return map[Math.floor(y)]?.[Math.floor(x)] || '#'; }
function blocked(x, y) { return cell(x, y) === '#'; }
function moveEntity(entity, dx, dy, radius = .18) {
  if (!blocked(entity.x + dx + Math.sign(dx || 1) * radius, entity.y)) entity.x += dx;
  if (!blocked(entity.x, entity.y + dy + Math.sign(dy || 1) * radius)) entity.y += dy;
}
function clampAngle(value) { return Math.atan2(Math.sin(value), Math.cos(value)); }
function distance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
function visibleToPlayer(item) { return Math.abs(clampAngle(Math.atan2(item.y-player.y, item.x-player.x) - player.angle)) < FOV * .55; }

function update(dt) {
  if (!started || state.phase !== 'playing') return;
  const speed = keys.has('shift') ? 2.7 : 1.65;
  let forward = (keys.has('w') || keys.has('arrowup') ? 1 : 0) - (keys.has('s') || keys.has('arrowdown') ? 1 : 0);
  let side = (keys.has('d') ? 1 : 0) - (keys.has('a') ? 1 : 0);
  if (keys.has('arrowleft')) player.angle -= 1.8 * dt;
  if (keys.has('arrowright')) player.angle += 1.8 * dt;
  if (forward || side) {
    const dx = (Math.cos(player.angle) * forward + Math.cos(player.angle + Math.PI/2) * side) * speed * dt;
    const dy = (Math.sin(player.angle) * forward + Math.sin(player.angle + Math.PI/2) * side) * speed * dt;
    moveEntity(player, dx, dy);
  }
  if (state.flashlightOn && state.battery > 0) state.battery = Math.max(0, state.battery - 3.2 * dt);
  else state.battery = Math.min(100, state.battery + 1.2 * dt);
  if (state.battery <= 0) state.flashlightOn = false;
  state.elapsed += dt;
  if (state.elapsed > 18) demon.active = true;
  if (demon.active) {
    const delta = { x:player.x-demon.x, y:player.y-demon.y };
    const gap = Math.hypot(delta.x, delta.y);
    const lookingAtDemon = state.flashlightOn && state.battery > 2 && visibleToPlayer(demon);
    const pace = (lookingAtDemon ? .23 : .48 + Math.min(.45, state.elapsed / 135)) * dt;
    if (gap > .2) moveEntity(demon, delta.x / gap * pace, delta.y / gap * pace, .16);
    demon.pulse += dt * 5;
    if (gap < .48) lose();
  }
  findInteraction();
  syncHud();
}

function findInteraction() {
  nearest = null;
  const remaining = cards.find((card) => !state.keycards.includes(card.id) && distance(player, card) < .72);
  if (remaining) nearest = { type:'card', item:remaining, text:`[E] ПОДНЯТЬ: ${remaining.name}` };
  else if (distance(player, generator) < .82) nearest = { type:'generator', item:generator, text:state.keycards.length === 3 ? '[E] ВКЛЮЧИТЬ ГЕНЕРАТОР' : '[E] ГЕНЕРАТОР: НУЖНЫ 3 КАРТЫ' };
  else if (distance(player, exitDoor) < .82) nearest = { type:'exit', item:exitDoor, text:state.generatorOn ? '[E] ОТКРЫТЬ ВЫХОД' : '[E] ВЫХОД ОБЕСТОЧЕН' };
  interaction.textContent = nearest?.text || (started ? state.message : 'Кликните по экрану, чтобы войти в смену');
}

function interact() {
  if (!started) { begin(); return; }
  if (!nearest || state.phase !== 'playing') return;
  if (nearest.type === 'card') collectKeycard(state, nearest.item.id);
  if (nearest.type === 'generator') activateGenerator(state);
  if (nearest.type === 'exit' && tryExit(state)) win();
  findInteraction(); syncHud();
}

function begin() {
  started = true;
  canvas.requestPointerLock?.();
  state.message = 'Тишина здесь никогда не бывает пустой.';
  findInteraction();
}
function toggleFlashlight() {
  if (state.battery <= 1) { state.message = 'Батарея пуста.'; findInteraction(); return; }
  state.flashlightOn = !state.flashlightOn;
  findInteraction(); syncHud();
}
function lose() {
  if (!catchPlayer(state)) return;
  document.exitPointerLock?.();
  endingKicker.textContent = '04:03 · СМЕНА НЕ ЗАКРЫТА';
  endingTitle.textContent = 'ОН НАШЁЛ ВАС';
  endingText.textContent = 'Фонарь погас слишком рано. В коридорах морга снова стало тихо.';
  ending.hidden = false;
  syncHud();
}
function win() {
  document.exitPointerLock?.();
  endingKicker.textContent = '04:11 · ВЫХОД РАЗБЛОКИРОВАН';
  endingTitle.textContent = 'ВЫЖИЛИ ДО РАССВЕТА';
  endingText.textContent = 'Генератор ожил, дверь открылась. За вами ещё долго слышались шаги.';
  ending.hidden = false;
  syncHud();
}
function syncHud() {
  batteryValue.textContent = `${Math.ceil(state.battery)}%`;
  batteryFill.style.width = `${state.battery}%`;
  batteryFill.style.background = state.battery < 22 ? '#d93a32' : '#e1bc70';
  keycardValue.textContent = `${state.keycards.length} / 3`;
  generatorValue.textContent = state.generatorOn ? 'ВКЛ' : 'ВЫКЛ';
  generatorValue.style.color = state.generatorOn ? '#e1bc70' : '';
  objective.textContent = state.message;
  flashlightLabel.textContent = `ФОНАРЬ: ${state.flashlightOn ? 'ВКЛ' : 'ВЫКЛ'}`;
  flashlightButton.setAttribute('aria-pressed', String(state.flashlightOn));
}

function castRay(angle) {
  const step = .018;
  let d = .02;
  while (d < 18) {
    const x = player.x + Math.cos(angle) * d;
    const y = player.y + Math.sin(angle) * d;
    if (blocked(x, y)) return d;
    d += step;
  }
  return 18;
}
function drawWall(x, corrected, raw) {
  const h = Math.min(canvas.height * 1.3, canvas.height / corrected);
  const y = (canvas.height - h) / 2;
  const light = state.flashlightOn ? Math.max(15, 145 - corrected * 15) : Math.max(5, 35 - corrected * 3);
  const stripe = Math.floor(raw * 10) % 2 ? 8 : 0;
  ctx.fillStyle = `rgb(${light + stripe}, ${light + stripe + 4}, ${light + stripe})`;
  ctx.fillRect(x, y, 2, h);
  ctx.fillStyle = 'rgba(0,0,0,.24)';
  ctx.fillRect(x, y, 1, h);
}
function drawSprite(entity, kind) {
  const dx = entity.x - player.x, dy = entity.y - player.y;
  const rawDist = Math.hypot(dx,dy);
  const rel = clampAngle(Math.atan2(dy,dx) - player.angle);
  if (Math.abs(rel) > FOV*.65 || rawDist < .1) return;
  const corrected = rawDist * Math.cos(rel);
  const screenX = canvas.width * .5 + (rel / FOV) * canvas.width;
  const index = Math.max(0, Math.min(wallDepth.length-1, Math.floor(screenX/2)));
  if (corrected > (wallDepth[index] || Infinity) + .1) return;
  const scale = Math.min(720, 340 / corrected);
  const x = screenX - scale*.2;
  const bottom = canvas.height*.57 + scale*.48;
  ctx.save();
  if (kind === 'demon') {
    ctx.fillStyle = '#070707'; ctx.fillRect(x, bottom-scale*1.12, scale*.4, scale*1.12);
    ctx.fillStyle = '#2b2823'; ctx.fillRect(x+scale*.08, bottom-scale*1.03, scale*.24, scale*.29);
    ctx.fillStyle = '#d93a32'; ctx.shadowColor='#e5241b'; ctx.shadowBlur=15+Math.sin(demon.pulse)*5;
    ctx.fillRect(x+scale*.12,bottom-scale*.93,scale*.05,scale*.035); ctx.fillRect(x+scale*.25,bottom-scale*.93,scale*.05,scale*.035);
    ctx.fillStyle='#080808'; ctx.shadowBlur=0; ctx.beginPath(); ctx.moveTo(x-scale*.08,bottom); ctx.lineTo(x+scale*.48,bottom); ctx.lineTo(x+scale*.2,bottom-scale*1.08); ctx.fill();
  } else if (kind === 'generator') {
    ctx.fillStyle='#665b42'; ctx.fillRect(x, bottom-scale*.6,scale*.38,scale*.6); ctx.fillStyle=state.generatorOn?'#e1bc70':'#34251e'; ctx.fillRect(x+scale*.12,bottom-scale*.48,scale*.12,scale*.12);
  } else if (kind === 'exit') {
    ctx.fillStyle=state.generatorOn?'#6e755c':'#252826'; ctx.fillRect(x,bottom-scale*.95,scale*.4,scale*.95); ctx.fillStyle='#d8d2bf'; ctx.fillRect(x+scale*.3,bottom-scale*.47,scale*.035,scale*.035);
  } else {
    ctx.fillStyle=entity.color; ctx.fillRect(x,bottom-scale*.35,scale*.4,scale*.24); ctx.fillStyle='#f3f0e7'; ctx.fillRect(x+scale*.04,bottom-scale*.3,scale*.29,scale*.13);
  }
  ctx.restore();
}
function render() {
  const w=canvas.width,h=canvas.height;
  const sky=ctx.createLinearGradient(0,0,0,h*.5); sky.addColorStop(0,'#080a0b'); sky.addColorStop(1,'#1a1d1c'); ctx.fillStyle=sky; ctx.fillRect(0,0,w,h*.5);
  const floor=ctx.createLinearGradient(0,h*.45,0,h); floor.addColorStop(0,'#25231e'); floor.addColorStop(1,'#090a0a'); ctx.fillStyle=floor; ctx.fillRect(0,h*.5,w,h*.5);
  wallDepth=[];
  for (let x=0;x<w;x+=2) { const angle=player.angle - FOV/2 + (x/w)*FOV; const raw=castRay(angle); const corrected=raw*Math.cos(angle-player.angle); wallDepth[x/2]=corrected; drawWall(x,corrected,raw); }
  cards.filter(c=>!state.keycards.includes(c.id)).forEach(c=>drawSprite(c,'card'));
  drawSprite(generator,'generator'); drawSprite(exitDoor,'exit'); if(demon.active) drawSprite(demon,'demon');
  if (state.flashlightOn && state.battery>0) {
    const glow=ctx.createRadialGradient(w*.5,h*.5,20,w*.5,h*.5,Math.min(w,h)*.57); glow.addColorStop(0,'rgba(255,244,203,.18)'); glow.addColorStop(.5,'rgba(255,243,194,.06)'); glow.addColorStop(1,'rgba(0,0,0,.6)'); ctx.fillStyle=glow; ctx.fillRect(0,0,w,h);
  } else { ctx.fillStyle='rgba(0,0,0,.72)'; ctx.fillRect(0,0,w,h); }
  if(demon.active && distance(player,demon)<2.2) { ctx.fillStyle=`rgba(145,0,0,${Math.max(0,.35-(distance(player,demon)-.5)*.18)})`; ctx.fillRect(0,0,w,h); }
}
function frame(now) { const dt=Math.min(.05,(now-lastTime)/1000); lastTime=now; update(dt); render(); requestAnimationFrame(frame); }

canvas.addEventListener('click', begin);
document.addEventListener('mousemove', (event) => { if(document.pointerLockElement===canvas && state.phase==='playing') player.angle += event.movementX*.0026; });
document.addEventListener('keydown', (event) => { const key=event.key.toLowerCase(); if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright','shift'].includes(key)) { keys.add(key); event.preventDefault(); } if(key==='e') interact(); if(key==='f') toggleFlashlight(); });
document.addEventListener('keyup', (event) => keys.delete(event.key.toLowerCase()));
flashlightButton.addEventListener('click', toggleFlashlight);
restartButton.addEventListener('click', resetWorld);
syncHud(); requestAnimationFrame(frame);
