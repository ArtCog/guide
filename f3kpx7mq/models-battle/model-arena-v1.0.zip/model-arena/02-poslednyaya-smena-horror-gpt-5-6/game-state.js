const REQUIRED_KEYCARDS = ['red', 'blue', 'white'];

export function createGameState() {
  return {
    phase: 'playing',
    keycards: [],
    generatorOn: false,
    battery: 100,
    flashlightOn: true,
    message: 'Найдите три ключ-карты. Выход заперт.',
    elapsed: 0
  };
}

export function collectKeycard(state, id) {
  if (state.phase !== 'playing' || !REQUIRED_KEYCARDS.includes(id) || state.keycards.includes(id)) {
    return false;
  }
  state.keycards.push(id);
  state.message = `Ключ-карта найдена: ${state.keycards.length}/3.`;
  return true;
}

export function activateGenerator(state) {
  if (state.phase !== 'playing' || state.keycards.length !== REQUIRED_KEYCARDS.length) {
    state.message = 'Генератор ждёт все три ключ-карты.';
    return false;
  }
  if (state.generatorOn) {
    state.message = 'Генератор уже работает.';
    return false;
  }
  state.generatorOn = true;
  state.message = 'Генератор ожил. Выход разблокирован.';
  return true;
}

export function tryExit(state) {
  if (state.phase !== 'playing' || !state.generatorOn) {
    state.message = 'Дверь не поддаётся. Нужен генератор.';
    return false;
  }
  state.phase = 'won';
  state.message = 'Вы выбрались до рассвета.';
  return true;
}

export function catchPlayer(state) {
  if (state.phase !== 'playing') return false;
  state.phase = 'lost';
  state.message = 'Он нашёл вас.';
  return true;
}

export function restartGame(state) {
  Object.assign(state, createGameState());
  return state;
}
