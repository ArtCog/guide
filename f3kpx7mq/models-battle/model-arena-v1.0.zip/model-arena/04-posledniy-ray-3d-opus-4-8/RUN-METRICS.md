# RUN-METRICS

| Поле | Значение |
|---|---|
| **Модель** | Claude Opus 4.8 (`claude-opus-4-8`) |
| **Тест** | «Последний рай» — интерактивная 3D-сцена (город-сад над разрушенной Землёй) |
| **Время задачи** | 42m 7s |
| **Input tokens** | 22.9k |
| **Output tokens** | 107.9k |
| **Cache read** | 7.1m |
| **Cache write** | 270.5k |
| **Стоимость USD** | $8.74 |
| **Путь к index.html** | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\03-posledniy-ray-3d-opus-4-8\index.html` |
| **Вердикт** | Готово и проверено в реальном браузере. Сильный hero-кадр: рай сверху и горящая Земля снизу читаются в одной композиции; 4 режима реально меняют камеру/свет/цвет/эффекты; консоль без ошибок. |

## Источник метрик

Метрики перенесены со скрина вкладки `Usage` Claude Code после выполнения теста.
`42m 7s` — время выполнения именно третьего задания.

Разбивка стоимости по скрину: `claude-opus-4-8` — $23.95; `claude-haiku-4-5` —
$0.0078. Общая стоимость сессии на экране: $23.96.

## Как проверялось (фактически)

- Локальный сервер: `python -m http.server 8848`.
- Реальный рендеринг: **Puppeteer + системный Chrome** в headless-режиме
  (WebGL через ANGLE/SwiftShader), viewport 1600×900.
- Диагностика: `window.__scene_ready === true`, живой WebGL2-контекст
  (`WebGL 2.0 (OpenGL ES 3.0 Chromium)`), `ERRORS_COUNT 0` в консоли.
- Сняты 4 скриншота реальных режимов через `window.__setMode(...)`:
  `01_hero.png`, `02_truth.png`, `03_catastrophe.png`, `04_survivors.png`.

## Найденные и исправленные при проверке дефекты

1. **TDZ-баг**: `boot()` вызывался до инициализации `const NOISE` → сцена падала
   в fallback. Вызов перенесён в конец модуля.
2. **Пересвет Земли**: жёлто-белый эмиссивный шейдер выбивался bloom в белый.
   Переписан на тёмную поверхность с тонкими насыщенными красно-оранжевыми
   разломами и ограниченной яркостью; переработан шейдер дыма; перенастроены
   bloom, экспозиция и кадрирование режимов.
3. **Английский текст в UI** убран (по ТЗ интерфейс полностью русский);
   подавлена 404-ошибка favicon.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $23.96 / 52.9k input / 242.1k output / 13.9m cache read / 1.1m cache write.
- Previous checkpoint: $15.22 / 34.0k input / 134.2k output / 6.8m cache read / 829.5k cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
