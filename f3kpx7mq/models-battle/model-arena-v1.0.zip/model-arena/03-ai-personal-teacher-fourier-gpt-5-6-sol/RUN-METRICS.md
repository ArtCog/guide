# Run Metrics

- Model: GPT-5.6 Sol
- Test: 03 - AI Personal Teacher / Fourier
- Cost USD: ~$2.36 API-equivalent (cache-write cost unavailable)
- Task time: 11m 23s (measured wall interval; active time unavailable separately)
- API time: unavailable
- Wall time: 11m 23s
- Prompt tokens: unavailable
- Input tokens: 126 665
- Output tokens: 26 044
- Cache read: 1 882 880
- Cache write: unavailable
- Path: index.html
- Verdict: PASS — static contract passed; Chrome/Playwright browser test 1/1 passed; 0 critical console or page errors

## Measurement notes

- Source: local Codex session event log for thread `019f52cd-64b0-7c22-9748-7b03ec2db6f0`.
- Baseline token event: `2026-07-11T20:13:22.418Z` — input 135,127; output 2,807; cached input 101,376. This was captured after loading the required instructions and before implementation.
- Final token event used: `2026-07-11T20:24:26.942Z` — input 2,144,672; output 28,851; cached input 1,984,256.
- Wall interval: baseline timestamp `2026-07-11T20:13:18.3194662Z` to measurement timestamp `2026-07-11T20:24:40.9144644Z`.
- `Input tokens`, `Output tokens`, and `Cache read` are exact deltas of the aggregate counters available in that session log. Cached input is a subset of input, not an additional amount.
- The session reports a Plus plan rather than API billing. It exposes no per-run USD cost, prompt-token field separate from input, cache-write counter, API-duration counter, or active-task timer; those fields are therefore marked `unavailable`.
- API-equivalent cost uses the official GPT-5.6 Sol standard rates: $5.00 per 1M uncached input tokens, $0.50 per 1M cached input tokens, and $30.00 per 1M output tokens. `(126,665 × 5 + 1,882,880 × 0.5 + 26,044 × 30) / 1,000,000 = $2.356085`. Cache-write tokens were not exposed, so their potential cost is excluded.
- Metrics generated while writing this file and the final response cannot be included in their own preceding snapshot.
