@echo off
rem Video Planning Canvas — обычная вкладка браузера (вариант без окна-приложения).
rem Сервер поднимается только если ещё не запущен (проверка локале-независимая).
cd /d "%~dp0"
netstat -ano | findstr /r /c:"127.0.0.1:7377 .*0.0.0.0:0" >nul 2>&1
if errorlevel 1 (
  start "Planning Canvas server" /min cmd /c "node server.js"
  ping -n 2 127.0.0.1 >nul
)
start "" http://localhost:7377
