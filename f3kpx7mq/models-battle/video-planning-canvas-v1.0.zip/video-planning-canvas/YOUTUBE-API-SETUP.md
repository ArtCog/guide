# YouTube API — разовая настройка (~10 минут)

Зачем: кнопка **«Подтянуть из YouTube»** в секции «Аналитика» сама заполняет волны
(просмотры, watch time, AVD/AVP, источники трафика, подписки, intro retention) и сохраняет
кривую удержания для дашборда. Что API НЕ отдаёт: показы (impressions) и CTR — их по-прежнему
вносить руками или CSV-экспортом из Studio.

## Шаги (один раз)

1. Открой https://console.cloud.google.com → создай проект (имя любое, напр. `canvas-yt`).
2. **APIs & Services → Library** → включи два API:
   - **YouTube Analytics API**
   - **YouTube Data API v3**
3. **APIs & Services → OAuth consent screen**:
   - User type: **External** → Create
   - App name: `canvas`, почта — своя. Остальное пропустить → Save.
   - **Audience → Test users → + Add users** → добавь свой gmail канала (ki.art.cog@gmail.com).
     (Приложение остаётся в Testing — публиковать НЕ нужно; refresh token живёт, пока сам не отзовёшь.)
4. **APIs & Services → Credentials → + Create credentials → OAuth client ID**:
   - Application type: **Desktop app** → Create → **Download JSON**.
5. Скачанный файл сохрани как:
   ```
   C:\Projects\Tools\video-planning-canvas\.secrets\yt-client.json
   ```
   (папку `.secrets` создай; переименовать файл — достаточно, содержимое не менять.)
6. В Canvas открой проект → секция «Аналитика» → заполни «Ссылка на опубликованный ролик» →
   жми **«Подтянуть из YouTube»** → откроется окно Google → выбери аккаунт канала → Allow.
   Вернись и нажми кнопку ещё раз — волны заполнятся.

## Что где лежит

- `.secrets/yt-client.json` — OAuth-клиент (ты создал)
- `.secrets/yt.json` — токены (создаётся сам после согласия)
- Оба файла — секреты: не показывать в роликах, не коммитить (см. `.gitignore`).

## Отзыв доступа

https://myaccount.google.com/permissions → `canvas` → Remove access. Локально: удалить `.secrets/yt.json`.
