@echo off
rem Video Planning Canvas — запуск как приложение (окно без вкладок браузера).
rem Поднимает локальный сервер (если ещё не запущен) и открывает Canvas в режиме --app.
setlocal
cd /d "%~dp0"

set "URL=http://localhost:7377/"

rem --- поднять сервер, только если порт 7377 ещё не слушается ---
rem (проверка локале-независимая: у слушателя local=127.0.0.1:7377, remote=0.0.0.0:0 —
rem  слово LISTENING/ABHOREN зависит от языка Windows и НЕ используется)
netstat -ano | findstr /r /c:"127.0.0.1:7377 .*0.0.0.0:0" >nul 2>&1
if errorlevel 1 (
  start "Planning Canvas server" /min cmd /c "node server.js"
  rem дать серверу ~1.5 сек забиндить порт
  ping -n 2 127.0.0.1 >nul
)

rem --- открыть безрамочное окно приложения (Edge → Chrome → браузер по умолчанию) ---
set "EDGE_X86=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "EDGE_X64=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME_X64=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "CHROME_X86=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

if exist "%EDGE_X86%"   ( start "" "%EDGE_X86%"   --app=%URL% & goto :done )
if exist "%EDGE_X64%"   ( start "" "%EDGE_X64%"   --app=%URL% & goto :done )
if exist "%CHROME_X64%" ( start "" "%CHROME_X64%" --app=%URL% & goto :done )
if exist "%CHROME_X86%" ( start "" "%CHROME_X86%" --app=%URL% & goto :done )
start "" %URL%
:done
