/* Video Planning Canvas — vanilla JS engine.
 * State lives in `state.data` (the project's canvas.json), every edit
 * mutates it directly and schedules a debounced PUT. Structural changes
 * re-render the affected section; keystrokes never re-render. */
'use strict';

const $ = (sel, el) => (el || document).querySelector(sel);
const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));

const state = {
  slug: null,
  data: null,
  videoDir: 'C:\\Projects\\Video', // уточняется с сервера (/api/config) при старте
  ideas: [],
  mode: 'project',      // 'project' | 'ideas' — which store the editors save to
  pasteTarget: null,    // fn(file) set by an armed image drop-zone
  saveTimer: null,
};

const STATUS_LABELS = {
  idea: 'идея', prep: 'подготовка', filming: 'съёмка',
  editing: 'монтаж', published: 'опубликован', archived: 'архив',
};

// ---------- api ----------

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    let msg = res.status + ' ' + res.statusText;
    try { msg = (await res.json()).error || msg; } catch (e) { /* keep */ }
    throw new Error(msg);
  }
  return res.json();
}

// ---------- save ----------

// Editors always call scheduleSave(); it routes to whichever store is active.
function scheduleSave() {
  setSaveState('saving', 'сохраняю…');
  clearTimeout(state.saveTimer);
  state.saveTimer = setTimeout(state.mode === 'ideas' ? doSaveIdeas : doSave, 800);
  if (state.mode !== 'ideas') updateProgressUI();
}

async function doSave() {
  if (!state.slug || !state.data) return;
  try {
    const r = await api('PUT', '/api/projects/' + state.slug, state.data);
    state.data.updatedAt = r.updatedAt;
    setSaveState('saved', 'сохранено ' + new Date().toLocaleTimeString('ru-RU'));
  } catch (e) {
    setSaveState('error', 'ошибка сохранения: ' + e.message);
  }
}

async function doSaveIdeas() {
  try {
    await api('PUT', '/api/ideas', state.ideas);
    setSaveState('saved', 'сохранено ' + new Date().toLocaleTimeString('ru-RU'));
    updateIdeasCount();
  } catch (e) {
    setSaveState('error', 'ошибка сохранения: ' + e.message);
  }
}

// Flush any pending debounced save of the currently active store.
async function flushSave() {
  if (!state.saveTimer) return;
  clearTimeout(state.saveTimer);
  state.saveTimer = null;
  if (state.mode === 'ideas') await doSaveIdeas();
  else await doSave();
}

function setSaveState(st, text) {
  const el = $('#save-indicator');
  el.dataset.state = st;
  el.textContent = text;
}

// flush on close (mode-aware)
window.addEventListener('beforeunload', () => {
  if (!state.saveTimer) return;
  clearTimeout(state.saveTimer);
  const json = { 'Content-Type': 'application/json' };
  if (state.mode === 'ideas') {
    fetch('/api/ideas', { method: 'PUT', keepalive: true, headers: json, body: JSON.stringify(state.ideas) });
  } else if (state.slug) {
    fetch('/api/projects/' + state.slug, { method: 'PUT', keepalive: true, headers: json, body: JSON.stringify(state.data) });
  }
});

// ---------- toast ----------

let toastTimer = null;
function toast(msg, opts) {
  const el = $('#toast');
  el.className = (opts && opts.error) ? 'error' : '';
  el.textContent = msg;
  if (opts && opts.action) {
    const b = document.createElement('button');
    b.className = 'btn';
    b.textContent = opts.action.label;
    b.onclick = opts.action.fn;
    el.appendChild(b);
  }
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, (opts && opts.ms) || 5000);
}

// ---------- helpers ----------

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function autosize(ta) {
  ta.style.height = 'auto';
  ta.style.height = (ta.scrollHeight + 2) + 'px';
}

function textarea(value, placeholder, onInput) {
  const ta = el('textarea');
  ta.value = value || '';
  ta.rows = 1;
  if (placeholder) ta.placeholder = placeholder;
  ta.addEventListener('input', () => { autosize(ta); onInput(ta.value); scheduleSave(); });
  requestAnimationFrame(() => autosize(ta));
  return ta;
}

function textInput(value, placeholder, onInput, cls) {
  const inp = el('input', cls);
  inp.type = 'text';
  inp.value = value || '';
  if (placeholder) inp.placeholder = placeholder;
  inp.addEventListener('input', () => { onInput(inp.value); scheduleSave(); });
  return inp;
}

function select(options, value, onChange, cls) {
  const s = el('select', cls);
  for (const [v, label] of options) {
    const o = el('option', null, label);
    o.value = v;
    s.appendChild(o);
  }
  s.value = value;
  s.addEventListener('change', () => { onChange(s.value); scheduleSave(); });
  return s;
}

function segControl(options, getValue, setValue) {
  const wrap = el('div', 'seg');
  const render = () => {
    $$('button', wrap).forEach(b => b.classList.toggle('on', String(getValue()) === b.dataset.raw));
  };
  for (const [raw, dataV, label] of options) {
    const b = el('button', null, label);
    b.type = 'button';
    b.dataset.raw = String(raw);
    b.dataset.v = dataV;
    b.addEventListener('click', () => { setValue(raw); render(); scheduleSave(); });
    wrap.appendChild(b);
  }
  render();
  return wrap;
}

function confirmDel(what) { return confirm('Удалить ' + what + '? Действие не отменяется.'); }

function translit(s) {
  const map = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
  return s.toLowerCase().split('').map(c => map[c] !== undefined ? map[c] : c).join('')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').replace(/-{2,}/g, '-');
}

// ---------- project list ----------

async function loadProjects() {
  const list = await api('GET', '/api/projects');
  const nav = $('#project-list');
  nav.innerHTML = '';
  if (!list.length) {
    nav.appendChild(el('div', 'proj-slug', 'пока нет проектов — создай первый'))
      .style.padding = '8px 10px';
  }
  const active = list.filter(p => p.status !== 'archived');
  const archived = list.filter(p => p.status === 'archived');
  for (const p of active) nav.appendChild(projectRow(p));

  if (archived.length) {
    const grp = el('button', 'arch-toggle');
    grp.type = 'button';
    grp.textContent = 'Архив (' + archived.length + ')';
    const box = el('div', 'arch-box');
    box.hidden = true;
    grp.addEventListener('click', () => { box.hidden = !box.hidden; grp.classList.toggle('open', !box.hidden); });
    for (const p of archived) box.appendChild(projectRow(p));
    nav.appendChild(grp);
    nav.appendChild(box);
  }
}

function projectRow(p) {
  const row = el('div', 'proj-row');
  const b = el('button', 'proj' + (p.slug === state.slug ? ' active' : ''));
  b.type = 'button';
  const t = el('div', 'proj-title');
  const dot = el('span', 'dot');
  dot.dataset.status = p.status;
  t.appendChild(dot);
  t.appendChild(document.createTextNode(p.title));
  const meta = el('div', 'proj-meta');
  meta.appendChild(el('span', 'proj-slug', p.slug));
  meta.appendChild(el('span', 'proj-pct', (p.progress ? p.progress.pct : 0) + '%'));
  b.appendChild(t);
  b.appendChild(meta);
  b.addEventListener('click', () => openProject(p.slug));
  row.appendChild(b);

  const dup = el('button', 'proj-dup', '⧉');
  dup.type = 'button';
  dup.title = 'Дублировать структуру в новый проект (для серий)';
  dup.addEventListener('click', (e) => { e.stopPropagation(); duplicateProject(p); });
  row.appendChild(dup);

  const del = el('button', 'proj-del', '×');
  del.type = 'button';
  del.title = 'Удалить проект из полотна';
  del.addEventListener('click', (e) => { e.stopPropagation(); deleteProject(p); });
  row.appendChild(del);
  return row;
}

async function duplicateProject(p) {
  const title = prompt('Название нового ролика (структура берётся из «' + p.title + '»):', p.title + ' — часть 2');
  if (!title) return;
  const year = new Date().getFullYear();
  let slug = prompt('Slug папки:', year + '-' + translit(title));
  if (!slug) return;
  try {
    const data = await api('POST', '/api/projects/' + p.slug + '/duplicate', { slug: slug.trim(), title: title.trim() });
    await loadProjects();
    openProject(data.slug);
    toast('Создана серия: Video\\' + data.slug + ' (тексты сохранены, статусы и аналитика сброшены).');
  } catch (e) {
    toast('Не удалось дублировать: ' + e.message, { error: true });
  }
}

async function deleteProject(p) {
  const ok = confirm(
    'Удалить проект «' + p.title + '» из полотна?\n\n' +
    'Будут стёрты только данные планирования: canvas.json, CANVAS.md и картинки полотна (assets/canvas).\n' +
    'Отснятое (raw/work/renders) и другие файлы папки НЕ трогаются.\n\n' +
    'Действие не отменяется. Если проект нужен позже — лучше поставь статус «архив».'
  );
  if (!ok) return;
  try {
    const r = await api('DELETE', '/api/projects/' + p.slug);
    if (state.slug === p.slug) {
      state.slug = null; state.data = null;
      $('#project-view').hidden = true;
      $('#empty-state').hidden = false;
    }
    await loadProjects();
    toast(r.removedFolder ? 'Удалён проект и пустая папка Video\\' + p.slug : 'Удалены данные полотна. Папка Video\\' + p.slug + ' сохранена (в ней есть другие файлы).');
  } catch (e) {
    toast('Не удалось удалить: ' + e.message, { error: true });
  }
}

// ----- migration / template sync -----
// Existing canvas.json files are upgraded on open: new labels, new section types,
// block ids, merged proof→show. Values are never dropped (custom/non-empty kept).

async function getTemplate() {
  if (!state.template) state.template = await api('GET', '/api/template');
  return state.template;
}

function migrateProject(data, tpl) {
  // scriptmap: stable block ids + fold legacy proof into show
  const map = (data.sections || []).find(x => x.type === 'scriptmap');
  for (const b of (map && map.blocks) || []) {
    if (!b.id) b.id = newBlockId();
    if ((b.proof || '').trim()) {
      b.show = [b.show, 'Доказательство: ' + b.proof].filter(x => (x || '').trim()).join('\n');
    }
    delete b.proof;
  }
  // sync canonical sections with template (title/goal/gate/ref/labels/new fields)
  for (const ts of tpl.sections || []) {
    const s = (data.sections || []).find(x => x.id === ts.id && !x.custom);
    if (!s) continue;
    s.title = ts.title; s.goal = ts.goal; s.gate = ts.gate; s.ref = ts.ref;
    if (ts.refGroups) s.refGroups = ts.refGroups; else delete s.refGroups;
    // sync assemble flags of matching fields (mergeFields copies labels/hints only)
    for (const tf of ts.fields || []) {
      if (!tf.assembleFrom && !tf.assembleChapters) continue;
      const f = (s.fields || []).find(x => x.id === tf.id);
      if (!f) continue;
      if (tf.assembleFrom) f.assembleFrom = tf.assembleFrom;
      if (tf.assembleChapters) f.assembleChapters = true;
    }
    if (ts.type && s.type !== ts.type) s.type = ts.type;
    if (ts.records !== undefined && !s.records) s.records = {};
    if (ts.folder !== undefined && s.folder === undefined) s.folder = '';
    if (ts.files !== undefined && !s.files) s.files = [];
    if (ts.fields) s.fields = mergeFields(s.fields || [], ts.fields);
    if (ts.waves && s.waves) {
      for (const tw of ts.waves) {
        const w = s.waves.find(x => x.id === tw.id);
        if (w) { w.label = tw.label; w.fields = mergeFields(w.fields || [], tw.fields); }
      }
    }
    if (ts.checklist && !s.checklist) s.checklist = JSON.parse(JSON.stringify(ts.checklist));
  }
}

// Template fields dictate order/labels; user values, custom and non-empty legacy
// fields survive.
function mergeFields(current, tplFields) {
  const have = new Map(current.map(f => [f.id, f]));
  const out = [];
  for (const tf of tplFields) {
    const f = have.get(tf.id);
    if (f) {
      f.label = tf.label; f.hint = tf.hint;
      if (tf.images !== undefined && !f.images) f.images = [];
      out.push(f); have.delete(tf.id);
    } else {
      out.push(JSON.parse(JSON.stringify(tf)));
    }
  }
  for (const f of have.values()) if (f.custom || (f.value || '').trim() || (f.images || []).length) out.push(f);
  return out;
}

async function openProject(slug) {
  await flushSave();
  let data;
  try {
    data = await api('GET', '/api/projects/' + slug);
    migrateProject(data, await getTemplate());
  } catch (e) {
    toast('Не открылся проект: ' + e.message, { error: true });
    return;
  }
  state.mode = 'project';
  state.pasteTarget = null;
  state.data = data;
  state.slug = slug;
  $('#empty-state').hidden = true;
  $('#ideas-view').hidden = true;
  $('#btn-ideas').classList.remove('active');
  $('#project-view').hidden = false;
  renderHeader();
  renderSections();
  renderToc();
  updateProgressUI();
  loadProjects();
  setSaveState('idle', slug);
}

// ---------- header ----------

function renderHeader() {
  const d = state.data;
  const title = $('#p-title');
  title.value = d.title || '';
  title.oninput = () => { d.title = title.value; scheduleSave(); };

  const format = $('#p-format');
  format.value = d.format || '';
  format.oninput = () => { d.format = format.value; scheduleSave(); };

  const status = $('#p-status');
  status.value = d.status || 'idea';
  status.onchange = () => { d.status = status.value; scheduleSave(); loadProjects(); };

  $('#btn-folder').onclick = () => openPath(state.videoDir + '\\' + state.slug);
  $('#btn-agent').onclick = copyAgentTask;
}

// Готовый промпт для кодинг-агента (Claude Code / Codex): скопировать и вставить.
async function copyAgentTask() {
  await flushSave(); // свежий CANVAS.md до того, как агент его прочитает
  const d = state.data;
  const editing = (d.sections || []).find(x => x.id === 'editing');
  const task = editing && (editing.fields || []).find(f => f.id === 'agent_task');
  const lines = [
    `Проект ролика: ${state.videoDir}\\${state.slug}\\`,
    `Дорожная карта: прочитай canvas.json (или CANVAS.md — он всегда свежий) в этой папке.`,
    `Структура ролика — секция «Сценарная карта», критерии монтажа — чеклист секции «Монтаж».`,
    `Сырьё: raw\\ · промежутки: work\\ · финалы: renders\\.`,
  ];
  if (task && (task.value || '').trim()) lines.push('', 'Задание от Артура:', task.value.trim());
  else lines.push('', 'Задание: выполни секцию «Монтаж — задание AI-монтажёру» из canvas.json.');
  try {
    await navigator.clipboard.writeText(lines.join('\n'));
    toast('Промпт скопирован — вставь его агенту (Claude Code / Codex).');
  } catch (e) {
    toast('Буфер обмена недоступен: ' + e.message, { error: true });
  }
}

async function openPath(p) {
  try { await api('POST', '/api/open', { path: p }); }
  catch (e) { toast(e.message, { error: true }); }
}

function updateProgressUI() {
  if (!state.data) return;
  const pr = CanvasProgress.projectProgress(state.data);
  $('#p-progress-label').textContent = pr.pct + '%';
  $('#p-progress-bar').style.transform = 'scaleX(' + (pr.pct / 100) + ')';
  // per-section counters (section header + sidebar TOC)
  for (const s of state.data.sections) {
    const sp = CanvasProgress.sectionProgress(s);
    const tp = document.querySelector('[data-toc-progress="' + s.id + '"]');
    if (tp) {
      tp.textContent = sp.total ? sp.done + '/' + sp.total : '';
      tp.classList.toggle('full', sp.total > 0 && sp.done === sp.total);
    }
    const elp = document.querySelector('[data-sec-progress="' + s.id + '"]');
    if (!elp) continue;
    elp.textContent = sp.done + '/' + sp.total;
    elp.classList.toggle('full', sp.total > 0 && sp.done === sp.total);
  }
}

// ---------- sections ----------

function renderSections() {
  const host = $('#sections');
  host.innerHTML = '';
  for (const s of state.data.sections) host.appendChild(renderSection(s));
}

// li с поддержкой **жирного** — шпаргалки должны читаться структурно
function refLi(text, cls) {
  const li = el('li', cls || null);
  const parts = String(text).split(/\*\*(.+?)\*\*/g);
  parts.forEach((p, i) => {
    if (i % 2) { const b = el('b'); b.textContent = p; li.appendChild(b); }
    else if (p) li.appendChild(document.createTextNode(p));
  });
  return li;
}

function rerenderSection(s) {
  const old = document.querySelector('[data-sec="' + s.id + '"]');
  if (old) old.replaceWith(renderSection(s));
  updateProgressUI();
}

// ----- sidebar table of contents (fills the sidebar while scrolling long canvas) -----

let tocOpen = true;
try { tocOpen = localStorage.getItem('canvas-toc-open') !== '0'; } catch (e) {}

function toggleToc() {
  tocOpen = !tocOpen;
  try { localStorage.setItem('canvas-toc-open', tocOpen ? '1' : '0'); } catch (e) {}
  renderToc();
}

function renderToc() {
  const toc = $('#sec-toc');
  const lab = $('#toc-label');
  const on = state.mode === 'project' && !!state.data;
  toc.hidden = !on || !tocOpen;
  lab.hidden = !on;
  lab.classList.toggle('open', tocOpen);
  lab.onclick = toggleToc;
  if (!on) return;
  toc.innerHTML = '';
  for (const s of state.data.sections) {
    const b = el('button', 'toc-item');
    b.type = 'button';
    b.appendChild(el('span', 'toc-num', s.num || '·'));
    b.appendChild(el('span', 'toc-title', s.title));
    const pct = el('span', 'toc-pct', '');
    pct.dataset.tocProgress = s.id;
    b.appendChild(pct);
    b.addEventListener('click', () => {
      const target = document.querySelector('[data-sec="' + s.id + '"]');
      if (!target) return;
      if (s.collapsed) { s.collapsed = false; target.classList.add('open'); scheduleSave(); }
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    toc.appendChild(b);
  }
  updateProgressUI();
}

function renderSection(s) {
  const box = el('div', 'section' + (s.collapsed ? '' : ' open'));
  box.dataset.sec = s.id;

  // head
  const head = el('div', 'sec-head');
  head.appendChild(el('span', 'sec-num', s.num || '··'));
  const title = el('span', 'sec-title', s.title);
  head.appendChild(title);
  const prog = el('span', 'sec-progress', '');
  prog.dataset.secProgress = s.id;
  head.appendChild(prog);
  if (s.custom) {
    const ren = el('button', 'btn-ghost', '✎');
    ren.type = 'button';
    ren.title = 'Переименовать';
    ren.addEventListener('click', (e) => {
      e.stopPropagation();
      const name = prompt('Название секции:', s.title);
      if (name) { s.title = name; scheduleSave(); rerenderSection(s); }
    });
    head.appendChild(ren);
    const del = el('button', 'del-x', '×');
    del.type = 'button';
    del.title = 'Удалить секцию';
    del.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!confirmDel('секцию «' + s.title + '»')) return;
      state.data.sections = state.data.sections.filter(x => x !== s);
      scheduleSave(); renderSections(); updateProgressUI();
    });
    head.appendChild(del);
  }
  head.appendChild(el('span', 'sec-chevron', '▶'));
  head.addEventListener('click', () => {
    s.collapsed = !s.collapsed;
    box.classList.toggle('open', !s.collapsed);
    scheduleSave();
  });
  box.appendChild(head);

  // body
  const body = el('div', 'sec-body');
  if (s.goal) body.appendChild(el('div', 'sec-goal', s.goal));
  // Правило секции (gate) + пометки из исследований — одна тихая свёртка,
  // чтобы не кричали над полями (фидбек Артура), но оставались в одном клике.
  // refGroups — вложенные раскрывашки («13 типов хуков», «конструктор начала»…)
  if (s.gate || (s.ref && s.ref.length) || (s.refGroups && s.refGroups.length)) {
    const det = el('details', 'sec-ref');
    det.appendChild(el('summary', null, 'шпаргалка из исследований'));
    if (s.gate || (s.ref && s.ref.length)) {
      const ul = el('ul');
      if (s.gate) ul.appendChild(refLi(s.gate, 'ref-gate'));
      for (const r of s.ref || []) ul.appendChild(refLi(r));
      det.appendChild(ul);
    }
    for (const g of s.refGroups || []) {
      const sub = el('details', 'ref-group');
      sub.appendChild(el('summary', null, g.title));
      const ul = el('ul');
      for (const it of g.items || []) ul.appendChild(refLi(it));
      sub.appendChild(ul);
      det.appendChild(sub);
    }
    body.appendChild(det);
  }

  if (s.type === 'demand') renderDemand(s, body);
  if (s.type === 'scriptmap') renderScriptmap(s, body);
  if (s.type === 'assets') renderAssets(s, body);
  if (s.type === 'analytics') renderAnalytics(s, body);
  if (s.type === 'filming') renderFilming(s, body);

  if (s.fields) renderFields(s, body);
  if (s.checklist) renderChecklist(s, body);
  renderImages(s, body, sectionImgCfg(s));
  renderFiles(s, body);

  box.appendChild(body);
  requestAnimationFrame(updateProgressUI);
  return box;
}

// ----- generic fields -----

function renderFields(s, body) {
  const host = el('div');
  for (const f of s.fields) host.appendChild(renderField(s, f));
  body.appendChild(host);

  const addRow = el('div', 'add-row');
  const btn = el('button', 'btn', '+ поле');
  btn.type = 'button';
  btn.addEventListener('click', () => {
    const label = prompt('Название нового поля:');
    if (!label) return;
    s.fields.push({ id: 'f' + Date.now(), label, hint: '', value: '', done: false, custom: true });
    scheduleSave(); rerenderSection(s);
  });
  addRow.appendChild(btn);
  body.appendChild(addRow);
}

function renderField(s, f) {
  const row = el('div', 'field' + (f.done ? ' done' : ''));

  const check = el('button', 'field-check');
  check.type = 'button';
  check.title = 'Отметить готовым';
  check.dataset.done = f.done ? '1' : '0';
  check.addEventListener('click', () => {
    f.done = !f.done;
    check.dataset.done = f.done ? '1' : '0';
    row.classList.toggle('done', f.done);
    scheduleSave();
  });
  row.appendChild(check);

  const main = el('div', 'field-main');
  const label = el('div', 'field-label', f.label);
  if (f.custom) {
    const del = el('button', 'del-x', '×');
    del.type = 'button';
    del.addEventListener('click', () => {
      if (!confirmDel('поле «' + f.label + '»')) return;
      s.fields = s.fields.filter(x => x !== f);
      scheduleSave(); rerenderSection(s);
    });
    label.appendChild(del);
  }
  main.appendChild(label);
  if (f.hint) main.appendChild(el('div', 'field-hint', f.hint));
  main.appendChild(textarea(f.value, '', v => { f.value = v; }));
  // сводное поле (напр. «Хук целиком»): кнопка склеивает значения полей-источников
  if (f.assembleFrom) {
    const btn = el('button', 'btn btn-assemble', '⚡ Собрать черновик из полей выше');
    btn.type = 'button';
    btn.addEventListener('click', () => {
      const parts = f.assembleFrom
        .map(id => { const src = (s.fields || []).find(x => x.id === id); return src ? (src.value || '').trim() : ''; })
        .filter(Boolean);
      if (!parts.length) { toast('Сначала заполни поля выше — собирать пока нечего.'); return; }
      if ((f.value || '').trim() && !confirm('Заменить текущий текст собранным черновиком?')) return;
      f.value = parts.join('\n\n');
      scheduleSave(); rerenderSection(s);
      toast('Черновик собран — дошлифуй до живой речи.');
    });
    main.appendChild(btn);
  }
  // главы YouTube из сценарной карты: «00:00–00:30 Хук» → «0:00 Хук»
  if (f.assembleChapters) {
    const btn = el('button', 'btn btn-assemble', '⚡ Собрать главы из сценарной карты');
    btn.type = 'button';
    btn.addEventListener('click', () => {
      const map = state.data.sections.find(x => x.type === 'scriptmap');
      const lines = ((map && map.blocks) || [])
        .map(b => {
          let t = (b.time || '').split(/[–—-]/)[0].trim();
          if (!t || !b.title) return '';
          if (/^\d{1,2}:\d{2}$/.test(t)) t = t.replace(/^0(\d):/, '$1:'); // 00:30 → 0:30
          return t + ' ' + b.title.trim();
        })
        .filter(Boolean);
      if (!lines.length) { toast('В сценарной карте нет блоков с временем и названием.'); return; }
      if ((f.value || '').trim() && !confirm('Заменить текущие главы собранными из карты?')) return;
      f.value = lines.join('\n');
      scheduleSave(); rerenderSection(s);
      toast('Главы собраны: ' + lines.length + ' шт. Проверь, что первая — 0:00.');
    });
    main.appendChild(btn);
  }
  // per-field gallery (thumbnail concepts, final thumb, …): enabled when the
  // field carries an images[] array (template flag or added by an agent)
  if (f.images !== undefined) renderImages(f, main, sectionImgCfg(s));
  row.appendChild(main);
  return row;
}

// ----- checklist -----

function renderChecklist(s, body) {
  const wrap = el('div', 'checklist');
  wrap.appendChild(el('div', 'checklist-label', 'Чеклист'));
  for (const c of s.checklist) {
    const item = el('label', 'check-item');
    const cb = el('input');
    cb.type = 'checkbox';
    cb.checked = !!c.done;
    cb.addEventListener('change', () => { c.done = cb.checked; scheduleSave(); updateProgressUI(); });
    item.appendChild(cb);
    item.appendChild(el('span', null, c.text));
    wrap.appendChild(item);
  }
  body.appendChild(wrap);
}

// ----- demand -----

function renderDemand(s, body) {
  const layers = el('div', 'layers');
  for (const l of s.layers) {
    const card = el('div', 'layer');
    card.appendChild(el('div', 'layer-name', l.name));
    card.appendChild(el('div', 'layer-what', l.what));
    card.appendChild(segControl(
      [['none', 'none', 'не проверено'], ['weak', 'weak', 'слабый сигнал'], ['strong', 'strong', 'сильный сигнал']],
      () => l.status,
      v => { l.status = v; updateProgressUI(); }
    ));
    card.appendChild(textarea(l.links, 'Ссылки-доказательства', v => { l.links = v; }));
    card.appendChild(textarea(l.notes, 'Короткие наблюдения', v => { l.notes = v; }));
    card.appendChild(textarea(l.proves, 'Что это доказывает', v => { l.proves = v; }));
    layers.appendChild(card);
  }
  body.appendChild(layers);

  const axes = el('div', 'axes');
  const verdict = el('div', 'verdict');
  const updateVerdict = () => {
    const passes = s.axes.filter(a => a.pass === true).length;
    const answered = s.axes.filter(a => a.pass !== null).length;
    verdict.textContent = answered < s.axes.length
      ? `Матрица: ${passes}/6 · отвечено ${answered} из 6`
      : passes >= 4
        ? `✔ ${passes}/6 — можно готовить ролик`
        : `✖ ${passes}/6 — отложить или переформулировать`;
    verdict.className = 'verdict ' + (answered === s.axes.length && passes >= 4 ? 'pass' : 'fail');
  };
  for (const a of s.axes) {
    const row = el('div', 'axis');
    row.appendChild(el('span', 'axis-name', a.name));
    row.appendChild(el('span', 'axis-q', a.question));
    row.appendChild(segControl(
      [[null, 'null', '—'], [true, 'yes', 'да'], [false, 'no', 'нет']],
      () => a.pass,
      v => { a.pass = v; updateVerdict(); updateProgressUI(); }
    ));
    axes.appendChild(row);
  }
  body.appendChild(axes);
  updateVerdict();
  body.appendChild(verdict);

  const dec = el('div', 'decision-row');
  dec.appendChild(select(
    [['', 'решение…'], ['go', 'делаем'], ['later', 'откладываем'], ['drop', 'убираем']],
    s.decision.value,
    v => { s.decision.value = v; updateProgressUI(); }
  ));
  dec.appendChild(textInput(s.decision.comment, 'Комментарий к решению', v => { s.decision.comment = v; }));
  body.appendChild(dec);
}

// ----- scriptmap -----

const BLOCK_CELLS = [
  ['goal', 'Цель блока'], ['say', 'Что говорю'],
  ['show', 'Что на экране (вкл. демо-доказательство)'],
  ['payoff', 'Что зритель получил в конце блока'],
  ['loops', 'Петля: что обещаю дальше / что закрываю'],
];

function newBlockId() { return 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

function renderScriptmap(s, body) {
  const host = el('div', 'blocks');
  s.blocks.forEach((b, i) => host.appendChild(renderBlock(s, b, i)));
  body.appendChild(host);

  const addRow = el('div', 'add-row');
  const btn = el('button', 'btn btn-accent', '+ блок');
  btn.type = 'button';
  btn.addEventListener('click', () => {
    s.blocks.push({ id: newBlockId(), time: '', title: '', goal: '', say: '', show: '', payoff: '', loops: '', status: 'idea' });
    scheduleSave(); rerenderSection(s);
    rerenderFilming();
  });
  addRow.appendChild(btn);
  body.appendChild(addRow);
}

function renderBlock(s, b, i) {
  const card = el('div', 'block');
  card.dataset.status = b.status;

  const top = el('div', 'block-top');
  top.appendChild(textInput(b.time, '00:00–00:30', v => { b.time = v; }, 'block-time'));
  top.appendChild(textInput(b.title, 'Название блока', v => { b.title = v; }, 'block-title'));
  top.appendChild(select(
    [['idea', 'черновик'], ['ready', 'готов']],
    b.status,
    v => { b.status = v; card.dataset.status = v; updateProgressUI(); },
    'block-status'
  ));

  const move = el('div', 'block-move');
  const mk = (label, title, fn) => {
    const btn = el('button', null, label);
    btn.type = 'button'; btn.title = title;
    btn.addEventListener('click', fn);
    move.appendChild(btn);
  };
  mk('↑', 'Выше', () => { if (i > 0) { s.blocks.splice(i - 1, 0, s.blocks.splice(i, 1)[0]); scheduleSave(); rerenderSection(s); } });
  mk('↓', 'Ниже', () => { if (i < s.blocks.length - 1) { s.blocks.splice(i + 1, 0, s.blocks.splice(i, 1)[0]); scheduleSave(); rerenderSection(s); } });
  mk('×', 'Удалить блок', () => { if (confirmDel('блок «' + (b.title || b.time) + '»')) { s.blocks.splice(i, 1); scheduleSave(); rerenderSection(s); rerenderFilming(); } });
  top.appendChild(move);
  card.appendChild(top);

  const grid = el('div', 'block-grid');
  for (const [key, label] of BLOCK_CELLS) {
    const cell = el('div', 'bg-cell');
    const lab = el('label', null, label);
    cell.appendChild(lab);
    cell.appendChild(textarea(b[key], '', v => { b[key] = v; }));
    grid.appendChild(cell);
  }
  card.appendChild(grid);
  return card;
}

// ----- assets («Материалы ролика»: папка + простой список) -----

function fmtSize(n) {
  if (n > 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' МБ';
  if (n > 1024) return Math.round(n / 1024) + ' КБ';
  return n + ' Б';
}

function renderMaterialsFolder(s, body) {
  const wrap = el('div', 'folder-box');
  wrap.appendChild(el('div', 'folder-label', 'Папка материалов'));
  const row = el('div', 'folder-row');
  row.appendChild(textInput(s.folder || '', state.videoDir + '\\' + (state.slug || '<slug>') + '\\assets', v => { s.folder = v; }));
  const openBtn = el('button', 'btn', 'открыть');
  openBtn.type = 'button';
  openBtn.addEventListener('click', () => { if ((s.folder || '').trim()) openPath(s.folder.trim()); });
  row.appendChild(openBtn);
  const listBtn = el('button', 'btn', 'содержимое');
  listBtn.type = 'button';
  row.appendChild(listBtn);
  wrap.appendChild(row);

  const listing = el('div', 'folder-list');
  listing.hidden = true;
  listBtn.addEventListener('click', async () => {
    if (!listing.hidden) { listing.hidden = true; return; }
    if (!(s.folder || '').trim()) { toast('Сначала укажи путь к папке'); return; }
    try {
      const items = await api('GET', '/api/browse?path=' + encodeURIComponent(s.folder.trim()));
      listing.innerHTML = '';
      if (!items.length) listing.appendChild(el('div', 'folder-empty', 'папка пуста'));
      for (const it of items) {
        const line = el('button', 'folder-item' + (it.dir ? ' is-dir' : ''));
        line.type = 'button';
        line.appendChild(el('span', 'fi-ic', it.dir ? '▸' : '·'));
        line.appendChild(el('span', 'fi-name', it.name));
        if (!it.dir) line.appendChild(el('span', 'fi-size', fmtSize(it.size)));
        line.addEventListener('click', () => openPath(s.folder.trim().replace(/[\\/]+$/, '') + '\\' + it.name));
        listing.appendChild(line);
      }
      listing.hidden = false;
    } catch (e) {
      toast(e.message, { error: true });
    }
  });
  wrap.appendChild(listing);
  body.appendChild(wrap);
}

function renderAssets(s, body) {
  renderMaterialsFolder(s, body);

  const host = el('div');
  s.items.forEach((it, i) => host.appendChild(renderAsset(s, it, i)));
  body.appendChild(host);

  const addRow = el('div', 'add-row');
  const btn = el('button', 'btn btn-accent', '+ материал');
  btn.type = 'button';
  btn.addEventListener('click', () => {
    s.items.push({ name: '', path: '', link: '', status: 'todo' });
    scheduleSave(); rerenderSection(s);
  });
  addRow.appendChild(btn);
  body.appendChild(addRow);
}

function renderAsset(s, it, i) {
  const card = el('div', 'asset');
  card.dataset.status = it.status;

  const top = el('div', 'asset-top');
  top.appendChild(textInput(it.name, 'Что это (демо, обложка, скриншот…)', v => { it.name = v; }, 'asset-name'));
  top.appendChild(select(
    [['todo', 'не готов'], ['ready', 'готов']],
    it.status,
    v => { it.status = v; card.dataset.status = v; updateProgressUI(); }
  ));
  const del = el('button', 'del-x', '×');
  del.type = 'button';
  del.addEventListener('click', () => {
    if (confirmDel('материал «' + (it.name || '?') + '»')) { s.items.splice(i, 1); scheduleSave(); rerenderSection(s); }
  });
  top.appendChild(del);
  card.appendChild(top);

  const grid = el('div', 'asset-grid');
  const pathRow = el('div', 'path-row');
  pathRow.appendChild(textInput(it.path, 'C:\\локальный\\путь (или оставь пустым)', v => { it.path = v; }));
  const openBtn = el('button', 'btn', 'открыть');
  openBtn.type = 'button';
  openBtn.addEventListener('click', () => openPath(it.path || it.link));
  pathRow.appendChild(openBtn);
  grid.appendChild(pathRow);
  grid.appendChild(textInput(it.link, 'http://… (ссылка/localhost)', v => { it.link = v; }));
  card.appendChild(grid);
  return card;
}

// ----- filming (recording plan derived from the script map) -----

function rerenderFilming() {
  const s = state.data && state.data.sections.find(x => x.type === 'filming');
  if (s) rerenderSection(s);
}

function renderFilming(s, body) {
  s.records = s.records || {};
  const map = state.data.sections.find(x => x.type === 'scriptmap');
  const blocks = (map && map.blocks) || [];

  const wrap = el('div', 'film-blocks');
  wrap.appendChild(el('div', 'checklist-label', 'Блоки на запись — из Сценарной карты (05)'));
  if (!blocks.length) {
    wrap.appendChild(el('div', 'film-empty', 'Сценарная карта пуста. Добавь блоки в секции 05 — они появятся здесь как план записи.'));
  }
  for (const b of blocks) {
    if (!b.id) b.id = newBlockId();
    const r = s.records[b.id] = s.records[b.id] || { status: 'todo', note: '' };
    const row = el('div', 'film-row');
    row.dataset.status = r.status;
    row.appendChild(el('span', 'film-time', b.time || '—'));
    row.appendChild(el('span', 'film-title', b.title || 'без названия'));
    row.appendChild(segControl(
      [['todo', 'todo', 'не снято'], ['done', 'done', 'снято'], ['retake', 'retake', 'переснять']],
      () => r.status,
      v => { r.status = v; row.dataset.status = v; }
    ));
    row.appendChild(textInput(r.note, 'заметка (дубль, что не так…)', v => { r.note = v; }, 'film-note'));
    wrap.appendChild(row);
  }
  // прибрать записи по удалённым блокам
  const alive = new Set(blocks.map(b => b.id));
  for (const k of Object.keys(s.records)) if (!alive.has(k)) delete s.records[k];
  body.appendChild(wrap);
}

// ----- file attachments (CSV/ZIP из YouTube Studio и т.п.) -----

async function uploadAttachment(s, file) {
  try {
    setSaveState('saving', 'загружаю файл…');
    const dataUrl = await fileToDataUrl(file);
    const r = await api('POST', '/api/projects/' + state.slug + '/file', { name: file.name, dataUrl });
    s.files.push({ name: r.name, rel: r.rel });
    scheduleSave(); rerenderSection(s);
    toast('Файл сохранён: ' + r.name);
  } catch (e) {
    toast('Не загрузилось: ' + e.message, { error: true });
  }
}

function renderFiles(s, body) {
  if (s.files === undefined) return; // only sections that opted in (template)
  const wrap = el('div', 'files');
  if (s.files.length) {
    const chips = el('div', 'file-chips');
    s.files.forEach((f, i) => {
      const chip = el('span', 'file-chip');
      const a = el('a', 'file-name', f.name || f.rel);
      a.href = '/api/projects/' + state.slug + '/asset?p=' + encodeURIComponent(f.rel);
      a.target = '_blank'; a.rel = 'noopener';
      chip.appendChild(a);
      const del = el('button', 'del-x', '×');
      del.type = 'button';
      del.addEventListener('click', () => {
        if (!confirm('Убрать файл из полотна? Сам файл остаётся в assets/canvas.')) return;
        s.files.splice(i, 1); scheduleSave(); rerenderSection(s);
      });
      chip.appendChild(del);
      chips.appendChild(chip);
    });
    wrap.appendChild(chips);
  }
  const zone = el('div', 'img-drop');
  zone.appendChild(el('span', 'img-drop-text', '＋ файл (CSV/ZIP из YouTube Studio, JSON, TXT) — перетащи или '));
  const pick = el('label', 'img-pick', 'выбери файл');
  const inp = el('input');
  inp.type = 'file'; inp.accept = '.csv,.tsv,.txt,.json,.md,.zip'; inp.multiple = true; inp.hidden = true;
  inp.addEventListener('change', () => { Array.from(inp.files).forEach(f => uploadAttachment(s, f)); inp.value = ''; });
  pick.appendChild(inp);
  zone.appendChild(pick);
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault(); zone.classList.remove('over');
    Array.from(e.dataTransfer.files || []).forEach(f => uploadAttachment(s, f));
  });
  wrap.appendChild(zone);
  body.appendChild(wrap);
}

// ----- analytics -----

function renderAnalytics(s, body) {
  const bar = el('div', 'add-row');
  const dash = el('button', 'btn btn-accent', 'Дашборд удержания →');
  dash.type = 'button';
  dash.title = 'Графики удержания по CSV/ZIP-вложениям этой секции';
  dash.addEventListener('click', () => window.open('/retention/?slug=' + encodeURIComponent(state.slug), '_blank'));
  bar.appendChild(dash);

  const pull = el('button', 'btn', 'Подтянуть из YouTube');
  pull.type = 'button';
  pull.title = 'Автозаполнение волн через YouTube API (нужна разовая настройка)';
  pull.addEventListener('click', () => pullFromYouTube(s));
  bar.appendChild(pull);
  body.appendChild(bar);

  const waves = el('div', 'waves');
  for (const w of s.waves) {
    const card = el('div', 'wave');
    card.appendChild(el('div', 'wave-label', w.label));
    card.appendChild(textInput(w.date, 'дата замера', v => { w.date = v; }, 'wave-date'));
    for (const f of w.fields) {
      const row = el('div', 'field');
      row.appendChild(el('span', 'field-check')); // hidden by css, keeps grid
      const main = el('div', 'field-main');
      main.appendChild(el('div', 'field-label', f.label));
      if (f.hint) main.appendChild(el('div', 'field-hint', f.hint));
      main.appendChild(textarea(f.value, '', v => { f.value = v; }));
      row.appendChild(main);
      card.appendChild(row);
    }
    waves.appendChild(card);
  }
  body.appendChild(waves);
}

// ----- YouTube API pull -----

async function pullFromYouTube() {
  try {
    await flushSave(); // чтобы сервер видел свежий video_url
    setSaveState('saving', 'тяну метрики из YouTube…');
    const r = await api('POST', '/api/yt/pull', { slug: state.slug });
    if (r.needAuth) {
      await api('GET', '/api/yt/auth'); // сервер сам откроет браузер с согласием Google
      toast('Открыл окно входа Google. Разреши доступ и нажми «Подтянуть из YouTube» ещё раз.');
      setSaveState('idle', state.slug);
      return;
    }
    const parts = [];
    if (r.filled && r.filled.length) parts.push('заполнено полей: ' + r.filled.length);
    if (r.retentionCsv) parts.push('кривая удержания сохранена (api-retention.csv)');
    if (r.note) parts.push(r.note);
    toast('«' + r.video + '» (возраст ' + r.ageDays + ' дн): ' + (parts.join(' · ') || 'готово'));
    openProject(state.slug); // перечитать canvas.json с заполненными волнами
  } catch (e) {
    toast(e.message, { error: true });
    setSaveState('idle', state.slug || '');
  }
}

// ----- images (paste / drop screenshots) — reused by project sections AND ideas.
// `owner` is any object with an `images` array. `cfg` supplies the endpoints and
// how to persist + re-render for the current store. -----

function fileToDataUrl(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(new Error('чтение файла не удалось'));
    r.readAsDataURL(file);
  });
}

async function uploadImage(owner, file, cfg) {
  if (!file || !/^image\//.test(file.type)) { toast('Это не изображение', { error: true }); return; }
  try {
    setSaveState('saving', 'загружаю картинку…');
    const dataUrl = await fileToDataUrl(file);
    const r = await api('POST', cfg.uploadUrl, { dataUrl });
    owner.images = owner.images || [];
    owner.images.push({ id: 'img' + Date.now().toString(36), rel: r.rel, caption: '' });
    cfg.save();
    toast('Картинка сохранена');
  } catch (e) {
    toast('Не загрузилось: ' + e.message, { error: true });
  }
}

function renderThumb(owner, im, cfg) {
  const cell = el('div', 'thumb');
  const a = el('a');
  a.href = cfg.assetUrl(im.rel); a.target = '_blank'; a.rel = 'noopener';
  a.title = 'Открыть в полном размере';
  const img = el('img');
  img.src = cfg.assetUrl(im.rel); img.loading = 'lazy'; img.alt = im.caption || '';
  a.appendChild(img);
  cell.appendChild(a);
  cell.appendChild(textInput(im.caption, 'подпись', v => { im.caption = v; }, 'thumb-cap'));
  const del = el('button', 'thumb-del', '×');
  del.type = 'button'; del.title = 'Убрать из полотна';
  del.addEventListener('click', () => {
    if (!confirm('Убрать картинку? Сам файл остаётся на диске.')) return;
    owner.images = owner.images.filter(x => x !== im); cfg.save();
  });
  cell.appendChild(del);
  return cell;
}

function renderImages(owner, body, cfg) {
  owner.images = owner.images || [];
  const wrap = el('div', 'images' + (owner.images.length ? ' has' : ''));
  if (owner.images.length) {
    const grid = el('div', 'img-grid');
    owner.images.forEach(im => grid.appendChild(renderThumb(owner, im, cfg)));
    wrap.appendChild(grid);
  }

  const zone = el('div', 'img-drop');
  zone.tabIndex = 0;
  zone.appendChild(el('span', 'img-drop-text',
    owner.images.length ? 'добавить ещё — перетащи, вставь (Ctrl+V) или ' : '＋ картинка / скриншот — перетащи, вставь (Ctrl+V) или '));
  const pick = el('label', 'img-pick', 'выбери файл');
  const inp = el('input');
  inp.type = 'file'; inp.accept = 'image/*'; inp.multiple = true; inp.hidden = true;
  inp.addEventListener('change', () => { Array.from(inp.files).forEach(f => uploadImage(owner, f, cfg)); inp.value = ''; });
  pick.appendChild(inp);
  zone.appendChild(pick);

  const arm = () => { state.pasteTarget = (f) => uploadImage(owner, f, cfg); $$('.img-drop.armed').forEach(z => z.classList.remove('armed')); zone.classList.add('armed'); };
  zone.addEventListener('click', (e) => { if (e.target !== inp) arm(); });
  zone.addEventListener('focus', arm);
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault(); zone.classList.remove('over');
    Array.from(e.dataTransfer.files || []).filter(f => /^image\//.test(f.type)).forEach(f => uploadImage(owner, f, cfg));
  });
  wrap.appendChild(zone);
  body.appendChild(wrap);
}

// cfg for a project section (images live in <slug>/assets/canvas/)
function sectionImgCfg(s) {
  return {
    uploadUrl: '/api/projects/' + state.slug + '/image',
    assetUrl: (rel) => '/api/projects/' + state.slug + '/asset?p=' + encodeURIComponent(rel),
    save: () => { scheduleSave(); rerenderSection(s); },
  };
}

// Ctrl+S — принудительное сохранение (привычка из редакторов; автосейв и так работает)
document.addEventListener('keydown', async (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
    e.preventDefault();
    await flushSave();
    if (state.mode === 'ideas' || state.slug) toast('Сохранено.');
  }
});

// Paste a screenshot straight from clipboard into the last-armed drop-zone.
document.addEventListener('paste', (e) => {
  const items = e.clipboardData && e.clipboardData.items;
  if (!items) return;
  for (const it of items) {
    if (it.type && /^image\//.test(it.type)) {
      if (state.pasteTarget) { e.preventDefault(); state.pasteTarget(it.getAsFile()); }
      else toast('Кликни зону «картинка / скриншот», потом Ctrl+V');
      return;
    }
  }
});

// ---------- accent color ----------

const ACCENTS = [
  ['#3CE5B0', 'Мята'], ['#E5B93C', 'Янтарь'], ['#6AA8FF', 'Небо'],
  ['#FF6B6B', 'Коралл'], ['#B98CFF', 'Ирис'], ['#A6E22E', 'Лайм'],
];

function hexToRgba(hex, a) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}

function applyAccent(hex) {
  const root = document.documentElement.style;
  root.setProperty('--accent', hex);
  root.setProperty('--accent-dim', hexToRgba(hex, 0.08));
  root.setProperty('--accent-glow', hexToRgba(hex, 0.16));
  root.setProperty('--line-accent', hexToRgba(hex, 0.32));
  // bright = смесь с белым ~20% (hover-оттенок)
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  const mix = c => Math.min(255, Math.round(c + (255 - c) * 0.2));
  root.setProperty('--accent-bright',
    `rgb(${mix((n >> 16) & 255)}, ${mix((n >> 8) & 255)}, ${mix(n & 255)})`);
  try { localStorage.setItem('canvas-accent', hex); } catch (e) {}
  $$('#accent-picker button').forEach(b => b.classList.toggle('on', b.dataset.hex === hex));
}

function initAccent() {
  const host = $('#accent-picker');
  if (!host) return;
  let saved = '#3CE5B0';
  try { saved = localStorage.getItem('canvas-accent') || saved; } catch (e) {}
  for (const [hex, name] of ACCENTS) {
    const b = el('button');
    b.type = 'button';
    b.dataset.hex = hex;
    b.title = name;
    b.style.background = hex;
    b.addEventListener('click', () => applyAccent(hex));
    host.appendChild(b);
  }
  applyAccent(saved);
}

// ---------- idea inbox ----------

async function updateIdeasCount() {
  try {
    const n = state.mode === 'ideas' ? state.ideas.length : (await api('GET', '/api/ideas')).length;
    const b = $('#ideas-count');
    if (b) { b.textContent = n || ''; b.hidden = !n; }
  } catch (e) { /* ignore */ }
}

async function showIdeas() {
  await flushSave();
  try {
    state.ideas = await api('GET', '/api/ideas');
  } catch (e) {
    toast('Идеи не загрузились: ' + e.message, { error: true });
    return;
  }
  state.mode = 'ideas';
  state.slug = null;
  state.data = null;
  state.pasteTarget = null;
  $('#empty-state').hidden = true;
  $('#project-view').hidden = true;
  $('#ideas-view').hidden = false;
  $('#btn-ideas').classList.add('active');
  renderIdeas();
  loadProjects();
  setSaveState('idle', 'копилка идей');
}

function renderIdeas() {
  const host = $('#ideas-list');
  host.innerHTML = '';
  if (!state.ideas.length) {
    host.appendChild(el('div', 'ideas-empty', 'Пока пусто. Кинь сюда первую идею: заметку, ссылку на чужой ролик или скриншот.'));
  }
  state.ideas.forEach(idea => host.appendChild(renderIdeaCard(idea)));
  updateIdeasCount();
}

function renderIdeaLink(idea, lk, i) {
  const row = el('div', 'idea-link');
  const ic = el('span', 'idea-link-ic', /youtu\.?be/i.test(lk.url || '') ? '▶' : '↗');
  row.appendChild(ic);
  row.appendChild(textInput(lk.url, 'https://youtube.com/…  или любая ссылка', v => { lk.url = v; ic.textContent = /youtu\.?be/i.test(v) ? '▶' : '↗'; }, 'idea-link-url'));
  const open = el('button', 'btn', 'открыть');
  open.type = 'button';
  open.addEventListener('click', () => { if ((lk.url || '').trim()) openPath(lk.url.trim()); });
  row.appendChild(open);
  const del = el('button', 'del-x', '×');
  del.type = 'button';
  del.addEventListener('click', () => { idea.links.splice(i, 1); scheduleSave(); renderIdeas(); });
  row.appendChild(del);
  return row;
}

function renderIdeaCard(idea) {
  idea.links = idea.links || [];
  idea.images = idea.images || [];
  const card = el('div', 'idea-card' + (idea.star ? ' star' : ''));

  const top = el('div', 'idea-top');
  const star = el('button', 'idea-star' + (idea.star ? ' on' : ''), '★');
  star.type = 'button'; star.title = 'Отметить важным';
  star.addEventListener('click', () => { idea.star = !idea.star; star.classList.toggle('on', idea.star); card.classList.toggle('star', idea.star); scheduleSave(); });
  top.appendChild(star);
  top.appendChild(el('span', 'idea-date', idea.created ? new Date(idea.created).toLocaleDateString('ru-RU') : ''));
  const spacer = el('span', 'idea-spacer'); top.appendChild(spacer);
  const promote = el('button', 'btn btn-accent', 'В проект →');
  promote.type = 'button'; promote.title = 'Создать видео-проект из этой идеи';
  promote.addEventListener('click', () => promoteIdea(idea));
  top.appendChild(promote);
  const del = el('button', 'del-x', '×');
  del.type = 'button'; del.title = 'Удалить идею';
  del.addEventListener('click', () => {
    if (!confirm('Удалить идею? Действие не отменяется.')) return;
    state.ideas = state.ideas.filter(x => x !== idea); scheduleSave(); renderIdeas();
  });
  top.appendChild(del);
  card.appendChild(top);

  const note = textarea(idea.note, 'Идея, мысль, зачем это зрителю…', v => { idea.note = v; });
  note.classList.add('idea-note');
  card.appendChild(note);

  const links = el('div', 'idea-links');
  idea.links.forEach((lk, i) => links.appendChild(renderIdeaLink(idea, lk, i)));
  card.appendChild(links);
  const addLink = el('button', 'btn idea-addlink', '+ ссылка');
  addLink.type = 'button';
  addLink.addEventListener('click', () => { idea.links.push({ url: '' }); scheduleSave(); renderIdeas(); });
  card.appendChild(addLink);

  renderImages(idea, card, {
    uploadUrl: '/api/ideas/image',
    assetUrl: (rel) => '/api/ideas/asset?p=' + encodeURIComponent(rel),
    save: () => { scheduleSave(); renderIdeas(); },
  });
  return card;
}

async function promoteIdea(idea) {
  const firstLine = (idea.note || '').split('\n')[0].trim();
  const title = prompt('Название ролика:', firstLine.slice(0, 70));
  if (!title) return;
  const year = new Date().getFullYear();
  let slug = prompt('Slug папки (латиница, напр. ' + year + '-my-video):', year + '-' + translit(title));
  if (!slug) return;
  slug = slug.trim();
  try {
    const data = await api('POST', '/api/projects', { slug, title });
    // carry the idea note + links into «Источник идеи» of the demand section
    const src = (idea.note || '').trim();
    const links = idea.links.map(l => (l.url || '').trim()).filter(Boolean).join('\n');
    const text = [src, links].filter(Boolean).join('\n\n');
    if (text) {
      const demand = (data.sections || []).find(s => s.type === 'demand');
      const f = demand && (demand.fields || []).find(x => /источник идеи/i.test(x.label));
      if (f) { f.value = text; await api('PUT', '/api/projects/' + slug, data); }
    }
    state.ideas = state.ideas.filter(x => x !== idea);
    await doSaveIdeas();
    const imgNote = idea.images.length ? ' Картинки идеи остались в копилке (_ideas).' : '';
    toast('Создан проект Video\\' + slug + '. Заметка перенесена в «Источник идеи».' + imgNote);
    openProject(slug);
  } catch (e) {
    toast('Не удалось создать проект: ' + e.message, { error: true });
  }
}

function initIdeas() {
  $('#btn-ideas').addEventListener('click', showIdeas);
  $('#btn-add-idea').addEventListener('click', () => {
    state.ideas.unshift({ id: 'idea' + Date.now().toString(36), note: '', links: [], images: [], created: new Date().toISOString(), star: false });
    scheduleSave();
    renderIdeas();
    const first = document.querySelector('#ideas-list .idea-note');
    if (first) first.focus();
  });
  updateIdeasCount();
}

// ---------- new project ----------

function initNewProject() {
  const form = $('#new-form');
  const title = $('#new-title');
  const slug = $('#new-slug');
  let slugTouched = false;

  $('#btn-new').addEventListener('click', () => {
    form.hidden = !form.hidden;
    if (!form.hidden) title.focus();
  });
  $('#new-cancel').addEventListener('click', () => { form.hidden = true; });
  form.addEventListener('keydown', (e) => { if (e.key === 'Escape') form.hidden = true; });

  title.addEventListener('input', () => {
    if (!slugTouched) {
      const year = new Date().getFullYear();
      const t = translit(title.value);
      slug.value = t ? year + '-' + t : '';
    }
  });
  slug.addEventListener('input', () => { slugTouched = slug.value.trim() !== ''; });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const p = await api('POST', '/api/projects', { slug: slug.value.trim(), title: title.value.trim() || slug.value.trim() });
      form.hidden = true;
      title.value = ''; slug.value = ''; slugTouched = false;
      await loadProjects();
      openProject(p.slug);
      toast('Проект создан: Video\\' + p.slug + '\\canvas.json');
    } catch (err) {
      toast(err.message, { error: true });
    }
  });
}

// ---------- custom sections ----------

function initAddSection() {
  $('#btn-add-section').addEventListener('click', () => {
    const name = prompt('Название новой секции:');
    if (!name) return;
    state.data.sections.push({
      id: 's' + Date.now(),
      num: String(state.data.sections.length + 1).padStart(2, '0'),
      title: name,
      type: 'fields',
      goal: '',
      collapsed: false,
      custom: true,
      fields: [],
    });
    scheduleSave(); renderSections(); updateProgressUI();
  });
}

// ---------- boot ----------

initAccent();
initIdeas();
initNewProject();
initAddSection();
api('GET', '/api/config').then(c => { if (c.videoDir) state.videoDir = c.videoDir; }).catch(() => {});
loadProjects().catch(e => toast('Сервер недоступен: ' + e.message, { error: true }));
