/* ============================================================
 * Анализатор удержания YouTube-ролика
 * Локальный инструмент: ZIP/CSV из YouTube Studio → дашборд.
 *
 * Структура:
 *   1. Байты и кодировки (UTF-8 / windows-1252 / CP437)
 *   2. Встроенный ZIP-парсер (+ JSZip как запасной вариант)
 *   3. CSV-парсер и числа
 *   4. Распознавание типов отчётов YouTube Studio (DE/EN)
 *   5. Аналитика (ключевые точки, просадки, выходы, пересмотры, когорты)
 *   6. SVG-графики (линии, бары, кроссхейр, тултип)
 *   7. UI-обвязка
 * Ядро (1–5) не трогает DOM и тестируется в Node.
 * ============================================================ */

'use strict';

/* ============ 1. Байты и кодировки ============ */

// Верхняя половина CP437 — для имён файлов в ZIP без флага UTF-8.
const CP437_HIGH =
  'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»' +
  '░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀' +
  'αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ';

function decodeCp437(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    out += b < 128 ? String.fromCharCode(b) : CP437_HIGH[b - 128];
  }
  return out;
}

// Имя файла внутри ZIP: флаг UTF-8 → UTF-8; иначе пробуем строгий UTF-8
// (YouTube пишет UTF-8-байты без флага) и лишь потом CP437.
function decodeZipFileName(bytes, flags) {
  if (flags & 0x800) return new TextDecoder('utf-8').decode(bytes);
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch (e) {
    return decodeCp437(bytes);
  }
}

// Содержимое CSV: UTF-8 (со срезанным BOM); если появились символы
// замены — файл, скорее всего, в windows-1252/latin1.
function decodeBytes(bytes) {
  if (bytes.length >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) {
    bytes = bytes.subarray(3);
  }
  const utf8 = new TextDecoder('utf-8').decode(bytes);
  if (!utf8.includes('�')) return utf8;
  try {
    return new TextDecoder('windows-1252').decode(bytes);
  } catch (e) {
    return utf8; // хоть что-то: числа и структура обычно в ASCII и выживают
  }
}

/* ============ 2. Встроенный ZIP-парсер ============ */

async function inflateRaw(bytes) {
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([bytes]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

// Читает ZIP через центральный каталог. Поддерживает методы store/deflate —
// этого достаточно для экспортов YouTube Studio. ZIP64 не поддерживается
// (экспорты крошечные); в этом случае вызывающий код уходит на JSZip.
async function readZipBuiltin(arrayBuffer) {
  const buf = new Uint8Array(arrayBuffer);
  const view = new DataView(arrayBuffer);

  // Ищем End Of Central Directory с конца (комментарий до 64К).
  let eocd = -1;
  const minPos = Math.max(0, buf.length - 65557);
  for (let i = buf.length - 22; i >= minPos; i--) {
    if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Не найден каталог ZIP (EOCD)');

  const count = view.getUint16(eocd + 10, true);
  const cdOffset = view.getUint32(eocd + 16, true);
  if (cdOffset === 0xFFFFFFFF || count === 0xFFFF) throw new Error('ZIP64 не поддерживается');

  const entries = [];
  let p = cdOffset;
  for (let n = 0; n < count; n++) {
    if (view.getUint32(p, true) !== 0x02014b50) throw new Error('Повреждён центральный каталог ZIP');
    const flags = view.getUint16(p + 8, true);
    const method = view.getUint16(p + 10, true);
    const compSize = view.getUint32(p + 20, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const localOffset = view.getUint32(p + 42, true);
    const nameBytes = buf.subarray(p + 46, p + 46 + nameLen);
    entries.push({ name: decodeZipFileName(nameBytes, flags), method, compSize, localOffset });
    p += 46 + nameLen + extraLen + commentLen;
  }

  const files = [];
  for (const e of entries) {
    if (e.name.endsWith('/')) continue; // каталоги
    if (view.getUint32(e.localOffset, true) !== 0x04034b50) {
      throw new Error('Повреждён локальный заголовок ZIP: ' + e.name);
    }
    const nameLen = view.getUint16(e.localOffset + 26, true);
    const extraLen = view.getUint16(e.localOffset + 28, true);
    const dataStart = e.localOffset + 30 + nameLen + extraLen;
    const raw = buf.subarray(dataStart, dataStart + e.compSize);
    let bytes;
    if (e.method === 0) bytes = raw.slice();
    else if (e.method === 8) bytes = await inflateRaw(raw);
    else throw new Error('Метод сжатия ' + e.method + ' не поддерживается: ' + e.name);
    files.push({ name: e.name, bytes });
  }
  return files;
}

// Запасной путь: JSZip с CDN (если подключился).
async function readZipJSZip(arrayBuffer) {
  const JSZipLib = typeof JSZip !== 'undefined' ? JSZip : null;
  if (!JSZipLib) throw new Error('JSZip недоступен');
  const zip = await JSZipLib.loadAsync(arrayBuffer, { decodeFileName: decodeZipFileName });
  const files = [];
  for (const key of Object.keys(zip.files)) {
    const f = zip.files[key];
    if (f.dir) continue;
    files.push({ name: f.name, bytes: await f.async('uint8array') });
  }
  return files;
}

async function readZipAny(arrayBuffer) {
  try {
    return await readZipBuiltin(arrayBuffer);
  } catch (e1) {
    try {
      return await readZipJSZip(arrayBuffer);
    } catch (e2) {
      throw new Error('ZIP не распакован (' + e1.message + '; JSZip: ' + e2.message + '). ' +
        'Распакуйте архив вручную и загрузите CSV-файлы через кнопку «CSV вручную».');
    }
  }
}

/* ============ 3. CSV и числа ============ */

// Полноценный CSV: кавычки, экранированные кавычки "" и запятые в кавычках
// (заголовок "Anzahl, wie oft jeder Moment angesehen wurde" этого требует).
function parseCSV(text) {
  const rows = [];
  let row = [], field = '', inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += c;
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      row.push(field); field = '';
    } else if (c === '\n') {
      row.push(field); field = '';
      rows.push(row); row = [];
    } else if (c !== '\r') {
      field += c;
    }
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  // отбрасываем полностью пустые строки
  return rows.filter(r => r.some(c => c.trim() !== ''));
}

// "12.5" → 12.5; "12,5" → 12.5 (немецкая десятичная запятая);
// "" / "–" / текст → null. Реальные данные не подменяются нулями.
function parseNum(s) {
  if (s == null) return null;
  s = String(s).trim().replace(/\s|%/g, '');
  if (s === '' || s === '-' || s === '–' || s === '—') return null;
  if (/^-?\d+,\d+$/.test(s)) s = s.replace(',', '.');
  const v = Number(s);
  return Number.isFinite(v) ? v : null;
}

/* ============ 4. Распознавание отчётов YouTube Studio ============ */

// Убираем регистр, диакритику и типичные следы битой кодировки, чтобы
// матчить и «Aktivitäten», и «Aktivit├ñten», и «AktivitÃ¤ten».
function normalizeName(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

const COL = {
  position: /videoposition|video\s*position|\bposition\b/i,
  relative: /vergleich|relativ|compared|relative/i,
  absolute: /zuschauerbindung|audience\s*retention|absolute/i,
  started:  /gestartet|started/i,
  ended:    /beendet|ended|finished/i,
  moments:  /angesehen|moment.*watched|watched|wie\s*oft/i
};

// Семантика значения группирующей колонки (DE + EN) → ключ и русская подпись.
function classifyGroup(raw) {
  const s = String(raw || '').toLowerCase();
  if (/(ohne|nicht|not|non[- ])/.test(s) && /(abo|subscri)/.test(s))
    return { key: 'nonsub', label: 'Без подписки', order: 1 };
  if (/abonnenten|subscrib/.test(s)) return { key: 'sub', label: 'Подписчики', order: 0 };
  if (/wiederkehr|returning/.test(s)) return { key: 'returning', label: 'Возвращающиеся зрители', order: 1 };
  if (/gelegentlich|casual/.test(s)) return { key: 'casual', label: 'Случайные зрители', order: 1 };
  if (/regelm|regular/.test(s)) return { key: 'regular', label: 'Регулярные зрители', order: 2 };
  if (/neue|new/.test(s)) return { key: 'new', label: 'Новые зрители', order: 0 };
  if (/organi/.test(s)) return { key: 'organic', label: 'Органический трафик', order: 0 };
  if (/bezahlt|paid/.test(s)) return { key: 'paid', label: 'Платный трафик', order: 1 };
  return { key: 'other:' + s, label: String(raw), order: 9 };
}

// Тип когорты по составу групп — для заголовков и списка «ожидаемых» групп.
const COHORT_TYPES = {
  subs:        { title: 'Подписчики и не-подписчики', expect: ['sub', 'nonsub'] },
  newReturning:{ title: 'Новые и возвращающиеся зрители', expect: ['new', 'returning'] },
  loyalty:     { title: 'Новые, случайные и регулярные зрители', expect: ['new', 'casual', 'regular'] },
  traffic:     { title: 'Органический и платный трафик', expect: ['organic', 'paid'] },
  other:       { title: 'Сравнение групп зрителей', expect: [] }
};

function detectCohortType(groupKeys) {
  const has = k => groupKeys.includes(k);
  if (has('sub') || has('nonsub')) return 'subs';
  if (has('casual') || has('regular')) return 'loyalty';
  if (has('returning')) return 'newReturning';
  if (has('organic') || has('paid')) return 'traffic';
  return 'other';
}

// Человекочитаемое название файла по имени (подсказка, не основной сигнал).
function fileNameHint(name) {
  const n = normalizeName(name);
  if (/discovery/.test(n)) return 'ad-discovery';
  if (/berspringbare|skippable|anzeige|in stream/.test(n)) return 'ad-instream';
  if (/aktivit|activity|detail/.test(n)) return 'activity';
  if (/abonnenten|subscri/.test(n)) return 'subs';
  if (/gelegentlich|regelm|casual|regular/.test(n)) return 'loyalty';
  if (/wiederkehr|returning/.test(n)) return 'newReturning';
  if (/bezahlt|paid|traffic/.test(n)) return 'traffic';
  if (/organisch|organic/.test(n)) return 'organic';
  if (/^alle?\b|^all\b|gesamt|total/.test(n)) return 'all';
  return null;
}

const HINT_TITLES = {
  'ad-discovery': 'Реклама Video Discovery',
  'ad-instream': 'Пропускаемая видеореклама (in-stream)',
  'activity': 'Действия зрителей по моментам',
  'subs': 'Удержание: подписчики / без подписки',
  'loyalty': 'Удержание: новые / случайные / регулярные',
  'newReturning': 'Удержание: новые / возвращающиеся',
  'traffic': 'Удержание: органический / платный трафик',
  'organic': 'Удержание: органический трафик',
  'all': 'Общая кривая удержания (все зрители)'
};

// Главная функция распознавания одного CSV.
function detectReport(fileName, text) {
  const report = {
    fileName,
    hint: fileNameHint(fileName),
    kind: 'unknown',
    title: null,
    note: '',
    rowCount: 0,
    issues: []
  };

  const rows = parseCSV(text);
  if (!rows.length) {
    report.kind = 'empty';
    report.note = 'Файл полностью пуст.';
    report.title = HINT_TITLES[report.hint] || 'Неизвестный отчёт';
    return report;
  }

  const header = rows[0].map(h => h.trim());
  const data = rows.slice(1);
  report.rowCount = data.length;
  report.header = header;

  if (!data.length) {
    report.kind = 'empty';
    report.note = 'Только заголовок, строк с данными нет.';
    report.title = HINT_TITLES[report.hint] || 'Отчёт без данных';
    return report;
  }

  const findCol = (re, exclude) => header.findIndex((h, i) =>
    re.test(h) && (!exclude || !exclude.includes(i)));

  const posCol = findCol(COL.position);
  if (posCol < 0) {
    report.kind = 'unknown';
    report.note = 'Не найдена колонка позиции видео — это не отчёт об удержании.';
    report.title = HINT_TITLES[report.hint] || 'Нераспознанный CSV';
    return report;
  }

  const startedCol = findCol(COL.started);
  const endedCol = findCol(COL.ended);
  const momentsCol = findCol(COL.moments, [startedCol, endedCol]);

  // группирующая колонка: значения не числа и это не позиция
  let groupCol = -1;
  for (let i = 0; i < header.length; i++) {
    if (i === posCol) continue;
    const sample = data.slice(0, 5).map(r => r[i]).filter(v => v != null && v.trim() !== '');
    if (sample.length && sample.every(v => parseNum(v) === null)) { groupCol = i; break; }
  }

  const relCol = findCol(COL.relative);
  let absCol = header.findIndex((h, i) =>
    i !== posCol && i !== groupCol && i !== relCol && COL.absolute.test(h));

  const maxPos = data.reduce((m, r) => Math.max(m, parseNum(r[posCol]) ?? 0), 0);
  report.maxPos = maxPos;

  const seriesFromCol = col => {
    const arr = new Array(maxPos + 1).fill(null);
    for (const r of data) {
      const x = parseNum(r[posCol]);
      if (x == null || x < 0 || x > maxPos) continue;
      arr[x] = parseNum(r[col]);
    }
    return arr;
  };

  if (startedCol >= 0 || endedCol >= 0 || momentsCol >= 0) {
    report.kind = 'activity';
    report.title = 'Действия зрителей по моментам';
    report.started = startedCol >= 0 ? seriesFromCol(startedCol) : null;
    report.ended = endedCol >= 0 ? seriesFromCol(endedCol) : null;
    report.moments = momentsCol >= 0 ? seriesFromCol(momentsCol) : null;
    const gaps = ['started', 'ended', 'moments']
      .filter(k => report[k])
      .reduce((n, k) => n + report[k].filter(v => v === null).length, 0);
    report.suppressedCells = gaps;
    report.note = 'Старты, завершения и пересмотры по каждому проценту длительности.'
      + (gaps ? ` Пустых ячеек: ${gaps} (YouTube скрывает малые значения).` : '');
    return report;
  }

  if (groupCol >= 0) {
    report.kind = 'grouped';
    const byGroup = new Map();
    for (const r of data) {
      const x = parseNum(r[posCol]);
      const g = (r[groupCol] || '').trim();
      if (x == null || !g) continue;
      if (!byGroup.has(g)) byGroup.set(g, new Array(maxPos + 1).fill(null));
      const valCol = absCol >= 0 ? absCol : header.findIndex((h, i) =>
        i !== posCol && i !== groupCol && parseNum(r[i]) !== null);
      byGroup.get(g)[x] = parseNum(r[valCol]);
    }
    report.groups = [...byGroup.entries()].map(([raw, values]) => {
      const c = classifyGroup(raw);
      return { raw, key: c.key, label: c.label, order: c.order, values };
    }).sort((a, b) => a.order - b.order || a.label.localeCompare(b.label, 'ru'));
    report.cohortType = detectCohortType(report.groups.map(g => g.key));
    report.title = COHORT_TYPES[report.cohortType].title;
    report.note = 'Группы: ' + report.groups.map(g => g.label).join(', ') + '.';
    const expected = COHORT_TYPES[report.cohortType].expect;
    report.missingGroups = expected.filter(k => !report.groups.some(g => g.key === k));
    if (report.missingGroups.length) {
      const missLabels = { sub: 'Подписчики', nonsub: 'Без подписки', new: 'Новые зрители',
        returning: 'Возвращающиеся зрители', casual: 'Случайные зрители',
        regular: 'Регулярные зрители', organic: 'Органический трафик', paid: 'Платный трафик' };
      report.note += ' В выгрузке нет группы: ' +
        report.missingGroups.map(k => missLabels[k] || k).join(', ') +
        ' (обычно значит, что данных по ней слишком мало).';
    }
    return report;
  }

  if (absCol < 0 && relCol < 0) {
    report.kind = 'unknown';
    report.note = 'Есть позиция видео, но нет ни одной распознанной колонки удержания.';
    report.title = HINT_TITLES[report.hint] || 'Нераспознанный CSV';
    return report;
  }

  report.kind = 'retention';
  report.abs = absCol >= 0 ? seriesFromCol(absCol) : null;
  report.rel = relCol >= 0 ? seriesFromCol(relCol) : null;
  report.title = HINT_TITLES[report.hint] ||
    (report.hint === 'all' ? 'Общая кривая удержания (все зрители)' : 'Кривая удержания');
  report.note = 'Абсолютное удержание по позиции.'
    + (report.rel ? ' Есть колонка сравнения с другими видео (относительное удержание).' : '');
  return report;
}

/* ============ 5. Аналитика ============ */

const KEY_POSITIONS = [0, 1, 5, 10, 25, 50, 75, 90, 99];

function valueAt(values, x) {
  if (!values) return null;
  if (values[x] != null) return values[x];
  // ближайшая заполненная позиция в пределах ±2 — честно помечаем как приближение
  for (let d = 1; d <= 2; d++) {
    if (values[x - d] != null) return values[x - d];
    if (values[x + d] != null) return values[x + d];
  }
  return null;
}

function meanOf(values) {
  const v = values.filter(x => x != null);
  return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
}

function analyzeCurve(values) {
  const res = { keyPoints: [], drops: [], spikes: [], mean: meanOf(values) };
  for (const p of KEY_POSITIONS) {
    res.keyPoints.push({ pos: p, value: valueAt(values, p) });
  }
  for (let i = 1; i < values.length; i++) {
    if (values[i] == null || values[i - 1] == null) continue;
    const d = values[i] - values[i - 1];
    if (d < 0) res.drops.push({
      from: i - 1, to: i, before: values[i - 1], after: values[i], delta: d,
      isIntro: i <= 5,                    // спад вступления универсален
      isTail: i >= values.length - 2      // обрыв у конца — ролик просто кончается
    });
    if (d > 0.3) res.spikes.push({ from: i - 1, to: i, before: values[i - 1], after: values[i], delta: d });
  }
  res.drops.sort((a, b) => a.delta - b.delta);
  res.spikes.sort((a, b) => b.delta - a.delta);
  return res;
}

function analyzeExits(ended) {
  if (!ended) return null;
  const known = ended.map((v, i) => ({ pos: i, count: v })).filter(r => r.count != null);
  if (!known.length) return null;
  const total = known.reduce((s, r) => s + r.count, 0);
  const lastPos = known[known.length - 1].pos;
  const finalRow = known.find(r => r.pos === lastPos);
  const body = known.filter(r => r.pos !== lastPos && r.pos !== 0)
    .sort((a, b) => b.count - a.count);
  return {
    total,
    final: finalRow ? { ...finalRow, share: finalRow.count / total } : null,
    start: known.find(r => r.pos === 0) || null,
    top: body.slice(0, 7).map(r => ({ ...r, share: r.count / total })),
    suppressed: ended.filter(v => v === null).length
  };
}

// Пик пересмотров: локальный максимум, заметно выше медианы окрестности.
function analyzeRewatch(moments) {
  if (!moments) return null;
  const peaks = [];
  for (let i = 1; i < moments.length - 1; i++) {
    const v = moments[i];
    if (v == null) continue;
    const win = [];
    for (let d = -3; d <= 3; d++) {
      if (d === 0) continue;
      const w = moments[i + d];
      if (w != null) win.push(w);
    }
    if (win.length < 3) continue;
    win.sort((a, b) => a - b);
    const med = win[Math.floor(win.length / 2)];
    const prev = moments[i - 1], next = moments[i + 1];
    const isLocalMax = (prev == null || v >= prev) && (next == null || v >= next);
    const prominence = med > 0 ? (v - med) / med : 0;
    if (isLocalMax && prominence >= 0.03) peaks.push({ pos: i, count: v, prominence });
  }
  peaks.sort((a, b) => b.prominence - a.prominence);
  // схлопываем соседние позиции (пик размазывается на 2–3 процента)
  const merged = [];
  for (const p of peaks) {
    if (merged.some(m => Math.abs(m.pos - p.pos) <= 2)) continue;
    merged.push(p);
  }
  return { peaks: merged.slice(0, 6), suppressed: moments.filter(v => v === null).length };
}

function analyzeCohort(report) {
  const c = { report, groups: report.groups, facts: [], gap: null };
  const g = report.groups;
  if (g.length >= 2) {
    const a = g[0], b = g[1];
    const diffs = [];
    for (let i = 0; i < Math.min(a.values.length, b.values.length); i++) {
      if (a.values[i] != null && b.values[i] != null) {
        diffs.push({ pos: i, diff: a.values[i] - b.values[i] });
      }
    }
    if (diffs.length) {
      const avg = diffs.reduce((s, d) => s + d.diff, 0) / diffs.length;
      const maxAbs = diffs.reduce((m, d) => Math.abs(d.diff) > Math.abs(m.diff) ? d : m, diffs[0]);
      c.gap = { a: a.label, b: b.label, avg, maxAbs, n: diffs.length };
    }
  }
  for (const grp of g) {
    c.facts.push({
      label: grp.label,
      start: valueAt(grp.values, 0),
      p10: valueAt(grp.values, 10),
      p50: valueAt(grp.values, 50),
      end: valueAt(grp.values, Math.max(0, grp.values.length - 1))
    });
  }
  return c;
}

// ---------- Рекомендации: только из чисел, гипотезы помечены ----------

function buildRecommendations(a) {
  const recs = [];
  const pct = v => fmtNum(v, 1) + '%';
  const pp = v => fmtNum(Math.abs(v), 1) + ' пп';

  if (a.mainCurve) {
    const v = a.mainCurve;
    const v0 = valueAt(v, 0), v1 = valueAt(v, 1), v5 = valueAt(v, 5), v10 = valueAt(v, 10);

    if (v0 != null && v1 != null) {
      const loss = v0 - v1;
      const sev = v1 < 65 ? 'critical' : v1 < 75 ? 'serious' : v1 < 85 ? 'warning' : 'good';
      recs.push({
        sev,
        text: sev === 'good'
          ? `Старт удерживает: после первого 1% длительности остаётся ${pct(v1)} (потеря всего ${pp(loss)}). Приём, использованный в начале, стоит повторить.`
          : `Первый 1% длительности теряет ${pp(loss)}: удержание падает с ${pct(v0)} до ${pct(v1)}. В следующем ролике пересобрать самое начало: быстрее показать, что зритель получит, убрать всё, что не работает на первые секунды.`,
        hypo: sev === 'good' ? null
          : 'Что именно в первых секундах отталкивает — по CSV не видно; нужно пересмотреть начало ролика.'
      });
    }

    if (v1 != null && v10 != null && v1 - v10 > 15) {
      recs.push({
        sev: v1 - v10 > 25 ? 'serious' : 'warning',
        text: `После вступления спад продолжается: с ${pct(v1)} (позиция 1%) до ${pct(v10)} (позиция 10%) — ещё ${pp(v1 - v10)}. Первая десятая часть ролика не закрепляет аудиторию: стоит раньше давать конкретику и первое «вознаграждение» за просмотр.`,
        hypo: 'Без сценария нельзя сказать, что занимает этот участок — проверить по видео.'
      });
    } else if (v5 != null && v1 != null && v1 - v5 > 12) {
      recs.push({
        sev: 'warning',
        text: `На участке 1–5% длительности теряется ещё ${pp(v1 - v5)} (с ${pct(v1)} до ${pct(v5)}). Проверить, чем заняты эти секунды сразу после хука.`,
        hypo: 'Причина по данным не определяется — нужен просмотр фрагмента.'
      });
    }

    const bodyDrops = (a.curveStats?.drops || []).filter(d => !d.isIntro && !d.isTail);
    if (bodyDrops.length) {
      const top = bodyDrops.slice(0, 2);
      const list = top.map(d =>
        `${d.from}–${d.to}%${a.posTime ? ` (≈${a.posTime(d.to)})` : ''}: −${fmtNum(Math.abs(d.delta), 1)} пп (${pct(d.before)} → ${pct(d.after)})`
      ).join('; ');
      recs.push({
        sev: Math.abs(top[0].delta) >= 3 ? 'serious' : 'warning',
        text: `Самые резкие просадки в теле ролика — ${list}. Пересмотреть эти фрагменты и понять, что совпадает с обрывом: смена темы, затянутый кусок, невыполненное обещание.`,
        hypo: 'CSV показывает только ГДЕ падает удержание; ЧТО в этот момент на экране — известно только из самого видео.'
      });
    }
  }

  if (a.exits && a.exits.top.length) {
    const t = a.exits.top[0];
    recs.push({
      sev: 'warning',
      text: `Больше всего досрочных завершений — на позиции ${t.pos}%${a.posTime ? ` (≈${a.posTime(t.pos)})` : ''}: ${fmtInt(t.count)} выходов (${fmtNum(t.share * 100, 1)}% всех завершений). Ключевые обещания и призывы размещать до этой точки.`,
      hypo: null
    });
  }

  if (a.rewatch && a.rewatch.peaks.length) {
    const list = a.rewatch.peaks.slice(0, 3).map(p =>
      `${p.pos}%${a.posTime ? ` (≈${a.posTime(p.pos)})` : ''}`).join(', ');
    recs.push({
      sev: 'good',
      text: `Зрители чаще всего пересматривают моменты около позиций ${list}. Эти фрагменты работают — найти их в видео и использовать тот же формат подачи раньше и чаще.`,
      hypo: 'Пересмотры могут означать и «интересно», и «непонятно, пришлось вернуться» — различить можно только по содержанию фрагмента.'
    });
  }

  for (const c of a.cohorts || []) {
    if (!c.gap || Math.abs(c.gap.avg) < 5) continue;
    const leader = c.gap.avg > 0 ? c.gap.a : c.gap.b;
    const lagger = c.gap.avg > 0 ? c.gap.b : c.gap.a;
    recs.push({
      sev: 'warning',
      text: `«${leader}» смотрят заметно дольше, чем «${lagger}»: средний разрыв ${pp(c.gap.avg)} по всей длине (максимум ${fmtNum(Math.abs(c.gap.maxAbs.diff), 1)} пп на позиции ${c.gap.maxAbs.pos}%). Это структурный сигнал, а не случайность.`,
      hypo: `Почему «${lagger}» уходят раньше, данные не объясняют — гипотезы (повторность темы, несовпадение ожиданий) нужно проверять по контенту.`
    });
  }

  if (a.relative && a.relative.stats) {
    const s = a.relative.stats;
    if (s.midMean != null) {
      recs.push({
        sev: s.midMean >= 0 ? 'good' : 'warning',
        text: s.midMean >= 0
          ? `В середине ролика (20–80% длительности) удержание в среднем на ${pp(s.midMean)} выше, чем у похожих видео YouTube. Формат основной части работает — сохранить его.`
          : `В середине ролика (20–80% длительности) удержание в среднем на ${pp(s.midMean)} ниже, чем у похожих видео. Основную часть стоит уплотнить.`,
        hypo: 'Относительная метрика YouTube шумная (особенно в хвосте) — использовать как второстепенный сигнал.'
      });
    }
  }

  if (a.mainCurve) {
    const vEnd = valueAt(a.mainCurve, a.mainCurve.length - 1);
    const v90 = valueAt(a.mainCurve, 90);
    if (v90 != null && vEnd != null && v90 - vEnd > 5) {
      recs.push({
        sev: 'warning',
        text: `Финал: на позиции 90% ещё ${pct(v90)}, к концу остаётся ${pct(vEnd)} — последние 10% теряют ${pp(v90 - vEnd)}. Концовку сократить, а следующий шаг для зрителя (подписка, следующее видео) давать до начала массового выхода.`,
        hypo: null
      });
    }
  }

  const order = { critical: 0, serious: 1, warning: 2, good: 3 };
  recs.sort((x, y) => order[x.sev] - order[y.sev]);
  return recs;
}

// ---------- Ограничения: что нельзя сказать по этим данным ----------

function buildLimitations(a) {
  const items = [];
  items.push({
    strong: 'Нет самого видео, сценария, глав и таймкодов.',
    text: 'Инструмент видит, ГДЕ удержание падает или растёт, но не ЧТО в этот момент на экране. Формулировки вида «здесь началась реклама» или «здесь автор говорил о цене» из этих CSV вывести нельзя — все причинные объяснения в отчёте помечены как гипотезы.'
  });
  items.push({
    strong: 'Позиции даны в процентах длительности, а не в секундах.',
    text: a.duration
      ? `Таймкоды рассчитаны из введённой вручную длительности (${fmtTime(a.duration)}) и являются приближением с шагом 1% (${fmtNum(a.duration / 100, 1)} с).`
      : 'В CSV нет длительности ролика — таймкоды недоступны. Введите длительность в шапке, чтобы видеть приблизительные метки времени.'
  });
  items.push({
    strong: 'Нет данных о показах, CTR и источниках трафика.',
    text: 'По этой выгрузке нельзя судить об обложке, заголовке и дистрибуции — только о поведении зрителей уже внутри ролика.'
  });
  items.push({
    strong: 'Средняя глубина просмотра — оценка по кривой.',
    text: 'Точные AVD/AVP (среднее время и процент просмотра) YouTube Studio считает по другой методике; за точными значениями — в сам Studio.'
  });
  if (a.activityReport && a.activityReport.suppressedCells > 0) {
    items.push({
      strong: `В детальных действиях ${a.activityReport.suppressedCells} пустых ячеек.`,
      text: 'YouTube скрывает малые значения (обычно меньше ~10 событий). Пустая ячейка — «данных мало», а не ноль; такие моменты не участвуют в рейтингах выходов и пересмотров.'
    });
  }
  const missing = (a.cohorts || []).flatMap(c => (c.report.missingGroups || []));
  if (missing.length) {
    const labels = { sub: 'подписчики', nonsub: 'без подписки', new: 'новые', returning: 'возвращающиеся', casual: 'случайные', regular: 'регулярные', organic: 'органический трафик', paid: 'платный трафик' };
    items.push({
      strong: 'Часть зрительских групп отсутствует в выгрузке: ' + missing.map(m => labels[m] || m).join(', ') + '.',
      text: 'YouTube не выгружает группу, если по ней слишком мало данных. Сравнения по этим группам сделать нельзя.'
    });
  }
  const emptyFiles = (a.reports || []).filter(r => r.kind === 'empty');
  if (emptyFiles.length) {
    items.push({
      strong: `Файлы без данных: ${emptyFiles.map(r => r.fileName).join(', ')}.`,
      text: 'Это не ошибка: такие отчёты (обычно рекламные) пусты, если по ролику не было соответствующей активности.'
    });
  }
  if (a.relative) {
    items.push({
      strong: 'Относительное удержание («в сравнении с другими видео») — шумная метрика.',
      text: 'Особенно в хвосте ролика она сильно колеблется между выгрузками. Главные выводы в отчёте построены на абсолютной кривой и сырых счётчиках, относительная — вспомогательный сигнал.'
    });
  }
  items.push({
    strong: 'Один ролик, один экспорт.',
    text: 'Нельзя оценить динамику во времени и сравнить с другими вашими роликами — для этого нужны дополнительные выгрузки.'
  });
  return items;
}

// ---------- Сборка полного анализа ----------

function buildAnalysis(reports, duration) {
  const a = { reports, duration: duration || null, cohorts: [] };
  a.posTime = duration
    ? (pos => fmtTime(pos / 100 * duration))
    : null;

  const retention = reports.filter(r => r.kind === 'retention' && r.abs && r.abs.some(v => v != null));
  a.mainReport =
    retention.find(r => r.hint === 'all') ||
    retention.find(r => !r.rel) ||
    retention[0] || null;
  a.mainCurve = a.mainReport ? a.mainReport.abs : null;

  if (a.mainCurve) {
    a.curveStats = analyzeCurve(a.mainCurve);
    a.kpi = {
      start: valueAt(a.mainCurve, 0),
      p10: valueAt(a.mainCurve, 10),
      p50: valueAt(a.mainCurve, 50),
      end: valueAt(a.mainCurve, a.mainCurve.length - 1),
      endPos: a.mainCurve.length - 1,
      mean: a.curveStats.mean
    };
  }

  const relReport = reports.find(r => r.rel && r.rel.some(v => v != null));
  if (relReport) {
    const rel = relReport.rel;
    const mid = rel.slice(Math.floor(rel.length * 0.2), Math.ceil(rel.length * 0.8));
    a.relative = { report: relReport, values: rel, stats: { midMean: meanOf(mid) } };
  }

  a.activityReport = reports.find(r => r.kind === 'activity') || null;
  if (a.activityReport) {
    a.exits = analyzeExits(a.activityReport.ended);
    a.rewatch = analyzeRewatch(a.activityReport.moments);
  }

  a.cohorts = reports.filter(r => r.kind === 'grouped').map(analyzeCohort);
  a.recommendations = buildRecommendations(a);
  a.limitations = buildLimitations(a);
  return a;
}

/* ============ Форматирование ============ */

function fmtNum(v, digits) {
  if (v == null || !Number.isFinite(v)) return '—';
  return v.toLocaleString('ru-RU', { minimumFractionDigits: 0, maximumFractionDigits: digits ?? 1 });
}
function fmtInt(v) {
  if (v == null || !Number.isFinite(v)) return '—';
  return Math.round(v).toLocaleString('ru-RU');
}
function fmtTime(totalSeconds) {
  if (totalSeconds == null || !Number.isFinite(totalSeconds)) return '—';
  const s = Math.round(totalSeconds);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  const mm = h ? String(m).padStart(2, '0') : String(m);
  return (h ? h + ':' : '') + mm + ':' + String(sec).padStart(2, '0');
}
// "12:34" | "1:02:03" | "754" → секунды; иначе null
function parseDuration(str) {
  if (!str) return null;
  const s = String(str).trim();
  if (/^\d+$/.test(s)) return Number(s);
  const m = s.match(/^(\d+):(\d{1,2})(?::(\d{1,2}))?$/);
  if (!m) return null;
  if (m[3] != null) return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
  return Number(m[1]) * 60 + Number(m[2]);
}

/* ============ Экспорт ядра для Node-тестов ============ */

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    decodeBytes, decodeZipFileName, decodeCp437, readZipBuiltin,
    parseCSV, parseNum, normalizeName, classifyGroup, detectReport,
    analyzeCurve, analyzeExits, analyzeRewatch, analyzeCohort,
    buildAnalysis, parseDuration, fmtTime
  };
}

/* ============================================================
 * 6–7. Всё, что ниже, выполняется только в браузере.
 * ============================================================ */

if (typeof document !== 'undefined') {

  /* ---------- Помощники DOM (только textContent — имена из CSV не доверенные) ---------- */

  const $ = sel => document.querySelector(sel);

  function el(tag, attrs, ...children) {
    const node = tag.includes(':svg')
      ? document.createElementNS('http://www.w3.org/2000/svg', tag.replace(':svg', ''))
      : document.createElement(tag);
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (v == null) continue;
      if (k === 'class') node.setAttribute('class', v);
      else if (k === 'text') node.textContent = v;
      else node.setAttribute(k, v);
    }
    for (const c of children) {
      if (c == null) continue;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return node;
  }
  const svgEl = (tag, attrs, ...children) => el(tag + ':svg', attrs, ...children);

  /* ---------- Палитра (дублирует CSS-переменные для SVG) ---------- */

  const C = {
    s1: '#3987e5', s2: '#199e70', s3: '#c98500', s5: '#9085e9', s6: '#e66767',
    grid: '#2c2c2a', baseline: '#383835', muted: '#898781',
    ink: '#ffffff', ink2: '#c3c2b7', surface: '#1a1a19',
    dropBand: 'rgba(230,103,103,0.14)'
  };
  const SERIES_COLORS = [C.s1, C.s2, C.s3];

  /* ---------- Общий тултип ---------- */

  const tooltip = $('#chart-tooltip');

  function showTooltip(clientX, clientY, title, rows) {
    tooltip.textContent = '';
    tooltip.appendChild(el('div', { class: 'tt-title', text: title }));
    for (const r of rows) {
      const row = el('div', { class: 'tt-row' });
      const key = el('span', { class: 'tt-key' });
      key.style.borderTopColor = r.color;
      row.appendChild(key);
      row.appendChild(el('span', { class: 'tt-val', text: r.value }));
      row.appendChild(el('span', { class: 'tt-name', text: r.name }));
      tooltip.appendChild(row);
    }
    tooltip.hidden = false;
    const pad = 14;
    const rect = tooltip.getBoundingClientRect();
    let x = clientX + pad, y = clientY + pad;
    if (x + rect.width > window.innerWidth - 8) x = clientX - rect.width - pad;
    if (y + rect.height > window.innerHeight - 8) y = clientY - rect.height - pad;
    tooltip.style.left = x + 'px';
    tooltip.style.top = y + 'px';
  }
  function hideTooltip() { tooltip.hidden = true; }

  /* ---------- Оси и тики ---------- */

  function niceTicks(min, max, count) {
    const span = max - min || 1;
    const step0 = span / Math.max(1, count);
    const mag = Math.pow(10, Math.floor(Math.log10(step0)));
    const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => span / s <= count) || 10 * mag;
    const start = Math.ceil(min / step) * step;
    const ticks = [];
    for (let v = start; v <= max + 1e-9; v += step) ticks.push(Math.round(v * 1000) / 1000);
    return ticks;
  }

  /* ---------- Линейный график ----------
   * cfg: { series:[{name,color,values:number[]|null[]}], yMin, yMax, yUnit,
   *        height, showArea, markers:[{pos}], highlights:[{from,to}],
   *        xTitle, yTitle, zeroLine }
   * X — индекс массива (позиция 0..N-1, шаг 1% длительности). */

  function renderLineChart(host, cfg) {
    host.textContent = '';
    const W = 980, H = cfg.height || 300;
    const padL = 46, padR = 14, padT = 12, padB = 34;
    const plotW = W - padL - padR, plotH = H - padT - padB;
    const N = Math.max(...cfg.series.map(s => s.values.length));
    const xMax = N - 1;

    let yMin = cfg.yMin ?? 0, yMax = cfg.yMax ?? 100;
    if (cfg.autoY) {
      const all = cfg.series.flatMap(s => s.values).filter(v => v != null);
      const lo = Math.min(0, ...all), hi = Math.max(...all);
      const pad = (hi - lo) * 0.08 || 1;
      yMin = Math.floor(lo - (lo < 0 ? pad : 0));
      yMax = Math.ceil(hi + pad);
    }

    const xToPx = x => padL + x / xMax * plotW;
    const yToPx = y => padT + (yMax - y) / (yMax - yMin) * plotH;

    const svg = svgEl('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', tabindex: '0' });

    // легенда (только при ≥2 сериях)
    if (cfg.series.length >= 2) {
      const legend = el('div', { class: 'chart-legend' });
      for (const s of cfg.series) {
        const key = el('span', { class: 'key' });
        const sw = el('span', { class: 'swatch-line' });
        sw.style.borderTopColor = s.color;
        key.appendChild(sw);
        key.appendChild(document.createTextNode(s.name));
        legend.appendChild(key);
      }
      host.appendChild(legend);
    }

    // подсветка просадок — под сеткой и линиями
    for (const hl of (cfg.highlights || [])) {
      svg.appendChild(svgEl('rect', {
        x: xToPx(hl.from), y: padT,
        width: Math.max(2, xToPx(hl.to) - xToPx(hl.from)), height: plotH,
        fill: C.dropBand
      }));
    }

    // сетка Y
    const yTicks = cfg.yTicks || niceTicks(yMin, yMax, 5);
    for (const t of yTicks) {
      svg.appendChild(svgEl('line', {
        x1: padL, x2: W - padR, y1: yToPx(t), y2: yToPx(t),
        stroke: C.grid, 'stroke-width': 1
      }));
      svg.appendChild(svgEl('text', {
        x: padL - 8, y: yToPx(t) + 4, 'text-anchor': 'end',
        fill: C.muted, 'font-size': 11, 'font-family': 'inherit', text: fmtNum(t, 0) + (cfg.yUnit || '')
      }));
    }
    if (cfg.zeroLine && yMin < 0) {
      svg.appendChild(svgEl('line', {
        x1: padL, x2: W - padR, y1: yToPx(0), y2: yToPx(0),
        stroke: C.baseline, 'stroke-width': 1.5
      }));
    }

    // тики X (каждые 10%)
    for (let x = 0; x <= xMax; x += 10) {
      svg.appendChild(svgEl('text', {
        x: xToPx(x), y: H - padB + 18, 'text-anchor': 'middle',
        fill: C.muted, 'font-size': 11, text: x + '%'
      }));
      svg.appendChild(svgEl('line', {
        x1: xToPx(x), x2: xToPx(x), y1: H - padB, y2: H - padB + 4,
        stroke: C.baseline, 'stroke-width': 1
      }));
    }
    // ось X
    svg.appendChild(svgEl('line', {
      x1: padL, x2: W - padR, y1: H - padB, y2: H - padB,
      stroke: C.baseline, 'stroke-width': 1
    }));
    // подписи осей
    svg.appendChild(svgEl('text', {
      x: W - padR, y: H - 4, 'text-anchor': 'end',
      fill: C.muted, 'font-size': 11, text: cfg.xTitle || 'Позиция в ролике, % длительности'
    }));
    if (cfg.yTitle) {
      svg.appendChild(svgEl('text', {
        x: padL, y: padT - 1, fill: C.muted, 'font-size': 11, text: cfg.yTitle
      }));
    }

    // линии и площадь
    cfg.series.forEach((s, si) => {
      let d = '', area = '';
      let started = false;
      for (let x = 0; x < s.values.length; x++) {
        const v = s.values[x];
        if (v == null) { started = false; continue; }
        const cmd = started ? 'L' : 'M';
        d += `${cmd}${xToPx(x).toFixed(1)},${yToPx(v).toFixed(1)}`;
        started = true;
      }
      if (cfg.showArea && si === 0) {
        // площадь только по непрерывному началу первой серии
        let a = '', st = false, lastX = null;
        for (let x = 0; x < s.values.length; x++) {
          const v = s.values[x];
          if (v == null) break;
          a += `${st ? 'L' : 'M'}${xToPx(x).toFixed(1)},${yToPx(v).toFixed(1)}`;
          st = true; lastX = x;
        }
        if (lastX != null) {
          a += `L${xToPx(lastX).toFixed(1)},${yToPx(Math.max(yMin, 0)).toFixed(1)}`;
          a += `L${xToPx(0).toFixed(1)},${yToPx(Math.max(yMin, 0)).toFixed(1)}Z`;
          svg.appendChild(svgEl('path', { d: a, fill: s.color, opacity: 0.1 }));
        }
      }
      svg.appendChild(svgEl('path', {
        d, fill: 'none', stroke: s.color, 'stroke-width': 2,
        'stroke-linejoin': 'round', 'stroke-linecap': 'round'
      }));
    });

    // маркеры ключевых точек (кольцо цветом поверхности)
    for (const m of (cfg.markers || [])) {
      const s0 = cfg.series[0];
      const v = s0.values[m.pos];
      if (v == null) continue;
      svg.appendChild(svgEl('circle', {
        cx: xToPx(m.pos), cy: yToPx(v), r: 4.5,
        fill: s0.color, stroke: C.surface, 'stroke-width': 2
      }));
    }

    // кроссхейр + слой наведения
    const cross = svgEl('line', {
      y1: padT, y2: H - padB, stroke: C.muted, 'stroke-width': 1, visibility: 'hidden'
    });
    svg.appendChild(cross);
    const hoverDots = cfg.series.map(s => {
      const dot = svgEl('circle', { r: 4.5, fill: s.color, stroke: C.surface, 'stroke-width': 2, visibility: 'hidden' });
      svg.appendChild(dot);
      return dot;
    });

    const overlay = svgEl('rect', {
      x: padL, y: padT, width: plotW, height: plotH, fill: 'transparent'
    });
    svg.appendChild(overlay);

    let focusX = null;
    const showAt = (x, clientX, clientY) => {
      x = Math.max(0, Math.min(xMax, Math.round(x)));
      focusX = x;
      cross.setAttribute('x1', xToPx(x));
      cross.setAttribute('x2', xToPx(x));
      cross.setAttribute('visibility', 'visible');
      const rows = [];
      cfg.series.forEach((s, i) => {
        const v = s.values[x];
        if (v == null) { hoverDots[i].setAttribute('visibility', 'hidden'); return; }
        hoverDots[i].setAttribute('cx', xToPx(x));
        hoverDots[i].setAttribute('cy', yToPx(v));
        hoverDots[i].setAttribute('visibility', 'visible');
        rows.push({ color: s.color, name: s.name, value: (cfg.fmtVal || (vv => fmtNum(vv, 1) + (cfg.yUnit || '%')))(v) });
      });
      if (rows.length === 0) rows.push({ color: C.baseline, name: 'нет данных (скрыто YouTube)', value: '—' });
      showTooltip(clientX, clientY, posTitle(x), rows);
    };
    const hideAll = () => {
      cross.setAttribute('visibility', 'hidden');
      hoverDots.forEach(d => d.setAttribute('visibility', 'hidden'));
      hideTooltip();
      focusX = null;
    };

    overlay.addEventListener('pointermove', evt => {
      const rect = svg.getBoundingClientRect();
      const scale = W / rect.width;
      const x = ((evt.clientX - rect.left) * scale - padL) / plotW * xMax;
      showAt(x, evt.clientX, evt.clientY);
    });
    overlay.addEventListener('pointerleave', hideAll);
    svg.addEventListener('keydown', evt => {
      if (evt.key === 'Escape') { hideAll(); return; }
      if (evt.key !== 'ArrowLeft' && evt.key !== 'ArrowRight') return;
      evt.preventDefault();
      const next = focusX == null ? 0 : focusX + (evt.key === 'ArrowRight' ? 1 : -1);
      const rect = svg.getBoundingClientRect();
      const scale = rect.width / W;
      const cx = rect.left + (padL + Math.max(0, Math.min(xMax, next)) / xMax * plotW) * scale;
      showAt(next, cx, rect.top + rect.height / 2);
    });
    svg.addEventListener('blur', hideAll);

    host.appendChild(svg);
  }

  /* ---------- Столбчатый график (счётчики по позициям) ---------- */

  function renderBarChart(host, cfg) {
    host.textContent = '';
    const W = 980, H = cfg.height || 260;
    const padL = 52, padR = 14, padT = 12, padB = 34;
    const plotW = W - padL - padR, plotH = H - padT - padB;
    const values = cfg.values;
    const N = values.length, xMax = N - 1;
    const maxV = Math.max(...values.filter(v => v != null), 1);
    const yTicks = niceTicks(0, maxV, 4);
    const yTop = yTicks[yTicks.length - 1] < maxV ? maxV : yTicks[yTicks.length - 1];

    const xToPx = x => padL + x / xMax * plotW;
    const yToPx = v => padT + (1 - v / yTop) * plotH;

    const svg = svgEl('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img', tabindex: '0' });

    for (const t of yTicks) {
      svg.appendChild(svgEl('line', { x1: padL, x2: W - padR, y1: yToPx(t), y2: yToPx(t), stroke: C.grid, 'stroke-width': 1 }));
      svg.appendChild(svgEl('text', { x: padL - 8, y: yToPx(t) + 4, 'text-anchor': 'end', fill: C.muted, 'font-size': 11, text: fmtInt(t) }));
    }
    for (let x = 0; x <= xMax; x += 10) {
      svg.appendChild(svgEl('text', { x: xToPx(x), y: H - padB + 18, 'text-anchor': 'middle', fill: C.muted, 'font-size': 11, text: x + '%' }));
    }
    svg.appendChild(svgEl('line', { x1: padL, x2: W - padR, y1: H - padB, y2: H - padB, stroke: C.baseline, 'stroke-width': 1 }));
    svg.appendChild(svgEl('text', { x: W - padR, y: H - 4, 'text-anchor': 'end', fill: C.muted, 'font-size': 11, text: cfg.xTitle || 'Позиция в ролике, % длительности' }));
    if (cfg.yTitle) svg.appendChild(svgEl('text', { x: padL, y: padT - 1, fill: C.muted, 'font-size': 11, text: cfg.yTitle }));

    const step = plotW / N;
    const barW = Math.min(24, Math.max(2, step - 2)); // зазор ≥2px поверхностью
    const bars = [];
    values.forEach((v, x) => {
      if (v == null) { bars.push(null); return; }
      const h = Math.max(1, (H - padB) - yToPx(v));
      const bar = svgEl('rect', {
        x: xToPx(x) - barW / 2, y: yToPx(v), width: barW, height: h,
        rx: Math.min(1.5, barW / 3), fill: cfg.color
      });
      svg.appendChild(bar);
      bars.push(bar);
    });

    const overlay = svgEl('rect', { x: padL, y: padT, width: plotW, height: plotH, fill: 'transparent' });
    svg.appendChild(overlay);
    let lit = null, focusX = null;
    const showAt = (x, clientX, clientY) => {
      x = Math.max(0, Math.min(xMax, Math.round(x)));
      focusX = x;
      if (lit) lit.setAttribute('opacity', 1);
      lit = bars[x];
      if (lit) lit.setAttribute('opacity', 0.75);
      const v = values[x];
      showTooltip(clientX, clientY, posTitle(x), [{
        color: cfg.color, name: cfg.name,
        value: v == null ? 'скрыто (< ~10)' : fmtInt(v)
      }]);
    };
    const hideAll = () => { if (lit) lit.setAttribute('opacity', 1); lit = null; focusX = null; hideTooltip(); };
    overlay.addEventListener('pointermove', evt => {
      const rect = svg.getBoundingClientRect();
      const scale = W / rect.width;
      const x = ((evt.clientX - rect.left) * scale - padL) / plotW * xMax;
      showAt(x, evt.clientX, evt.clientY);
    });
    overlay.addEventListener('pointerleave', hideAll);
    svg.addEventListener('keydown', evt => {
      if (evt.key === 'Escape') { hideAll(); return; }
      if (evt.key !== 'ArrowLeft' && evt.key !== 'ArrowRight') return;
      evt.preventDefault();
      const next = focusX == null ? 0 : focusX + (evt.key === 'ArrowRight' ? 1 : -1);
      const rect = svg.getBoundingClientRect();
      showAt(next, rect.left + rect.width / 2, rect.top + rect.height / 2);
    });
    svg.addEventListener('blur', hideAll);

    host.appendChild(svg);
  }

  /* ---------- Состояние и рендер ---------- */

  const state = { reports: null, duration: null, sourceName: null };

  function posTitle(x) {
    const t = state.duration ? ` · ≈${fmtTime(x / 100 * state.duration)}` : '';
    return `Позиция ${x}%${t}`;
  }
  function posLabel(x) {
    return state.duration ? `${x}% (≈${fmtTime(x / 100 * state.duration)})` : `${x}%`;
  }

  function setStatus(msg, isError) {
    const s = $('#dropzone-status');
    s.hidden = !msg;
    s.textContent = msg || '';
    s.style.color = isError ? 'var(--st-critical)' : 'var(--st-warning)';
  }

  async function handleZipFile(file) {
    setStatus('Читаю ' + file.name + '…', false);
    try {
      const buf = await file.arrayBuffer();
      const entries = (await readZipAny(buf)).filter(e =>
        /\.csv$/i.test(e.name) && !e.name.includes('__MACOSX'));
      if (!entries.length) throw new Error('В архиве не нашлось ни одного CSV-файла.');
      const files = entries.map(e => ({
        name: e.name.split('/').pop(),
        text: decodeBytes(e.bytes)
      }));
      loadFiles(files, file.name);
    } catch (err) {
      setStatus('Ошибка: ' + err.message, true);
    }
  }

  async function handleCsvFiles(fileList) {
    const files = [];
    for (const f of fileList) {
      const buf = await f.arrayBuffer();
      files.push({ name: f.name, text: decodeBytes(new Uint8Array(buf)) });
    }
    if (files.length) loadFiles(files, files.length + ' CSV вручную');
  }

  function loadFiles(files, sourceName) {
    state.sourceName = sourceName;
    state.reports = files.map(f => {
      try {
        return detectReport(f.name, f.text);
      } catch (err) {
        return { fileName: f.name, kind: 'unknown', title: 'Ошибка чтения',
          note: 'Файл не разобран: ' + err.message, rowCount: 0 };
      }
    });
    setStatus('', false);
    render();
  }

  function render() {
    if (!state.reports) return;
    const analysis = buildAnalysis(state.reports, state.duration);
    $('#dashboard').hidden = false;
    const dz = $('#dropzone');
    dz.classList.add('compact');
    dz.querySelector('h2').textContent =
      'Загружено: ' + state.sourceName + ' — перетащите другой ZIP или CSV, чтобы проанализировать другой ролик';

    renderFilesPanel(analysis);
    renderKpi(analysis);
    renderMainChart(analysis);
    renderKeyPoints(analysis);
    renderDrops(analysis);
    renderExits(analysis);
    renderRewatch(analysis);
    renderCohorts(analysis);
    renderRelative(analysis);
    renderActions(analysis);
    renderLimits(analysis);

    document.title = 'Анализатор удержания — ' + state.sourceName;
  }

  function sectionEmpty(text) {
    return el('div', { class: 'section-empty', text });
  }

  /* ---------- Секции ---------- */

  function renderFilesPanel(a) {
    const table = $('#files-table');
    table.textContent = '';
    const head = el('tr', null,
      el('th', { text: 'Файл' }), el('th', { text: 'Что это' }),
      el('th', { class: 'num', text: 'Строк данных' }), el('th', { text: 'Статус' }),
      el('th', { text: 'Примечание' }));
    table.appendChild(el('thead', null, head));
    const tbody = el('tbody');
    for (const r of a.reports) {
      const status =
        r.kind === 'empty' ? el('span', { class: 'file-status empty', text: 'нет данных' }) :
        r.kind === 'unknown' ? el('span', { class: 'file-status unknown', text: 'не распознан' }) :
        el('span', { class: 'file-status ok', text: 'распознан' });
      tbody.appendChild(el('tr', null,
        el('td', { class: 'strong', text: r.fileName }),
        el('td', { text: r.title || '—' }),
        el('td', { class: 'num', text: r.rowCount ? fmtInt(r.rowCount) : '0' }),
        el('td', null, status),
        el('td', { text: r.note || '' })));
    }
    table.appendChild(tbody);

    const kinds = { retention: 0, grouped: 0, activity: 0, empty: 0, unknown: 0 };
    a.reports.forEach(r => kinds[r.kind]++);
    const recognized = kinds.retention + kinds.grouped + kinds.activity;
    $('#files-summary').textContent =
      `Всего CSV: ${a.reports.length} · распознано: ${recognized} · без данных: ${kinds.empty}` +
      (kinds.unknown ? ` · не распознано: ${kinds.unknown}` : '');
  }

  function renderKpi(a) {
    const row = $('#kpi-row');
    row.textContent = '';
    if (!a.kpi) {
      row.appendChild(sectionEmpty('Нет основной кривой удержания — KPI недоступны. Не хватает файла вида «Alle.csv» / «All.csv» с колонкой абсолютного удержания.'));
      return;
    }
    const tiles = [
      { label: 'Смотрят самое начало (0%)', value: a.kpi.start, note: a.kpi.start != null ? `${fmtNum(100 - a.kpi.start, 1)}% не начали смотреть всерьёз` : '' },
      { label: 'Прошли 10% ролика', value: a.kpi.p10, note: state.duration ? '≈' + fmtTime(0.10 * state.duration) : 'позиция 10% длительности' },
      { label: 'Дошли до середины', value: a.kpi.p50, note: state.duration ? '≈' + fmtTime(0.50 * state.duration) : 'позиция 50% длительности' },
      { label: `Досмотрели до конца (${a.kpi.endPos}%)`, value: a.kpi.end, note: 'последняя точка кривой' },
      { label: 'Средняя глубина просмотра', value: a.kpi.mean, note: 'оценка по площади кривой, не AVP из Studio' }
    ];
    for (const t of tiles) {
      const val = el('div', { class: 'kpi-value' },
        t.value == null ? '—' : fmtNum(t.value, 1), el('span', { class: 'unit', text: t.value == null ? '' : '%' }));
      row.appendChild(el('div', { class: 'kpi' },
        el('div', { class: 'kpi-label', text: t.label }), val,
        el('div', { class: 'kpi-note', text: t.note })));
    }
  }

  function renderMainChart(a) {
    const host = $('#main-chart');
    host.textContent = '';
    if (!a.mainCurve) {
      host.appendChild(sectionEmpty('Основная кривая удержания не найдена. Ожидается CSV с колонками «Videoposition (in %)» и «Absolute Zuschauerbindung (%)» (или английские аналоги).'));
      $('#main-chart-sub').textContent = '';
      $('#main-chart-note').textContent = '';
      return;
    }
    $('#main-chart-sub').textContent =
      `Источник: ${a.mainReport.fileName} · ${a.mainCurve.filter(v => v != null).length} точек, шаг 1% длительности` +
      (state.duration ? ` (≈${fmtNum(state.duration / 100, 1)} с на шаг)` : '');
    const bodyDrops = (a.curveStats?.drops || []).filter(d => !d.isIntro && !d.isTail).slice(0, 3);
    renderLineChart(host, {
      series: [{ name: 'Все зрители', color: C.s1, values: a.mainCurve }],
      yMin: 0, yMax: 100, yTicks: [0, 20, 40, 60, 80, 100], yUnit: '%',
      height: 380, showArea: true,
      markers: KEY_POSITIONS.map(p => ({ pos: Math.min(p, a.mainCurve.length - 1) })),
      highlights: bodyDrops.map(d => ({ from: d.from, to: d.to })),
      yTitle: 'Удержание, %'
    });
    $('#main-chart-note').textContent =
      'Точки — контрольные позиции (0–99%). Красные полосы — три самые резкие просадки вне вступления. ' +
      'Рост кривой означает, что участок пересматривают или на него перематывают.';
  }

  function renderKeyPoints(a) {
    const table = $('#keypoints-table');
    table.textContent = '';
    if (!a.curveStats) {
      table.parentElement.replaceChildren(sectionEmpty('Нет кривой удержания — ключевые точки недоступны.'));
      return;
    }
    table.appendChild(el('thead', null, el('tr', null,
      el('th', { text: 'Позиция' }),
      state.duration ? el('th', { text: 'Таймкод (≈)' }) : null,
      el('th', { class: 'num', text: 'Удержание' }),
      el('th', { class: 'num', text: 'Потеря с прошлой точки' }))));
    const tbody = el('tbody');
    let prev = null;
    for (const kp of a.curveStats.keyPoints) {
      const delta = (prev != null && kp.value != null) ? kp.value - prev : null;
      const deltaCell = el('td', { class: 'num' });
      if (delta != null && delta < -0.05) deltaCell.appendChild(el('span', { class: 'delta-bad', text: '−' + fmtNum(Math.abs(delta), 1) + ' пп' }));
      else if (delta != null && delta > 0.05) deltaCell.appendChild(el('span', { class: 'delta-good', text: '+' + fmtNum(delta, 1) + ' пп' }));
      else deltaCell.textContent = delta == null ? '—' : '0 пп';
      tbody.appendChild(el('tr', null,
        el('td', { class: 'strong', text: kp.pos + '%' }),
        state.duration ? el('td', { text: '≈' + fmtTime(kp.pos / 100 * state.duration) }) : null,
        el('td', { class: 'num strong', text: kp.value == null ? 'нет данных' : fmtNum(kp.value, 1) + '%' }),
        deltaCell));
      if (kp.value != null) prev = kp.value;
    }
    table.appendChild(tbody);
  }

  function renderDrops(a) {
    const table = $('#drops-table');
    table.textContent = '';
    if (!a.curveStats || !a.curveStats.drops.length) {
      table.parentElement.replaceChildren(sectionEmpty('Просадки не вычислены: нет кривой удержания.'));
      $('#drops-note').textContent = '';
      return;
    }
    table.appendChild(el('thead', null, el('tr', null,
      el('th', { text: 'Участок' }),
      el('th', { class: 'num', text: 'Было → стало' }),
      el('th', { class: 'num', text: 'Потеря' }),
      el('th', { text: '' }))));
    const tbody = el('tbody');
    for (const d of a.curveStats.drops.slice(0, 6)) {
      tbody.appendChild(el('tr', null,
        el('td', { class: 'strong', text: `${posLabel(d.from)} → ${posLabel(d.to)}` }),
        el('td', { class: 'num', text: `${fmtNum(d.before, 1)}% → ${fmtNum(d.after, 1)}%` }),
        el('td', { class: 'num' }, el('span', { class: 'delta-bad', text: '−' + fmtNum(Math.abs(d.delta), 1) + ' пп' })),
        el('td', null,
          d.isIntro ? el('span', { class: 'tag', text: 'вступление — спад там есть у всех роликов' }) :
          d.isTail ? el('span', { class: 'tag', text: 'самый конец — обрыв здесь естественен' }) :
          document.createTextNode(''))));
    }
    table.appendChild(tbody);
    $('#drops-note').textContent =
      'Резкий спад в первых 1–3% — универсальное поведение: часть зрителей уходит сразу. ' +
      'Диагностически важнее просадки в теле ролика (без метки).';
  }

  function renderExits(a) {
    const chartHost = $('#exits-chart');
    const table = $('#exits-table');
    chartHost.textContent = '';
    table.textContent = '';
    if (!a.exits) {
      $('#exits-sub').textContent = '';
      chartHost.appendChild(sectionEmpty('В выгрузке нет детальных действий («Aktivitäten im Detail» / «Detailed activity») — точки завершения просмотра недоступны. Не хватает колонки «Wiedergabe beendet» / «Ended».'));
      $('#exits-note').textContent = '';
      return;
    }
    const ex = a.exits;
    $('#exits-sub').textContent =
      `Сырые счётчики «просмотр завершён» по позициям · всего завершений: ${fmtInt(ex.total)} · источник: ${a.activityReport.fileName}`;
    renderBarChart(chartHost, {
      values: a.activityReport.ended, color: C.s6,
      name: 'Завершили просмотр', yTitle: 'Завершений, шт.', height: 260
    });

    table.appendChild(el('thead', null, el('tr', null,
      el('th', { text: 'Позиция' }),
      el('th', { class: 'num', text: 'Завершений' }),
      el('th', { class: 'num', text: 'Доля всех завершений' }),
      el('th', { text: '' }))));
    const tbody = el('tbody');
    const addRow = (r, tag) => tbody.appendChild(el('tr', null,
      el('td', { class: 'strong', text: posLabel(r.pos) }),
      el('td', { class: 'num strong', text: fmtInt(r.count) }),
      el('td', { class: 'num', text: fmtNum(r.share * 100, 1) + '%' }),
      el('td', null, tag ? el('span', { class: 'tag', text: tag }) : document.createTextNode(''))));
    if (ex.start && ex.start.count > 0) addRow({ ...ex.start, share: ex.start.count / ex.total }, 'мгновенный уход на старте');
    for (const r of ex.top) addRow(r);
    if (ex.final) addRow(ex.final, 'естественное завершение ролика');
    table.appendChild(tbody);
    $('#exits-note').textContent =
      (ex.suppressed ? `Пустые позиции (${ex.suppressed} шт.) — YouTube скрывает значения меньше ~10; это «мало данных», а не ноль. ` : '') +
      'Завершение на последней позиции — норма: ролик просто закончился.';
  }

  function renderRewatch(a) {
    const chartHost = $('#rewatch-chart');
    const table = $('#rewatch-table');
    chartHost.textContent = '';
    table.textContent = '';
    if (!a.rewatch || !a.activityReport?.moments) {
      $('#rewatch-sub').textContent = '';
      chartHost.appendChild(sectionEmpty('Нет данных о том, сколько раз просматривали каждый момент («Anzahl, wie oft jeder Moment angesehen wurde» / «Times each moment watched») — пересмотры недоступны.'));
      $('#rewatch-note').textContent = '';
      return;
    }
    $('#rewatch-sub').textContent =
      `Сколько раз просмотрен каждый момент (включая повторы) · источник: ${a.activityReport.fileName}`;
    renderLineChart(chartHost, {
      series: [{ name: 'Просмотров момента', color: C.s2, values: a.activityReport.moments }],
      autoY: true, yUnit: '', height: 260,
      markers: a.rewatch.peaks.map(p => ({ pos: p.pos })),
      yTitle: 'Просмотров момента, шт.',
      fmtVal: v => fmtInt(v)
    });

    if (a.rewatch.peaks.length) {
      table.appendChild(el('thead', null, el('tr', null,
        el('th', { text: 'Позиция' }),
        el('th', { class: 'num', text: 'Просмотров момента' }),
        el('th', { class: 'num', text: 'Выше окружения на' }))));
      const tbody = el('tbody');
      for (const p of a.rewatch.peaks) {
        tbody.appendChild(el('tr', null,
          el('td', { class: 'strong', text: posLabel(p.pos) }),
          el('td', { class: 'num strong', text: fmtInt(p.count) }),
          el('td', { class: 'num' }, el('span', { class: 'delta-good', text: '+' + fmtNum(p.prominence * 100, 1) + '%' }))));
      }
      table.appendChild(tbody);
    } else {
      table.parentElement.appendChild(sectionEmpty('Выраженных пиков пересмотра не найдено — кривая просмотров монотонна.'));
    }
    $('#rewatch-note').textContent =
      'Пик — момент, который смотрят заметно чаще соседних (пересмотры или перемотка к нему). ' +
      'Что именно там происходит, по CSV определить нельзя — найдите эти таймкоды в самом ролике.';
  }

  function renderCohorts(a) {
    const root = $('#cohorts-root');
    root.textContent = '';
    const wanted = [
      { type: 'subs', missing: 'Нет CSV «Abonnenten und Nicht-Abonnenten» / «Subscribed status» — сравнение подписчиков и не-подписчиков недоступно.' },
      { type: 'newReturning', missing: 'Нет CSV «Neue und wiederkehrende Zuschauer» / «New and returning viewers» — сравнение новых и возвращающихся недоступно.' },
      { type: 'loyalty', missing: 'Нет CSV «Neue, gelegentliche und regelmäßige Zuschauer» / «New, casual and regular viewers» — сравнение по лояльности недоступно.' }
    ];
    const done = new Set();

    const renderOne = c => {
      const panel = el('section', { class: 'panel' });
      panel.appendChild(el('div', { class: 'panel-head' },
        el('h2', { text: c.report.title }),
        el('p', { class: 'panel-sub', text: `Источник: ${c.report.fileName} · ${c.report.note}` })));
      const host = el('div', { class: 'chart-host' });
      panel.appendChild(host);
      renderLineChart(host, {
        series: c.groups.map((g, i) => ({ name: g.label, color: SERIES_COLORS[i % SERIES_COLORS.length], values: g.values })),
        yMin: 0, yMax: 100, yTicks: [0, 20, 40, 60, 80, 100], yUnit: '%', height: 300,
        yTitle: 'Удержание, %'
      });
      const facts = el('div', { class: 'cohort-facts' });
      for (const f of c.facts) {
        facts.appendChild(el('div', { class: 'cohort-fact' },
          el('b', { text: f.label }), document.createElement('br'),
          `старт ${fmtNum(f.start, 1)}% · 10% ролика: ${fmtNum(f.p10, 1)}% · середина: ${fmtNum(f.p50, 1)}% · конец: ${fmtNum(f.end, 1)}%`));
      }
      if (c.gap) {
        facts.appendChild(el('div', { class: 'cohort-fact' },
          el('b', { text: 'Разрыв групп' }), document.createElement('br'),
          `«${c.gap.a}» минус «${c.gap.b}»: в среднем ${c.gap.avg >= 0 ? '+' : '−'}${fmtNum(Math.abs(c.gap.avg), 1)} пп; ` +
          `максимум ${fmtNum(Math.abs(c.gap.maxAbs.diff), 1)} пп на позиции ${c.gap.maxAbs.pos}%`));
      }
      panel.appendChild(facts);
      if (c.groups.length < 2) {
        panel.appendChild(el('p', { class: 'chart-note', text: 'В файле только одна группа — сравнивать не с чем. ' + (c.report.missingGroups?.length ? 'Отсутствует: ' + c.report.missingGroups.join(', ') + '.' : '') }));
      }
      root.appendChild(panel);
    };

    for (const c of a.cohorts) { renderOne(c); done.add(c.report.cohortType); }

    for (const w of wanted) {
      if (done.has(w.type)) continue;
      const panel = el('section', { class: 'panel' });
      panel.appendChild(el('div', { class: 'panel-head' }, el('h2', { text: COHORT_TYPES[w.type].title })));
      panel.appendChild(sectionEmpty(w.missing));
      root.appendChild(panel);
    }
  }

  function renderRelative(a) {
    const host = $('#relative-chart');
    host.textContent = '';
    if (!a.relative) {
      $('#relative-sub').textContent = '';
      host.appendChild(sectionEmpty('В выгрузке нет колонки «Im Vergleich zu anderen Videos» / «Compared to other videos» — сравнение с похожими видео недоступно.'));
      $('#relative-note').textContent = '';
      return;
    }
    $('#relative-sub').textContent =
      `Относительное удержание YouTube: выше нуля — лучше похожих видео · источник: ${a.relative.report.fileName}`;
    renderLineChart(host, {
      series: [{ name: 'Относительно других видео', color: C.s5, values: a.relative.values }],
      autoY: true, yUnit: ' пп', height: 280, zeroLine: true,
      yTitle: 'Отклонение от похожих видео, пп',
      fmtVal: v => (v >= 0 ? '+' : '') + fmtNum(v, 1) + ' пп'
    });
    const mm = a.relative.stats.midMean;
    $('#relative-note').textContent =
      (mm != null ? `Средний уровень в середине ролика (20–80%): ${mm >= 0 ? '+' : ''}${fmtNum(mm, 1)} пп. ` : '') +
      'Внимание: это самая шумная метрика выгрузки, особенно в хвосте — используйте её как вспомогательную, а не главную.';
  }

  function renderActions(a) {
    const list = $('#actions-list');
    list.textContent = '';
    if (!a.recommendations.length) {
      list.appendChild(sectionEmpty('Недостаточно данных для рекомендаций: нужна хотя бы основная кривая удержания.'));
      return;
    }
    const sevLabel = { critical: 'критично', serious: 'серьёзно', warning: 'внимание', good: 'работает' };
    for (const r of a.recommendations) {
      const body = el('div', { class: 'action-body' });
      body.appendChild(document.createTextNode(r.text));
      if (r.hypo) body.appendChild(el('span', { class: 'hypo', text: 'Гипотеза/ограничение: ' + r.hypo }));
      list.appendChild(el('li', null,
        el('span', { class: 'sev ' + r.sev, text: sevLabel[r.sev] }), body));
    }
  }

  function renderLimits(a) {
    const list = $('#limits-list');
    list.textContent = '';
    for (const item of a.limitations) {
      const li = el('li');
      li.appendChild(el('b', { text: item.strong + ' ' }));
      li.appendChild(document.createTextNode(item.text));
      list.appendChild(li);
    }
  }

  /* ---------- Загрузка файлов: кнопки и drag&drop ---------- */

  $('#btn-zip').addEventListener('click', () => $('#file-zip').click());
  $('#btn-csv').addEventListener('click', () => $('#file-csv').click());
  $('#file-zip').addEventListener('change', e => {
    if (e.target.files[0]) handleZipFile(e.target.files[0]);
    e.target.value = '';
  });
  $('#file-csv').addEventListener('change', e => {
    if (e.target.files.length) handleCsvFiles([...e.target.files]);
    e.target.value = '';
  });

  const dz = $('#dropzone');
  for (const evtName of ['dragover', 'dragenter']) {
    document.addEventListener(evtName, e => { e.preventDefault(); dz.classList.add('dragover'); });
  }
  for (const evtName of ['dragleave', 'drop']) {
    document.addEventListener(evtName, e => { e.preventDefault(); if (evtName === 'dragleave' && e.relatedTarget) return; dz.classList.remove('dragover'); });
  }
  document.addEventListener('drop', e => {
    e.preventDefault();
    const files = [...(e.dataTransfer?.files || [])];
    if (!files.length) return;
    const zip = files.find(f => /\.zip$/i.test(f.name));
    if (zip) handleZipFile(zip);
    else {
      const csvs = files.filter(f => /\.csv$/i.test(f.name));
      if (csvs.length) handleCsvFiles(csvs);
      else setStatus('Поддерживаются ZIP-архив из YouTube Studio или CSV-файлы из него.', true);
    }
  });

  $('#duration-input').addEventListener('change', e => {
    state.duration = parseDuration(e.target.value);
    if (e.target.value.trim() && state.duration == null) {
      setStatus('Длительность не распознана. Формат: «12:34», «1:02:03» или секунды числом.', true);
      return;
    }
    setStatus('', false);
    render();
  });

  /* ---------- Canvas slug-режим: авто-загрузка вложений проекта ----------
   * /retention/?slug=<slug> — дашборд сам тянет CSV/ZIP из секции «Аналитика»
   * Video Planning Canvas (canvas.json → analytics.files[]). Без slug — обычный
   * ручной режим. Ядро анализа не тронуто. */

  (async function initSlugMode() {
    const slug = new URLSearchParams(location.search).get('slug');
    if (!slug) return;
    try {
      setStatus('Загружаю вложения проекта ' + slug + '…', false);
      const resp = await fetch('/api/projects/' + encodeURIComponent(slug));
      if (!resp.ok) throw new Error('проект не найден в Canvas');
      const canvas = await resp.json();
      const an = (canvas.sections || []).find(s => s.type === 'analytics');
      const atts = (an && an.files) || [];
      const files = [];
      for (const f of atts) {
        const u = '/api/projects/' + encodeURIComponent(slug) + '/asset?p=' + encodeURIComponent(f.rel);
        if (/\.zip$/i.test(f.rel)) {
          const buf = await (await fetch(u)).arrayBuffer();
          const entries = (await readZipAny(buf)).filter(e =>
            /\.csv$/i.test(e.name) && !e.name.includes('__MACOSX'));
          for (const e of entries) files.push({ name: e.name.split('/').pop(), text: decodeBytes(e.bytes) });
        } else if (/\.(csv|tsv)$/i.test(f.rel)) {
          const buf = await (await fetch(u)).arrayBuffer();
          files.push({ name: f.name || f.rel.split('/').pop(), text: decodeBytes(new Uint8Array(buf)) });
        }
      }
      if (!files.length) {
        setStatus('В секции «Аналитика» проекта «' + (canvas.title || slug) + '» нет CSV/ZIP-вложений. Прикрепи экспорт из YouTube Studio в Canvas — или загрузи вручную ниже.', true);
        return;
      }
      document.title = 'Удержание — ' + (canvas.title || slug);
      loadFiles(files, (canvas.title || slug) + ' — из Canvas');
    } catch (err) {
      setStatus('Slug-режим: ' + err.message + '. Загрузи файлы вручную.', true);
    }
  })();

}
