# YouTube Retention Analyzer (local dashboard)

A reusable, browser-only tool that turns a YouTube Studio audience-retention
export (ZIP with CSV files) into a readable analysis dashboard for a single
video: retention curve, key checkpoints, sharpest drops, exit moments,
rewatched moments, cohort comparisons, and data-grounded recommendations.

The UI is in Russian. Everything runs locally in the browser — no server,
no Google API, no sign-in, no data leaves the machine.

## How to open

1. Open `index.html` in any modern browser (Chrome, Edge, Firefox, Safari).
   Double-clicking the file is enough — the tool works over `file://`.
2. Drag & drop the ZIP exported from YouTube Studio onto the page
   (or click **«Загрузить ZIP»**).
3. Optionally enter the video duration (**«Длительность ролика»**, e.g. `12:34`)
   to see approximate timecodes next to every position — the CSVs themselves
   only contain positions as percent of duration.

No build step, no dependencies to install. JSZip is referenced from a CDN as a
*fallback only*; the primary ZIP parser is built in (pure JS +
`DecompressionStream`), so the tool works fully offline.

### Where the ZIP comes from

YouTube Studio → Analytics → Advanced mode → **Audience retention**
(«Zuschauerbindung» in German UI) → **Export current view** → ZIP.

### If the ZIP won't open in the browser

Click **«CSV вручную»** and select several CSV files from the unpacked archive
(or drag & drop the CSV files directly). The analysis pipeline is identical;
any subset of files works — sections without data show an explicit
"no data / what's missing" note instead of failing.

## What it understands

German and English column headers, decimal commas, UTF-8 / windows-1252
content, ZIP entries whose filenames were stored without the UTF-8 flag
(the `Aktivit+ñten` mojibake case), quoted headers with embedded commas, and
empty report files (shown as «нет данных», not as an error). Recognition is
based on column structure, not on hardcoded filenames, so other exports of the
same type work too. Details in [REPORT.md](REPORT.md).

## Project layout

```
index.html          page skeleton (all sections, Russian UI)
assets/styles.css   dark "studio console" theme
assets/script.js    ZIP/CSV parsing, report detection, analysis, SVG charts
README.md           this file
REPORT.md           what was built, what is recognized, known limitations
```

The analysis core in `assets/script.js` (sections 1–5) is DOM-free and can be
required from Node for testing:

```js
const core = require('./assets/script.js');
core.detectReport('Alle.csv', csvText);
```
