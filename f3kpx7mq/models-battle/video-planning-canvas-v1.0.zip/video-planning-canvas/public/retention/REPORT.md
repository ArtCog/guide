# Build report — YouTube Retention Analyzer

Model: **Claude Fable 5**. Date: 2026-07-03.

## What was built

A local, reusable browser dashboard (plain HTML/CSS/JS, no build step) that
ingests a YouTube Studio audience-retention export and produces a single-video
analysis. All requirements from the task are implemented:

- ZIP upload (button + drag & drop) with a **built-in pure-JS ZIP parser**
  (central directory + `DecompressionStream('deflate-raw')`); JSZip from CDN is
  only a fallback path, so the tool works offline.
- **Manual CSV mode** («CSV вручную», multi-select + drag & drop) for cases
  where the ZIP cannot be unpacked in the browser. Any subset of files works.
- **File inventory panel**: every CSV with a human explanation of what it is,
  row count, and status — recognized / **«нет данных»** (empty files are a
  normal state, not an error) / not recognized.
- Overall **retention curve** (SVG, crosshair + tooltip, key-point markers,
  top body drops highlighted as red bands).
- **Key retention checkpoints**: 0, 1, 5, 10, 25, 50, 75, 90, 99 % of duration,
  with loss vs the previous checkpoint.
- **Sharpest drops** table. Drops inside the first 5 % are tagged as intro
  (universal behavior), drops at the last 2 positions as natural ending —
  neither is presented as a mid-video problem.
- **Exit moments** («Wiedergabe beendet» counts): bar chart + top table, with
  instant-bounce (position 0) and natural-end rows tagged separately.
- **Rewatched moments**: peaks of "times each moment was watched" vs the local
  median (±3 window, ≥3 % prominence, adjacent peaks merged).
- **Cohort comparisons** when the corresponding CSV exists: subscribers vs
  non-subscribers; new vs returning; new / casual / regular; organic vs paid
  traffic. Average gap and maximum-gap position are computed per cohort.
  Missing groups (e.g. "regular viewers" absent from the export) are reported
  explicitly.
- **Relative retention** ("compared to other videos") as a separate chart,
  labeled as the noisiest metric of the export.
- **«Что улучшить в следующем ролике»** — rule-based recommendations computed
  only from the numbers, ordered by severity; causal statements are impossible
  from CSV alone and are explicitly marked as hypotheses.
- **«Ограничения анализа»** — an honest, partly dynamic list (see below).
- Optional **video duration input** — the export has positions only as % of
  duration; entering `мм:сс` adds approximate timecodes everywhere.

## Which CSVs are recognized

Detection is **structure-based** (column headers + data shape), with filenames
used only as display hints — nothing is hardcoded to this particular archive.
German and English headers are supported.

| Report | Detected by |
|---|---|
| Overall retention (`Alle.csv` / `All`) | position + absolute retention columns |
| Retention with relative curve (`Organische Zugriffe`, ad reports) | + "Im Vergleich zu anderen Videos" / "compared" column |
| Detailed activity (`Aktivitäten im Detail`) | started / ended / "times each moment watched" columns |
| Grouped cohorts (subscribers, new/returning, loyalty, traffic) | a non-numeric group column; group values classified DE/EN |
| Empty reports (ad files with header only) | zero data rows → status «нет данных» |
| Anything else | status «не распознан» with a reason, never a crash |

Robustness: full CSV quoting (the activity header contains a comma inside
quotes), decimal commas (`12,5`), UTF-8 BOM, windows-1252 fallback when UTF-8
decoding produces replacement characters, ZIP filenames stored as UTF-8 bytes
without the UTF-8 flag (strict-UTF-8 attempt, then CP437), `__MACOSX` entries
skipped, empty cells kept as `null` (YouTube suppresses small counts) — never
replaced with zeros or random values.

## What was verified

- **Node test harness** (analysis core is DOM-free and importable): 39 checks
  against the real fixture ZIP — ZIP extraction and umlaut filename decoding,
  all 9 files classified correctly, key-point/drop/exit/rewatch/cohort numbers
  spot-checked against manually read CSV values, English-header variants,
  garbage CSV, empty CSV, minimal one-file input, duration parsing. All pass.
- **Headless Chrome** (puppeteer-core + real ZIP upload): full render with no
  JS errors — 9 file rows, 5 KPI tiles, 8 SVG charts, 4 cohort panels,
  10 recommendations, 9 limitations; crosshair + tooltip verified visually.
- **Fallback paths**: manual upload of a 2-file subset renders 6 explicit
  "what's missing" empty states; ZIP upload with CDN blocked (offline
  simulation) parses via the built-in parser.
- **Chart palette** validated with a CVD/contrast checker (3-series dark set:
  worst adjacent ΔE 15.7 ≥ 12 target, all series ≥3:1 on the dark surface);
  legends are always present for multi-series charts.

## Findings in the provided archive (youtube-retention-claude-openrouter.zip)

9 CSV files, German locale. 7 recognized with data, 2 ad reports empty
(no ad activity — shown as «нет данных»). Notable numbers:

- Retention at 1 % of duration: 72.4 % (−19.5 pp from the start), 51.5 % by
  5 % — a steep intro wall; by mid-video 34.1 %, at the end 9.5 %.
- Sharpest non-intro drops: 36→37 % (−3.1 pp, right after a rewatch peak) and
  20→21 % (−2.6 pp).
- Exit counts confirm the intro wall: positions 1–4 % dominate early exits
  (902 instant bounces at position 0).
- Rewatch peaks at ≈7 %, ≈23 %, ≈34 %, ≈66 % (the 7 % and 34 % peaks are also
  visible as rises of the retention curve itself).
- Non-subscribers retain ~9 pp better than subscribers on average; new viewers
  ~10–11 pp better than returning/casual ones.
- Relative retention in the mid-section is ≈+31 pp above similar videos —
  treated as a secondary signal (noisy metric).
- Missing from the export: "regular viewers" group, paid-traffic group.

## Limitations

- The CSVs contain **no video content, script, chapters or timestamps** — the
  tool states *where* retention changes, never *why*; cause-level statements
  are labeled hypotheses in the UI.
- Positions are **percent of duration**; real timecodes appear only if the
  user enters the duration manually (approximation, 1 % steps).
- No impressions/CTR/traffic-source data → no conclusions about packaging
  (title/thumbnail) or distribution.
- Average view depth is a curve-based estimate, not Studio's AVD/AVP.
- Suppressed small counts (empty cells) are excluded from rankings, not
  treated as zeros.
- Relative retention is noisy (especially in the tail) and is never used as
  the primary basis for a recommendation.
- ZIP64 archives are not supported by the built-in parser (irrelevant for
  these exports; JSZip fallback or manual CSV mode covers exotic cases).
