# RUN-METRICS — тест 04 «Анализатор удержания YouTube»

| Поле | Значение |
|---|---|
| Модель | Claude Fable 5 (`claude-fable-5`), Claude Code |
| Тест | 04 — локальный дашборд анализа ZIP/CSV из YouTube Studio |
| Время задачи | 8m 34s |
| Input tokens | 18.4k |
| Output tokens | 91.7k |
| Cache read | 4.2m |
| Cache write | 237.6k |
| Стоимость USD | $13.49 |
| Путь к index.html | `C:\Users\magme\TEST FABLE VS OPUS VS SONNET\04-youtube-retention-dashboard-fable-5\index.html` |
| Короткий вердикт | Реальный браузерный анализатор ZIP/CSV, не статичная страница: есть встроенный ZIP-парсер, ручная загрузка CSV, распознавание отчетов, графики, ограничения анализа и отчет по реальному архиву. |

**Источник метрик:** данные пользователя из вкладки `Usage` Claude Code после выполнения теста.
`8m 34s` — время выполнения именно четвертого задания, строка `Cogitated/Brewed for 8m 34s`.

**Важно по времени:** `Total duration (API): 1h 43m 55s` и `Total duration (wall): 1d 4h 26m`
не используются как время задачи. Это общие длительности сессии/ожидания, а не чистое время выполнения теста.

**Разбивка стоимости по скрину/статистике:** `claude-fable-5` — $58.41;
`claude-haiku-4-5` — $0.0099. Общая стоимость сессии: $58.42.

## Подход модели

Fable 5 сначала прочитала реальный ZIP, затем создала браузерный инструмент в
`index.html`, `assets/styles.css`, `assets/script.js`, `README.md` и `REPORT.md`.
В отчете указано, что она проверяла проект на реальном fixture ZIP, тестировала
ZIP-разбор, ручной CSV-режим, классификацию 9 CSV-файлов, рендер в headless Chrome
и отсутствие JS-ошибок.

## Проверка на «мухлеж»

По файлам не видно прямой подмены задачи статичным отчетом: итоговые числа из
архива зашиты только в `REPORT.md` как текстовый итог анализа, а не в основной
код дашборда. В `assets/script.js` есть реальные функции чтения ZIP, парсинга CSV,
распознавания типов отчетов и построения графиков. Названия конкретных CSV
используются в интерфейсных подсказках и состояниях «нет данных», но основное
распознавание заявлено и реализовано через структуру колонок.

Слабое место: тестовые скрипты, которыми модель проверяла работу, лежали во
временной папке scratchpad и не были сохранены в проект как воспроизводимый
набор тестов. Это не похоже на мухлеж, но снижает прозрачность проверки.

## Metric recalculation

Cost and token metrics above were recalculated on 2026-07-04 as per-test values, not cumulative `Usage` snapshots.

- Snapshot after this test: $58.42 / 66.2k input / 335.1k output / 17.2m cache read / 1.2m cache write.
- Previous checkpoint: $44.93 / 49.8k input / 243.4k output / 13.0m cache read / 962.4k cache write.
- Formula: `test = snapshot after test - previous checkpoint`.

- Token values include visible helper Haiku calls where the screenshots/reports exposed them.
