/* Shared progress calculation — used by both server.js (require) and browser (script tag).
 * A "unit" is any fillable thing; "done" = filled or explicitly checked. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CanvasProgress = factory();
})(typeof self !== 'undefined' ? self : this, function () {

  function filled(v) { return typeof v === 'string' && v.trim().length > 0; }

  function fieldUnits(fields) {
    var total = 0, done = 0;
    (fields || []).forEach(function (f) {
      total++;
      if (f.done === true || filled(f.value)) done++;
    });
    return [total, done];
  }

  function sectionProgress(s) {
    var total = 0, done = 0;
    function add(pair) { total += pair[0]; done += pair[1]; }

    add(fieldUnits(s.fields));

    (s.checklist || []).forEach(function (c) { total++; if (c.done) done++; });

    if (s.type === 'demand') {
      (s.layers || []).forEach(function (l) { total++; if (l.status && l.status !== 'none') done++; });
      (s.axes || []).forEach(function (a) { total++; if (a.pass === true || a.pass === false) done++; });
      total++; if (s.decision && filled(s.decision.value)) done++;
    }

    if (s.type === 'scriptmap') {
      var blocks = s.blocks || [];
      total++; if (blocks.length >= 3) done++; // карта считается начатой с 3+ блоков
      blocks.forEach(function (b) { total++; if (b.status === 'ready') done++; });
    }

    if (s.type === 'assets') {
      (s.items || []).forEach(function (it) { total++; if (it.status === 'ready') done++; });
    }

    if (s.type === 'analytics') {
      (s.waves || []).forEach(function (w) { add(fieldUnits(w.fields)); });
    }

    return { total: total, done: done };
  }

  function projectProgress(data) {
    var total = 0, done = 0;
    (data.sections || []).forEach(function (s) {
      var p = sectionProgress(s);
      total += p.total; done += p.done;
    });
    return { total: total, done: done, pct: total ? Math.round(done / total * 100) : 0 };
  }

  return { sectionProgress: sectionProgress, projectProgress: projectProgress };
});
