#!/usr/bin/env node
/* Video Planning Canvas — zero-dependency local server.
 * Serves the UI and stores each project's data as canvas.json
 * inside its canonical video folder: C:\Projects\Video\<slug>\canvas.json
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const progress = require('./public/progress.js');
const yt = require('./youtube.js');

const PORT = Number(process.env.CANVAS_PORT) || 7377;
const HOST = '127.0.0.1';
// Дом инструмента — C:\Projects\Tools\video-planning-canvas, а ДАННЫЕ роликов
// живут в C:\Projects\Video\<slug>\ (канон воркспейса). Переопределение — env CANVAS_VIDEO_DIR.
const VIDEO_DIR = process.env.CANVAS_VIDEO_DIR || path.join(__dirname, 'projects');
const PUB = path.join(__dirname, 'public');
const TEMPLATE_PATH = path.join(__dirname, 'template.json');
const IDEAS_DIR = path.join(VIDEO_DIR, '_ideas');          // idea inbox (pre-project)
const IDEAS_FILE = path.join(IDEAS_DIR, 'ideas.json');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.ttf': 'font/ttf',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
};

const SLUG_RE = /^[a-z0-9][a-z0-9-]{1,80}$/;

// ---------- helpers ----------

function send(res, code, body, type) {
  const buf = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': type || 'application/json; charset=utf-8' });
  res.end(buf);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 32 * 1024 * 1024) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch (e) { reject(new Error('invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function canvasPath(slug) {
  if (!SLUG_RE.test(slug)) return null;
  const p = path.join(VIDEO_DIR, slug, 'canvas.json');
  if (!p.startsWith(VIDEO_DIR)) return null;
  return p;
}

// Resolve a relative path under a base dir, refusing directory traversal.
function assetUnder(base, rel) {
  const p = path.normalize(path.join(base, String(rel || '')));
  if (p !== base && !p.startsWith(base + path.sep)) return null;
  return p;
}

function projectAsset(slug, rel) {
  if (!SLUG_RE.test(slug)) return null;
  return assetUnder(path.join(VIDEO_DIR, slug), rel);
}

// Decode a data-URL image into `dir`, return the generated filename.
function writeImage(dir, dataUrl) {
  const m = /^data:image\/(png|jpe?g|gif|webp);base64,([\s\S]+)$/i.exec(String(dataUrl || ''));
  if (!m) throw new Error('Ожидается data:image/* base64');
  const ext = m[1].toLowerCase() === 'jpeg' ? 'jpg' : m[1].toLowerCase();
  const buf = Buffer.from(m[2], 'base64');
  if (!buf.length) throw new Error('пустое изображение');
  fs.mkdirSync(dir, { recursive: true });
  const name = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7) + '.' + ext;
  fs.writeFileSync(path.join(dir, name), buf);
  return name;
}

function saveImage(slug, dataUrl) {
  return 'assets/canvas/' + writeImage(path.join(VIDEO_DIR, slug, 'assets', 'canvas'), dataUrl);
}

// Non-image attachments (analytics CSV/ZIP etc.). Extension whitelist, original
// name kept (sanitized) so YouTube Studio exports stay recognizable.
const ATTACH_EXT = new Set(['.csv', '.tsv', '.txt', '.json', '.md', '.zip']);

function saveAttachment(slug, name, dataUrl) {
  const m = /^data:[a-z0-9.+/-]+;base64,([\s\S]+)$/i.exec(String(dataUrl || ''));
  if (!m) throw new Error('Ожидается data-URL base64');
  const buf = Buffer.from(m[1], 'base64');
  if (!buf.length) throw new Error('пустой файл');
  const clean = String(name || 'file').replace(/[^\p{L}\p{N} ._()-]/gu, '_').slice(-80);
  const ext = path.extname(clean).toLowerCase();
  if (!ATTACH_EXT.has(ext)) throw new Error('Разрешены: ' + Array.from(ATTACH_EXT).join(' '));
  const dir = path.join(VIDEO_DIR, slug, 'assets', 'canvas');
  fs.mkdirSync(dir, { recursive: true });
  let fname = clean;
  if (fs.existsSync(path.join(dir, fname))) fname = Date.now().toString(36) + '-' + clean;
  fs.writeFileSync(path.join(dir, fname), buf);
  return 'assets/canvas/' + fname;
}

function loadTemplate() {
  return JSON.parse(fs.readFileSync(TEMPLATE_PATH, 'utf8'));
}

function listProjects() {
  const out = [];
  for (const d of fs.readdirSync(VIDEO_DIR, { withFileTypes: true })) {
    if (!d.isDirectory() && !d.isSymbolicLink()) continue;
    if (d.name.startsWith('_') || d.name.startsWith('.')) continue;
    const file = path.join(VIDEO_DIR, d.name, 'canvas.json');
    if (!fs.existsSync(file)) continue;
    try {
      const data = JSON.parse(fs.readFileSync(file, 'utf8'));
      out.push({
        slug: d.name,
        title: data.title || d.name,
        format: data.format || '',
        status: data.status || 'idea',
        updatedAt: data.updatedAt || '',
        progress: progress.projectProgress(data),
      });
    } catch (e) {
      out.push({ slug: d.name, title: d.name + ' (битый canvas.json)', status: 'error', progress: { pct: 0 } });
    }
  }
  out.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  return out;
}

// ---------- Markdown export ----------

function mdEscapeCell(s) { return String(s || '').replace(/\|/g, '\\|').replace(/\r?\n/g, '<br>'); }

function fieldsToMd(fields, lines) {
  for (const f of fields || []) {
    const mark = (f.done || (f.value || '').trim()) ? 'x' : ' ';
    lines.push(`- [${mark}] **${f.label}:** ${f.value ? f.value.trim() : '—'}`);
    for (const im of f.images || []) {
      lines.push(`  ![${(im.caption || '').replace(/[\[\]]/g, '')}](${im.rel})`);
    }
  }
}

function imagesToMd(owner, lines) {
  if (!(owner.images || []).length) return;
  lines.push('');
  for (const im of owner.images) lines.push(`![${(im.caption || '').replace(/[\[\]]/g, '')}](${im.rel})`);
}

function filesToMd(owner, lines) {
  if (!(owner.files || []).length) return;
  lines.push('');
  lines.push('**Вложения:**');
  for (const f of owner.files) lines.push(`- [${f.name || f.rel}](${f.rel})`);
}

function exportMarkdown(data) {
  const L = [];
  L.push(`# Canvas — ${data.title || data.slug}`);
  L.push('');
  L.push(`> Формат: ${data.format || '—'} · Статус: ${data.status} · Обновлено: ${data.updatedAt || '—'}`);
  L.push(`> Экспорт из Video Planning Canvas. Источник правды: \`${data.slug}/canvas.json\`.`);
  L.push('');
  for (const s of data.sections || []) {
    L.push(`## ${s.num || ''} ${s.title}`.trim());
    if (s.goal) L.push(`*${s.goal}*`);
    L.push('');

    if (s.type === 'demand') {
      L.push('### Слои проверки спроса');
      for (const l of s.layers || []) {
        const st = { none: '⬜ не проверено', weak: '🟡 слабый сигнал', strong: '🟢 сильный сигнал' }[l.status] || l.status;
        L.push(`- **${l.name}** — ${st}`);
        if ((l.links || '').trim()) L.push(`  - Ссылки: ${l.links.trim()}`);
        if ((l.notes || '').trim()) L.push(`  - Наблюдения: ${l.notes.trim()}`);
        if ((l.proves || '').trim()) L.push(`  - Что доказывает: ${l.proves.trim()}`);
      }
      L.push('');
      L.push('### Матрица отбора (правило 4 из 6)');
      L.push('| Ось | Вопрос | Вердикт |');
      L.push('|---|---|---|');
      let passes = 0;
      for (const a of s.axes || []) {
        const v = a.pass === true ? '✅' : a.pass === false ? '❌' : '—';
        if (a.pass === true) passes++;
        L.push(`| ${a.name} | ${mdEscapeCell(a.question)} | ${v} |`);
      }
      L.push('');
      L.push(`**Итог: ${passes}/6.** ${passes >= 4 ? 'Можно готовить ролик.' : 'Отложить или переформулировать.'}`);
      if (s.decision && (s.decision.value || s.decision.comment)) {
        L.push(`**Решение:** ${s.decision.value || '—'}${s.decision.comment ? ' — ' + s.decision.comment : ''}`);
      }
      L.push('');
    }

    if (s.type === 'scriptmap') {
      L.push('| Время | Блок | Цель | Что говорю | Что на экране | Зритель получил | Петля | Статус |');
      L.push('|---|---|---|---|---|---|---|---|');
      for (const b of s.blocks || []) {
        L.push(`| ${mdEscapeCell(b.time)} | ${mdEscapeCell(b.title)} | ${mdEscapeCell(b.goal)} | ${mdEscapeCell(b.say)} | ${mdEscapeCell(b.show)} | ${mdEscapeCell(b.payoff)} | ${mdEscapeCell(b.loops)} | ${b.status === 'ready' ? '✅' : '…'} |`);
      }
      L.push('');
    }

    if (s.type === 'assets') {
      if ((s.folder || '').trim()) L.push(`**Папка материалов:** \`${s.folder.trim()}\`\n`);
      if ((s.items || []).length) {
        L.push('| Материал | Путь/ссылка | Статус |');
        L.push('|---|---|---|');
        for (const it of s.items || []) {
          const loc = [it.path, it.link].filter(Boolean).join(' · ');
          L.push(`| ${mdEscapeCell(it.name)} | ${mdEscapeCell(loc)} | ${it.status === 'ready' ? '✅' : '…'} |`);
        }
        L.push('');
      }
    }

    if (s.type === 'filming') {
      const map = (data.sections || []).find(x => x.type === 'scriptmap');
      const recs = s.records || {};
      if (map && (map.blocks || []).length) {
        L.push('**Блоки на запись (из Сценарной карты):**');
        for (const b of map.blocks) {
          const r = recs[b.id] || {};
          const st = { done: '✅ снято', retake: '🔁 переснять' }[r.status] || '⬜ не снято';
          L.push(`- ${st} — ${b.time || ''} ${b.title || 'без названия'}${r.note ? ' · ' + r.note : ''}`);
        }
        L.push('');
      }
    }

    if (s.type === 'analytics') {
      for (const w of s.waves || []) {
        L.push(`### ${w.label}${w.date ? ' (' + w.date + ')' : ''}`);
        fieldsToMd(w.fields, L);
        L.push('');
      }
    }

    if (s.fields && s.fields.length) fieldsToMd(s.fields, L);

    if (s.checklist && s.checklist.length) {
      L.push('');
      L.push('**Чеклист:**');
      for (const c of s.checklist) L.push(`- [${c.done ? 'x' : ' '}] ${c.text}`);
    }
    imagesToMd(s, L);
    filesToMd(s, L);
    L.push('');
  }
  return L.join('\n');
}

// ---------- routes ----------

async function handleApi(req, res, url) {
  const parts = url.pathname.split('/').filter(Boolean); // ['api', ...]

  // GET /api/projects
  if (req.method === 'GET' && url.pathname === '/api/projects') {
    return send(res, 200, listProjects());
  }

  // ---- idea inbox (pre-project): _ideas/ideas.json + _ideas/assets/ ----
  if (url.pathname === '/api/ideas' && req.method === 'GET') {
    let arr = [];
    try { if (fs.existsSync(IDEAS_FILE)) arr = JSON.parse(fs.readFileSync(IDEAS_FILE, 'utf8')); } catch (e) {}
    return send(res, 200, Array.isArray(arr) ? arr : []);
  }
  if (url.pathname === '/api/ideas' && req.method === 'PUT') {
    const arr = await readBody(req);
    fs.mkdirSync(IDEAS_DIR, { recursive: true });
    const tmp = IDEAS_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(Array.isArray(arr) ? arr : [], null, 2), 'utf8');
    fs.renameSync(tmp, IDEAS_FILE);
    return send(res, 200, { ok: true });
  }
  if (url.pathname === '/api/ideas/image' && req.method === 'POST') {
    const body = await readBody(req);
    return send(res, 201, { rel: 'assets/' + writeImage(path.join(IDEAS_DIR, 'assets'), body.dataUrl) });
  }
  if (url.pathname === '/api/ideas/asset' && req.method === 'GET') {
    const p = assetUnder(IDEAS_DIR, url.searchParams.get('p'));
    if (!p || !fs.existsSync(p) || !fs.statSync(p).isFile()) return send(res, 404, 'not found', 'text/plain');
    return send(res, 200, fs.readFileSync(p), MIME[path.extname(p).toLowerCase()] || 'application/octet-stream');
  }

  // POST /api/projects  {slug, title}
  if (req.method === 'POST' && url.pathname === '/api/projects') {
    const body = await readBody(req);
    const slug = String(body.slug || '').trim();
    const file = canvasPath(slug);
    if (!file) return send(res, 400, { error: 'Некорректный slug. Формат: 2026-kebab-name (a-z, 0-9, дефисы).' });
    if (fs.existsSync(file)) return send(res, 409, { error: 'У этого проекта уже есть canvas.json.' });
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const data = loadTemplate();
    data.slug = slug;
    data.title = String(body.title || slug).trim();
    data.format = String(body.format || '').trim();
    data.status = 'idea';
    data.createdAt = new Date().toISOString();
    data.updatedAt = data.createdAt;
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    return send(res, 201, data);
  }

  // /api/projects/:slug[/export]
  if (parts[0] === 'api' && parts[1] === 'projects' && parts[2]) {
    const slug = parts[2];
    const file = canvasPath(slug);
    if (!file) return send(res, 400, { error: 'bad slug' });

    if (req.method === 'GET' && parts.length === 3) {
      if (!fs.existsSync(file)) return send(res, 404, { error: 'not found' });
      return send(res, 200, fs.readFileSync(file, 'utf8'), 'application/json; charset=utf-8');
    }

    if (req.method === 'PUT' && parts.length === 3) {
      const data = await readBody(req);
      data.slug = slug;
      data.updatedAt = new Date().toISOString();
      const tmp = file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
      fs.renameSync(tmp, file);
      // Auto-export: agents read CANVAS.md as the always-fresh roadmap.
      // Never fail the save because of an export hiccup.
      try {
        fs.writeFileSync(path.join(VIDEO_DIR, slug, 'CANVAS.md'), exportMarkdown(data), 'utf8');
      } catch (e) { console.error('auto-export failed:', e.message); }
      return send(res, 200, { ok: true, updatedAt: data.updatedAt });
    }

    // DELETE /api/projects/:slug — remove ONLY planning data (canvas.json,
    // CANVAS.md, assets/canvas/). Never touch raw/work/renders or other docs.
    // If the whole folder ends up empty, drop the empty folder too.
    if (req.method === 'DELETE' && parts.length === 3) {
      if (!fs.existsSync(file)) return send(res, 404, { error: 'not found' });
      const dir = path.dirname(file);
      fs.unlinkSync(file);
      const rm = (p) => { try { if (fs.existsSync(p)) fs.rmSync(p, { recursive: true, force: true }); } catch (e) {} };
      rm(path.join(dir, 'CANVAS.md'));
      rm(path.join(dir, 'assets', 'canvas'));
      try {
        const assetsDir = path.join(dir, 'assets');
        if (fs.existsSync(assetsDir) && fs.readdirSync(assetsDir).length === 0) fs.rmdirSync(assetsDir);
      } catch (e) {}
      let removedFolder = false;
      try { if (fs.readdirSync(dir).length === 0) { fs.rmdirSync(dir); removedFolder = true; } } catch (e) {}
      return send(res, 200, { ok: true, removedFolder });
    }

    // POST /api/projects/:slug/duplicate {slug, title} — новый проект с той же
    // структурой (серии роликов): тексты и кастомные поля сохраняются, а всё
    // «прожитое» сбрасывается — статусы, чеклисты, аналитика, картинки/вложения
    // (они принадлежат папке старого ролика).
    if (req.method === 'POST' && parts[3] === 'duplicate') {
      if (!fs.existsSync(file)) return send(res, 404, { error: 'not found' });
      const body = await readBody(req);
      const newSlug = String(body.slug || '').trim();
      const target = canvasPath(newSlug);
      if (!target) return send(res, 400, { error: 'Некорректный slug. Формат: 2026-kebab-name.' });
      if (fs.existsSync(target)) return send(res, 409, { error: 'У проекта ' + newSlug + ' уже есть canvas.json.' });
      const data = JSON.parse(fs.readFileSync(file, 'utf8'));
      data.slug = newSlug;
      data.title = String(body.title || data.title + ' (серия)').trim();
      data.status = 'idea';
      data.createdAt = data.updatedAt = new Date().toISOString();
      for (const s of data.sections || []) {
        if (s.images) s.images = [];
        if (s.files) s.files = [];
        if (s.records) s.records = {};
        if (s.folder !== undefined) s.folder = '';
        for (const f of s.fields || []) { f.done = false; if (f.images) f.images = []; }
        for (const c of s.checklist || []) c.done = false;
        for (const b of s.blocks || []) b.status = 'idea';
        for (const it of s.items || []) it.status = 'todo';
        for (const l of s.layers || []) l.status = 'none';
        for (const a of s.axes || []) a.pass = null;
        if (s.decision) s.decision = { value: '', comment: '' };
        for (const w of s.waves || []) { w.date = ''; for (const f of w.fields || []) { f.value = ''; f.done = false; } }
        if (s.id === 'analytics') for (const f of s.fields || []) f.value = '';
      }
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, JSON.stringify(data, null, 2), 'utf8');
      return send(res, 201, data);
    }

    // POST /api/projects/:slug/image  {dataUrl} → saves file, returns {rel}
    if (req.method === 'POST' && parts[3] === 'image') {
      const body = await readBody(req);
      const rel = saveImage(slug, body.dataUrl);
      return send(res, 201, { rel });
    }

    // POST /api/projects/:slug/file  {name, dataUrl} → non-image attachment (CSV/ZIP…)
    if (req.method === 'POST' && parts[3] === 'file') {
      const body = await readBody(req);
      const rel = saveAttachment(slug, body.name, body.dataUrl);
      return send(res, 201, { rel, name: path.basename(rel) });
    }

    // GET /api/projects/:slug/asset?p=assets/canvas/xxx.png → serves the image
    if (req.method === 'GET' && parts[3] === 'asset') {
      const p = projectAsset(slug, url.searchParams.get('p'));
      if (!p || !fs.existsSync(p) || !fs.statSync(p).isFile()) return send(res, 404, 'not found', 'text/plain');
      return send(res, 200, fs.readFileSync(p), MIME[path.extname(p).toLowerCase()] || 'application/octet-stream');
    }

    if (req.method === 'POST' && parts[3] === 'export') {
      if (!fs.existsSync(file)) return send(res, 404, { error: 'not found' });
      const data = JSON.parse(fs.readFileSync(file, 'utf8'));
      const md = exportMarkdown(data);
      const out = path.join(VIDEO_DIR, slug, 'CANVAS.md');
      fs.writeFileSync(out, md, 'utf8');
      return send(res, 200, { ok: true, path: out });
    }
  }

  // POST /api/open {path} — open a local file/folder or URL in its default app.
  // Folders go through explorer.exe directly (cmd `start` is unreliable for dirs);
  // files and URLs go through `start` so the OS picks the default handler.
  if (req.method === 'POST' && url.pathname === '/api/open') {
    const body = await readBody(req);
    const target = String(body.path || '').trim();
    if (!target) return send(res, 400, { error: 'empty path' });
    const isUrl = /^https?:\/\//i.test(target);
    if (!isUrl && !fs.existsSync(target)) return send(res, 404, { error: 'Путь не существует: ' + target });
    const isDir = !isUrl && fs.statSync(target).isDirectory();
    if (isDir) {
      execFile('explorer.exe', [target], { windowsHide: true }, () => {}); // explorer returns 1 even on success — ignored
    } else {
      execFile('cmd', ['/c', 'start', '', target], { windowsHide: true }, () => {});
    }
    return send(res, 200, { ok: true });
  }

  // GET /api/browse?path=C:\... — read-only listing of a local folder (1 level)
  // for the «Папка материалов» inline preview. Opening files goes via /api/open.
  if (req.method === 'GET' && url.pathname === '/api/browse') {
    const p = String(url.searchParams.get('path') || '').trim();
    if (!p) return send(res, 400, { error: 'empty path' });
    if (!fs.existsSync(p)) return send(res, 404, { error: 'Путь не существует: ' + p });
    if (!fs.statSync(p).isDirectory()) return send(res, 400, { error: 'Это не папка: ' + p });
    const out = [];
    for (const d of fs.readdirSync(p, { withFileTypes: true }).slice(0, 200)) {
      try {
        const st = fs.statSync(path.join(p, d.name));
        out.push({ name: d.name, dir: d.isDirectory(), size: st.size, mtime: st.mtimeMs });
      } catch (e) { /* locked file — skip */ }
    }
    out.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name, 'ru'));
    return send(res, 200, out);
  }

  // GET /api/config — клиенту нужен реальный путь к папке проектов (для кнопки
  // «Папка», промпта агенту и placeholder'ов); в публичной сборке он другой.
  if (req.method === 'GET' && url.pathname === '/api/config') {
    return send(res, 200, { videoDir: VIDEO_DIR });
  }

  // GET /api/template
  if (req.method === 'GET' && url.pathname === '/api/template') {
    return send(res, 200, fs.readFileSync(TEMPLATE_PATH, 'utf8'), 'application/json; charset=utf-8');
  }

  // ---- YouTube API (фаза 2) ----
  if (req.method === 'GET' && url.pathname === '/api/yt/status') {
    return send(res, 200, yt.status());
  }
  if (req.method === 'GET' && url.pathname === '/api/yt/auth') {
    const u = yt.authUrl(); // бросит понятную ошибку, если нет yt-client.json
    execFile('cmd', ['/c', 'start', '', u.replace(/&/g, '^&')], { windowsHide: true }, () => {});
    return send(res, 200, { url: u });
  }
  if (req.method === 'POST' && url.pathname === '/api/yt/pull') {
    const body = await readBody(req);
    const st = yt.status();
    // приоритет: OAuth (полная аналитика) → API-ключ (публичная статистика) → инструкция
    if (!st.authorized && st.configured) return send(res, 200, { needAuth: true });
    if (!st.authorized && !st.hasKey) {
      return send(res, 400, { error: 'Нет ни OAuth, ни API-ключа. Открой Tools\\video-planning-canvas\\YOUTUBE-API-SETUP.md — настройка ~10 минут.' });
    }
    const slug = String(body.slug || '');
    const file = canvasPath(slug);
    if (!file || !fs.existsSync(file)) return send(res, 404, { error: 'проект не найден' });
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    const an = (data.sections || []).find(x => x.type === 'analytics');
    if (!an) return send(res, 400, { error: 'в проекте нет секции Аналитика' });
    const urlField = (an.fields || []).find(f => f.id === 'video_url');
    const videoId = yt.parseVideoId(body.videoUrl || (urlField && urlField.value));
    if (!videoId) return send(res, 400, { error: 'Заполни поле «Ссылка на опубликованный ролик» в секции Аналитика (URL или ID).' });

    const pulled = await yt.pull(videoId);
    const summary = applyYtPull(data, an, pulled, slug);
    data.updatedAt = new Date().toISOString();
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    try { fs.writeFileSync(path.join(VIDEO_DIR, slug, 'CANVAS.md'), exportMarkdown(data), 'utf8'); } catch (e) {}
    return send(res, 200, summary);
  }

  return send(res, 404, { error: 'unknown api route' });
}

// ---------- YouTube pull → заполнение волн аналитики ----------

const TRAFFIC_RU = {
  SUBSCRIBER: 'подписки/лента', RELATED_VIDEO: 'suggested', YT_SEARCH: 'поиск',
  BROWSE: 'browse (главная)', EXT_URL: 'внешние ссылки', NOTIFICATION: 'уведомления',
  PLAYLIST: 'плейлисты', SHORTS: 'shorts', NO_LINK_OTHER: 'прочее',
};

function setIfEmpty(fields, id, value) {
  const f = (fields || []).find(x => x.id === id);
  if (!f || !value) return false;
  if ((f.value || '').trim()) return false; // ручные записи не трогаем
  f.value = value;
  return true;
}

function applyYtPull(data, an, p, slug) {
  const today = new Date().toISOString().slice(0, 10);
  const days = (Date.now() - Date.parse(p.video.publishedAt)) / 86400000;
  const stamp = `(YouTube API, ${today})`;
  const filled = [];
  const wave = (id) => (an.waves || []).find(w => w.id === id);

  const t = p.totals;
  const trafficStr = p.traffic
    .map(r => (TRAFFIC_RU[r.insightTrafficSourceType] || r.insightTrafficSourceType) + ': ' + r.views)
    .join(' · ');

  const w24 = wave('w24');
  if (w24 && days >= 0.5) {
    if (!w24.date) w24.date = today;
    const views = t.views ?? p.video.stats.viewCount;
    const watch = t.estimatedMinutesWatched != null ? ` · ${t.estimatedMinutesWatched} мин watch time` : '';
    if (setIfEmpty(w24.fields, 'velocity', views != null ? `${views} просмотров${watch} ${stamp}` : '')) filled.push('velocity');
    if (setIfEmpty(w24.fields, 'sources', trafficStr && trafficStr + ' ' + stamp)) filled.push('sources');
    if (setIfEmpty(w24.fields, 'comments', `${p.video.stats.commentCount ?? t.comments ?? '?'} комментариев · ${p.video.stats.likeCount ?? '?'} лайков ${stamp}`)) filled.push('comments');
  }

  const w72 = wave('w72');
  if (w72 && days >= 2) {
    if (!w72.date) w72.date = today;
    if (t.averageViewDuration != null
      && setIfEmpty(w72.fields, 'avd', `AVD ${t.averageViewDuration} сек · AVP ${t.averageViewPercentage}% ${stamp}`)) filled.push('avd');
    // intro retention ≈ audienceWatchRatio в точке 30 сек
    if (p.retention.length && p.video.durationSec) {
      const ratio30 = Math.min(1, 30 / p.video.durationSec);
      const row = p.retention.reduce((best, r) =>
        Math.abs(r.elapsedVideoTimeRatio - ratio30) < Math.abs(best.elapsedVideoTimeRatio - ratio30) ? r : best);
      const pct = Math.round(row.audienceWatchRatio * 100);
      if (setIfEmpty(w72.fields, 'intro', `≈${pct}% на 30 сек ${stamp} — бенчмарк ≥55%`)) filled.push('intro');
    }
    if (t.subscribersGained != null
      && setIfEmpty(w72.fields, 'endscreen', `подписок с видео: ${t.subscribersGained} ${stamp}`)) filled.push('endscreen');
  }

  const w7d = wave('w7d');
  if (w7d && days >= 6) {
    if (!w7d.date) w7d.date = today;
    if (p.retention.length) {
      const avgRel = p.retention.reduce((s, r) => s + (r.relativeRetentionPerformance || 0), 0) / p.retention.length;
      if (setIfEmpty(w7d.fields, 'median', `relativeRetentionPerformance в среднем ${avgRel.toFixed(2)} (>0.5 = выше медианы) ${stamp}`)) filled.push('median');
    }
  }

  // кривая удержания → CSV, который понимает /retention-дашборд
  let retentionCsv = false;
  if (p.retention.length) {
    const L = ['Video position (%),Absolute audience retention (%),Relative retention performance'];
    for (const r of p.retention) {
      L.push(`${Math.round(r.elapsedVideoTimeRatio * 100)},${(r.audienceWatchRatio * 100).toFixed(2)},${(r.relativeRetentionPerformance ?? '')}`);
    }
    const dir = path.join(VIDEO_DIR, slug, 'assets', 'canvas');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'api-retention.csv'), L.join('\n'), 'utf8');
    an.files = an.files || [];
    if (!an.files.some(f => f.rel === 'assets/canvas/api-retention.csv')) {
      an.files.push({ name: 'api-retention.csv', rel: 'assets/canvas/api-retention.csv' });
    }
    retentionCsv = true;
  }

  return {
    ok: true,
    mode: p.mode,
    video: p.video.title,
    ageDays: Math.floor(days * 10) / 10,
    filled,
    retentionCsv,
    note: p.mode === 'key'
      ? 'Режим API-ключа: только публичная статистика. Удержание/AVD/источники появятся после OAuth (YOUTUBE-API-SETUP.md).'
      : (filled.length ? undefined : 'Все поля волн уже заполнены вручную — ничего не перезаписано.'),
  };
}

function serveStatic(req, res, url) {
  let rel = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
  let file = path.normalize(path.join(PUB, decodeURIComponent(rel)));
  if (!file.startsWith(PUB) || !fs.existsSync(file)) {
    return send(res, 404, 'not found', 'text/plain; charset=utf-8');
  }
  // directory: redirect to trailing slash so relative asset paths resolve,
  // then serve its index.html
  if (fs.statSync(file).isDirectory()) {
    if (!url.pathname.endsWith('/')) {
      res.writeHead(302, { Location: url.pathname + '/' + url.search });
      return res.end();
    }
    file = path.join(file, 'index.html');
    if (!fs.existsSync(file)) return send(res, 404, 'not found', 'text/plain; charset=utf-8');
  }
  send(res, 200, fs.readFileSync(file), MIME[path.extname(file).toLowerCase()] || 'application/octet-stream');
}

fs.mkdirSync(VIDEO_DIR, { recursive: true });

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname === '/oauth2/callback') {
      // возврат из Google после согласия
      const code = url.searchParams.get('code');
      if (!code) return send(res, 400, 'Нет кода авторизации: ' + (url.searchParams.get('error') || '?'), 'text/plain; charset=utf-8');
      await yt.exchangeCode(code);
      return send(res, 200,
        '<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif;background:#0B0F0E;color:#E8EDEB;display:grid;place-items:center;height:100vh">'
        + '<div style="text-align:center"><h2 style="color:#3CE5B0">YouTube подключён ✓</h2>'
        + '<p>Вкладку можно закрыть. Вернись в Canvas и нажми «Подтянуть из YouTube» ещё раз.</p></div>',
        'text/html; charset=utf-8');
    }
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (e) {
    send(res, 500, { error: String(e.message || e) });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Video Planning Canvas → http://localhost:${PORT}`);
  console.log(`Projects dir: ${VIDEO_DIR}\\<slug>\\canvas.json`);
});
