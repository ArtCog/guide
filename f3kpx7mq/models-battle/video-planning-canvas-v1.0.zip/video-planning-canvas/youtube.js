'use strict';
/* YouTube Data + Analytics API — zero-dependency OAuth2 (loopback flow).
 * Secrets live in _canvas/.secrets/ (never committed):
 *   yt-client.json — OAuth client (downloaded from Google Cloud, "Desktop app")
 *   yt.json        — tokens (created automatically after consent)
 * Setup guide for Artur: YOUTUBE-API-SETUP.md
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const SECRETS = path.join(__dirname, '.secrets');
const CLIENT_FILE = path.join(SECRETS, 'yt-client.json');
const TOKEN_FILE = path.join(SECRETS, 'yt.json');
const KEY_FILE = path.join(SECRETS, 'yt-key.txt'); // простой API-ключ (публичная Data API)
const REDIRECT = 'http://127.0.0.1:7377/oauth2/callback';
const SCOPES = [
  'https://www.googleapis.com/auth/yt-analytics.readonly',
  'https://www.googleapis.com/auth/youtube.readonly',
].join(' ');

function loadClient() {
  if (!fs.existsSync(CLIENT_FILE)) return null;
  try {
    const j = JSON.parse(fs.readFileSync(CLIENT_FILE, 'utf8'));
    const c = j.installed || j.web || j; // accept raw or Google-downloaded format
    return c.client_id && c.client_secret ? c : null;
  } catch (e) { return null; }
}

function loadToken() {
  try { return JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8')); } catch (e) { return null; }
}

function saveToken(t) {
  fs.mkdirSync(SECRETS, { recursive: true });
  fs.writeFileSync(TOKEN_FILE, JSON.stringify(t, null, 2), 'utf8');
}

function form(o) {
  return Object.entries(o).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
}

function request(method, urlStr, opts = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const req = https.request(
      { method, hostname: u.hostname, path: u.pathname + u.search, headers: opts.headers || {} },
      (res) => {
        let d = '';
        res.on('data', (c) => { d += c; });
        res.on('end', () => {
          let j = null;
          try { j = JSON.parse(d); } catch (e) { /* non-JSON */ }
          if (res.statusCode >= 200 && res.statusCode < 300) return resolve(j != null ? j : d);
          const msg = (j && j.error && (j.error_description || j.error.message || String(j.error)))
            || ('HTTP ' + res.statusCode + ': ' + d.slice(0, 200));
          reject(new Error(msg));
        });
      }
    );
    req.on('error', reject);
    if (opts.body) req.write(opts.body);
    req.end();
  });
}

function loadKey() {
  try { return fs.readFileSync(KEY_FILE, 'utf8').trim() || null; } catch (e) { return null; }
}

function status() {
  const t = loadToken();
  return { configured: !!loadClient(), authorized: !!(t && t.refresh_token), hasKey: !!loadKey() };
}

function authUrl() {
  const c = loadClient();
  if (!c) throw new Error('Нет _canvas\\.secrets\\yt-client.json — открой YOUTUBE-API-SETUP.md');
  return 'https://accounts.google.com/o/oauth2/v2/auth?' + form({
    client_id: c.client_id,
    redirect_uri: REDIRECT,
    response_type: 'code',
    scope: SCOPES,
    access_type: 'offline',
    prompt: 'consent',
  });
}

async function exchangeCode(code) {
  const c = loadClient();
  const t = await request('POST', 'https://oauth2.googleapis.com/token', {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form({
      code, client_id: c.client_id, client_secret: c.client_secret,
      redirect_uri: REDIRECT, grant_type: 'authorization_code',
    }),
  });
  t.expiry = Date.now() + (t.expires_in || 3600) * 1000;
  const old = loadToken();
  if (old && old.refresh_token && !t.refresh_token) t.refresh_token = old.refresh_token;
  saveToken(t);
  return t;
}

async function accessToken() {
  let t = loadToken();
  if (!t || !t.refresh_token) throw new Error('YouTube не подключён — нажми «Подключить YouTube»');
  if (!t.access_token || Date.now() > (t.expiry || 0) - 60000) {
    const c = loadClient();
    const r = await request('POST', 'https://oauth2.googleapis.com/token', {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form({
        refresh_token: t.refresh_token, client_id: c.client_id,
        client_secret: c.client_secret, grant_type: 'refresh_token',
      }),
    });
    t = Object.assign({}, t, r, { expiry: Date.now() + (r.expires_in || 3600) * 1000 });
    saveToken(t);
  }
  return t.access_token;
}

function parseVideoId(s) {
  s = String(s || '').trim();
  if (!s) return null;
  const m = s.match(/(?:v=|youtu\.be\/|shorts\/|live\/)([\w-]{11})/);
  if (m) return m[1];
  if (/^[\w-]{11}$/.test(s)) return s;
  return null;
}

// ISO8601 duration (PT#H#M#S) → seconds
function parseDuration(iso) {
  const m = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(iso || '');
  if (!m) return null;
  return (+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0);
}

async function apiGet(urlStr) {
  const tok = await accessToken();
  return request('GET', urlStr, { headers: { Authorization: 'Bearer ' + tok } });
}

// rows+columnHeaders → [{name: value, …}]
function rowsToObjects(report) {
  if (!report || !report.rows) return [];
  const names = (report.columnHeaders || []).map((h) => h.name);
  return report.rows.map((r) => {
    const o = {};
    names.forEach((n, i) => { o[n] = r[i]; });
    return o;
  });
}

async function pull(videoId) {
  // Два режима: OAuth (полная аналитика канала) или простой API-ключ
  // (только публичная статистика — просмотры/лайки/комментарии).
  const st = status();
  const dataUrl = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=' + videoId;
  const v = st.authorized
    ? await apiGet(dataUrl)
    : await request('GET', dataUrl + '&key=' + loadKey());
  if (!v.items || !v.items.length) throw new Error('Видео не найдено: ' + videoId);
  const it = v.items[0];

  let totals = {}, traffic = [], retention = [];
  if (st.authorized) {
    const published = it.snippet.publishedAt.slice(0, 10);
    const today = new Date().toISOString().slice(0, 10);
    const base = 'https://youtubeanalytics.googleapis.com/v2/reports?ids=channel%3D%3DMINE'
      + '&startDate=' + published + '&endDate=' + today + '&filters=video%3D%3D' + videoId;

    totals = rowsToObjects(await apiGet(base + '&metrics='
      + encodeURIComponent('views,estimatedMinutesWatched,averageViewDuration,averageViewPercentage,subscribersGained,likes,comments')))[0] || {};

    try {
      traffic = rowsToObjects(await apiGet(base + '&dimensions=insightTrafficSourceType&metrics=views&sort=-views&maxResults=10'));
    } catch (e) { /* необязательный отчёт */ }

    try {
      retention = rowsToObjects(await apiGet(base + '&dimensions=elapsedVideoTimeRatio&metrics='
        + encodeURIComponent('audienceWatchRatio,relativeRetentionPerformance')));
    } catch (e) { /* кривая доступна не сразу после публикации */ }
  }

  return {
    mode: st.authorized ? 'oauth' : 'key',
    video: {
      id: videoId,
      title: it.snippet.title,
      publishedAt: it.snippet.publishedAt,
      durationSec: parseDuration(it.contentDetails.duration),
      stats: it.statistics || {},
    },
    totals, traffic, retention,
  };
}

module.exports = { status, authUrl, exchangeCode, pull, parseVideoId };
