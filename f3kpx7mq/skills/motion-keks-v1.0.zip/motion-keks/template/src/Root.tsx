import {Composition} from 'remotion';
import {Demo} from './videos/demo/Demo';

// One <Composition> per video. Duration = voice length + ~0.5 s, in frames.
export const Root = () => (
	<>
		<Composition id="demo" component={Demo} durationInFrames={150} fps={30} width={1920} height={1080} />
	</>
);
