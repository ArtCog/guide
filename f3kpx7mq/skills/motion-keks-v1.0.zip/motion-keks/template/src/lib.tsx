import type {CSSProperties, ReactNode} from 'react';
import {AbsoluteFill, Audio, getInputProps, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

export type Word = {word: string; start: number; end: number};

/** The voice track. Left out when the sound is rendered for mix.py (--props '{"fxOnly":true}'). */
export const Voice = ({src}: {src: string}) => (getInputProps().fxOnly ? null : <Audio src={staticFile(src)} />);

const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

/** Frame where the nth word starting with `needle` is spoken (from words.json). */
export const wordFrame = (words: Word[], needle: string, fps: number, nth = 0): number => {
	const hits = words.filter((w) => norm(w.word).startsWith(norm(needle)));
	const hit = hits[nth];
	if (!hit) throw new Error(`word "${needle}" #${nth} not in words.json`);
	return Math.round(hit.start * fps);
};

/** 0 → 1 spring that starts at frame `at`. */
export const useAppear = (at: number, damping = 14): number => {
	const frame = useCurrentFrame();
	const {fps} = useVideoConfig();
	return spring({frame: frame - at, fps, config: {damping}});
};

/** A cut-out AI image: pops in at `at`, then floats gently so it never stands still. */
export const Cutout = (p: {src: string; at: number; x: number; y: number; width: number; style?: CSSProperties}) => {
	const frame = useCurrentFrame();
	const k = useAppear(p.at);
	const float = Math.sin((frame - p.at) / 22) * 6;
	return (
		<Img
			src={staticFile(p.src)}
			style={{
				position: 'absolute', left: p.x, top: p.y + float, width: p.width,
				transform: `translate(-50%, -50%) scale(${0.6 + 0.4 * k}) rotate(${(1 - k) * -8}deg)`,
				opacity: k, filter: 'drop-shadow(0 30px 40px rgba(0,0,0,0.35))', ...p.style,
			}}
		/>
	);
};

/** Background that keeps moving: two slow drifting glows over a base colour. */
export const Backdrop = (p: {base: string; glowA: string; glowB: string; children?: ReactNode}) => {
	const frame = useCurrentFrame();
	const ax = interpolate(Math.sin(frame / 90), [-1, 1], [20, 45]);
	const bx = interpolate(Math.cos(frame / 110), [-1, 1], [55, 85]);
	return (
		<AbsoluteFill style={{background: `radial-gradient(circle at ${ax}% 30%, ${p.glowA}, transparent 45%),
			radial-gradient(circle at ${bx}% 75%, ${p.glowB}, transparent 50%), ${p.base}`}}>
			{p.children}
		</AbsoluteFill>
	);
};
