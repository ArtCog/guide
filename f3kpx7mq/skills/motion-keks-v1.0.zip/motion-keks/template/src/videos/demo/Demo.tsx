import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Backdrop, useAppear} from '../../lib';

// Smoke test of the studio: renders without any files. Real videos live next to it in src/videos/<slug>/
// and take their images, voice.mp3 and words.json from public/<slug>/ (Cutout, wordFrame, <Audio>).
export const Demo = () => {
	const frame = useCurrentFrame();
	const k = useAppear(10);
	return (
		<Backdrop base="#0b1020" glowA="#2b4cff55" glowB="#00d1b244">
			<AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
				<div style={{fontFamily: 'Arial', fontWeight: 800, fontSize: 140, color: 'white',
					transform: `translateY(${(1 - k) * 60}px)`, opacity: k,
					letterSpacing: interpolate(frame, [0, 150], [2, 8])}}>
					motion-keks
				</div>
			</AbsoluteFill>
		</Backdrop>
	);
};
