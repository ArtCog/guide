"""List ElevenLabs voices with free preview links.

python voices.py mine                      voices in the account («My Voices»)
python voices.py library --lang ru [--n 12] shared library filtered by language
python voices.py add <public_owner_id> <voice_id> <name>   add a library voice to «My Voices»
"""
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

from _env import load, need

KEY = need(load(), "ELEVENLABS_API_KEY")
API = "https://api.elevenlabs.io"


def call(path, method="GET", body=None):
    req = urllib.request.Request(API + path, method=method, data=json.dumps(body).encode() if body else None,
                                 headers={"xi-api-key": KEY, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise SystemExit(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:400]}")


cmd = sys.argv[1] if len(sys.argv) > 1 else "mine"
if cmd == "mine":
    for v in call("/v1/voices").get("voices", []):
        labels = ", ".join(f"{k}: {x}" for k, x in (v.get("labels") or {}).items())
        print(f"{v['name']} | id {v['voice_id']} | {v.get('category', '')} | {labels}\n  preview: {v.get('preview_url')}")
elif cmd == "library":
    lang = sys.argv[sys.argv.index("--lang") + 1] if "--lang" in sys.argv else "ru"
    n = sys.argv[sys.argv.index("--n") + 1] if "--n" in sys.argv else "12"
    q = urllib.parse.urlencode({"language": lang, "page_size": n, "sort": "trending"})
    for v in call(f"/v1/shared-voices?{q}").get("voices", []):
        print(f"{v['name']} | id {v['voice_id']} | owner {v.get('public_owner_id')} | {v.get('gender', '')}, "
              f"{v.get('age', '')}, {v.get('use_case', '')} | {(v.get('description') or '')[:90]}\n"
              f"  preview: {v.get('preview_url')}")
elif cmd == "add":
    owner, voice_id, name = sys.argv[2], sys.argv[3], sys.argv[4]
    print(call(f"/v1/voices/add/{owner}/{voice_id}", "POST", {"new_name": name}))
