"""Check the keys in .env without ever printing them.

python keys.py image   image key: filled, on the right line, accepted by the service
python keys.py voice   ElevenLabs key: filled, accepted, has the rights the skill needs
"""
import sys
import urllib.error
import urllib.request

from _env import ENV_FILE, load


def get(url, headers):
    req = urllib.request.Request(url, headers={"User-Agent": "motion-keks", **headers})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


values = load()
image_key = values.get("IMAGE_API_KEY", "")
voice_key = values.get("ELEVENLABS_API_KEY", "")

if sys.argv[1:] == ["image"]:
    if not image_key:
        if voice_key and not voice_key.startswith("sk_"):
            raise SystemExit("WRONG LINE: IMAGE_API_KEY is empty and the key sits in ELEVENLABS_API_KEY. "
                             f"Move it to the line IMAGE_API_KEY= in {ENV_FILE} and save.")
        raise SystemExit(f"EMPTY: IMAGE_API_KEY has no key in {ENV_FILE}. Paste it right after = and save the file.")
    base = values.get("IMAGE_BASE_URL", "").rstrip("/")
    code, _ = get(f"{base}/models", {"Authorization": f"Bearer {image_key}"})
    if code != 200:
        raise SystemExit(f"REFUSED: {base} answered HTTP {code}. Check that the whole key was copied.")
    print("image key OK")
elif sys.argv[1:] == ["voice"]:
    if not voice_key:
        raise SystemExit(f"EMPTY: ELEVENLABS_API_KEY has no key in {ENV_FILE}. Paste it right after = and save the file.")
    code, body = get("https://api.elevenlabs.io/v1/voices", {"xi-api-key": voice_key})
    if "voices_read" in body:
        raise SystemExit("NO RIGHTS: the ElevenLabs key cannot read voices. In ElevenLabs open Developers, API Keys "
                         "and turn on Text to Speech, Voices (read) and Models (read).")
    if code != 200:
        raise SystemExit(f"REFUSED: ElevenLabs answered HTTP {code}. Check that the whole key was copied.")
    print("voice key OK")
else:
    raise SystemExit(__doc__)
