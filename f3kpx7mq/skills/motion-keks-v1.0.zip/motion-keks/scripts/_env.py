"""Read the skill's .env (next to SKILL.md). Keys are never printed."""
import os
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = SKILL_DIR / ".env"


def load() -> dict:
    values = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            name, value = line.split("=", 1)
            values[name.strip()] = value.strip().strip('"').strip("'")
    for name, value in os.environ.items():
        if name in ("IMAGE_BASE_URL", "IMAGE_API_KEY", "ELEVENLABS_API_KEY") and value:
            values.setdefault(name, value)
    return values


def need(values: dict, name: str) -> str:
    value = values.get(name, "")
    if not value:
        raise SystemExit(f"{name} is empty: paste it into {ENV_FILE} (never into the chat)")
    return value
