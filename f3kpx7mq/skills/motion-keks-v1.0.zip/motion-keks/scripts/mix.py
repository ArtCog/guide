"""Final sound: voice on top, music and effects pushed down automatically while the voice speaks.

python mix.py <video.mp4> <voice.mp3> <fx.wav> <out.mp4>
fx.wav is the composition rendered without the voice (--props '{"fxOnly":true}' --codec=wav).
"""
import subprocess
import sys

video, voice, fx, out = sys.argv[1:5]
graph = ("[1:a]aresample=48000,aformat=channel_layouts=stereo,asplit=2[key][v];"
         "[2:a]aresample=48000,aformat=channel_layouts=stereo[fx];"
         "[fx][key]sidechaincompress=threshold=0.02:ratio=10:attack=5:release=300[ducked];"
         "[v][ducked]amix=inputs=2:normalize=0:duration=longest,"
         "loudnorm=I=-15:TP=-1.5:LRA=11,aresample=48000[a]")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", video, "-i", voice, "-i", fx, "-filter_complex", graph,
                "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", out], check=True)
print(f"saved {out}")
