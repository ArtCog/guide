"""Generate one cut-out image (transparent PNG) through an OpenAI-compatible images API (LLM Router, OpenAI).

python image.py "<prompt>" out.png [--ref photo.png] [--model gpt-image-2.5] [--size 1024x1024] [--quality high]
"""
import argparse
import base64
import json
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

from _env import load, need

p = argparse.ArgumentParser()
p.add_argument("prompt")
p.add_argument("out")
p.add_argument("--ref", help="user's own picture: the same object comes back cut out")
p.add_argument("--model", default="gpt-image-2.5")
p.add_argument("--size", default="1024x1024")
p.add_argument("--quality", default="high")
a = p.parse_args()

env = load()
base = env.get("IMAGE_BASE_URL", "https://llm-router.org/v1").rstrip("/")
key = need(env, "IMAGE_API_KEY")
prompt = a.prompt + ". Single isolated object, transparent background, no ground shadow, no frame."
fields = {"model": a.model, "prompt": prompt, "n": "1", "size": a.size, "quality": a.quality,
          "background": "transparent", "output_format": "png", "response_format": "b64_json"}

if a.ref:
    boundary = uuid.uuid4().hex
    parts = []
    for k, v in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    ref = Path(a.ref)
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{ref.name}"\r\n'
                 f"Content-Type: image/png\r\n\r\n".encode() + ref.read_bytes() + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(base + "/images/edits", data=b"".join(parts), method="POST",
                                 headers={"Authorization": f"Bearer {key}",
                                          "Content-Type": f"multipart/form-data; boundary={boundary}"})
else:
    req = urllib.request.Request(base + "/images/generations", data=json.dumps(fields).encode(), method="POST",
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})

t0 = time.time()
data = {}
for wait in (30, 60, 120, 180, 0):  # the image service sometimes drops out for a while
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            data = json.loads(r.read())
        break
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:500]
        if e.code not in (429, 500, 502, 503, 504):
            raise SystemExit(f"HTTP {e.code}: {body}")
        if not wait:
            raise SystemExit(f"SERVICE DOWN: HTTP {e.code} after 5 tries over 6 minutes, nothing was charged. {body}")
        print(f"HTTP {e.code}, the service is not answering, next try in {wait} s", flush=True)
        time.sleep(wait)

out = Path(a.out)
out.parent.mkdir(parents=True, exist_ok=True)
out.write_bytes(base64.b64decode(data["data"][0]["b64_json"]))

try:  # the object comes back ~99 % opaque; make it solid so nothing shows through
    from PIL import Image
    im = Image.open(out).convert("RGBA")
    alpha = im.getchannel("A").point([v if v < 240 else 255 for v in range(256)])
    im.putalpha(alpha)
    im.save(out)
    note = f"{im.size[0]}x{im.size[1]} RGBA"
except ImportError:
    note = "Pillow not installed: alpha left as is"
print(f"saved {out} ({note}) in {time.time() - t0:.0f} s, model {a.model}")
