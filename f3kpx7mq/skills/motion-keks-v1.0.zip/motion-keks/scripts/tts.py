"""Voice the whole script in one take with ElevenLabs and save word timings.

python tts.py <voice_id> <text.txt> <out_dir> [--model eleven_v4]
Writes <out_dir>/voice.mp3 and <out_dir>/words.json: [{"word", "start", "end"}] in seconds.
"""
import base64
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

from _env import load, need

KEY = need(load(), "ELEVENLABS_API_KEY")
API = "https://api.elevenlabs.io"
voice_id, text_file, out_dir = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
wanted = sys.argv[sys.argv.index("--model") + 1] if "--model" in sys.argv else "eleven_v4"
text = text_file.read_text(encoding="utf-8").strip()


def call(path, body=None):
    req = urllib.request.Request(API + path, method="POST" if body else "GET",
                                 data=json.dumps(body).encode() if body else None,
                                 headers={"xi-api-key": KEY, "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=300) as r:
        return json.loads(r.read()), dict(r.headers)


try:
    models = [m["model_id"] for m in call("/v1/models")[0] if m.get("can_do_text_to_speech")]
except urllib.error.HTTPError:  # key without models_read: just try the wanted model
    models = [wanted]
order = [wanted, "eleven_v3", "eleven_multilingual_v2"]
model = next((m for m in order if m in models), models[0])
if model != wanted:
    print(f"{wanted} not available on this account, using {model}")

try:
    data, headers = call(f"/v1/text-to-speech/{voice_id}/with-timestamps?output_format=mp3_44100_128",
                         {"text": text, "model_id": model})
except urllib.error.HTTPError as e:
    body = e.read().decode('utf-8', 'replace')[:400]
    hint = "Free ElevenLabs plan: library voices need a paid plan (Starter), built-in voices work." \
        if "paid_plan_required" in body else ""
    raise SystemExit(f"HTTP {e.code}: {body}\n{hint}")

out_dir.mkdir(parents=True, exist_ok=True)
(out_dir / "voice.mp3").write_bytes(base64.b64decode(data["audio_base64"]))

al = data.get("alignment") or data.get("normalized_alignment")
words, cur, start, end = [], "", 0.0, 0.0
for ch, s, e in zip(al["characters"], al["character_start_times_seconds"], al["character_end_times_seconds"]):
    if ch.isspace():
        if cur:
            words.append({"word": cur, "start": round(start, 3), "end": round(end, 3)})
        cur = ""
        continue
    if not cur:
        start = float(s)
    cur, end = cur + ch, float(e)
if cur:
    words.append({"word": cur, "start": round(start, 3), "end": round(end, 3)})
(out_dir / "words.json").write_text(json.dumps(words, ensure_ascii=False, indent=1), encoding="utf-8")

cost = headers.get("character-cost") or headers.get("x-character-count") or "see ElevenLabs usage"
print(f"voice.mp3 + words.json ({len(words)} words, {words[-1]['end']:.1f} s) in {out_dir}; model {model}; "
      f"credits: {cost}")
